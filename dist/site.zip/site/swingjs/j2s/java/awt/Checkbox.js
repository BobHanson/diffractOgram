(function(){var P$=Clazz.newPackage("java.awt");
/*c*/var C$=Clazz.newClass(P$, "Checkbox", null, 'swingjs.a2s.Checkbox');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (label) {
;C$.superclazz.c$$S.apply(this,[label]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z',  function (label, state) {
;C$.superclazz.c$$S$Z.apply(this,[label, state]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$Z$java_awt_CheckboxGroup',  function (label, state, group) {
;C$.superclazz.c$$S$Z$java_awt_CheckboxGroup.apply(this,[label, state, group]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$java_awt_CheckboxGroup$Z',  function (label, group, state) {
;C$.superclazz.c$$S$Z$java_awt_CheckboxGroup.apply(this,[label, state, group]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-13 09:09:45 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
