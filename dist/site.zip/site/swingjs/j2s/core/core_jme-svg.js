(function(Clazz,Clazz_setTVer,Clazz_toLong,Clazz_incrAN,Clazz_array,Clazz_assert,Clazz_clone,Clazz_exceptionOf,Clazz_forName,Clazz_getClass,Clazz_instanceOf,Clazz_load,Clazz_new_,Clazz_newClass,Clazz_newEnumConst,Clazz_newInstance,Clazz_newInterface,Clazz_newMeth,Clazz_newPackage,Clazz_super_){(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.DepictorTransformation','java.util.ArrayList','com.actelion.research.gui.generic.GenericPoint','com.actelion.research.util.ColorHelper','java.awt.Color',['com.actelion.research.chem.AbstractDepictor','.DepictorLine'],'com.actelion.research.gui.editor.AtomQueryFeatureDialogBuilder','StringBuilder','java.util.Arrays',['com.actelion.research.chem.AbstractDepictor','.DepictorDot'],'com.actelion.research.gui.generic.GenericPolygon']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "AbstractDepictor", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['DepictorDot',9],['DepictorLine',9]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.mBoundingRect=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['Z',['mIsValidatingView'],'D',['mpBondSpacing','mpDotDiameter','mpLineWidth','mpQFDiameter','mpBondHiliteRadius','mFactorTextSize','mpExcludeGroupRadius','mChiralTextSize'],'I',['mpLabelSize','mStandardForegroundColor','mDisplayMode','mCurrentColor','mPreviousColor','mOverruleForeground','mOverruleBackground','mBondBGHiliteColor','mBondFGHiliteColor','mExcludeGroupFGColor','mExcludeGroupBGColor','mCustomForeground','mCustomBackground','mRGBColor'],'O',['mAtomIsConnected','boolean[]','+mAtomLabelDisplayed','mpTabuZone','java.util.ArrayList','+mpDot','mMol','com.actelion.research.chem.StereoMolecule','mBoundingRect','com.actelion.research.gui.generic.GenericRectangle','mTransformation','com.actelion.research.chem.DepictorTransformation','mChiralTextLocation','com.actelion.research.gui.generic.GenericPoint','mAtomColor','int[]','+mAtomHiliteColor','mAtomHiliteRadius','float[]','mAtomText','String[]','mAlternativeCoords','com.actelion.research.gui.generic.GenericPoint[]','mContext','<T>']]
,['O',['ATOM_LABEL_COLOR','int[]']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, 0]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, displayMode) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mDisplayMode=displayMode;
this.init$();
}, 1);

Clazz_newMeth(C$, 'setDisplayMode$I',  function (displayMode) {
this.mDisplayMode=displayMode;
});

Clazz_newMeth(C$, 'setAtomText$SA',  function (atomText) {
this.mAtomText=atomText;
});

Clazz_newMeth(C$, 'setForegroundColor$java_awt_Color$java_awt_Color',  function (foreground, background) {
this.setForegroundColor$I$I(foreground == null  ? 0 : foreground.getRGB$(), background == null  ? 0 : background.getRGB$());
});

Clazz_newMeth(C$, 'setForegroundColor$I$I',  function (foreground, background) {
this.mStandardForegroundColor=-6;
this.mCustomForeground=foreground;
this.mCustomBackground=background;
p$1.updateBondHiliteColor.apply(this, []);
});

Clazz_newMeth(C$, 'setOverruleColor$java_awt_Color$java_awt_Color',  function (foreground, background) {
this.setOverruleColor$I$I(foreground == null  ? 0 : foreground.getRGB$(), background == null  ? 0 : background.getRGB$());
});

Clazz_newMeth(C$, 'setOverruleColor$I$I',  function (foreground, background) {
this.mOverruleForeground=foreground;
this.mOverruleBackground=background;
p$1.updateBondHiliteColor.apply(this, []);
});

Clazz_newMeth(C$, 'setAtomHighlightColors$IA$FA',  function (argb, radius) {
this.mAtomHiliteColor=argb;
this.mAtomHiliteRadius=radius;
});

Clazz_newMeth(C$, 'setTransformation$com_actelion_research_chem_DepictorTransformation',  function (t) {
this.mTransformation=t;
});

Clazz_newMeth(C$, 'setFactorTextSize$D',  function (factor) {
this.mFactorTextSize=factor;
});

Clazz_newMeth(C$, 'getTransformation$',  function () {
return this.mTransformation;
});

Clazz_newMeth(C$, 'applyTransformation$com_actelion_research_chem_DepictorTransformation',  function (t) {
t.applyTo$com_actelion_research_chem_DepictorTransformation(this.mTransformation);
t.applyTo$com_actelion_research_gui_generic_GenericRectangle(this.mBoundingRect);
t.applyTo$com_actelion_research_gui_generic_GenericPoint(this.mChiralTextLocation);
});

Clazz_newMeth(C$, 'updateCoords$O$com_actelion_research_gui_generic_GenericRectangle$I',  function (context, viewRect, mode) {
this.validateView$O$com_actelion_research_gui_generic_GenericRectangle$I(context, viewRect, mode);
if (this.mTransformation.isVoidTransformation$()) {
return null;
} else {
var t=this.mTransformation;
this.mTransformation.applyTo$com_actelion_research_chem_Molecule(this.mMol);
this.mTransformation=Clazz_new_($I$(2,1));
return t;
}});

Clazz_newMeth(C$, 'simpleUpdateCoords$com_actelion_research_gui_generic_GenericRectangle$I',  function (viewRect, mode) {
this.simpleValidateView$com_actelion_research_gui_generic_GenericRectangle$I(viewRect, mode);
if (this.mTransformation.isVoidTransformation$()) {
return null;
} else {
var t=this.mTransformation;
this.mTransformation.applyTo$com_actelion_research_chem_Molecule(this.mMol);
this.mTransformation=Clazz_new_($I$(2,1));
return t;
}});

Clazz_newMeth(C$, 'getMolecule$',  function () {
return this.mMol;
});

Clazz_newMeth(C$, 'validateView$O$com_actelion_research_gui_generic_GenericRectangle$I',  function (context, viewRect, mode) {
if (this.mMol.getAllAtoms$() == 0) return null;
var t1=this.simpleValidateView$com_actelion_research_gui_generic_GenericRectangle$I(viewRect, mode);
this.mMol.ensureHelperArrays$I(p$1.requiredHelperArrays.apply(this, []));
p$1.markIsolatedAtoms.apply(this, []);
this.mpDot.clear$();
this.mpTabuZone.clear$();
this.mContext=context;
p$1.calculateParameters.apply(this, []);
p$1.mpSetNormalLabelSize.apply(this, []);
this.mIsValidatingView=true;
for (var i=0; i < this.mMol.getAllAtoms$(); i++) p$1.mpDrawAtom$I$IAA.apply(this, [i, null]);

this.mIsValidatingView=false;
var avbl=this.mTransformation.getScaling$() * this.mMol.getAverageBondLength$();
p$1.expandBoundsByTabuZones$D.apply(this, [avbl]);
p$1.setChiralTextLocation$com_actelion_research_gui_generic_GenericRectangle$D$I.apply(this, [viewRect, avbl, mode]);
if (viewRect == null  || viewRect.contains$com_actelion_research_gui_generic_GenericRectangle(this.mBoundingRect) ) return t1;
var t2=Clazz_new_($I$(2,1).c$$com_actelion_research_gui_generic_GenericRectangle$com_actelion_research_gui_generic_GenericRectangle$D$I,[this.mBoundingRect, viewRect, avbl, mode]);
t2.applyTo$com_actelion_research_chem_DepictorTransformation(this.mTransformation);
t2.applyTo$com_actelion_research_gui_generic_GenericRectangle(this.mBoundingRect);
t2.applyTo$com_actelion_research_gui_generic_GenericPoint(this.mChiralTextLocation);
if (t1 == null ) return t2;
t2.applyTo$com_actelion_research_chem_DepictorTransformation(t1);
return t1;
});

Clazz_newMeth(C$, 'simpleValidateView$com_actelion_research_gui_generic_GenericRectangle$I',  function (viewRect, mode) {
if (this.mMol.getAllAtoms$() == 0) return null;
this.mBoundingRect=this.simpleCalculateBounds$();
var avbl=this.mTransformation.getScaling$() * this.mMol.getAverageBondLength$();
var t=Clazz_new_($I$(2,1).c$$com_actelion_research_gui_generic_GenericRectangle$com_actelion_research_gui_generic_GenericRectangle$D$I,[this.mBoundingRect, viewRect, avbl, mode]);
if (t.isVoidTransformation$()) {
t=null;
} else {
t.applyTo$com_actelion_research_chem_DepictorTransformation(this.mTransformation);
t.applyTo$com_actelion_research_gui_generic_GenericRectangle(this.mBoundingRect);
}p$1.setChiralTextLocation$com_actelion_research_gui_generic_GenericRectangle$D$I.apply(this, [viewRect, avbl, mode]);
return t;
});

Clazz_newMeth(C$, 'onDrawBond$I$D$D$D$D',  function (bond, x1, y1, x2, y2) {
});

Clazz_newMeth(C$, 'onDrawAtom$I$S$D$D',  function (atom, symbol, x, y) {
});

Clazz_newMeth(C$, 'simpleCalculateBounds$',  function () {
var minx=this.getAtomX$I(0);
var maxx=this.getAtomX$I(0);
var miny=this.getAtomY$I(0);
var maxy=this.getAtomY$I(0);
for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
if (minx > this.getAtomX$I(i) ) minx=this.getAtomX$I(i);
if (maxx < this.getAtomX$I(i) ) maxx=this.getAtomX$I(i);
if (miny > this.getAtomY$I(i) ) miny=this.getAtomY$I(i);
if (maxy < this.getAtomY$I(i) ) maxy=this.getAtomY$I(i);
}
return Clazz_new_($I$(1,1).c$$D$D$D$D,[minx, miny, maxx - minx, maxy - miny]);
});

Clazz_newMeth(C$, 'expandBoundsByTabuZones$D',  function (avbl) {
for (var i=0; i < this.mpTabuZone.size$(); i++) this.mBoundingRect=this.mBoundingRect.union$com_actelion_research_gui_generic_GenericRectangle(this.mpTabuZone.get$I(i));

p$1.expandByHiliteBackgrounds$D.apply(this, [avbl]);
var border=0.1 * avbl;
this.mBoundingRect.x-=border;
this.mBoundingRect.y-=border;
this.mBoundingRect.width+=2.0 * border;
this.mBoundingRect.height+=2.0 * border;
}, p$1);

Clazz_newMeth(C$, 'expandByHiliteBackgrounds$D',  function (avbl) {
var isAtomHilited=Clazz_array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
for (var i=0; i < this.mMol.getAllBonds$(); i++) {
if (this.mMol.isBondBackgroundHilited$I(i)) {
isAtomHilited[this.mMol.getBondAtom$I$I(0, i)]=true;
isAtomHilited[this.mMol.getBondAtom$I$I(1, i)]=true;
}}
var rect=Clazz_new_($I$(1,1));
for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
var radius=Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(i),536870912)),0 ) ? avbl * 0.47 : isAtomHilited[i] ? avbl * 0.38 : 0;
if (radius != 0 ) {
var x=this.mTransformation.transformX$D(this.mMol.getAtomX$I(i));
var y=this.mTransformation.transformY$D(this.mMol.getAtomY$I(i));
rect.set$D$D$D$D(x - radius, y - radius, radius * 2, radius * 2);
this.mBoundingRect=this.mBoundingRect.union$com_actelion_research_gui_generic_GenericRectangle(rect);
}}
}, p$1);

Clazz_newMeth(C$, 'setChiralTextLocation$com_actelion_research_gui_generic_GenericRectangle$D$I',  function (viewRect, avbl, mode) {
var spacing=avbl / 2.0;
switch (mode & 786432) {
case 786432:
if (viewRect != null ) {
this.mChiralTextLocation.x=viewRect.x + viewRect.width / 2.0;
this.mChiralTextLocation.y=viewRect.y + viewRect.height - spacing;
break;
}case 0:
this.mChiralTextLocation.x=this.mBoundingRect.x + this.mBoundingRect.width / 2.0;
this.mChiralTextLocation.y=this.mBoundingRect.y + this.mBoundingRect.height + spacing ;
if (viewRect != null  && this.mChiralTextLocation.y > viewRect.y + viewRect.height - spacing  ) this.mChiralTextLocation.y=viewRect.y + viewRect.height - spacing;
break;
case 524288:
if (viewRect != null ) {
this.mChiralTextLocation.x=viewRect.x + viewRect.width / 2.0;
this.mChiralTextLocation.y=viewRect.y + spacing;
break;
}case 262144:
this.mChiralTextLocation.x=this.mBoundingRect.x + this.mBoundingRect.width / 2.0;
this.mChiralTextLocation.y=this.mBoundingRect.y - spacing;
if (viewRect != null  && this.mChiralTextLocation.y < viewRect.y + spacing  ) this.mChiralTextLocation.y=viewRect.y + spacing;
break;
}
}, p$1);

Clazz_newMeth(C$, 'getAtomX$I',  function (atom) {
return this.mTransformation.transformX$D(this.mMol.getAtomX$I(atom));
});

Clazz_newMeth(C$, 'getAtomY$I',  function (atom) {
return this.mTransformation.transformY$D(this.mMol.getAtomY$I(atom));
});

Clazz_newMeth(C$, 'getBoundingRect$',  function () {
return this.mBoundingRect;
});

Clazz_newMeth(C$, 'init$',  function () {
this.mFactorTextSize=1.0;
this.mTransformation=Clazz_new_($I$(2,1));
this.mpTabuZone=Clazz_new_($I$(3,1));
this.mpDot=Clazz_new_($I$(3,1));
this.mAtomLabelDisplayed=Clazz_array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
this.mChiralTextLocation=Clazz_new_($I$(4,1));
this.mStandardForegroundColor=0;
this.mCurrentColor=-1;
p$1.updateBondHiliteColor.apply(this, []);
});

Clazz_newMeth(C$, 'updateBondHiliteColor',  function () {
var background=(this.mOverruleBackground != 0) ? this.mOverruleBackground : (this.mCustomBackground != 0) ? this.mCustomBackground : -1;
this.mBondBGHiliteColor=$I$(5).intermediateColor$I$I$F(background, -10706689, 0.3);
this.mBondFGHiliteColor=$I$(5).getContrastColor$I$I(-32768, background);
this.mExcludeGroupBGColor=-24321;
this.mExcludeGroupFGColor=-6291392;
}, p$1);

Clazz_newMeth(C$, 'calculateParameters',  function () {
var averageBondLength=this.mTransformation.getScaling$() * this.mMol.getAverageBondLength$();
this.mpLineWidth=averageBondLength * 0.06;
this.mpBondSpacing=averageBondLength * 0.15;
this.mpBondHiliteRadius=averageBondLength * 0.38;
this.mpExcludeGroupRadius=averageBondLength * 0.47;
this.mpLabelSize=((averageBondLength * this.mFactorTextSize * 0.6  + 0.5)|0);
this.mpDotDiameter=averageBondLength * 0.12;
this.mpQFDiameter=averageBondLength * 0.4;
this.mChiralTextSize=averageBondLength * 0.5 + 0.5;
}, p$1);

Clazz_newMeth(C$, 'paint$O',  function (context) {
if (this.mMol.getAllAtoms$() == 0) return;
this.mMol.ensureHelperArrays$I(p$1.requiredHelperArrays.apply(this, []));
this.mContext=context;
p$1.calculateParameters.apply(this, []);
var esrGroupMemberCount=this.mMol.getESRGroupMemberCounts$();
var explicitAtomColors=false;
this.mAtomColor=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
this.mAtomColor[atom]=this.mMol.getAtomColor$I(atom);
if (this.mAtomColor[atom] != 0) explicitAtomColors=true;
if (this.mMol.isSelectedAtom$I(atom)) this.mAtomColor[atom]=128;
if (this.mMol.getStereoProblem$I(atom) && (this.mDisplayMode & 2048) == 0 ) this.mAtomColor[atom]=256;
}
p$1.setColor_$I.apply(this, [-10]);
if (this.mAtomHiliteColor != null  && (this.mAtomHiliteColor.length >= this.mMol.getAtoms$()) ) this.hiliteAtomBackgrounds$IA$FA(this.mAtomHiliteColor, this.mAtomHiliteRadius);
p$1.hiliteExcludeGroups.apply(this, []);
p$1.hiliteBondBackgrounds.apply(this, []);
p$1.indicateQueryFeatures.apply(this, []);
p$1.addChiralInfo.apply(this, []);
p$1.mpSetNormalLabelSize.apply(this, []);
this.setLineWidth$D(this.mpLineWidth);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
p$1.markIsolatedAtoms.apply(this, []);
this.mpDot.clear$();
this.mpTabuZone.clear$();
if ((this.mDisplayMode & 1) != 0) {
p$1.mpDrawAllBonds$IAA.apply(this, [esrGroupMemberCount]);
p$1.mpDrawAllDots.apply(this, []);
p$1.mpDrawBondQueryFeatures.apply(this, []);
}for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
if (p$1.isHighlightedAtom$I.apply(this, [i])) {
p$1.setColor_$I.apply(this, [-3]);
p$1.mpDrawAtom$I$IAA.apply(this, [i, esrGroupMemberCount]);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
} else if (this.mAtomColor[i] != 0) {
p$1.setColor_$I.apply(this, [this.mAtomColor[i]]);
p$1.mpDrawAtom$I$IAA.apply(this, [i, esrGroupMemberCount]);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
} else if (!explicitAtomColors && this.mMol.getMoleculeColor$() != 1  && this.mMol.getAtomicNo$I(i) != 1  && this.mMol.getAtomicNo$I(i) != 6  && ((this.mDisplayMode & 1024) == 0)  && this.mMol.getAtomList$I(i) == null   && this.mMol.getAtomicNo$I(i) < C$.ATOM_LABEL_COLOR.length ) {
p$1.setRGBColor$I.apply(this, [p$1.getContrastColor$I$I.apply(this, [C$.ATOM_LABEL_COLOR[this.mMol.getAtomicNo$I(i)], i])]);
p$1.mpDrawAtom$I$IAA.apply(this, [i, esrGroupMemberCount]);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
} else {
p$1.mpDrawAtom$I$IAA.apply(this, [i, esrGroupMemberCount]);
}}
if ((this.mDisplayMode & 1) == 0) {
p$1.mpDrawAllDots.apply(this, []);
p$1.mpDrawBondQueryFeatures.apply(this, []);
p$1.mpDrawAllBonds$IAA.apply(this, [esrGroupMemberCount]);
}});

Clazz_newMeth(C$, 'getBackgroundColor$',  function () {
return Clazz_new_([this.getBackgroundRGB$()],$I$(6,1).c$$I);
});

Clazz_newMeth(C$, 'getBackgroundRGB$',  function () {
return this.mOverruleBackground != 0 ? this.mOverruleBackground : this.mCustomBackground != 0 ? this.mCustomBackground : -1;
});

Clazz_newMeth(C$, 'getContrastColor$I$I',  function (rgb, atom) {
var bg=(this.mOverruleBackground != 0) ? this.mOverruleBackground : (this.mAtomHiliteColor != null  && atom < this.mAtomHiliteColor.length  && (this.mAtomHiliteColor[atom] & -16777216) != 0 ) ? this.mAtomHiliteColor[atom] : (this.mCustomBackground != 0) ? this.mCustomBackground : -1;
return $I$(5).getContrastColor$I$I(rgb, bg);
}, p$1);

Clazz_newMeth(C$, 'isHighlightedAtom$I',  function (atom) {
if (this.mMol.getAllConnAtoms$I(atom) == 0) return false;
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) if (!this.mMol.isBondForegroundHilited$I(this.mMol.getConnBond$I$I(atom, i))) return false;

return true;
}, p$1);

Clazz_newMeth(C$, 'requiredHelperArrays',  function () {
return ((this.mDisplayMode & 256) != 0) ? 63 : ((this.mDisplayMode & 512) != 0) ? 95 : 31;
}, p$1);

Clazz_newMeth(C$, 'markIsolatedAtoms',  function () {
this.mAtomIsConnected=Clazz_array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
for (var bnd=0; bnd < this.mMol.getAllBonds$(); bnd++) {
this.mAtomIsConnected[this.mMol.getBondAtom$I$I(0, bnd)]=true;
this.mAtomIsConnected[this.mMol.getBondAtom$I$I(1, bnd)]=true;
}
}, p$1);

Clazz_newMeth(C$, 'addChiralInfo',  function () {
if ((this.mDisplayMode & 32) != 0) return;
var chiralText=this.mMol.getChiralText$();
if (chiralText != null ) {
if (this.mChiralTextLocation.x == 0.0  && this.mChiralTextLocation.y == 0.0  ) {
var avbl=this.mTransformation.getScaling$() * this.mMol.getAverageBondLength$();
this.mBoundingRect=this.simpleCalculateBounds$();
p$1.expandBoundsByTabuZones$D.apply(this, [avbl]);
p$1.setChiralTextLocation$com_actelion_research_gui_generic_GenericRectangle$D$I.apply(this, [null, avbl, 0]);
}this.setTextSize$I((this.mChiralTextSize|0));
if (this.mMol.getMoleculeColor$() != 1) p$1.setColor_$I.apply(this, [448]);
this.drawString$S$D$D(chiralText, this.mChiralTextLocation.x, this.mChiralTextLocation.y + 0.3 * this.mChiralTextSize);
}}, p$1);

Clazz_newMeth(C$, 'hiliteAtomBackgrounds$IA$FA',  function (argb, radius) {
var background=(this.mOverruleBackground != 0) ? this.mOverruleBackground : (this.mCustomBackground != 0) ? this.mCustomBackground : -1;
var avbl=this.mTransformation.getScaling$() * this.mMol.getAverageBondLength$();
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var alpha=(argb[atom] & -16777216) >>> 24;
if (alpha != 0) {
var rgb=argb[atom];
if (alpha != 255) rgb=$I$(5).intermediateColor$I$I$F(background, argb[atom], alpha / 255.0);
var r=(radius == null ) ? 0.5 * avbl : 0.6 * radius[atom] * avbl ;
this.setRGB$I(rgb);
this.fillCircle$D$D$D(this.getAtomX$I(atom) - r, this.getAtomY$I(atom) - r, 2 * r);
}}
});

Clazz_newMeth(C$, 'hiliteBondBackgrounds',  function () {
this.setLineWidth$D(2 * this.mpBondHiliteRadius);
var line=Clazz_new_($I$(7,1));
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
if (this.mMol.isBondBackgroundHilited$I(bond)) {
line.x1=this.getAtomX$I(atom1);
line.y1=this.getAtomY$I(atom1);
line.x2=this.getAtomX$I(atom2);
line.y2=this.getAtomY$I(atom2);
p$1.setColor_$I.apply(this, [-2]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(line);
}}
}, p$1);

Clazz_newMeth(C$, 'hiliteExcludeGroups',  function () {
if (this.mMol.isFragment$()) {
var radius=this.mpExcludeGroupRadius;
p$1.setColor_$I.apply(this, [-7]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),536870912)),0 )) this.fillCircle$D$D$D(this.getAtomX$I(atom) - radius, this.getAtomY$I(atom) - radius, 2 * radius);

this.setLineWidth$D(2.0 * this.mpExcludeGroupRadius);
var line=Clazz_new_($I$(7,1));
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom1),this.mMol.getAtomQueryFeatures$I(atom2) , 536870912 )),0 )) {
line.x1=this.getAtomX$I(atom1);
line.y1=this.getAtomY$I(atom1);
line.x2=this.getAtomX$I(atom2);
line.y2=this.getAtomY$I(atom2);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(line);
}}
}}, p$1);

Clazz_newMeth(C$, 'indicateQueryFeatures',  function () {
if (this.mMol.isFragment$()) {
p$1.setColor_$I.apply(this, [320]);
if (((this.mDisplayMode & 8) != 0)) for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),(Long.$not(536870912)))),0 )) this.fillCircle$D$D$D(this.getAtomX$I(atom) - this.mpQFDiameter / 2, this.getAtomY$I(atom) - this.mpQFDiameter / 2, this.mpQFDiameter);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondQueryFeatures$I(bond) != 0) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
this.fillCircle$D$D$D((this.getAtomX$I(atom1) + this.getAtomX$I(atom2) - this.mpQFDiameter) / 2, (this.getAtomY$I(atom1) + this.getAtomY$I(atom2) - this.mpQFDiameter) / 2, this.mpQFDiameter);
}}
}}, p$1);

Clazz_newMeth(C$, 'mpDrawAllBonds$IAA',  function (esrGroupMemberCount) {
var origColor=this.mStandardForegroundColor;
var origForeground=this.mCustomForeground;
if ((this.mDisplayMode & 16384) != 0) {
this.mStandardForegroundColor=-6;
this.mCustomForeground=-8355712;
p$1.setColor_$I.apply(this, [1]);
}this.mAlternativeCoords=Clazz_array($I$(4), [this.mMol.getAllAtoms$()]);
for (var i=0; i < this.mMol.getAllBonds$(); i++) if (this.mMol.getBondType$I(i) == 2 || this.mMol.getBondType$I(i) == 386  || this.mMol.getBondType$I(i) == 64 ) p$1.mpDrawBond$I.apply(this, [i]);

for (var i=0; i < this.mMol.getAllBonds$(); i++) if (this.mMol.getBondType$I(i) != 2 && this.mMol.getBondType$I(i) != 386  && this.mMol.getBondType$I(i) != 64 ) p$1.mpDrawBond$I.apply(this, [i]);

if ((this.mDisplayMode & 64) == 0) {
for (var i=0; i < this.mMol.getAllBonds$(); i++) {
if (this.mMol.getBondCIPParity$I(i) != 0) {
var cipStr=null;
if (this.mMol.getBondCIPParity$I(i) == 1 || this.mMol.getBondCIPParity$I(i) == 2 ) {
if (this.mMol.getBondOrder$I(i) == 2 || this.mMol.getBondESRType$I(i) == 0  || esrGroupMemberCount == null   || esrGroupMemberCount[this.mMol.getBondESRType$I(i)][this.mMol.getBondESRGroup$I(i)] > 1 ) {
if (this.mMol.getBondCIPParity$I(i) == 1) cipStr=(this.mMol.getBondOrder$I(i) == 2) ? "E" : this.mMol.isBondParityPseudo$I(i) ? "p" : "P";
 else cipStr=(this.mMol.getBondOrder$I(i) == 2) ? "Z" : this.mMol.isBondParityPseudo$I(i) ? "m" : "M";
}} else {
cipStr="?";
}if (cipStr != null ) {
p$1.mpSetSmallLabelSize.apply(this, []);
p$1.setColor_$I.apply(this, [this.mMol.isBondForegroundHilited$I(i) ? -3 : (this.mMol.getMoleculeColor$() == 1 || (this.mDisplayMode & 4096) != 0 ) ? this.mStandardForegroundColor : 448]);
var atom1=this.mMol.getBondAtom$I$I(0, i);
var atom2=this.mMol.getBondAtom$I$I(1, i);
var x=(this.getAtomX$I(atom1) + this.getAtomX$I(atom2)) / 2;
var y=(this.getAtomY$I(atom1) + this.getAtomY$I(atom2)) / 2;
var dx=(this.getAtomX$I(atom1) - this.getAtomX$I(atom2)) / 3;
var dy=(this.getAtomY$I(atom1) - this.getAtomY$I(atom2)) / 3;
p$1.mpDrawString$D$D$S$Z.apply(this, [x + dy, y - dx, cipStr, true]);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
p$1.mpSetNormalLabelSize.apply(this, []);
}}}
}if ((this.mDisplayMode & 4) != 0) {
p$1.mpSetSmallLabelSize.apply(this, []);
p$1.setColor_$I.apply(this, [384]);
for (var i=0; i < this.mMol.getAllBonds$(); i++) {
var atom1=this.mMol.getBondAtom$I$I(0, i);
var atom2=this.mMol.getBondAtom$I$I(1, i);
var type=this.mMol.isDelocalizedBond$I(i) ? "d" : this.mMol.isAromaticBond$I(i) ? "a" : "";
var x=(this.getAtomX$I(atom1) + this.getAtomX$I(atom2)) / 2;
var y=(this.getAtomY$I(atom1) + this.getAtomY$I(atom2)) / 2;
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, type + String.valueOf$I(i), true]);
}
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if ((this.mDisplayMode & 16384) != 0) {
this.mStandardForegroundColor=origColor;
this.mCustomForeground=origForeground;
}}, p$1);

Clazz_newMeth(C$, 'mpDrawBond$I',  function (bnd) {
var theLine=Clazz_new_($I$(7,1));
var aLine=Clazz_new_($I$(7,1));
var bLine=Clazz_new_($I$(7,1));
var piBondOffset=Clazz_new_($I$(4,1));
var nextBondOffset=Clazz_new_($I$(4,1));
var atom1=this.mMol.getBondAtom$I$I(0, bnd);
var atom2=this.mMol.getBondAtom$I$I(1, bnd);
this.onDrawBond$I$D$D$D$D(bnd, this.getAtomX$I(atom1), this.getAtomY$I(atom1), this.getAtomX$I(atom2), this.getAtomY$I(atom2));
if (!this.mMol.isSelectedAtom$I(atom1) && !this.mMol.isSelectedAtom$I(atom2) && Long.$ne((Long.$and((Long.$or(this.mMol.getAtomQueryFeatures$I(atom1),this.mMol.getAtomQueryFeatures$I(atom2))),536870912)),0 )  ) p$1.setColor_$I.apply(this, [-8]);
if (this.mAlternativeCoords[atom1] == null ) {
theLine.x1=this.getAtomX$I(atom1);
theLine.y1=this.getAtomY$I(atom1);
} else {
theLine.x1=this.mAlternativeCoords[atom1].x;
theLine.y1=this.mAlternativeCoords[atom1].y;
}if (this.mAlternativeCoords[atom2] == null ) {
theLine.x2=this.getAtomX$I(atom2);
theLine.y2=this.getAtomY$I(atom2);
} else {
theLine.x2=this.mAlternativeCoords[atom2].x;
theLine.y2=this.mAlternativeCoords[atom2].y;
}if ((this.mMol.getBondQueryFeatures$I(bnd) & 130560) != 0) {
p$1.mpHandleDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
p$1.setColor_$I.apply(this, [-9]);
return;
}var bondOrder=(this.mMol.getBondType$I(bnd) == 64) ? 0 : (this.mMol.getBondType$I(bnd) == 32) ? 1 : this.mMol.getBondOrder$I(bnd);
switch (bondOrder) {
case 1:
var bondType=this.mMol.getBondType$I(bnd);
if ((this.mDisplayMode & 128) != 0 && (bondType == 257 || bondType == 129 ) ) {
var stereoCenter=this.mMol.getBondAtom$I$I(0, bnd);
var esrType=this.mMol.getAtomESRType$I(stereoCenter);
if (esrType != 0) {
var esrGroup=this.mMol.getAtomESRGroup$I(stereoCenter);
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomESRType$I(atom) == esrType && this.mMol.getAtomESRGroup$I(atom) == esrGroup ) ++count;

if (count == 1) bondType=1;
}}switch (bondType) {
case 1:
p$1.mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
break;
case 257:
p$1.mpHandleWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
break;
case 129:
var xdiff=theLine.x2 - theLine.x1;
var ydiff=theLine.y2 - theLine.y1;
var color1;
var color2;
if (this.mMol.isBondForegroundHilited$I(this.mMol.getBond$I$I(atom1, atom2))) {
color1=-3;
color2=-3;
} else {
color1=this.mAtomColor[atom1];
color2=p$1.getESRColor$I.apply(this, [atom1]);
if (color1 == this.mMol.getAtomColor$I(atom1)) color1=color2;
}for (var i=2; i < 17; i+=2) {
aLine.x1=theLine.x1 + i * xdiff / 17 - i * ydiff / 128;
aLine.y1=theLine.y1 + i * ydiff / 17 + i * xdiff / 128;
aLine.x2=theLine.x1 + i * xdiff / 17 + i * ydiff / 128;
aLine.y2=theLine.y1 + i * ydiff / 17 - i * xdiff / 128;
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [aLine])) {
p$1.setColor_$I.apply(this, [(i < 9) ? color1 : color2]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(aLine);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}}
break;
case 32:
p$1.mpHandleShortDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
break;
}
break;
case 0:
case 2:
if ((this.mAtomLabelDisplayed[atom1] || this.mMol.getAtomPi$I(atom1) == 2 ) && (this.mAtomLabelDisplayed[atom2] || this.mMol.getAtomPi$I(atom2) == 2 ) && !this.mMol.isRingBond$I(bnd) && bondOrder == 2  ) {
if (!p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) break;
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
var xdiff=piBondOffset.x / 2;
var ydiff=piBondOffset.y / 2;
aLine.x1=theLine.x1 + xdiff;
aLine.y1=theLine.y1 + ydiff;
aLine.x2=theLine.x2 + xdiff;
aLine.y2=theLine.y2 + ydiff;
bLine.x1=theLine.x1 - xdiff;
bLine.y1=theLine.y1 - ydiff;
bLine.x2=theLine.x2 - xdiff;
bLine.y2=theLine.y2 - ydiff;
if (this.mMol.getBondType$I(bnd) == 386) p$1.mpMakeCrossBond$com_actelion_research_chem_AbstractDepictor_DepictorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [aLine, bLine]);
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atom1, atom2]);
if (bondOrder == 2) p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atom1, atom2]);
 else p$1.drawDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atom1, atom2]);
} else if ((this.mAtomLabelDisplayed[atom2] || this.mMol.getAtomPi$I(atom2) == 2 ) && bondOrder == 2 ) {
p$1.mpDBFromNonLabelToLabel$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$Z.apply(this, [theLine, bnd, false]);
} else if ((this.mAtomLabelDisplayed[atom1] || this.mMol.getAtomPi$I(atom1) == 2 ) && bondOrder == 2 ) {
p$1.mpDBFromNonLabelToLabel$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$Z.apply(this, [theLine, bnd, true]);
} else {
var side=this.mMol.mpPreferredSide$I(bnd);
if (side == 0) side=1;
aLine.x1=theLine.x1;
aLine.y1=theLine.y1;
aLine.x2=theLine.x2;
aLine.y2=theLine.y2;
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
if (side > 0) {
bLine.x1=theLine.x1 + piBondOffset.x;
bLine.y1=theLine.y1 + piBondOffset.y;
bLine.x2=theLine.x2 + piBondOffset.x;
bLine.y2=theLine.y2 + piBondOffset.y;
if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atom1, atom2, 1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atom1) > 1) ) {
bLine.x1+=nextBondOffset.x + piBondOffset.y;
bLine.y1+=nextBondOffset.y - piBondOffset.x;
}if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atom2, atom1, -1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atom2) > 1) ) {
bLine.x2+=nextBondOffset.x - piBondOffset.y;
bLine.y2+=nextBondOffset.y + piBondOffset.x;
}} else {
bLine.x1=theLine.x1 - piBondOffset.x;
bLine.y1=theLine.y1 - piBondOffset.y;
bLine.x2=theLine.x2 - piBondOffset.x;
bLine.y2=theLine.y2 - piBondOffset.y;
if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atom1, atom2, -1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atom1) > 1) ) {
bLine.x1+=nextBondOffset.x + piBondOffset.y;
bLine.y1+=nextBondOffset.y - piBondOffset.x;
}if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atom2, atom1, 1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atom2) > 1) ) {
bLine.x2+=nextBondOffset.x - piBondOffset.y;
bLine.y2+=nextBondOffset.y + piBondOffset.x;
}}if (this.mMol.getBondType$I(bnd) == 386) p$1.mpMakeCrossBond$com_actelion_research_chem_AbstractDepictor_DepictorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [aLine, bLine]);
p$1.mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atom1, atom2]);
if (bondOrder == 2) p$1.mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atom1, atom2]);
 else p$1.mpHandleDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atom1, atom2]);
}break;
case 3:
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) {
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, piBondOffset.x, piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, -piBondOffset.x, -piBondOffset.y, aLine]);
}break;
case 4:
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) {
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, 1.5 * piBondOffset.x, 1.5 * piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, 0.5 * piBondOffset.x, 0.5 * piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, -0.5 * piBondOffset.x, -0.5 * piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, -1.5 * piBondOffset.x, -1.5 * piBondOffset.y, aLine]);
}break;
case 5:
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) {
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, 2 * piBondOffset.x, 2 * piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, piBondOffset.x, piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, -piBondOffset.x, -piBondOffset.y, aLine]);
p$1.drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine, atom1, atom2, -2 * piBondOffset.x, -2 * piBondOffset.y, aLine]);
}break;
}
if (this.mCurrentColor == -8) p$1.setColor_$I.apply(this, [-9]);
}, p$1);

Clazz_newMeth(C$, 'drawOffsetLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I$D$D$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine, atom1, atom2, dx, dy, aLine) {
aLine.x1=theLine.x1 + dx;
aLine.y1=theLine.y1 + dy;
aLine.x2=theLine.x2 + dx;
aLine.y2=theLine.y2 + dy;
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atom1, atom2]);
}, p$1);

Clazz_newMeth(C$, 'mpDBFromNonLabelToLabel$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$Z',  function (theLine, bnd, inverted) {
var aLine=Clazz_new_($I$(7,1));
var bLine=Clazz_new_($I$(7,1));
var piBondOffset=Clazz_new_($I$(4,1));
var nextBondOffset=Clazz_new_($I$(4,1));
var atm1=this.mMol.getBondAtom$I$I(0, bnd);
var atm2=this.mMol.getBondAtom$I$I(1, bnd);
if (inverted) {
var td=theLine.x1;
theLine.x1=theLine.x2;
theLine.x2=td;
td=theLine.y1;
theLine.y1=theLine.y2;
theLine.y2=td;
var ti=atm1;
atm1=atm2;
atm2=ti;
}if (!p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) return;
if (this.mMol.isRingBond$I(bnd)) {
aLine.x1=theLine.x1;
aLine.y1=theLine.y1;
aLine.x2=theLine.x2;
aLine.y2=theLine.y2;
var side=(inverted) ? -this.mMol.mpPreferredSide$I(bnd) : this.mMol.mpPreferredSide$I(bnd);
if (side == 0) side=1;
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
if (side > 0) {
bLine.x1=theLine.x1 + piBondOffset.x;
bLine.y1=theLine.y1 + piBondOffset.y;
bLine.x2=theLine.x2 + piBondOffset.x;
bLine.y2=theLine.y2 + piBondOffset.y;
if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atm1, atm2, 1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atm1) > 1) ) {
bLine.x1+=nextBondOffset.x + piBondOffset.y;
bLine.y1+=nextBondOffset.y - piBondOffset.x;
}} else {
bLine.x1=theLine.x1 - piBondOffset.x;
bLine.y1=theLine.y1 - piBondOffset.y;
bLine.x2=theLine.x2 - piBondOffset.x;
bLine.y2=theLine.y2 - piBondOffset.y;
if (p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atm1, atm2, -1, nextBondOffset]) || (this.mMol.getConnAtoms$I(atm1) > 1) ) {
bLine.x1+=nextBondOffset.x + piBondOffset.y;
bLine.y1+=nextBondOffset.y - piBondOffset.x;
}}if (this.mMol.getBondType$I(bnd) == 386) p$1.mpMakeCrossBond$com_actelion_research_chem_AbstractDepictor_DepictorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [aLine, bLine]);
p$1.mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atm1, atm2]);
if (this.mMol.getBondType$I(bnd) == 64) p$1.mpHandleDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atm1, atm2]);
 else p$1.mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atm1, atm2]);
} else {
p$1.mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint.apply(this, [theLine.x2 - theLine.x1, theLine.y2 - theLine.y1, piBondOffset]);
var xdiff=piBondOffset.x / 2;
var ydiff=piBondOffset.y / 2;
var aLineIsInnerLine=false;
aLine.x1=theLine.x1 + xdiff;
aLine.y1=theLine.y1 + ydiff;
aLine.x2=theLine.x2 + xdiff;
aLine.y2=theLine.y2 + ydiff;
if (this.mMol.getConnAtoms$I(atm1) > 1) {
if (!p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atm1, atm2, 1, nextBondOffset])) {
this.mAlternativeCoords[atm1]=Clazz_new_($I$(4,1).c$$D$D,[aLine.x1, aLine.y1]);
} else {
aLine.x1+=nextBondOffset.x;
aLine.y1+=nextBondOffset.y;
if (this.mMol.getConnAtoms$I(atm1) == 2) {
if (nextBondOffset.x != 0  || nextBondOffset.y != 0  ) {
aLine.x1+=piBondOffset.y;
aLine.y1-=piBondOffset.x;
}}}}bLine.x1=theLine.x1 - xdiff;
bLine.y1=theLine.y1 - ydiff;
bLine.x2=theLine.x2 - xdiff;
bLine.y2=theLine.y2 - ydiff;
if (this.mMol.getConnAtoms$I(atm1) > 1) {
if (!p$1.mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint.apply(this, [atm1, atm2, 0, nextBondOffset])) {
this.mAlternativeCoords[atm1]=Clazz_new_($I$(4,1).c$$D$D,[bLine.x1, bLine.y1]);
aLineIsInnerLine=true;
} else {
bLine.x1+=nextBondOffset.x;
bLine.y1+=nextBondOffset.y;
if (this.mMol.getConnAtoms$I(atm1) == 2) {
if (nextBondOffset.x != 0  || nextBondOffset.y != 0  ) {
bLine.x1+=piBondOffset.y;
bLine.y1-=piBondOffset.x;
}}}}if (this.mMol.getBondType$I(bnd) == 386) p$1.mpMakeCrossBond$com_actelion_research_chem_AbstractDepictor_DepictorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [aLine, bLine]);
if (this.mMol.getBondType$I(bnd) == 64) {
if (aLineIsInnerLine) {
p$1.drawDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atm1, atm2]);
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atm1, atm2]);
} else {
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atm1, atm2]);
p$1.drawDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atm1, atm2]);
}} else {
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [aLine, atm1, atm2]);
p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [bLine, atm1, atm2]);
}}}, p$1);

Clazz_newMeth(C$, 'mpMakeCrossBond$com_actelion_research_chem_AbstractDepictor_DepictorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (aLine, bLine) {
var temp;
temp=aLine.x2;
aLine.x2=bLine.x2;
bLine.x2=temp;
temp=aLine.y2;
aLine.y2=bLine.y2;
bLine.y2=temp;
}, p$1);

Clazz_newMeth(C$, 'mpCalcPiBondOffset$D$D$com_actelion_research_gui_generic_GenericPoint',  function (dx, dy, piBondOffset) {
if (dx == 0 ) {
if (dy < 0 ) piBondOffset.x=this.mpBondSpacing;
 else piBondOffset.x=-this.mpBondSpacing;
piBondOffset.y=0;
return;
}var alpha=Math.atan(dy / dx);
if (dx < 0 ) alpha+=3.141592653589793;
piBondOffset.x=-(this.mpBondSpacing * Math.sin(alpha));
piBondOffset.y=(this.mpBondSpacing * Math.cos(alpha));
}, p$1);

Clazz_newMeth(C$, 'mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var endsExchanged;
var retval;
if (theLine.x1 == theLine.x2  && theLine.y1 == theLine.y2  ) {
for (var tabuZone, $tabuZone = this.mpTabuZone.iterator$(); $tabuZone.hasNext$()&&((tabuZone=($tabuZone.next$())),1);) if (tabuZone.contains$D$D(theLine.x1, theLine.y1)) return false;

return true;
}var theFrame=p$1.mpGetFrame$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
endsExchanged=false;
if (theLine.x1 > theLine.x2 ) {
p$1.mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
endsExchanged=true;
}for (var i=0; i < this.mpTabuZone.size$(); i++) {
var tabuZone=this.mpTabuZone.get$I(i);
if (tabuZone.x > theFrame.x + theFrame.width  || tabuZone.y > theFrame.y + theFrame.height   || theFrame.x > tabuZone.x + tabuZone.width   || theFrame.y > tabuZone.y + tabuZone.height  ) continue;
if (p$1.mpInTabuZone$D$D$I.apply(this, [theLine.x1, theLine.y1, i])) {
if (p$1.mpInTabuZone$D$D$I.apply(this, [theLine.x2, theLine.y2, i])) {
if (endsExchanged) p$1.mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
return false;
}p$1.mpShortenLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, 0, i]);
retval=p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
if (endsExchanged) p$1.mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
return retval;
}if (p$1.mpInTabuZone$D$D$I.apply(this, [theLine.x2, theLine.y2, i])) {
p$1.mpShortenLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, 1, i]);
retval=p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
if (endsExchanged) p$1.mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
return retval;
}}
if (endsExchanged) p$1.mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine]);
return true;
}, p$1);

Clazz_newMeth(C$, 'mpCalcNextBondOffset$I$I$I$com_actelion_research_gui_generic_GenericPoint',  function (atm1, atm2, side, nextBondOffset) {
var RO_LIMIT=2.617993878;
var LO_LIMIT=3.665191429;
var RI_LIMIT=0.523598776;
var LI_LIMIT=5.759586531;
var retval;
var i;
var remoteAtm;
var bnd;
var bondAngle;
var theBondAngle;
var testAngle;
var angleDiff;
var currentAngleDiff;
var distance;
retval=false;
nextBondOffset.x=0;
nextBondOffset.y=0;
if (side > 0) angleDiff=2.617993878;
 else angleDiff=3.665191429;
theBondAngle=this.mMol.getBondAngle$I$I(atm1, atm2);
for (i=0; i < this.mMol.getConnAtoms$I(atm1); i++) {
bnd=this.mMol.getConnBond$I$I(atm1, i);
bondAngle=theBondAngle;
if (this.mMol.getBondAtom$I$I(0, bnd) == atm1) remoteAtm=this.mMol.getBondAtom$I$I(1, bnd);
 else remoteAtm=this.mMol.getBondAtom$I$I(0, bnd);
if (remoteAtm == atm2) continue;
testAngle=this.mMol.getBondAngle$I$I(atm1, remoteAtm);
if (bondAngle < testAngle ) bondAngle+=6.283185307179586;
currentAngleDiff=bondAngle - testAngle;
if (side > 0) {
if (currentAngleDiff < 3.141592653589793 ) retval=true;
if (currentAngleDiff > 2.617993878 ) currentAngleDiff=2.617993878;
if (currentAngleDiff < 0.523598776 ) currentAngleDiff=0.523598776;
if (currentAngleDiff <= angleDiff ) {
angleDiff=currentAngleDiff;
distance=this.mpBondSpacing * Math.tan(angleDiff - 1.5707963267948966) / 2;
nextBondOffset.x=-(distance * Math.sin(bondAngle));
nextBondOffset.y=-(distance * Math.cos(bondAngle));
}} else {
if (currentAngleDiff >= 3.141592653589793 ) retval=true;
if (currentAngleDiff < 3.665191429 ) currentAngleDiff=3.665191429;
if (currentAngleDiff > 5.759586531 ) currentAngleDiff=5.759586531;
if (currentAngleDiff >= angleDiff ) {
angleDiff=currentAngleDiff;
distance=this.mpBondSpacing * Math.tan(4.712388981 - angleDiff) / 2;
nextBondOffset.x=-(distance * Math.sin(bondAngle));
nextBondOffset.y=-(distance * Math.cos(bondAngle));
}}}
return retval;
}, p$1);

Clazz_newMeth(C$, 'mpExchangeLineEnds$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var temp;
temp=theLine.x1;
theLine.x1=theLine.x2;
theLine.x2=temp;
temp=theLine.y1;
theLine.y1=theLine.y2;
theLine.y2=temp;
}, p$1);

Clazz_newMeth(C$, 'mpHandleLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atm1, atm2) {
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) p$1.drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atm1, atm2]);
}, p$1);

Clazz_newMeth(C$, 'mpHandleDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atm1, atm2) {
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) p$1.drawDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atm1, atm2]);
}, p$1);

Clazz_newMeth(C$, 'mpHandleShortDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atm1, atm2) {
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) p$1.drawShortDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atm1, atm2]);
}, p$1);

Clazz_newMeth(C$, 'mpHandleDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atm1, atm2) {
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theLine])) this.drawDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(theLine);
}, p$1);

Clazz_newMeth(C$, 'mpHandleWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (origWedge, atm1, atm2) {
var theWedge=Clazz_new_($I$(7,1));
if (origWedge.x1 == origWedge.x2  && origWedge.y1 == origWedge.y2  ) return;
theWedge.x1=origWedge.x1;
theWedge.y1=origWedge.y1;
theWedge.x2=origWedge.x2;
theWedge.y2=origWedge.y2;
var theFrame=p$1.mpGetFrame$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [theWedge]);
for (var i=0; i < this.mpTabuZone.size$(); i++) {
var tabuZone=this.mpTabuZone.get$I(i);
if (tabuZone.x > theFrame.x + theFrame.width  || tabuZone.y > theFrame.y + theFrame.height   || theFrame.x > tabuZone.x + tabuZone.width   || theFrame.y > tabuZone.y + tabuZone.height  ) continue;
if (p$1.mpInTabuZone$D$D$I.apply(this, [theWedge.x1, theWedge.y1, i])) {
if (p$1.mpInTabuZone$D$D$I.apply(this, [theWedge.x2, theWedge.y2, i])) return;
p$1.mpShortenLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theWedge, 0, i]);
p$1.mpHandleWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theWedge, atm1, atm2]);
return;
}if (p$1.mpInTabuZone$D$D$I.apply(this, [theWedge.x2, theWedge.y2, i])) {
p$1.mpShortenLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theWedge, 1, i]);
p$1.mpHandleWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theWedge, atm1, atm2]);
return;
}}
p$1.drawWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theWedge, atm1, atm2]);
}, p$1);

Clazz_newMeth(C$, 'mpGetFrame$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var theFrame=Clazz_new_($I$(1,1));
if (theLine.x1 <= theLine.x2 ) {
theFrame.x=theLine.x1;
theFrame.width=theLine.x2 - theLine.x1;
} else {
theFrame.x=theLine.x2;
theFrame.width=theLine.x1 - theLine.x2;
}if (theLine.y1 <= theLine.y2 ) {
theFrame.y=theLine.y1;
theFrame.height=theLine.y2 - theLine.y1;
} else {
theFrame.y=theLine.y2;
theFrame.height=theLine.y1 - theLine.y2;
}return theFrame;
}, p$1);

Clazz_newMeth(C$, 'mpInTabuZone$D$D$I',  function (x, y, tabuZoneNo) {
if ((this.mDisplayMode & 1) != 0) return false;
var tabuZone=this.mpTabuZone.get$I(tabuZoneNo);
return (x > tabuZone.x  && x < tabuZone.x + tabuZone.width   && y > tabuZone.y   && y < tabuZone.y + tabuZone.height  );
}, p$1);

Clazz_newMeth(C$, 'mpShortenLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, pointNo, tabuZoneNo) {
var x1;
var y1;
var x2;
var y2;
var dx;
var dy;
var tabuX;
var tabuY;
var sx;
var sy;
if (pointNo == 0) {
x1=theLine.x1;
y1=theLine.y1;
x2=theLine.x2;
y2=theLine.y2;
} else {
x1=theLine.x2;
y1=theLine.y2;
x2=theLine.x1;
y2=theLine.y1;
}var tabuZone=this.mpTabuZone.get$I(tabuZoneNo);
tabuX=(x2 > x1 ) ? tabuZone.x + tabuZone.width : tabuZone.x;
tabuY=(y2 > y1 ) ? tabuZone.y + tabuZone.height : tabuZone.y;
dx=x2 - x1;
dy=y2 - y1;
if (Math.abs(dx) > Math.abs(dy) ) {
if (y1 == y2 ) {
sx=tabuX;
sy=y1;
} else {
sx=x1 + dx * (tabuY - y1) / dy;
if ((x2 > x1 ) == (tabuX > sx ) ) {
sy=tabuY;
} else {
sx=tabuX;
sy=y1 + dy * (tabuX - x1) / dx;
}}} else {
if (x1 == x2 ) {
sx=x1;
sy=tabuY;
} else {
sy=y1 + dy * (tabuX - x1) / dx;
if ((y2 > y1 ) == (tabuY > sy ) ) {
sx=tabuX;
} else {
sx=x1 + dx * (tabuY - y1) / dy;
sy=tabuY;
}}}if (pointNo == 0) {
theLine.x1=sx;
theLine.y1=sy;
} else {
theLine.x2=sx;
theLine.y2=sy;
}}, p$1);

Clazz_newMeth(C$, 'mpDrawAtom$I$IAA',  function (atom, esrGroupMemberCount) {
var chax;
var chay;
var xdiff;
var ydiff;
var x;
var y;
if (!this.mIsValidatingView) this.onDrawAtom$I$S$D$D(atom, this.mMol.getAtomLabel$I(atom), this.getAtomX$I(atom), this.getAtomY$I(atom));
var propStr=null;
if (this.mMol.getAtomCharge$I(atom) != 0) {
var valStr=(Math.abs(this.mMol.getAtomCharge$I(atom)) == 1) ? "" : String.valueOf$I(Math.abs(this.mMol.getAtomCharge$I(atom)));
propStr=(this.mMol.getAtomCharge$I(atom) < 0) ? valStr + "-" : valStr + "+";
}if (this.mAtomText != null  && (atom < this.mAtomText.length)  && this.mAtomText[atom] != null   && this.mAtomText[atom].length$() > 0 ) propStr=p$1.append$S$S.apply(this, [propStr, this.mAtomText[atom]]);
var isoStr=null;
var queryFeatures=this.mMol.getAtomQueryFeatures$I(atom);
if (Long.$ne(queryFeatures,0 )) {
if (Long.$ne((Long.$and(queryFeatures,17592186044416)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "*"]);
if (Long.$ne((Long.$and(queryFeatures,35184372088832)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "!*"]);
if (Long.$ne((Long.$and(queryFeatures,70368744177664)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "ha"]);
 else if (Long.$ne((Long.$and(queryFeatures,2)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "a"]);
 else if (Long.$ne((Long.$and(queryFeatures,4)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "!a"]);
if (Long.$ne((Long.$and(queryFeatures,4096)),0 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "s"]);
if (Long.$ne((Long.$and(queryFeatures,1920)),0 )) {
var hydrogens=(Long.$and(queryFeatures,1920));
if (Long.$eq(hydrogens,1792 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h0"]);
 else if (Long.$eq(hydrogens,1664 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h1"]);
 else if (Long.$eq(hydrogens,1408 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h2"]);
 else if (Long.$eq(hydrogens,128 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h>0"]);
 else if (Long.$eq(hydrogens,384 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h>1"]);
 else if (Long.$eq(hydrogens,896 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h>2"]);
 else if (Long.$eq(hydrogens,1024 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h<3"]);
 else if (Long.$eq(hydrogens,1536 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "h<2"]);
}if (Long.$ne((Long.$and(queryFeatures,234881024)),0 )) {
var charge=(Long.$and(queryFeatures,234881024));
if (Long.$eq(charge,167772160 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "c0"]);
 else if (Long.$eq(charge,100663296 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "c+"]);
 else if (Long.$eq(charge,201326592 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "c-"]);
}if (Long.$ne((Long.$and(queryFeatures,114688)),0 )) {
var piElectrons=(Long.$and(queryFeatures,114688));
if (Long.$eq(piElectrons,98304 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "pi0"]);
 else if (Long.$eq(piElectrons,81920 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "pi1"]);
 else if (Long.$eq(piElectrons,49152 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "pi2"]);
 else if (Long.$eq(piElectrons,16384 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "pi>0"]);
}if (Long.$ne((Long.$and(queryFeatures,4063232)),0 )) {
var neighbours=(Long.$and(queryFeatures,4063232));
if (Long.$eq(neighbours,(3801088) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n1"]);
 else if (Long.$eq(neighbours,(3538944) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n2"]);
 else if (Long.$eq(neighbours,(3014656) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n3"]);
 else if (Long.$eq(neighbours,3145728 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n<3"]);
 else if (Long.$eq(neighbours,2097152 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n<4"]);
 else if (Long.$eq(neighbours,393216 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n>1"]);
 else if (Long.$eq(neighbours,917504 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n>2"]);
 else if (Long.$eq(neighbours,(1966080) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "n>3"]);
}if (Long.$ne((Long.$and(queryFeatures,17042430230528)),0 )) {
var eNegNeighbours=(Long.$and(queryFeatures,17042430230528));
if (Long.$eq(eNegNeighbours,(16492674416640) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e0"]);
 else if (Long.$eq(eNegNeighbours,(15942918602752) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e1"]);
 else if (Long.$eq(eNegNeighbours,(14843406974976) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e2"]);
 else if (Long.$eq(eNegNeighbours,(12644383719424) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e3"]);
 else if (Long.$eq(eNegNeighbours,(15393162788864) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e<2"]);
 else if (Long.$eq(eNegNeighbours,(13194139533312) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e<3"]);
 else if (Long.$eq(eNegNeighbours,8796093022208 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e<4"]);
 else if (Long.$eq(eNegNeighbours,549755813888 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e>0"]);
 else if (Long.$eq(eNegNeighbours,(1649267441664) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e>1"]);
 else if (Long.$eq(eNegNeighbours,(3848290697216) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e>2"]);
 else if (Long.$eq(eNegNeighbours,(8246337208320) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e>3"]);
 else if (Long.$eq(eNegNeighbours,(4947802324992) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e1-2"]);
 else if (Long.$eq(eNegNeighbours,(9345848836096) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e1-3"]);
 else if (Long.$eq(eNegNeighbours,(10445360463872) )) isoStr=p$1.append$S$S.apply(this, [isoStr, "e2-3"]);
}if (Long.$ne((Long.$and(queryFeatures,120)),0 )) {
var ringBonds=(Long.$and(queryFeatures,120));
if (Long.$eq(ringBonds,112 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "!r"]);
 else if (Long.$eq(ringBonds,8 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "r"]);
 else if (Long.$eq(ringBonds,96 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "rb<3"]);
 else if (Long.$eq(ringBonds,104 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "rb2"]);
 else if (Long.$eq(ringBonds,88 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "rb3"]);
 else if (Long.$eq(ringBonds,56 )) isoStr=p$1.append$S$S.apply(this, [isoStr, "rb4"]);
}if (Long.$ne((Long.$and(queryFeatures,29360128)),0 )) {
isoStr=p$1.append$S$S.apply(this, [isoStr, "r" + (Long.$s(Long.$sr((Long.$and(queryFeatures,29360128)),22)))]);
}if (Long.$ne((Long.$and(queryFeatures,545460846592)),0 )) {
isoStr=p$1.append$S$S.apply(this, [isoStr, p$1.createRingSizeText$J.apply(this, [queryFeatures])]);
}if (Long.$ne((Long.$and(queryFeatures,268435456)),0 )) {
isoStr=p$1.append$S$S.apply(this, [isoStr, "f"]);
}}if (this.mMol.getAtomMass$I(atom) != 0) {
isoStr=p$1.append$S$S.apply(this, [isoStr, String.valueOf$I(this.mMol.getAtomMass$I(atom))]);
}var unpairedElectrons=0;
if (this.mMol.getAtomRadical$I(atom) != 0) {
switch (this.mMol.getAtomRadical$I(atom)) {
case 16:
propStr=p$1.append$S$S.apply(this, [propStr, "|"]);
break;
case 32:
unpairedElectrons=1;
break;
case 48:
unpairedElectrons=2;
break;
}
}var cipStr=null;
if ((this.mDisplayMode & 64) == 0) {
if (this.mMol.isAtomConfigurationUnknown$I(atom)) cipStr="?";
 else if (this.mMol.getAtomCIPParity$I(atom) != 0) {
if (this.mMol.getAtomESRType$I(atom) == 0 || esrGroupMemberCount == null   || esrGroupMemberCount[this.mMol.getAtomESRType$I(atom)][this.mMol.getAtomESRGroup$I(atom)] > 1 ) {
if (this.mMol.getConnAtoms$I(atom) == 2) {
switch (this.mMol.getAtomCIPParity$I(atom)) {
case 2:
cipStr=this.mMol.isAtomParityPseudo$I(atom) ? "p" : "P";
break;
case 1:
cipStr=this.mMol.isAtomParityPseudo$I(atom) ? "m" : "M";
break;
default:
cipStr="*";
break;
}
} else {
switch (this.mMol.getAtomCIPParity$I(atom)) {
case 1:
cipStr=this.mMol.isAtomParityPseudo$I(atom) ? "r" : "R";
break;
case 2:
cipStr=this.mMol.isAtomParityPseudo$I(atom) ? "s" : "S";
break;
default:
cipStr="*";
break;
}
}}}}if ((this.mDisplayMode & 768) != 0) cipStr=p$1.append$S$S.apply(this, [cipStr, String.valueOf$I(this.mMol.getSymmetryRank$I(atom))]);
var mapStr=null;
if ((this.mDisplayMode & 16) != 0 && this.mMol.getAtomMapNo$I(atom) != 0 ) mapStr="" + this.mMol.getAtomMapNo$I(atom);
var esrStr=null;
if (this.mMol.getStereoBond$I(atom) != -1) {
var esrInfo=p$1.getESRTypeToDisplayAt$I.apply(this, [atom]);
if (esrInfo != -1) esrStr=(esrInfo == 0) ? "abs" : (((esrInfo & 255) == 1) ? "&" : "or") + (1 + (esrInfo >> 8));
}var hydrogensToAdd=0;
if ((this.mDisplayMode & 8192) == 0) {
if (this.mMol.isFragment$()) {
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),2048)),0 )) hydrogensToAdd=this.mMol.getImplicitHydrogens$I(atom);
} else {
if (this.mMol.getAtomicNo$I(atom) != 6 || this.mMol.getAtomMass$I(atom) != 0  || !this.mAtomIsConnected[atom]  || this.mMol.getAtomRadical$I(atom) != 0 ) hydrogensToAdd=this.mMol.getImplicitHydrogens$I(atom);
}}var largeIsoString=false;
var atomStr=this.mMol.getAtomCustomLabel$I(atom);
if (atomStr != null  && atomStr.startsWith$S("]") ) {
isoStr=p$1.append$S$S.apply(this, [atomStr.substring$I(1), isoStr]);
atomStr=null;
largeIsoString=true;
}if (atomStr != null ) {
hydrogensToAdd=0;
} else if (this.mMol.getAtomList$I(atom) != null ) {
var atmStart=(Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) ? "[!" : "[";
atomStr=atmStart + this.mMol.getAtomListString$I(atom) + "]" ;
if (atomStr.length$() > 5) atomStr=atmStart + this.mMol.getAtomList$I(atom).length + "]" ;
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),2048)),0 )) hydrogensToAdd=-1;
} else if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) {
atomStr="?";
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),2048)),0 )) hydrogensToAdd=-1;
} else if (this.mMol.getAtomicNo$I(atom) != 6 || propStr != null   || isoStr != null   || (hydrogensToAdd > 0)  || !this.mAtomIsConnected[atom] ) atomStr=this.mMol.getAtomLabel$I(atom);
var labelWidth=0.0;
if (!!(!this.mMol.isSelectedAtom$I(atom) & Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),536870912)),0 ))) p$1.setColor_$I.apply(this, [-8]);
if (atomStr != null ) {
labelWidth=this.getStringWidth$S(atomStr);
p$1.mpDrawString$D$D$S$Z.apply(this, [this.getAtomX$I(atom), this.getAtomY$I(atom), atomStr, true]);
this.mAtomLabelDisplayed[atom]=true;
} else if (p$1.mpAlleneCenter$I.apply(this, [atom])) p$1.mpDrawDot$D$D$I.apply(this, [this.getAtomX$I(atom), this.getAtomY$I(atom), atom]);
if (propStr != null ) {
p$1.mpSetSmallLabelSize.apply(this, []);
x=this.getAtomX$I(atom) + ((labelWidth + this.getStringWidth$S(propStr)) / 2.0 + 1);
y=this.getAtomY$I(atom) - (((this.getTextSize$() * 4 - 4)/8|0));
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, propStr, true]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if ((this.mDisplayMode & 2) != 0) isoStr=String.valueOf$I(atom);
if (isoStr != null ) {
if (largeIsoString) p$1.mpSetReducedLabelSize.apply(this, []);
 else p$1.mpSetSmallLabelSize.apply(this, []);
x=this.getAtomX$I(atom) - ((labelWidth + this.getStringWidth$S(isoStr)) / 2.0);
y=this.getAtomY$I(atom) - (((this.getTextSize$() * 4 - 4)/8|0));
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, isoStr, true]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if (cipStr != null ) {
p$1.mpSetSmallLabelSize.apply(this, []);
x=this.getAtomX$I(atom) - ((labelWidth + this.getStringWidth$S(cipStr)) / 2.0);
y=this.getAtomY$I(atom) + (((this.getTextSize$() * 4 + 4)/8|0));
var theColor=this.mCurrentColor;
if (this.mMol.getMoleculeColor$() != 1 && (this.mDisplayMode & 4096) == 0 ) p$1.setColor_$I.apply(this, [448]);
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, cipStr, false]);
p$1.setColor_$I.apply(this, [theColor]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if (mapStr != null ) {
p$1.mpSetSmallLabelSize.apply(this, []);
x=this.getAtomX$I(atom) + ((labelWidth + this.getStringWidth$S(mapStr)) / 2.0 + 1);
y=this.getAtomY$I(atom) + (((this.getTextSize$() * 4 + 4)/8|0));
var theColor=this.mCurrentColor;
p$1.setColor_$I.apply(this, [this.mMol.isAutoMappedAtom$I(atom) ? 384 : 448]);
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, mapStr, true]);
p$1.setColor_$I.apply(this, [theColor]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if (esrStr != null ) {
var angle=p$1.mpGetFreeSpaceAngle$I.apply(this, [atom]);
p$1.mpSetSmallLabelSize.apply(this, []);
x=this.getAtomX$I(atom) + 0.7 * this.getTextSize$() * Math.sin(angle) ;
y=this.getAtomY$I(atom) + 0.7 * this.getTextSize$() * Math.cos(angle) ;
var theColor=this.mCurrentColor;
if (!this.mIsValidatingView && this.mMol.getMoleculeColor$() != 1 ) p$1.setColor_$I.apply(this, [p$1.getESRColor$I.apply(this, [atom])]);
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, esrStr, false]);
p$1.setColor_$I.apply(this, [theColor]);
p$1.mpSetNormalLabelSize.apply(this, []);
}if (hydrogensToAdd == 0 && unpairedElectrons == 0 ) {
if (this.mCurrentColor == -8) p$1.setColor_$I.apply(this, [-9]);
return;
}var hindrance=Clazz_array(Double.TYPE, [4]);
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
var bnd=this.mMol.getConnBond$I$I(atom, i);
for (var j=0; j < 2; j++) {
if (this.mMol.getBondAtom$I$I(j, bnd) == atom) {
var theAngle=this.mMol.getBondAngle$I$I(this.mMol.getBondAtom$I$I(j, bnd), this.mMol.getBondAtom$I$I(1 - j, bnd));
if (theAngle < -1.5707963267948966 ) {
hindrance[0]-=(theAngle + 1.5707963267948966);
hindrance[3]+=(theAngle + 3.141592653589793);
} else if (theAngle < 0 ) {
hindrance[2]+=(theAngle + 1.5707963267948966);
hindrance[3]-=theAngle;
} else if (theAngle < 1.5707963267948966 ) {
hindrance[1]+=theAngle;
hindrance[2]+=(1.5707963267948966 - theAngle);
} else {
hindrance[0]+=(theAngle - 1.5707963267948966);
hindrance[1]+=(3.141592653589793 - theAngle);
}}}
}
if (this.mMol.getConnAtoms$I(atom) == 0) {
if (this.mMol.isElectronegative$I(atom)) hindrance[3]-=0.2;
 else hindrance[1]-=0.2;
} else hindrance[1]-=0.1;
if (propStr != null  || mapStr != null  ) hindrance[1]+=10;
if (isoStr != null  || cipStr != null  ) hindrance[3]+=10;
var hNoStr="";
if (hydrogensToAdd != 0) {
var hydrogenWidth=this.getStringWidth$S("H");
var hNoWidth=0.0;
var hHeight=this.getTextSize$();
if (hydrogensToAdd == -1) {
hNoStr="n";
p$1.mpSetSmallLabelSize.apply(this, []);
hNoWidth=this.getStringWidth$S(hNoStr);
} else if (hydrogensToAdd > 1) {
hNoStr=String.valueOf$I(hydrogensToAdd);
p$1.mpSetSmallLabelSize.apply(this, []);
hNoWidth=this.getStringWidth$S(hNoStr);
}if (hindrance[1] < 0.6  || hindrance[3] < 0.6  ) {
chay=this.getAtomY$I(atom);
if (hindrance[1] <= hindrance[3] ) {
hindrance[1]+=10;
chax=this.getAtomX$I(atom) + ((labelWidth + hydrogenWidth) / 2.0);
} else {
hindrance[3]+=10;
chax=this.getAtomX$I(atom) - ((labelWidth + hydrogenWidth) / 2.0) - hNoWidth ;
}} else {
chax=this.getAtomX$I(atom);
if (hindrance[0] < hindrance[2] ) {
hindrance[0]+=10;
chay=this.getAtomY$I(atom) - hHeight;
} else {
hindrance[2]+=10;
chay=this.getAtomY$I(atom) + hHeight;
}}if (hNoWidth > 0 ) {
x=chax + ((hydrogenWidth + hNoWidth) / 2.0);
y=chay + (((this.getTextSize$() * 4 + 4)/8|0));
p$1.mpDrawString$D$D$S$Z.apply(this, [x, y, hNoStr, true]);
p$1.mpSetNormalLabelSize.apply(this, []);
}p$1.mpDrawString$D$D$S$Z.apply(this, [chax, chay, "H", true]);
}var bestSide=0;
if (unpairedElectrons != 0) {
var minHindrance=50.0;
var counterHindrance=0.0;
for (var i=0; i < 4; i++) {
var counterSide=(i > 1) ? i - 2 : i + 2;
if (hindrance[i] < minHindrance ) {
bestSide=i;
minHindrance=hindrance[i];
counterHindrance=hindrance[counterSide];
} else if (hindrance[i] == minHindrance ) {
if (hindrance[counterSide] > counterHindrance ) {
bestSide=i;
counterHindrance=hindrance[counterSide];
}}}
switch (bestSide) {
case 0:
chax=this.getAtomX$I(atom);
chay=this.getAtomY$I(atom) - this.mpDotDiameter - labelWidth / 2 ;
break;
case 1:
chax=this.getAtomX$I(atom) + this.mpDotDiameter + labelWidth / 2 ;
chay=this.getAtomY$I(atom);
break;
case 2:
chax=this.getAtomX$I(atom);
chay=this.getAtomY$I(atom) + this.mpDotDiameter + labelWidth / 2 ;
break;
default:
chax=this.getAtomX$I(atom) - this.mpDotDiameter - labelWidth / 2 ;
chay=this.getAtomY$I(atom);
break;
}
if (unpairedElectrons == 1) {
p$1.mpDrawDot$D$D$I.apply(this, [chax, chay, atom]);
} else {
switch (bestSide) {
case 0:
xdiff=2 * this.mpDotDiameter;
ydiff=0;
chax-=this.mpDotDiameter;
break;
case 1:
xdiff=0;
ydiff=2 * this.mpDotDiameter;
chay-=this.mpDotDiameter;
break;
case 2:
xdiff=2 * this.mpDotDiameter;
ydiff=0;
chax-=this.mpDotDiameter;
break;
default:
xdiff=0;
ydiff=2 * this.mpDotDiameter;
chay-=this.mpDotDiameter;
break;
}
p$1.mpDrawDot$D$D$I.apply(this, [chax, chay, atom]);
p$1.mpDrawDot$D$D$I.apply(this, [chax + xdiff, chay + ydiff, atom]);
}}if (this.mCurrentColor == -8) p$1.setColor_$I.apply(this, [-9]);
}, p$1);

Clazz_newMeth(C$, 'createRingSizeText$J',  function (queryFeatures) {
(queryFeatures=Long.$and(queryFeatures,(545460846592)));
for (var i=0; i < $I$(8).RING_SIZE_VALUES.length; i++) if (Long.$eq(queryFeatures,$I$(8).RING_SIZE_VALUES[i] )) return $I$(8).RING_SIZE_SHORT_TEXT[i];

var customOption=Clazz_new_($I$(9,1).c$$S,["R"]);
if (Long.$ne((Long.$and(queryFeatures,4294967296)),0 )) customOption.append$S("0");
if (Long.$ne((Long.$and(queryFeatures,8589934592)),0 )) customOption.append$S("3");
if (Long.$ne((Long.$and(queryFeatures,17179869184)),0 )) customOption.append$S("4");
if (Long.$ne((Long.$and(queryFeatures,34359738368)),0 )) customOption.append$S("5");
if (Long.$ne((Long.$and(queryFeatures,68719476736)),0 )) customOption.append$S("6");
if (Long.$ne((Long.$and(queryFeatures,137438953472)),0 )) customOption.append$S("7");
if (Long.$ne((Long.$and(queryFeatures,274877906944)),0 )) customOption.append$S("8");
return customOption.toString();
}, p$1);

Clazz_newMeth(C$, 'mpSetNormalLabelSize',  function () {
this.setTextSize$I(this.mpLabelSize);
}, p$1);

Clazz_newMeth(C$, 'mpSetReducedLabelSize',  function () {
this.setTextSize$I(((this.mpLabelSize * 5 + 1)/6|0));
}, p$1);

Clazz_newMeth(C$, 'mpSetSmallLabelSize',  function () {
this.setTextSize$I(((this.mpLabelSize * 2 + 1)/3|0));
}, p$1);

Clazz_newMeth(C$, 'mpGetFreeSpaceAngle$I',  function (atom) {
var angle=Clazz_array(Double.TYPE, [this.mMol.getAllConnAtoms$I(atom)]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) angle[i]=this.mMol.getBondAngle$I$I(atom, this.mMol.getConnAtom$I$I(atom, i));

$I$(10).sort$DA(angle);
var maxMean=p$1.mpGetMeanAngle$DA$I.apply(this, [angle, 0]);
var maxVal=p$1.mpGetAngleESRScore$DA$I$D.apply(this, [angle, 0, maxMean]);
for (var i=1; i < angle.length; i++) {
var mean=p$1.mpGetMeanAngle$DA$I.apply(this, [angle, i]);
var val=p$1.mpGetAngleESRScore$DA$I$D.apply(this, [angle, i, mean]);
if (maxVal < val ) {
maxVal=val;
maxMean=mean;
}}
return maxMean;
}, p$1);

Clazz_newMeth(C$, 'mpGetAngleESRScore$DA$I$D',  function (angleList, index, meanAngle) {
var score=(index == 0) ? 6.283185307179586 + angleList[0] - angleList[angleList.length - 1] : angleList[index] - angleList[index - 1];
if (meanAngle > -2.0943951023931953  && meanAngle < 1.0471975511965976  ) score-=2 * Math.cos(meanAngle + 0.5235987755982988);
 else score-=0.5 * Math.cos(meanAngle + 0.5235987755982988);
return score;
}, p$1);

Clazz_newMeth(C$, 'mpGetMeanAngle$DA$I',  function (angle, index) {
if (index > 0) return (angle[index] + angle[index - 1]) / 2.0;
var mean=3.141592653589793 + (angle[0] + angle[angle.length - 1]) / 2.0;
return (mean > 3.141592653589793 ) ? mean - 6.283185307179586 : mean;
}, p$1);

Clazz_newMeth(C$, 'append$S$S',  function (a, b) {
return (a == null ) ? b : (b == null ) ? a : a + "," + b ;
}, p$1);

Clazz_newMeth(C$, 'mpDrawString$D$D$S$Z',  function (x, y, str, withTabu) {
if (withTabu) {
var strWidth;
var xdiff;
var ydiff;
strWidth=this.getStringWidth$S(str);
xdiff=strWidth / 2 + (this.getTextSize$()/8|0);
ydiff=(this.getTextSize$()/2|0);
if (str === "+"  || str === "-"  ) ydiff=ydiff * 2 / 3;
this.mpTabuZone.add$O(Clazz_new_($I$(1,1).c$$D$D$D$D,[x - xdiff, y - ydiff, 2 * xdiff, 2 * ydiff]));
}if (!this.mIsValidatingView) this.drawString$S$D$D(str, x, y);
}, p$1);

Clazz_newMeth(C$, 'mpDrawDot$D$D$I',  function (x, y, atm) {
this.mpTabuZone.add$O(Clazz_new_($I$(1,1).c$$D$D$D$D,[x - this.mpDotDiameter, y - this.mpDotDiameter, 2 * this.mpDotDiameter, 2 * this.mpDotDiameter]));
if (!this.mIsValidatingView) {
this.mpDot.add$O(Clazz_new_([x, y, p$1.isHighlightedAtom$I.apply(this, [atm]) ? -3 : this.mAtomColor[atm]],$I$(11,1).c$$D$D$I));
}}, p$1);

Clazz_newMeth(C$, 'mpDrawAllDots',  function () {
for (var dot, $dot = this.mpDot.iterator$(); $dot.hasNext$()&&((dot=($dot.next$())),1);) {
p$1.setColor_$I.apply(this, [dot.color]);
this.drawDot$D$D(dot.x, dot.y);
}
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}, p$1);

Clazz_newMeth(C$, 'mpAlleneCenter$I',  function (atm) {
if (this.mMol.getConnAtoms$I(atm) != 2) return false;
for (var i=0; i < 2; i++) if (this.mMol.getConnBondOrder$I$I(atm, i) != 2) return false;

return true;
}, p$1);

Clazz_newMeth(C$, 'mpDrawBondQueryFeatures',  function () {
var textSizeChanged=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var label=null;
if (this.mMol.isBondBridge$I(bond)) {
var minAtoms=this.mMol.getBondBridgeMinSize$I(bond);
var maxAtoms=this.mMol.getBondBridgeMaxSize$I(bond);
label=(minAtoms == maxAtoms) ? "[" + minAtoms + "]"  : "[" + minAtoms + ":" + maxAtoms + "]" ;
} else if ((this.mMol.getBondQueryFeatures$I(bond) & 6291456) != 0) {
label=((this.mMol.getBondQueryFeatures$I(bond) & 6291456) == 2097152) ? "a" : ((this.mMol.getBondQueryFeatures$I(bond) & 384) == 256) ? "r!a" : "!a";
} else if ((this.mMol.getBondQueryFeatures$I(bond) & 384) != 0) {
label=((this.mMol.getBondQueryFeatures$I(bond) & 384) == 256) ? "r" : "!r";
}var ringSize=(this.mMol.getBondQueryFeatures$I(bond) & 917504) >> 17;
if (ringSize != 0) label=((label == null ) ? "" : label) + ringSize;
if (label != null ) {
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
if (!textSizeChanged) {
p$1.mpSetSmallLabelSize.apply(this, []);
textSizeChanged=true;
}var x=(this.getAtomX$I(atom1) + this.getAtomX$I(atom2)) / 2;
var y=(this.getAtomY$I(atom1) + this.getAtomY$I(atom2)) / 2;
var dx=this.getAtomX$I(atom2) - this.getAtomX$I(atom1);
var dy=this.getAtomY$I(atom2) - this.getAtomY$I(atom1);
var d=Math.sqrt(dx * dx + dy * dy);
var hw=0.6 * this.getStringWidth$S(label);
var hh=0.55 * this.getTextSize$();
if (d != 0 ) {
if (dx > 0 ) p$1.mpDrawString$D$D$S$Z.apply(this, [x + hw * dy / d, y - hh * dx / d, label, true]);
 else p$1.mpDrawString$D$D$S$Z.apply(this, [x - hw * dy / d, y + hh * dx / d, label, true]);
}}}
if (textSizeChanged) p$1.mpSetNormalLabelSize.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'drawLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atom1, atom2) {
if (this.mMol.isBondForegroundHilited$I(this.mMol.getBond$I$I(atom1, atom2))) {
p$1.setColor_$I.apply(this, [-3]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(theLine);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
} else if (this.mAtomColor[atom1] != this.mAtomColor[atom2]) {
p$1.drawColorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I.apply(this, [theLine, atom1, atom2]);
} else if (this.mAtomColor[atom1] != 0) {
p$1.setColor_$I.apply(this, [this.mAtomColor[atom1]]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(theLine);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
} else {
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(theLine);
}}, p$1);

Clazz_newMeth(C$, 'drawColorLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atm1, atm2) {
var line1=Clazz_new_($I$(7,1));
var line2=Clazz_new_($I$(7,1));
line1.x1=theLine.x1;
line1.y1=theLine.y1;
line1.x2=(theLine.x1 + theLine.x2) / 2;
line1.y2=(theLine.y1 + theLine.y2) / 2;
line2.x1=line1.x2;
line2.y1=line1.y2;
line2.x2=theLine.x2;
line2.y2=theLine.y2;
if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [line1])) {
p$1.setColor_$I.apply(this, [this.mAtomColor[atm1]]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(line1);
}if (p$1.mpProperLine$com_actelion_research_chem_AbstractDepictor_DepictorLine.apply(this, [line2])) {
p$1.setColor_$I.apply(this, [this.mAtomColor[atm2]]);
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(line2);
}p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}, p$1);

Clazz_newMeth(C$, 'drawDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atom1, atom2) {
var xinc=(theLine.x2 - theLine.x1) / 10;
var yinc=(theLine.y2 - theLine.y1) / 10;
var aLine=Clazz_new_($I$(7,1));
var color1;
var color2;
if (this.mMol.isBondForegroundHilited$I(this.mMol.getBond$I$I(atom1, atom2))) {
color1=-3;
color2=-3;
} else {
color1=this.mAtomColor[atom1];
color2=this.mAtomColor[atom2];
}p$1.setColor_$I.apply(this, [color1]);
aLine.x1=theLine.x1;
aLine.y1=theLine.y1;
aLine.x2=theLine.x1 + xinc * 2;
aLine.y2=theLine.y1 + yinc * 2;
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(aLine);
aLine.x1=theLine.x1 + xinc * 4;
aLine.y1=theLine.y1 + yinc * 4;
aLine.x2=theLine.x1 + xinc * 5;
aLine.y2=theLine.y1 + yinc * 5;
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(aLine);
p$1.setColor_$I.apply(this, [color2]);
aLine.x1=theLine.x1 + xinc * 5;
aLine.y1=theLine.y1 + yinc * 5;
aLine.x2=theLine.x1 + xinc * 6;
aLine.y2=theLine.y1 + yinc * 6;
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(aLine);
aLine.x1=theLine.x1 + xinc * 8;
aLine.y1=theLine.y1 + yinc * 8;
aLine.x2=theLine.x2;
aLine.y2=theLine.y2;
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(aLine);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}, p$1);

Clazz_newMeth(C$, 'drawShortDashedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theLine, atom1, atom2) {
var xdif=theLine.x2 - theLine.x1;
var ydif=theLine.y2 - theLine.y1;
var length=Math.sqrt(xdif * xdif + ydif * ydif);
var points=2 * Long.$ival(Math.round$D(length / (4 * this.mpLineWidth)));
var xinc=xdif / (points - 1);
var yinc=ydif / (points - 1);
var color1;
var color2;
if (this.mMol.isBondForegroundHilited$I(this.mMol.getBond$I$I(atom1, atom2))) {
color1=-3;
color2=-3;
} else {
color1=this.mAtomColor[atom1];
color2=this.mAtomColor[atom2];
}var x=theLine.x1 - this.mpLineWidth / 2;
var y=theLine.y1 - this.mpLineWidth / 2;
p$1.setColor_$I.apply(this, [color1]);
for (var i=0; i < (points/2|0); i++) {
this.fillCircle$D$D$D(x, y, this.mpLineWidth);
x+=xinc;
y+=yinc;
}
p$1.setColor_$I.apply(this, [color2]);
for (var i=0; i < (points/2|0); i++) {
this.fillCircle$D$D$D(x, y, this.mpLineWidth);
x+=xinc;
y+=yinc;
}
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}, p$1);

Clazz_newMeth(C$, 'drawWedge$com_actelion_research_chem_AbstractDepictor_DepictorLine$I$I',  function (theWedge, atom1, atom2) {
var xdiff=(theWedge.y1 - theWedge.y2) / 9;
var ydiff=(theWedge.x2 - theWedge.x1) / 9;
var xe1=(theWedge.x2 + xdiff);
var ye1=(theWedge.y2 + ydiff);
var xe2=(theWedge.x2 - xdiff);
var ye2=(theWedge.y2 - ydiff);
var xm1=(theWedge.x1 + xe1) / 2;
var ym1=(theWedge.y1 + ye1) / 2;
var xm2=(theWedge.x1 + xe2) / 2;
var ym2=(theWedge.y1 + ye2) / 2;
var p1=Clazz_new_($I$(12,1).c$$I,[3]);
var p2=Clazz_new_($I$(12,1).c$$I,[4]);
p1.addPoint$D$D(theWedge.x1, theWedge.y1);
p1.addPoint$D$D(xm1, ym1);
p1.addPoint$D$D(xm2, ym2);
p2.addPoint$D$D(xm2, ym2);
p2.addPoint$D$D(xm1, ym1);
p2.addPoint$D$D(xe1, ye1);
p2.addPoint$D$D(xe2, ye2);
var color1;
var color2;
if (this.mMol.isBondForegroundHilited$I(this.mMol.getBond$I$I(atom1, atom2))) {
color1=-3;
color2=-3;
} else {
color1=this.mAtomColor[atom1];
color2=this.mAtomColor[atom2];
if (this.mMol.getMoleculeColor$() != 1) {
color2=p$1.getESRColor$I.apply(this, [atom1]);
if (color1 == this.mMol.getAtomColor$I(atom1)) color1=color2;
}}p$1.setColor_$I.apply(this, [color1]);
this.drawPolygon$com_actelion_research_gui_generic_GenericPolygon(p1);
p$1.setColor_$I.apply(this, [color2]);
this.drawPolygon$com_actelion_research_gui_generic_GenericPolygon(p2);
p$1.setColor_$I.apply(this, [this.mStandardForegroundColor]);
}, p$1);

Clazz_newMeth(C$, 'drawDot$D$D',  function (x, y) {
this.fillCircle$D$D$D(x - this.mpDotDiameter / 2, y - this.mpDotDiameter / 2, this.mpDotDiameter);
});

Clazz_newMeth(C$, 'setRGBColor$I',  function (rgb) {
if (this.mOverruleForeground != 0) {
if (this.mCurrentColor != -4) {
this.mCurrentColor=-4;
this.setRGB$I(this.mOverruleForeground);
}return;
}this.mCurrentColor=-5;
this.mRGBColor=rgb;
this.setRGB$I(rgb);
}, p$1);

Clazz_newMeth(C$, 'setColor_$I',  function (theColor) {
if (this.mIsValidatingView) return;
if (theColor == -10) {
this.mCurrentColor=-999;
theColor=this.mStandardForegroundColor;
}if (theColor != -2 && theColor != -7  && this.mOverruleForeground != 0 ) theColor=-4;
if (theColor == this.mCurrentColor) return;
if (this.mCurrentColor == -8 && theColor != -9 ) return;
if (theColor == -8) this.mPreviousColor=this.mCurrentColor;
if (theColor == -9) theColor=this.mPreviousColor;
this.mCurrentColor=theColor;
switch (theColor) {
case 0:
this.setRGB$I(this.mCustomForeground == 0 ? -16777216 : this.mCustomForeground);
break;
case -6:
this.setRGB$I(this.mCustomForeground);
break;
case -4:
this.setRGB$I(this.mOverruleForeground);
break;
case -2:
this.setRGB$I(this.mBondBGHiliteColor);
break;
case -3:
this.setRGB$I(this.mBondFGHiliteColor);
break;
case -7:
this.setRGB$I(this.mExcludeGroupBGColor);
break;
case -8:
this.setRGB$I(this.mExcludeGroupFGColor);
break;
case -5:
this.setRGB$I(this.mRGBColor);
break;
case 64:
this.setRGB$I(-14655233);
break;
case 128:
this.setRGB$I(-65536);
break;
case 256:
this.setRGB$I(-4194049);
break;
case 192:
this.setRGB$I(-16711936);
break;
case 320:
this.setRGB$I(-24576);
break;
case 384:
this.setRGB$I(-16744448);
break;
case 448:
this.setRGB$I(-6291456);
break;
case 1:
this.setRGB$I(-8355712);
break;
default:
this.setRGB$I(-16777216);
break;
}
}, p$1);

Clazz_newMeth(C$, 'getESRTypeToDisplayAt$I',  function (atom) {
var type=-1;
var group=-1;
if ((this.mDisplayMode & 128) != 0) return type;
if (this.mMol.isAtomStereoCenter$I(atom)) {
type=this.mMol.getAtomESRType$I(atom);
group=this.mMol.getAtomESRGroup$I(atom);
}var bond=this.mMol.findBINAPChiralityBond$I(atom);
if (bond != -1) {
type=this.mMol.getBondESRType$I(bond);
group=this.mMol.getBondESRGroup$I(bond);
}if (type != -1 && type != 0 ) type|=(group << 8);
return type;
}, p$1);

Clazz_newMeth(C$, 'getESRColor$I',  function (atom) {
if ((this.mDisplayMode & (4224)) != 0) return this.mAtomColor[atom];
var esrInfo=p$1.getESRTypeToDisplayAt$I.apply(this, [atom]);
if (esrInfo == -1) {
var alleneCenter=this.mMol.findAlleneCenterAtom$I(atom);
if (alleneCenter != -1) {
atom=alleneCenter;
esrInfo=p$1.getESRTypeToDisplayAt$I.apply(this, [atom]);
}}if (esrInfo == -1) return this.mAtomColor[atom];
switch (esrInfo & 255) {
case 1:
return 384;
case 2:
return 64;
default:
return 448;
}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.ATOM_LABEL_COLOR=Clazz_array(Integer.TYPE, -1, [0, 16777215, 14286847, 13402367, 12779264, 16758197, 9474192, 3166456, 16715021, 9494608, 11789301, 11230450, 9109248, 12560038, 15780000, 16744448, 16777008, 2093087, 8442339, 9388244, 4062976, 15132390, 12567239, 10921643, 9083335, 10255047, 14706227, 15765664, 5296208, 13140019, 8224944, 12750735, 6721423, 12419299, 16752896, 10889513, 6076625, 7351984, 65280, 9764863, 9756896, 7586505, 5551541, 3907230, 2396047, 687500, 27013, 12632256, 16767375, 10909043, 6717568, 10380213, 13924864, 9699476, 4366000, 5707663, 51456, 7394559, 16777159, 14286791, 13107143, 10747847, 9437127, 6422471, 4587463, 3211207, 2097095, 65436, 58997, 54354, 48952, 43812, 5096191, 5089023, 2200790, 2522539, 2516630, 1528967, 13684960, 16765219, 12105936, 10900557, 5724513, 10375093, 11230208, 7688005, 4358806, 4325478, 32000, 7384058, 47871, 41471, 36863, 33023, 27647, 5528818, 7888099, 9064419, 10565332, 11739092, 11739066, 11734438, 12389767, 13041766, 13369433, 13697103, 14221381, 14680120, 15073326, 15400998, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13158600, 1334015, 56540, 15075850, 15132160, 56540, 15075850, 15461355, 8553170, 1016335, 1016335, 1334015, 15132160, 3289770, 14456450, 16422400, 16422400, 11819700, 3289770, 1016335]);
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.AbstractDepictor, "DepictorDot", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x','y'],'I',['color']]]

Clazz_newMeth(C$, 'c$$D$D$I',  function (x, y, color) {
;C$.$init$.apply(this);
this.x=x;
this.y=y;
this.color=color;
}, 1);

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.AbstractDepictor, "DepictorLine", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x1','y1','x2','y2']]]

Clazz_newMeth(C$, 'c$$D$D$D$D',  function (x1, y1, x2, y2) {
;C$.$init$.apply(this);
this.x1=x1;
this.y1=y1;
this.x2=x2;
this.y2=y2;
}, 1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:16 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.Arrays','com.actelion.research.chem.CanonizerMesoHelper','java.util.ArrayList','com.actelion.research.chem.CanonizerBond','com.actelion.research.chem.CanonizerBaseValue','com.actelion.research.chem.SortedStringList','com.actelion.research.chem.CanonizerFragment','com.actelion.research.chem.EZHalfParity','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Molecule','StringBuilder','com.actelion.research.chem.Canonizer$1RankObject','com.actelion.research.chem.Canonizer$2RankObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Canonizer", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ESRGroup',0]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mIsMeso','mStereoCentersFound','mIsOddParityRound','mZCoordinatesAvailable','mCIPParityNoDistinctionProblem','mEncodeAvoid127','mGraphGenerated'],'I',['mMode','mNoOfRanks','mNoOfPseudoGroups','mGraphRings','mFeatureBlock','mEncodingBitsAvail','mEncodingTempData','mAtomBits','mMaxConnAtoms'],'S',['mIDCode','mEncodedCoords','mMapping'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mCanRank','int[]','+mCanRankBeforeTieBreaking','+mPseudoTHGroup','+mPseudoEZGroup','mTHParity','byte[]','+mEZParity','+mTHConfiguration','+mEZConfiguration','+mTHCIPParity','+mEZCIPParity','+mTHESRType','+mTHESRGroup','+mEZESRType','+mEZESRGroup','+mAbnormalValence','mCanBase','com.actelion.research.chem.CanonizerBaseValue[]','mMesoHelper','com.actelion.research.chem.CanonizerMesoHelper','mIsStereoCenter','boolean[]','+mTHParityIsMesoInverted','+mTHParityNeedsNormalization','+mTHESRTypeNeedsNormalization','+mTHParityRoundIsOdd','+mEZParityRoundIsOdd','+mTHParityIsPseudo','+mEZParityIsPseudo','+mProTHAtomsInSameFragment','+mProEZAtomsInSameFragment','+mNitrogenQualifiesForParity','mFragmentList','java.util.ArrayList','+mTHParityNormalizationGroupList','mGraphAtom','int[]','+mGraphIndex','+mGraphBond','+mGraphFrom','+mGraphClosure','mEncodingBuffer','StringBuilder']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, 0]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, mode) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMode=mode;
this.mMol.ensureHelperArrays$I(7);
this.mAtomBits=C$.getNeededBits$I(this.mMol.getAtoms$());
if ((this.mMode & 2048) == 0) p$1.canFindNitrogenQualifyingForParity.apply(this, []);
this.mZCoordinatesAvailable=((mode & 64) != 0) || this.mMol.is3D$() ;
if ((this.mMode & 2048) == 0) {
this.mTHParity=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityIsPseudo=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityRoundIsOdd=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mEZParity=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
this.mEZParityRoundIsOdd=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mEZParityIsPseudo=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
}this.mCIPParityNoDistinctionProblem=false;
p$1.canInitializeRanking.apply(this, []);
if ((this.mMode & 2048) == 0) p$1.canRankStereo.apply(this, []);
p$1.canRankFinal.apply(this, []);
}, 1);

Clazz_newMeth(C$, 'hasCIPParityDistinctionProblem$',  function () {
return this.mCIPParityNoDistinctionProblem;
});

Clazz_newMeth(C$, 'canFindNitrogenQualifyingForParity',  function () {
this.mNitrogenQualifiesForParity=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomicNo$I(atom) == 7) {
if (this.mMol.getConnAtoms$I(atom) == 4) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getConnAtoms$I(atom) == 3) {
if (this.mMol.getAtomRingSize$I(atom) == 3) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getAtomCharge$I(atom) == 1) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.isFlatNitrogen$I(atom)) continue;
if ((this.mMode & 32) != 0) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getAtomRingBondCount$I(atom) != 3) continue;
var smallRingSize=this.mMol.getAtomRingSize$I(atom);
if (smallRingSize > 7) continue;
var ringSet=this.mMol.getRingSet$();
var smallRingNo=0;
while (smallRingNo < ringSet.getSize$()){
if (ringSet.getRingSize$I(smallRingNo) == smallRingSize && ringSet.isAtomMember$I$I(smallRingNo, atom) ) break;
++smallRingNo;
}
if (smallRingNo >= 1024 && smallRingNo == ringSet.getSize$() ) continue;
var firstBridgeAtom=-1;
var firstBridgeBond=-1;
for (var i=0; i < 3; i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (!ringSet.isBondMember$I$I(smallRingNo, connBond)) {
firstBridgeAtom=this.mMol.getConnAtom$I$I(atom, i);
firstBridgeBond=connBond;
break;
}}
var neglectBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
neglectBond[firstBridgeBond]=true;
var pathAtom=Clazz_array(Integer.TYPE, [11]);
var pathLength=this.mMol.getPath$IA$I$I$I$ZA(pathAtom, firstBridgeAtom, atom, 10, neglectBond);
if (pathLength == -1) continue;
var bridgeAtomCount=1;
while (!ringSet.isAtomMember$I$I(smallRingNo, pathAtom[bridgeAtomCount]))++bridgeAtomCount;

var bondCountToBridgeHead=pathLength - bridgeAtomCount;
var bridgeHead=pathAtom[bridgeAtomCount];
if (smallRingSize == 6 && bondCountToBridgeHead == 2  && bridgeAtomCount == 3 ) {
if (this.mMol.getAtomRingBondCount$I(pathAtom[1]) >= 3) {
var isAdamantane=false;
var ringAtom=ringSet.getRingAtoms$I(smallRingNo);
for (var i=0; i < 6; i++) {
if (atom == ringAtom[i]) {
var potentialOtherBridgeHeadIndex=ringSet.validateMemberIndex$I$I(smallRingNo, (bridgeHead == ringAtom[ringSet.validateMemberIndex$I$I(smallRingNo, i + 2)]) ? i - 2 : i + 2);
var potentialOtherBridgeHead=ringAtom[potentialOtherBridgeHeadIndex];
if (this.mMol.getAtomRingBondCount$I(potentialOtherBridgeHead) >= 3 && this.mMol.getPathLength$I$I$I$ZA(pathAtom[1], potentialOtherBridgeHead, 2, null) == 2 ) isAdamantane=true;
break;
}}
if (isAdamantane) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}}}var bridgeHeadIsFlat=(this.mMol.getAtomPi$I(bridgeHead) == 1 || this.mMol.isAromaticAtom$I(bridgeHead)  || this.mMol.isFlatNitrogen$I(bridgeHead) );
var bridgeHeadMayInvert=!bridgeHeadIsFlat && this.mMol.getAtomicNo$I(bridgeHead) == 7  && this.mMol.getAtomCharge$I(bridgeHead) != 1 ;
if (bondCountToBridgeHead == 1) {
if (!bridgeHeadIsFlat && !bridgeHeadMayInvert && smallRingSize <= 4   && bridgeAtomCount <= 3 ) this.mNitrogenQualifiesForParity[atom]=true;
continue;
}switch (smallRingSize) {
case 4:
if (!bridgeHeadIsFlat && !bridgeHeadMayInvert ) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}break;
case 5:
if (bridgeHeadMayInvert) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
} else if (!bridgeHeadIsFlat) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}break;
case 6:
if (bondCountToBridgeHead == 2) {
if (bridgeHeadIsFlat) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
} else if (!bridgeHeadMayInvert) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
}} else if (bondCountToBridgeHead == 3) {
if (bridgeHeadIsFlat) {
if (bridgeAtomCount <= 6) this.mNitrogenQualifiesForParity[atom]=true;
} else {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}}break;
case 7:
if (bondCountToBridgeHead == 3) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
}break;
}
}}}
}, p$1);

Clazz_newMeth(C$, 'canCalcImplicitAbnormalValence$I',  function (atom) {
var explicitAbnormalValence=this.mMol.getAtomAbnormalValence$I(atom);
var implicitHigherValence=this.mMol.getImplicitHigherValence$I$Z(atom, false);
var newImplicitHigherValence=this.mMol.getImplicitHigherValence$I$Z(atom, true);
var valence=-1;
if (implicitHigherValence != newImplicitHigherValence) {
if (explicitAbnormalValence != -1 && explicitAbnormalValence > implicitHigherValence ) valence=($b$[0] = explicitAbnormalValence, $b$[0]);
 else valence=($b$[0] = implicitHigherValence, $b$[0]);
} else if (explicitAbnormalValence != -1) {
if (explicitAbnormalValence > newImplicitHigherValence || (explicitAbnormalValence < newImplicitHigherValence && explicitAbnormalValence >= this.mMol.getOccupiedValence$I(atom) ) ) valence=($b$[0] = explicitAbnormalValence, $b$[0]);
} else if (!this.mMol.supportsImplicitHydrogen$I(atom) && this.mMol.getExplicitHydrogens$I(atom) != 0 ) {
valence=this.mMol.getOccupiedValence$I(atom);
valence-=this.mMol.getElectronValenceCorrection$I$I(atom, valence);
}p$1.canSetAbnormalValence$I$I.apply(this, [atom, valence]);
return valence;
}, p$1);

Clazz_newMeth(C$, 'canSetAbnormalValence$I$I',  function (atom, valence) {
if (this.mAbnormalValence == null ) {
this.mAbnormalValence=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
$I$(1).fill$BA$B(this.mAbnormalValence, -1);
}this.mAbnormalValence[atom]=(valence|0);
}, p$1);

Clazz_newMeth(C$, 'canRankStereo',  function () {
var noOfRanksWithoutStereo=this.mNoOfRanks;
var canRankWithoutStereo=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
if (!this.mMol.isFragment$()) {
p$1.canRecursivelyFindCIPParities.apply(this, []);
p$1.initializeParities$I$IA.apply(this, [noOfRanksWithoutStereo, canRankWithoutStereo]);
}this.mTHESRType=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mTHESRGroup=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mTHESRType[atom]=(this.mMol.getAtomESRType$I(atom)|0);
this.mTHESRGroup[atom]=(this.mMol.getAtomESRGroup$I(atom)|0);
}
this.mEZESRType=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
this.mEZESRGroup=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mEZESRType[bond]=(this.mMol.getBondESRType$I(bond)|0);
this.mEZESRGroup[bond]=(this.mMol.getBondESRGroup$I(bond)|0);
}
p$1.canRecursivelyFindAllParities.apply(this, []);
this.mStereoCentersFound=false;
this.mIsStereoCenter=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0) {
this.mIsStereoCenter[atom]=true;
this.mStereoCentersFound=true;
}}
p$1.canRemoveOverspecifiedESRGroups.apply(this, []);
this.mMesoHelper=null;
this.mTHESRTypeNeedsNormalization=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
if (this.mStereoCentersFound) {
this.mMesoHelper=Clazz_new_($I$(2,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$ZA$BA$BA$BA$BA$BA$BA$ZA$ZA$ZA,[this.mMol, canRankWithoutStereo, this.mIsStereoCenter, this.mTHParity, this.mEZParity, this.mTHESRType, this.mTHESRGroup, this.mEZESRType, this.mEZESRGroup, this.mTHParityRoundIsOdd, this.mEZParityRoundIsOdd, this.mTHESRTypeNeedsNormalization]);
this.mMesoHelper.normalizeESRGroups$();
}this.mTHParityIsMesoInverted=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityNeedsNormalization=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityNormalizationGroupList=Clazz_new_($I$(3,1));
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
p$1.canMarkESRGroupsForParityNormalization.apply(this, []);
p$1.initializeParities$I$IA.apply(this, [noOfRanksWithoutStereo, canRankWithoutStereo]);
p$1.canRecursivelyFindCanonizedParities.apply(this, []);
if (this.mMesoHelper != null ) this.mIsMeso=this.mMesoHelper.isMeso$();
p$1.determineChirality$IA.apply(this, [canRankWithoutStereo]);
}, p$1);

Clazz_newMeth(C$, 'canRankFinal',  function () {
if ((this.mMode & 1) != 0 && (this.mMode & 2) == 0 ) {
this.mCanRankBeforeTieBreaking=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
}if ((this.mMode & 2048) == 0) {
this.mProTHAtomsInSameFragment=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mProEZAtomsInSameFragment=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
if (this.mNoOfRanks < this.mMol.getAtoms$()) {
p$1.canBreakTiesByHeteroTopicity.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}}}if (this.mCanRankBeforeTieBreaking == null  && (this.mMode & 1) != 0  && (this.mMode & 2) != 0 ) this.mCanRankBeforeTieBreaking=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
while (this.mNoOfRanks < this.mMol.getAtoms$()){
p$1.canBreakTiesRandomly.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}}
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
p$1.canFindPseudoParities.apply(this, []);
p$1.flagStereoProblems.apply(this, []);
}}, p$1);

Clazz_newMeth(C$, 'canBreakTiesByHeteroTopicity',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
var found=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) found=!!(found|(p$1.canCalcTHParity$I$I.apply(this, [atom, 3])));

for (var bond=0; bond < this.mMol.getBonds$(); bond++) found=!!(found|(p$1.canCalcEZParity$I$I.apply(this, [bond, 3])));

if (!found) return false;
while (this.mNoOfRanks < this.mMol.getAtoms$()){
found=p$1.canInnerBreakTiesByHeteroTopicity.apply(this, []);
if (!found) break;
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}
return true;
}, p$1);

Clazz_newMeth(C$, 'canInnerBreakTiesByHeteroTopicity',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
for (var rank=1; rank <= this.mNoOfRanks; rank++) {
var found=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] == rank) found=!!(found|(p$1.canCalcTHParity$I$I.apply(this, [atom, 2])));

if (found) {
var oldRanks=this.mNoOfRanks;
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks != oldRanks) return true;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
}}
var rankedBond=Clazz_array($I$(4), [this.mMol.getBonds$()]);
for (var i=0; i < rankedBond.length; i++) rankedBond[i]=Clazz_new_([this.mCanRank[this.mMol.getBondAtom$I$I(0, i)], this.mCanRank[this.mMol.getBondAtom$I$I(1, i)], i],$I$(4,1).c$$I$I$I);

$I$(1).sort$OA(rankedBond);
for (var i=0; i < rankedBond.length; i++) {
if (p$1.canCalcEZParity$I$I.apply(this, [rankedBond[i].bond, 2])) {
while (i + 1 < rankedBond.length && rankedBond[i].compareTo$com_actelion_research_chem_CanonizerBond(rankedBond[i + 1]) == 0 )p$1.canCalcEZParity$I$I.apply(this, [rankedBond[++i].bond, 2]);

var oldRanks=this.mNoOfRanks;
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks != oldRanks) return true;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'canBreakTiesRandomly',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits + 1, 2 * this.mCanRank[atom]);
}
var rankCount=Clazz_array(Integer.TYPE, [this.mNoOfRanks + 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) ++rankCount[this.mCanRank[atom]];

var rank=1;
while (rankCount[rank] == 1)++rank;

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mCanRank[atom] == rank) {
this.mCanBase[atom].add$J(1);
break;
}}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'initializeParities$I$IA',  function (noOfRanksWithoutStereo, canRankWithoutStereo) {
this.mNoOfRanks=noOfRanksWithoutStereo;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanRank[atom]=canRankWithoutStereo[atom];
this.mTHParity[atom]=(0|0);
this.mTHParityRoundIsOdd[atom]=false;
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mEZParity[bond]=(0|0);
this.mEZParityRoundIsOdd[bond]=false;
}
}, p$1);

Clazz_newMeth(C$, 'canInitializeRanking',  function () {
var bondQueryFeaturesPresent=false;
if (this.mMol.isFragment$()) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondQueryFeatures$I(bond) != 0) {
bondQueryFeaturesPresent=true;
break;
}}
}this.mMaxConnAtoms=2;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mMaxConnAtoms=Math.max(this.mMaxConnAtoms, this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom));

var baseValueSize=Math.max(2, bondQueryFeaturesPresent ? ((62 + this.mAtomBits + this.mMaxConnAtoms * (this.mAtomBits + 23) )/63|0) : ((62 + this.mAtomBits + this.mMaxConnAtoms * (this.mAtomBits + 5) )/63|0));
this.mCanRank=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
this.mCanBase=Clazz_array($I$(5), [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mCanBase[atom]=Clazz_new_($I$(5,1).c$$I,[baseValueSize]);

var atomListFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
if ((Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) || this.mMol.getAtomList$I(atom) != null  ) this.mCanBase[atom].add$I$J(8, 6);
 else this.mCanBase[atom].add$I$J(8, this.mMol.getAtomicNo$I(atom));
this.mCanBase[atom].add$I$J(8, this.mMol.getAtomMass$I(atom));
this.mCanBase[atom].add$I$J(2, this.mMol.getAtomPi$I(atom));
this.mCanBase[atom].add$I$J(4, this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom));
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) this.mCanBase[atom].add$I$J(4, 8);
 else this.mCanBase[atom].add$I$J(4, 8 + this.mMol.getAtomCharge$I(atom));
this.mCanBase[atom].add$I$J(5, Math.min(31, this.mMol.getAtomRingSize$I(atom)));
this.mCanBase[atom].add$I$J(4, p$1.canCalcImplicitAbnormalValence$I.apply(this, [atom]) + 1);
this.mCanBase[atom].add$I$J(2, this.mMol.getAtomRadical$I(atom) >> 4);
if (this.mMol.isFragment$()) {
this.mCanBase[atom].add$I$J(46, this.mMol.getAtomQueryFeatures$I(atom));
if (this.mMol.getAtomList$I(atom) != null ) atomListFound=true;
}}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks < this.mMol.getAtoms$()) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var bondRingSize=Clazz_array(Integer.TYPE, [this.mMol.getConnAtoms$I(atom)]);
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
bondRingSize[i]=this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)] << 5;
bondRingSize[i]|=Math.min(31, this.mMol.getBondRingSize$I(this.mMol.getConnBond$I$I(atom, i)));
}
$I$(1).sort$IA(bondRingSize);
for (var i=this.mMaxConnAtoms; i > bondRingSize.length; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 5, 0);

for (var i=bondRingSize.length - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 5, bondRingSize[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if (atomListFound && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var atomList=this.mMol.getAtomList$I(atom);
var listLength=(atomList == null ) ? 0 : Math.min(12, atomList.length);
for (var i=12; i > listLength; i--) this.mCanBase[atom].add$I$J(8, 0);

for (var i=listLength - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(8, atomList[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if (bondQueryFeaturesPresent && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var bondQFList=Clazz_array(Long.TYPE, [this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom)]);
var index=0;
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
bondQFList[index]=this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)];
(bondQFList[$k$=index]=Long.$sl(bondQFList[$k$],(23)));
(bondQFList[$k$=index]=Long.$or(bondQFList[$k$],(this.mMol.getBondQueryFeatures$I(this.mMol.getConnBond$I$I(atom, i)))));
++index;
}}
$I$(1).sort$JA(bondQFList);
for (var i=this.mMaxConnAtoms; i > bondQFList.length; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 23, 0);

for (var i=bondQFList.length - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 23, bondQFList[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 8) != 0 && this.mNoOfRanks < this.mMol.getAtoms$() ) {
var list=Clazz_new_($I$(6,1));
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomCustomLabel$I(atom) != null ) list.addString$S(this.mMol.getAtomCustomLabel$I(atom));

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var rank=(this.mMol.getAtomCustomLabel$I(atom) == null ) ? 0 : 1 + list.getListIndex$S(this.mMol.getAtomCustomLabel$I(atom));
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(this.mAtomBits, rank);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 16) != 0 && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(1, this.mMol.isSelectedAtom$I(atom) ? 1 : 0);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 512) != 0 && this.mMol.isFragment$() ) p$1.canBreakFreeValenceAtomTies.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'canBreakFreeValenceAtomTies',  function () {
while (true){
var isFreeValenceRank=Clazz_array(Boolean.TYPE, [this.mNoOfRanks + 1]);
var highestSharedFreeValenceRank=-1;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getLowestFreeValence$I(atom) != 0) {
if (isFreeValenceRank[this.mCanRank[atom]] && highestSharedFreeValenceRank < this.mCanRank[atom] ) highestSharedFreeValenceRank=this.mCanRank[atom];
isFreeValenceRank[this.mCanRank[atom]]=true;
}}
if (highestSharedFreeValenceRank == -1) break;
var increment=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var value=0;
if (this.mCanRank[atom] == highestSharedFreeValenceRank) value=++increment;
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(8, value);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}
}, p$1);

Clazz_newMeth(C$, 'canRemoveOverspecifiedESRGroups',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (!this.mIsStereoCenter[atom] || this.mTHParity[atom] == 3 ) this.mTHESRType[atom]=(0|0);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(bond) != 1 || this.mEZParity[bond] == 0  || this.mEZParity[bond] == 3 ) this.mEZESRType[bond]=(0|0);

}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindAllParities',  function () {
this.mIsOddParityRound=true;
var paritiesFound=p$1.canFindParities$Z.apply(this, [false]);
var parityInfoBits=9;
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && paritiesFound ){
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var thParityInfo=this.mTHParity[atom] << (7);
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) && this.mTHESRType[atom] != 0 ) {
thParityInfo|=(this.mTHESRType[atom] << 5);
thParityInfo|=this.mTHESRGroup[atom];
}this.mCanBase[atom].add$I$J(18, thParityInfo << 9);
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var ezParityInfo=this.mEZParity[bond] << (7);
if ((this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) && this.mMol.getBondType$I(bond) == 1  && this.mEZESRType[bond] != 0 ) {
ezParityInfo|=(this.mEZESRType[bond] << 5);
ezParityInfo|=this.mEZESRGroup[bond];
}this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(ezParityInfo);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(ezParityInfo);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
paritiesFound=p$1.canFindParities$Z.apply(this, [false]);
}
}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindCIPParities',  function () {
this.mIsOddParityRound=true;
this.mTHCIPParity=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mEZCIPParity=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
var paritiesFound=p$1.canFindParities$Z.apply(this, [true]);
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && paritiesFound ){
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits + 4, (this.mCanRank[atom] << 4) | (this.mTHParity[atom] << 2));
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(this.mEZParity[bond]);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(this.mEZParity[bond]);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
paritiesFound=p$1.canFindParities$Z.apply(this, [true]);
}
}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindCanonizedParities',  function () {
this.mIsOddParityRound=true;
var esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
if (this.mMesoHelper != null  && this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank) ) esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
if (p$1.canFindParities$Z.apply(this, [false])) p$1.canNormalizeGroupParities.apply(this, []);
var newStereoInfoAvailable=true;
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && newStereoInfoAvailable ){
var groupRank=p$1.canGetESRGroupRank$IAAA.apply(this, [esrGroupMember]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(20, 0);
if (!this.mTHESRTypeNeedsNormalization[atom] && this.mTHESRType[atom] != 0 ) this.mCanBase[atom].add$J((this.mTHESRType[atom] << 18) + (groupRank[(this.mTHESRType[atom] == 1) ? 0 : 1][this.mTHESRGroup[atom]] << 8));
var parity=this.mTHParity[atom];
if (this.mTHParityIsMesoInverted[atom]) {
if (parity == 1) parity=2;
 else if (parity == 2) parity=1;
}this.mCanBase[atom].add$J(parity << 4);
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(this.mEZParity[bond]);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(this.mEZParity[bond]);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
newStereoInfoAvailable=false;
if (this.mMesoHelper != null  && this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank) ) {
newStereoInfoAvailable=true;
esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
}if (p$1.canFindParities$Z.apply(this, [false])) {
newStereoInfoAvailable=true;
p$1.canNormalizeGroupParities.apply(this, []);
}}
}, p$1);

Clazz_newMeth(C$, 'compileESRGroupMembers',  function () {
var esrGroupMember=Clazz_array(Integer.TYPE, [2, 32, null]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsStereoCenter[atom]) {
if (this.mTHESRType[atom] == 1) esrGroupMember[0][this.mTHESRGroup[atom]]=$I$(2).addToIntArray$IA$I(esrGroupMember[0][this.mTHESRGroup[atom]], atom);
 else if (this.mTHESRType[atom] == 2) esrGroupMember[1][this.mTHESRGroup[atom]]=$I$(2).addToIntArray$IA$I(esrGroupMember[0][this.mTHESRGroup[atom]], atom);
}}
return esrGroupMember;
}, p$1);

Clazz_newMeth(C$, 'canNormalizeGroupParities',  function () {
var groupNormalized=false;
for (var i=0; i < this.mTHParityNormalizationGroupList.size$(); i++) {
var groupAtom=this.mTHParityNormalizationGroupList.get$I(i);
var allParitiesDetermined=true;
var maxRank=-1;
var invertParities=false;
for (var j=0; j < groupAtom.length; j++) {
var atom=groupAtom[j];
if (this.mTHParity[atom] == 0) {
allParitiesDetermined=false;
break;
}if (this.mTHParity[atom] != 3) {
var isUniqueRank=true;
for (var k=0; k < groupAtom.length; k++) {
if (k != j && this.mCanRank[atom] == this.mCanRank[groupAtom[k]] ) {
isUniqueRank=false;
break;
}}
if (isUniqueRank && maxRank < this.mCanRank[atom] ) {
maxRank=this.mCanRank[atom];
invertParities=(this.mTHParity[atom] == 1);
}}}
if (allParitiesDetermined && maxRank != -1 ) {
for (var atom, $atom = 0, $$atom = groupAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 )) this.mTHParityIsMesoInverted[atom]=invertParities;
this.mTHParityNeedsNormalization[atom]=false;
}
this.mTHParityNormalizationGroupList.remove$O(groupAtom);
groupNormalized=true;
--i;
}}
return groupNormalized;
}, p$1);

Clazz_newMeth(C$, 'canMarkESRGroupsForParityNormalization',  function () {
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mTHESRType[atom] != 0 && (this.mTHESRType[atom] != 2 || (this.mMode & 256) == 0 ) ) ++count;

if (count == 0) return;
var parity=Clazz_array(Integer.TYPE, [count]);
count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHESRType[atom] != 0 && (this.mTHESRType[atom] != 2 || (this.mMode & 256) == 0 ) ) {
parity[count]=(this.mTHESRType[atom] << 29) | (this.mTHESRGroup[atom] << 24) | (this.mCanRank[atom] << 12) | atom ;
++count;
}}
$I$(1).sort$IA(parity);
var groupBase=0;
var nextGroupBase=0;
var groupID=parity[0] & -16777216;
while (true){
++nextGroupBase;
if (nextGroupBase == parity.length || groupID != (parity[nextGroupBase] & -16777216) ) {
var atomList=Clazz_array(Integer.TYPE, [nextGroupBase - groupBase]);
for (var i=groupBase; i < nextGroupBase; i++) {
var atom=parity[i] & 4095;
atomList[i - groupBase]=atom;
this.mTHParityNeedsNormalization[atom]=true;
}
this.mTHParityNormalizationGroupList.add$O(atomList);
if (nextGroupBase == parity.length) break;
groupID=(parity[nextGroupBase] & -16777216);
groupBase=nextGroupBase;
}}
}, p$1);

Clazz_newMeth(C$, 'canGetESRGroupRank$IAAA',  function (groupMember) {
var groupRank=Clazz_array(Integer.TYPE, [2, 32]);
for (var groupTypeIndex=0; groupTypeIndex < 2; groupTypeIndex++) {
var atomRank=Clazz_array(Integer.TYPE, [32, null]);
var rankCount=0;
for (var group=0; group < 32; group++) {
if (groupMember[groupTypeIndex][group] != null ) {
var memberCount=groupMember[groupTypeIndex][group].length;
atomRank[group]=Clazz_array(Integer.TYPE, [memberCount]);
for (var i=0; i < memberCount; i++) atomRank[group][i]=this.mCanRank[groupMember[groupTypeIndex][group][i]];

$I$(1).sort$IA(atomRank[group]);
++rankCount;
}}
for (var rank=rankCount; rank > 0; rank--) {
var maxGroup=0;
var maxAtomRank=null;
for (var group=0; group < 32; group++) {
if (atomRank[group] != null ) {
if (maxAtomRank == null  || maxAtomRank.length < atomRank[group].length ) {
maxAtomRank=atomRank[group];
maxGroup=group;
} else if (maxAtomRank.length == atomRank[group].length) {
for (var i=maxAtomRank.length - 1; i >= 0; i--) {
if (maxAtomRank[i] < atomRank[group][i]) {
maxAtomRank=atomRank[group];
maxGroup=group;
break;
}}
}}}
groupRank[groupTypeIndex][maxGroup]=rank;
atomRank[maxGroup]=null;
}
}
return groupRank;
}, p$1);

Clazz_newMeth(C$, 'canFindParities$Z',  function (doCIP) {
var ezFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (p$1.canCalcEZParity$I$I.apply(this, [bond, 1])) {
this.mEZParityRoundIsOdd[bond]=this.mIsOddParityRound;
if (doCIP) p$1.cipCalcEZParity$I.apply(this, [bond]);
ezFound=true;
}
var thFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (p$1.canCalcTHParity$I$I.apply(this, [atom, 1])) {
this.mTHParityRoundIsOdd[atom]=this.mIsOddParityRound;
if (doCIP) p$1.cipCalcTHParity$I.apply(this, [atom]);
thFound=true;
}
if (thFound) this.mIsOddParityRound=!this.mIsOddParityRound;
return ezFound || thFound ;
}, p$1);

Clazz_newMeth(C$, 'determineChirality$IA',  function (canRankWithoutStereo) {
var stereoCenters=0;
var stereoCentersUnknown=0;
var stereoCentersTypeAbs=0;
var stereoCentersTypeAbsInMesoFragment=0;
var stereoCentersTypeAndGroup0=0;
var stereoCentersTypeOrGroup0=0;
var typeAndGroups=0;
var typeAndInMesoFragmentFound=false;
var andGroupUsed=Clazz_array(Boolean.TYPE, [32]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0) {
++stereoCenters;
if (this.mTHParity[atom] == 3) {
++stereoCentersUnknown;
} else {
if (this.mTHESRType[atom] == 0) {
++stereoCentersTypeAbs;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(atom) ) ++stereoCentersTypeAbsInMesoFragment;
} else if (this.mTHESRType[atom] == 2) {
if (this.mTHESRGroup[atom] == 0) ++stereoCentersTypeOrGroup0;
} else if (this.mTHESRType[atom] == 1) {
var group=this.mTHESRGroup[atom];
if (!andGroupUsed[group]) {
++typeAndGroups;
andGroupUsed[group]=true;
}if (this.mTHESRGroup[atom] == 0) ++stereoCentersTypeAndGroup0;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(atom) ) typeAndInMesoFragmentFound=true;
}}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] != 0 && this.mMol.getBondType$I(bond) == 1 ) {
++stereoCenters;
if (this.mEZParity[bond] == 3) {
++stereoCentersUnknown;
} else {
if (this.mEZESRType[bond] == 0) {
++stereoCentersTypeAbs;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(0, bond))  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(1, bond)) ) ++stereoCentersTypeAbsInMesoFragment;
} else if (this.mEZESRType[bond] == 2) {
if (this.mEZESRGroup[bond] == 0) ++stereoCentersTypeOrGroup0;
} else if (this.mEZESRType[bond] == 1) {
var group=this.mEZESRGroup[bond];
if (!andGroupUsed[group]) {
++typeAndGroups;
andGroupUsed[group]=true;
}if (this.mEZESRGroup[bond] == 0) ++stereoCentersTypeAndGroup0;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(0, bond))  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(1, bond)) ) typeAndInMesoFragmentFound=true;
}}}}
if (stereoCenters == 0) {
this.mMol.setChirality$I(65536);
return;
}if (stereoCentersUnknown != 0) {
this.mMol.setChirality$I(0);
return;
}if (this.mIsMeso) {
this.mMol.setChirality$I(131072 + (1 << typeAndGroups));
return;
}if (stereoCentersTypeAndGroup0 + stereoCentersTypeAbsInMesoFragment == stereoCenters && !typeAndInMesoFragmentFound ) {
this.mMol.setChirality$I(196608);
} else if (stereoCentersTypeAbs == stereoCenters) {
this.mMol.setChirality$I(262144);
} else if (stereoCentersTypeOrGroup0 == stereoCenters) {
this.mMol.setChirality$I(327680);
} else if (stereoCentersTypeAbs == stereoCenters - 1 && stereoCentersTypeAndGroup0 == 1 ) {
this.mMol.setChirality$I(393216);
} else {
this.mMol.setChirality$I(458752 + (1 << typeAndGroups));
}}, p$1);

Clazz_newMeth(C$, 'canFindPseudoParities',  function () {
var isFreshPseudoParityAtom=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var isFreshPseudoParityBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
var anyPseudoParityCount=0;
var pseudoParity1Or2Found=false;
if ((this.mMode & 128) != 0) {
this.mPseudoTHGroup=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mPseudoEZGroup=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
}for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mProTHAtomsInSameFragment[atom]) {
if (!this.mTHParityIsPseudo[atom]) {
if (p$1.canCalcTHParity$I$I.apply(this, [atom, 1])) {
this.mTHParityIsPseudo[atom]=true;
isFreshPseudoParityAtom[atom]=true;
++anyPseudoParityCount;
}}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mProEZAtomsInSameFragment[bond]) {
if (!this.mEZParityIsPseudo[bond]) {
if (p$1.canCalcEZParity$I$I.apply(this, [bond, 1])) {
this.mEZParityIsPseudo[bond]=true;
isFreshPseudoParityBond[bond]=true;
++anyPseudoParityCount;
}}}}
if (anyPseudoParityCount == 1) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (isFreshPseudoParityAtom[atom]) {
this.mTHParity[atom]=(0|0);
break;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (isFreshPseudoParityBond[bond]) {
this.mEZParity[bond]=(0|0);
break;
}}
} else if (anyPseudoParityCount > 1) {
p$1.canEnsureFragments.apply(this, []);
this.mNoOfPseudoGroups=0;
for (var f, $f = this.mFragmentList.iterator$(); $f.hasNext$()&&((f=($f.next$())),1);) {
var pseudoParitiesInGroup=0;
var pseudoParity1Or2InGroup=0;
var highRankingTHAtom=0;
var highRankingEZBond=0;
var highTHAtomRank=-1;
var highEZBondRank=-1;
for (var i=0; i < f.atom.length; i++) {
if (isFreshPseudoParityAtom[f.atom[i]]) {
++pseudoParitiesInGroup;
if (this.mTHParity[f.atom[i]] == 1 || this.mTHParity[f.atom[i]] == 2 ) {
++pseudoParity1Or2InGroup;
pseudoParity1Or2Found=true;
if (highTHAtomRank < this.mCanRank[f.atom[i]]) {
highTHAtomRank=this.mCanRank[f.atom[i]];
highRankingTHAtom=f.atom[i];
}}}}
for (var i=0; i < f.bond.length; i++) {
if (isFreshPseudoParityBond[f.bond[i]]) {
++pseudoParitiesInGroup;
var rank1=this.mCanRank[this.mMol.getBondAtom$I$I(0, f.bond[i])];
var rank2=this.mCanRank[this.mMol.getBondAtom$I$I(1, f.bond[i])];
var higherRank=(rank1 > rank2) ? (rank1 << 16) + rank2 : (rank2 << 16) + rank1;
if (this.mEZParity[f.bond[i]] == 1 || this.mEZParity[f.bond[i]] == 2 ) {
++pseudoParity1Or2InGroup;
pseudoParity1Or2Found=true;
if (highEZBondRank < higherRank) {
highEZBondRank=higherRank;
highRankingEZBond=f.bond[i];
}}}}
if (pseudoParitiesInGroup == 0) continue;
if (pseudoParitiesInGroup == 1) {
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mTHParity[f.atom[i]]=(0|0);

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mEZParity[f.bond[i]]=(0|0);

} else {
if (pseudoParity1Or2InGroup == 1) {
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mTHParity[f.atom[i]]=(3|0);

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mEZParity[f.bond[i]]=(3|0);

} else {
if ((this.mMode & 128) != 0) {
++this.mNoOfPseudoGroups;
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mPseudoTHGroup[f.atom[i]]=this.mNoOfPseudoGroups;

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mPseudoEZGroup[f.bond[i]]=this.mNoOfPseudoGroups;

}var invertFragmentsStereoFeatures=false;
if (highTHAtomRank != -1) {
if (this.mTHParity[highRankingTHAtom] == 2) invertFragmentsStereoFeatures=true;
} else {
if (this.mEZParity[highRankingEZBond] == 2) invertFragmentsStereoFeatures=true;
}if (invertFragmentsStereoFeatures) {
for (var i=0; i < f.atom.length; i++) {
if (isFreshPseudoParityAtom[f.atom[i]]) {
switch (this.mTHParity[f.atom[i]]) {
case 1:
this.mTHParity[f.atom[i]]=(2|0);
break;
case 2:
this.mTHParity[f.atom[i]]=(1|0);
break;
}
}}
for (var i=0; i < f.bond.length; i++) {
if (isFreshPseudoParityBond[f.bond[i]]) {
switch (this.mEZParity[f.bond[i]]) {
case 1:
this.mEZParity[f.bond[i]]=(2|0);
break;
case 2:
this.mEZParity[f.bond[i]]=(1|0);
break;
}
}}
}}}}
}return pseudoParity1Or2Found;
}, p$1);

Clazz_newMeth(C$, 'canEnsureFragments',  function () {
if (this.mFragmentList != null ) return;
this.mFragmentList=Clazz_new_($I$(3,1));
var fragmentCount=0;
var fragmentNo=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var fragmentAtom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var fragmentBond=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (fragmentNo[atom] == 0 && (this.mMol.isRingAtom$I(atom) || this.mMol.getAtomPi$I(atom) == 1 ) ) {
fragmentAtom[0]=atom;
var fragmentAtoms=1;
var fragmentBonds=0;
fragmentNo[atom]=++fragmentCount;
var bondHandled=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
for (var current=0; current < fragmentAtoms; current++) {
for (var i=0; i < this.mMol.getConnAtoms$I(fragmentAtom[current]); i++) {
var connBond=this.mMol.getConnBond$I$I(fragmentAtom[current], i);
if (this.mMol.isRingBond$I(connBond) || this.mMol.getBondOrder$I(connBond) == 2  || this.mMol.isBINAPChiralityBond$I(connBond) ) {
var connAtom=this.mMol.getConnAtom$I$I(fragmentAtom[current], i);
if (!bondHandled[connBond]) {
fragmentBond[fragmentBonds++]=connBond;
bondHandled[connBond]=true;
}if (fragmentNo[connAtom] == 0) {
fragmentAtom[fragmentAtoms++]=connAtom;
fragmentNo[connAtom]=fragmentCount;
}}}
}
this.mFragmentList.add$O(Clazz_new_($I$(7,1).c$$IA$I$IA$I,[fragmentAtom, fragmentAtoms, fragmentBond, fragmentBonds]));
}}
}, p$1);

Clazz_newMeth(C$, 'canPerformRanking',  function () {
var oldNoOfRanks;
var newNoOfRanks;
newNoOfRanks=p$1.canConsolidate.apply(this, []);
do {
oldNoOfRanks=newNoOfRanks;
p$1.canCalcNextBaseValues.apply(this, []);
newNoOfRanks=p$1.canConsolidate.apply(this, []);
} while (oldNoOfRanks != newNoOfRanks);
return newNoOfRanks;
}, p$1);

Clazz_newMeth(C$, 'canCalcNextBaseValues',  function () {
var connRank=Clazz_array(Integer.TYPE, [this.mMaxConnAtoms]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var neighbours=this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom);
var neighbour=0;
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
var rank=2 * this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)];
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.getBondOrder$I(connBond) == 2) if (!this.mMol.isAromaticBond$I(connBond)) ++rank;
var j;
for (j=0; j < neighbour; j++) if (rank < connRank[j]) break;

for (var k=neighbour; k > j; k--) connRank[k]=connRank[k - 1];

connRank[j]=rank;
++neighbour;
}}
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
for (var i=neighbours; i < this.mMaxConnAtoms; i++) this.mCanBase[atom].add$I$J(this.mAtomBits + 1, 0);

for (var i=0; i < neighbours; i++) this.mCanBase[atom].add$I$J(this.mAtomBits + 1, connRank[i]);

}
}, p$1);

Clazz_newMeth(C$, 'canConsolidate',  function () {
var canRank=0;
$I$(1).sort$OA(this.mCanBase);
for (var i=0; i < this.mCanBase.length; i++) {
if (i == 0 || this.mCanBase[i].compareTo$com_actelion_research_chem_CanonizerBaseValue(this.mCanBase[i - 1]) != 0 ) ++canRank;
this.mCanRank[this.mCanBase[i].getAtom$()]=canRank;
}
return canRank;
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity$I$I',  function (atom, mode) {
if (this.mTHParity[atom] != 0) return false;
if (this.mMol.getAtomicNo$I(atom) != 5 && this.mMol.getAtomicNo$I(atom) != 6  && this.mMol.getAtomicNo$I(atom) != 7  && this.mMol.getAtomicNo$I(atom) != 14  && this.mMol.getAtomicNo$I(atom) != 15  && this.mMol.getAtomicNo$I(atom) != 16 ) return false;
if (this.mMol.getAtomPi$I(atom) != 0) {
if (this.mMol.isCentralAlleneAtom$I(atom)) return p$1.canCalcAlleneParity$I$I.apply(this, [atom, mode]);
if (this.mMol.getAtomicNo$I(atom) != 15 && this.mMol.getAtomicNo$I(atom) != 16 ) return false;
}if (this.mMol.getConnAtoms$I(atom) < 3 || this.mMol.getAllConnAtoms$I(atom) > 4 ) return false;
if (this.mMol.getAtomCharge$I(atom) > 0 && this.mMol.getAtomicNo$I(atom) == 6 ) return false;
if (this.mMol.getAtomicNo$I(atom) == 5 && this.mMol.getAllConnAtoms$I(atom) != 4 ) return false;
if (this.mMol.getAtomicNo$I(atom) == 7 && !this.mNitrogenQualifiesForParity[atom] ) return false;
var remappedConn=Clazz_array(Integer.TYPE, [4]);
var remappedRank=Clazz_array(Integer.TYPE, [4]);
var neighbourUsed=Clazz_array(Boolean.TYPE, [4]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var highestRank=-1;
var highestConn=0;
for (var j=0; j < this.mMol.getAllConnAtoms$I(atom); j++) {
if (!neighbourUsed[j]) {
if (highestRank < this.mCanRank[this.mMol.getConnAtom$I$I(atom, j)]) {
highestRank=this.mCanRank[this.mMol.getConnAtom$I$I(atom, j)];
highestConn=j;
}}}
remappedConn[i]=highestConn;
remappedRank[i]=highestRank;
neighbourUsed[highestConn]=true;
}
if (this.mMol.getAllConnAtoms$I(atom) == 4 && remappedRank[0] == remappedRank[1]  && remappedRank[2] == remappedRank[3] ) return false;
if ((this.mMol.getAllConnAtoms$I(atom) == 4) && (remappedRank[0] == remappedRank[2] || remappedRank[1] == remappedRank[3] ) ) return false;
if (this.mMol.getAllConnAtoms$I(atom) == 3 && remappedRank[0] == remappedRank[2] ) return false;
var proTHAtom1=0;
var proTHAtom2=0;
var proTHAtomsFound=false;
for (var i=1; i < this.mMol.getAllConnAtoms$I(atom); i++) {
if (remappedRank[i - 1] == remappedRank[i]) {
if (mode == 1 || remappedRank[i] == 0 ) return false;
proTHAtom1=this.mMol.getConnAtom$I$I(atom, remappedConn[i - 1]);
proTHAtom2=this.mMol.getConnAtom$I$I(atom, remappedConn[i]);
if (mode == 3 && this.mMol.isRingBond$I(this.mMol.getConnBond$I$I(atom, remappedConn[i])) ) this.mProTHAtomsInSameFragment[atom]=true;
proTHAtomsFound=true;
}}
if (mode != 1 && !proTHAtomsFound ) return false;
var atomTHParity=(this.mZCoordinatesAvailable) ? p$1.canCalcTHParity3D$I$IA.apply(this, [atom, remappedConn]) : p$1.canCalcTHParity2D$I$IA.apply(this, [atom, remappedConn]);
if (mode == 1) {
this.mTHParity[atom]=atomTHParity;
} else if (mode == 2) {
if (atomTHParity == 1) {
this.mCanBase[proTHAtom1].add$J(this.mCanRank[atom]);
} else if (atomTHParity == 2) {
this.mCanBase[proTHAtom2].add$J(this.mCanRank[atom]);
}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity2D$I$IA',  function (atom, remappedConn) {
var up_down=Clazz_array(Integer.TYPE, -2, [Clazz_array(Integer.TYPE, -1, [2, 1, 2, 1]), Clazz_array(Integer.TYPE, -1, [1, 2, 2, 1]), Clazz_array(Integer.TYPE, -1, [1, 1, 2, 2]), Clazz_array(Integer.TYPE, -1, [2, 1, 1, 2]), Clazz_array(Integer.TYPE, -1, [2, 2, 1, 1]), Clazz_array(Integer.TYPE, -1, [1, 2, 1, 2])]);
var angle=Clazz_array(Double.TYPE, [this.mMol.getAllConnAtoms$I(atom)]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) angle[i]=this.mMol.getBondAngle$I$I(this.mMol.getConnAtom$I$I(atom, remappedConn[i]), atom);

var parity=($b$[0] = this.mMol.getFisherProjectionParity$I$IA$DA$IA(atom, remappedConn, angle, null), $b$[0]);
if (parity != 3) return parity;
var stereoBond=0;
var stereoType=0;
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var bnd=this.mMol.getConnBond$I$I(atom, remappedConn[i]);
if (this.mMol.getBondAtom$I$I(0, bnd) == atom) {
if (this.mMol.getBondType$I(bnd) == 129) {
if (stereoType != 0) this.mMol.setStereoProblem$I(atom);
stereoBond=i;
stereoType=1;
}if (this.mMol.getBondType$I(bnd) == 257) {
if (stereoType != 0) this.mMol.setStereoProblem$I(atom);
stereoBond=i;
stereoType=2;
}}}
if (stereoType == 0) return $b$[0] = 3, $b$[0];
for (var i=1; i < this.mMol.getAllConnAtoms$I(atom); i++) if (angle[i] < angle[0] ) angle[i]+=6.283185307179586;

if (this.mMol.getAllConnAtoms$I(atom) == 3) {
switch (stereoBond) {
case 0:
if (((angle[1] < angle[2] ) && (angle[2] - angle[1] < 3.141592653589793 ) ) || ((angle[1] > angle[2] ) && (angle[1] - angle[2] > 3.141592653589793 ) ) ) stereoType=3 - stereoType;
break;
case 1:
if (angle[2] - angle[0] > 3.141592653589793 ) stereoType=3 - stereoType;
break;
case 2:
if (angle[1] - angle[0] < 3.141592653589793 ) stereoType=3 - stereoType;
break;
}
return (stereoType == 1) ? 2 : ($b$[0] = 1, $b$[0]);
}var order=0;
if (angle[1] <= angle[2]  && angle[2] <= angle[3]  ) order=0;
 else if (angle[1] <= angle[3]  && angle[3] <= angle[2]  ) order=1;
 else if (angle[2] <= angle[1]  && angle[1] <= angle[3]  ) order=2;
 else if (angle[2] <= angle[3]  && angle[3] <= angle[1]  ) order=3;
 else if (angle[3] <= angle[1]  && angle[1] <= angle[2]  ) order=4;
 else if (angle[3] <= angle[2]  && angle[2] <= angle[1]  ) order=5;
return (up_down[order][stereoBond] == stereoType) ? 2 : ($b$[0] = 1, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity3D$I$IA',  function (atom, remappedConn) {
var atomList=Clazz_array(Integer.TYPE, [4]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) atomList[i]=this.mMol.getConnAtom$I$I(atom, remappedConn[i]);

if (this.mMol.getAllConnAtoms$I(atom) == 3) atomList[3]=atom;
var coords=Clazz_array(Double.TYPE, [3, 3]);
for (var i=0; i < 3; i++) {
coords[i][0]=this.mMol.getAtomX$I(atomList[i + 1]) - this.mMol.getAtomX$I(atomList[0]);
coords[i][1]=this.mMol.getAtomY$I(atomList[i + 1]) - this.mMol.getAtomY$I(atomList[0]);
coords[i][2]=this.mMol.getAtomZ$I(atomList[i + 1]) - this.mMol.getAtomZ$I(atomList[0]);
}
var n=Clazz_array(Double.TYPE, [3]);
n[0]=coords[0][1] * coords[1][2] - coords[0][2] * coords[1][1];
n[1]=coords[0][2] * coords[1][0] - coords[0][0] * coords[1][2];
n[2]=coords[0][0] * coords[1][1] - coords[0][1] * coords[1][0];
var cosa=(coords[2][0] * n[0] + coords[2][1] * n[1] + coords[2][2] * n[2]) / (Math.sqrt(coords[2][0] * coords[2][0] + coords[2][1] * coords[2][1] + coords[2][2] * coords[2][2]) * Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]));
return (cosa > 0.0 ) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity$I$I',  function (atom, mode) {
if (this.mMol.getAtomicNo$I(atom) != 6 && this.mMol.getAtomicNo$I(atom) != 7 ) return false;
var atom1=this.mMol.getConnAtom$I$I(atom, 0);
var atom2=this.mMol.getConnAtom$I$I(atom, 1);
if (this.mMol.getAtomPi$I(atom1) != 1 || this.mMol.getAtomPi$I(atom2) != 1 ) return false;
if (this.mMol.getConnAtoms$I(atom1) == 1 || this.mMol.getConnAtoms$I(atom2) == 1 ) return false;
if ((this.mMol.getAllConnAtoms$I(atom1) > 3) || (this.mMol.getAllConnAtoms$I(atom2) > 3) ) return false;
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom, atom1]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom, atom2]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual && halfParity1.mInSameFragment ) this.mProTHAtomsInSameFragment[atom]=true;
if (halfParity2.mRanksEqual && halfParity2.mInSameFragment ) this.mProTHAtomsInSameFragment[atom]=true;
}var alleneParity=this.mZCoordinatesAvailable ? p$1.canCalcAlleneParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcAlleneParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mTHParity[atom]=alleneParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (alleneParity == 1) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[atom1]);
} else {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[atom1]);
}}if (halfParity2.mRanksEqual) {
if (alleneParity == 2) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[atom2]);
} else {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[atom2]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var hp1=halfParity1.getValue$();
var hp2=halfParity2.getValue$();
if (hp1 == -1 || hp2 == -1  || ((hp1 + hp2) & 1) == 0 ) return $b$[0] = 3, $b$[0];
var alleneParity=($b$[0] = 0, $b$[0]);
switch (hp1 + hp2) {
case 3:
case 7:
alleneParity=($b$[0] = 2, $b$[0]);
break;
case 5:
alleneParity=($b$[0] = 1, $b$[0]);
break;
}
return alleneParity;
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var atom=Clazz_array(Integer.TYPE, [4]);
atom[0]=halfParity1.mHighConn;
atom[1]=halfParity1.mCentralAxialAtom;
atom[2]=halfParity2.mCentralAxialAtom;
atom[3]=halfParity2.mHighConn;
var torsion=this.mMol.calculateTorsion$IA(atom);
if (Math.abs(torsion) < 0.3  || Math.abs(torsion) > 2.8415926535897933  ) return $b$[0] = 3, $b$[0];
if (torsion < 0 ) return $b$[0] = 2, $b$[0];
 else return $b$[0] = 1, $b$[0];
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity$I$I',  function (bond, mode) {
if (!this.mMol.isBINAPChiralityBond$I(bond)) return false;
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom1, atom2]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom2, atom1]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual) this.mProEZAtomsInSameFragment[bond]=p$1.hasSecondBINAPBond$I.apply(this, [atom2]);
if (halfParity2.mRanksEqual) this.mProEZAtomsInSameFragment[bond]=p$1.hasSecondBINAPBond$I.apply(this, [atom1]);
}var axialParity=this.mZCoordinatesAvailable ? p$1.canCalcBINAPParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcBINAPParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mEZParity[bond]=axialParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (axialParity == 2) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[atom2]);
} else {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[atom2]);
}}if (halfParity2.mRanksEqual) {
if (axialParity == 2) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[atom1]);
} else {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[atom1]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var hp1=halfParity1.getValue$();
var hp2=halfParity2.getValue$();
if (hp1 == -1 || hp2 == -1  || ((hp1 + hp2) & 1) == 0 ) return $b$[0] = 3, $b$[0];
var axialParity=($b$[0] = 0, $b$[0]);
switch (hp1 + hp2) {
case 3:
case 7:
axialParity=($b$[0] = 1, $b$[0]);
break;
case 5:
axialParity=($b$[0] = 2, $b$[0]);
break;
}
return axialParity;
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var atom=Clazz_array(Integer.TYPE, [4]);
atom[0]=halfParity1.mHighConn;
atom[1]=halfParity1.mCentralAxialAtom;
atom[2]=halfParity2.mCentralAxialAtom;
atom[3]=halfParity2.mHighConn;
var torsion=this.mMol.calculateTorsion$IA(atom);
if (Math.abs(torsion) < 0.3  || Math.abs(torsion) > 2.8415926535897933  ) return $b$[0] = 3, $b$[0];
if (torsion < 0 ) return $b$[0] = 1, $b$[0];
 else return $b$[0] = 2, $b$[0];
}, p$1);

Clazz_newMeth(C$, 'hasSecondBINAPBond$I',  function (atom) {
var ringSet=this.mMol.getRingSet$();
for (var i=0; i < ringSet.getSize$(); i++) {
if (ringSet.isAromatic$I(i) && ringSet.isAtomMember$I$I(i, atom) ) {
for (var j, $j = 0, $$j = ringSet.getRingAtoms$I(i); $j<$$j.length&&((j=($$j[$j])),1);$j++) if (j != atom) for (var k=0; k < this.mMol.getConnAtoms$I(j); k++) if (this.mMol.isBINAPChiralityBond$I(this.mMol.getConnBond$I$I(j, k))) return true;


return false;
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity$I$I',  function (bond, mode) {
if (this.mEZParity[bond] != 0) return false;
if (this.mMol.getBondOrder$I(bond) == 1) return p$1.canCalcBINAPParity$I$I.apply(this, [bond, mode]);
if (this.mMol.getBondOrder$I(bond) != 2) return false;
if (this.mMol.isAromaticBond$I(bond)) return false;
var dbAtom1=this.mMol.getBondAtom$I$I(0, bond);
var dbAtom2=this.mMol.getBondAtom$I$I(1, bond);
if (this.mMol.getConnAtoms$I(dbAtom1) == 1 || this.mMol.getConnAtoms$I(dbAtom2) == 1 ) return false;
if ((this.mMol.getConnAtoms$I(dbAtom1) > 3) || (this.mMol.getConnAtoms$I(dbAtom2) > 3) ) return false;
if (this.mMol.getAtomPi$I(dbAtom1) == 2 || this.mMol.getAtomPi$I(dbAtom2) == 2 ) return false;
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, dbAtom2, dbAtom1]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, dbAtom1, dbAtom2]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual && halfParity1.mInSameFragment ) this.mProEZAtomsInSameFragment[bond]=true;
if (halfParity2.mRanksEqual && halfParity2.mInSameFragment ) this.mProEZAtomsInSameFragment[bond]=true;
}var bondDBParity=this.mMol.isBondParityUnknownOrNone$I(bond) ? ($b$[0] = 3, $b$[0]) : (this.mZCoordinatesAvailable) ? p$1.canCalcEZParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcEZParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mEZParity[bond]=bondDBParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (bondDBParity == 1) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[dbAtom1]);
} else if (bondDBParity == 2) {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[dbAtom1]);
}}if (halfParity2.mRanksEqual) {
if (bondDBParity == 1) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[dbAtom2]);
} else if (bondDBParity == 2) {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[dbAtom2]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
if (halfParity1.getValue$() == -1 || halfParity2.getValue$() == -1 ) return $b$[0] = 3, $b$[0];
if (((halfParity1.getValue$() | halfParity2.getValue$()) & 1) != 0) return $b$[0] = 3, $b$[0];
return (halfParity1.getValue$() == halfParity2.getValue$()) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var db=Clazz_array(Double.TYPE, [3]);
db[0]=this.mMol.getAtomX$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomX$I(halfParity1.mCentralAxialAtom);
db[1]=this.mMol.getAtomY$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomY$I(halfParity1.mCentralAxialAtom);
db[2]=this.mMol.getAtomZ$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomZ$I(halfParity1.mCentralAxialAtom);
var s1=Clazz_array(Double.TYPE, [3]);
s1[0]=this.mMol.getAtomX$I(halfParity1.mHighConn) - this.mMol.getAtomX$I(halfParity1.mCentralAxialAtom);
s1[1]=this.mMol.getAtomY$I(halfParity1.mHighConn) - this.mMol.getAtomY$I(halfParity1.mCentralAxialAtom);
s1[2]=this.mMol.getAtomZ$I(halfParity1.mHighConn) - this.mMol.getAtomZ$I(halfParity1.mCentralAxialAtom);
var s2=Clazz_array(Double.TYPE, [3]);
s2[0]=this.mMol.getAtomX$I(halfParity2.mHighConn) - this.mMol.getAtomX$I(halfParity2.mCentralAxialAtom);
s2[1]=this.mMol.getAtomY$I(halfParity2.mHighConn) - this.mMol.getAtomY$I(halfParity2.mCentralAxialAtom);
s2[2]=this.mMol.getAtomZ$I(halfParity2.mHighConn) - this.mMol.getAtomZ$I(halfParity2.mCentralAxialAtom);
var n1=Clazz_array(Double.TYPE, [3]);
n1[0]=db[1] * s1[2] - db[2] * s1[1];
n1[1]=db[2] * s1[0] - db[0] * s1[2];
n1[2]=db[0] * s1[1] - db[1] * s1[0];
var n2=Clazz_array(Double.TYPE, [3]);
n2[0]=db[1] * n1[2] - db[2] * n1[1];
n2[1]=db[2] * n1[0] - db[0] * n1[2];
n2[2]=db[0] * n1[1] - db[1] * n1[0];
var cosa=(s1[0] * n2[0] + s1[1] * n2[1] + s1[2] * n2[2]) / (Math.sqrt(s1[0] * s1[0] + s1[1] * s1[1] + s1[2] * s1[2]) * Math.sqrt(n2[0] * n2[0] + n2[1] * n2[1] + n2[2] * n2[2]));
var cosb=(s2[0] * n2[0] + s2[1] * n2[1] + s2[2] * n2[2]) / (Math.sqrt(s2[0] * s2[0] + s2[1] * s2[1] + s2[2] * s2[2]) * Math.sqrt(n2[0] * n2[0] + n2[1] * n2[1] + n2[2] * n2[2]));
return (!!((cosa < 0.0 ) ^ (cosb < 0.0 ))) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'flagStereoProblems',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 3 && !this.mMol.isAtomConfigurationUnknown$I(atom) ) this.mMol.setStereoProblem$I(atom);
if ((this.mMol.getAtomESRType$I(atom) == 1 || this.mMol.getAtomESRType$I(atom) == 2 ) && (this.mTHParity[atom] == 3) ) this.mMol.setStereoProblem$I(atom);
if (this.mMol.isAtomConfigurationUnknown$I(atom) && this.mTHParity[atom] != 3  && !p$1.isUnknownBINAPBondAtom$I.apply(this, [atom]) ) this.mMol.setStereoProblem$I(atom);
}
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) if (this.mMol.isStereoBond$I(bond) && !p$1.isJustifiedStereoBond$I.apply(this, [bond]) ) this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 2) {
if (this.mMol.isBondParityUnknownOrNone$I(bond) && (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) ) {
this.mEZParity[bond]=(3|0);
this.mMol.setBondType$I$I(bond, 386);
}if (this.mEZParity[bond] == 3 && !this.mEZParityIsPseudo[bond] ) {
if (this.mMol.getBondType$I(bond) != 386) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}}}if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] == 3  && !this.mMol.isAtomConfigurationUnknown$I(this.mMol.getBondAtom$I$I(0, bond))  && !this.mMol.isAtomConfigurationUnknown$I(this.mMol.getBondAtom$I$I(1, bond)) ) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}if ((this.mMol.getBondESRType$I(bond) == 1 || this.mMol.getBondESRType$I(bond) == 2 ) && (this.mMol.getBondType$I(bond) != 1 || (this.mEZParity[bond] != 1 && this.mEZParity[bond] != 2 ) ) ) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}}
}, p$1);

Clazz_newMeth(C$, 'isUnknownBINAPBondAtom$I',  function (atom) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mEZParity[this.mMol.getConnBond$I$I(atom, i)] == 3 && this.mMol.getConnBondOrder$I$I(atom, i) == 1 ) return true;

return false;
}, p$1);

Clazz_newMeth(C$, 'isJustifiedStereoBond$I',  function (bond) {
var atom=this.mMol.getBondAtom$I$I(0, bond);
if (atom >= this.mMol.getAtoms$()) return false;
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) return true;
if (this.mTHParity[atom] == 3) return false;
var binapBond=this.mMol.findBINAPChiralityBond$I(atom);
if (binapBond != -1) return this.mEZParity[binapBond] == 1 || this.mEZParity[binapBond] == 2 ;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
if (this.mMol.getConnBondOrder$I$I(atom, i) == 2) {
if (this.mTHParity[this.mMol.getConnAtom$I$I(atom, i)] == 1 || this.mTHParity[this.mMol.getConnAtom$I$I(atom, i)] == 2 ) return true;
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'generateGraph',  function () {
if (this.mMol.getAtoms$() == 0) return;
if (this.mGraphGenerated) return;
this.mGraphRings=0;
var startAtom=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] > this.mCanRank[startAtom]) startAtom=atom;

var atomHandled=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var bondHandled=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mGraphIndex=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphAtom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphFrom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphBond=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
this.mGraphAtom[0]=startAtom;
this.mGraphIndex[startAtom]=0;
atomHandled[startAtom]=true;
var atomsWithoutParents=1;
var firstUnhandled=0;
var firstUnused=1;
var graphBonds=0;
while (firstUnhandled < this.mMol.getAtoms$()){
if (firstUnhandled < firstUnused) {
while (true){
var highestRankingConnAtom=0;
var highestRankingConnBond=0;
var highestRank=-1;
var atom=this.mGraphAtom[firstUnhandled];
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
if (!atomHandled[connAtom] && this.mCanRank[connAtom] > highestRank ) {
highestRankingConnAtom=connAtom;
highestRankingConnBond=this.mMol.getConnBond$I$I(atom, i);
highestRank=this.mCanRank[connAtom];
}}}
if (highestRank == -1) break;
this.mGraphIndex[highestRankingConnAtom]=firstUnused;
this.mGraphFrom[firstUnused]=firstUnhandled;
this.mGraphAtom[firstUnused++]=highestRankingConnAtom;
this.mGraphBond[graphBonds++]=highestRankingConnBond;
atomHandled[highestRankingConnAtom]=true;
bondHandled[highestRankingConnBond]=true;
}
++firstUnhandled;
} else {
var highestRankingAtom=0;
var highestRank=-1;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (!atomHandled[atom] && this.mCanRank[atom] > highestRank ) {
highestRankingAtom=atom;
highestRank=this.mCanRank[atom];
}}
++atomsWithoutParents;
this.mGraphIndex[highestRankingAtom]=firstUnused;
this.mGraphFrom[firstUnused]=-1;
this.mGraphAtom[firstUnused++]=highestRankingAtom;
atomHandled[highestRankingAtom]=true;
}}
this.mGraphClosure=Clazz_array(Integer.TYPE, [2 * (this.mMol.getBonds$() - graphBonds)]);
while (true){
var lowAtomNo1=this.mMol.getMaxAtoms$();
var lowAtomNo2=this.mMol.getMaxAtoms$();
var lowBond=-1;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var loAtom;
var hiAtom;
if (!bondHandled[bond]) {
if (this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)] < this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)]) {
loAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)];
hiAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)];
} else {
loAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)];
hiAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)];
}if (loAtom < lowAtomNo1 || (loAtom == lowAtomNo1 && hiAtom < lowAtomNo2 ) ) {
lowAtomNo1=loAtom;
lowAtomNo2=hiAtom;
lowBond=bond;
}}}
if (lowBond == -1) break;
bondHandled[lowBond]=true;
this.mGraphBond[graphBonds++]=lowBond;
this.mGraphClosure[2 * this.mGraphRings]=lowAtomNo1;
this.mGraphClosure[2 * this.mGraphRings + 1]=lowAtomNo2;
++this.mGraphRings;
}
this.mGraphGenerated=true;
}, p$1);

Clazz_newMeth(C$, 'getCanMolecule$',  function () {
return this.getCanMolecule$Z(false);
});

Clazz_newMeth(C$, 'getCanMolecule$Z',  function (includeExplicitHydrogen) {
p$1.generateGraph.apply(this, []);
var mol=Clazz_new_([this.mMol.getAtoms$(), this.mMol.getBonds$()],$I$(9,1).c$$I$I);
mol.setFragment$Z(this.mMol.isFragment$());
for (var i=0; i < this.mMol.getAtoms$(); i++) {
this.mMol.copyAtom$com_actelion_research_chem_Molecule$I$I$I(mol, this.mGraphAtom[i], 0, 0);
mol.setAtomESR$I$I$I(i, this.mTHESRType[this.mGraphAtom[i]], this.mTHESRGroup[this.mGraphAtom[i]]);
}
for (var i=0; i < this.mMol.getBonds$(); i++) {
this.mMol.copyBond$com_actelion_research_chem_Molecule$I$I$I$IA$Z(mol, this.mGraphBond[i], 0, 0, this.mGraphIndex, false);
if (!mol.isStereoBond$I(i) && mol.getBondAtom$I$I(0, i) > mol.getBondAtom$I$I(1, i) ) {
var temp=mol.getBondAtom$I$I(0, i);
mol.setBondAtom$I$I$I(0, i, mol.getBondAtom$I$I(1, i));
mol.setBondAtom$I$I$I(1, i, temp);
}mol.setBondESR$I$I$I(i, this.mEZESRType[this.mGraphBond[i]], this.mEZESRGroup[this.mGraphBond[i]]);
}
if (includeExplicitHydrogen) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) {
var hydrogen=this.mMol.copyAtom$com_actelion_research_chem_Molecule$I$I$I(mol, this.mMol.getConnAtom$I$I(atom, j), 0, 0);
this.mMol.copyBond$com_actelion_research_chem_Molecule$I$I$I$I$I$Z(mol, this.mMol.getConnBond$I$I(atom, j), 0, 0, this.mGraphIndex[atom], hydrogen, false);
}
}
}for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var atom=mol.getBondAtom$I$I(0, bond);
if (this.mTHParityIsMesoInverted[this.mGraphAtom[atom]]) {
if (mol.getBondType$I(bond) == 257) mol.setBondType$I$I(bond, 129);
 else if (mol.getBondType$I(bond) == 129) mol.setBondType$I$I(bond, 257);
}}
this.mMol.copyMoleculeProperties$com_actelion_research_chem_Molecule(mol);
this.mMol.invalidateHelperArrays$I(8);
return mol;
});

Clazz_newMeth(C$, 'setUnknownParitiesToExplicitlyUnknown$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (!this.mMol.isAtomConfigurationUnknown$I(atom) && this.mTHParity[atom] == 3 ) this.mMol.setAtomConfigurationUnknown$I$Z(atom, true);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 3) {
var order=this.mMol.getBondOrder$I(bond);
if (order == 1) {
this.mMol.setAtomConfigurationUnknown$I$Z(this.mMol.getBondAtom$I$I(0, bond), true);
} else if (order == 2) {
this.mMol.setBondType$I$I(bond, 386);
}}}
});

Clazz_newMeth(C$, 'setSingleUnknownAsRacemicParity$',  function () {
var unknownTHParities=0;
var knownTHParities=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0 && !this.mTHParityIsPseudo[atom] ) {
if (this.mTHParity[atom] == 3) ++unknownTHParities;
 else ++knownTHParities;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] != 0  && !this.mEZParityIsPseudo[bond] ) {
if (this.mEZParity[bond] == 3) ++unknownTHParities;
 else ++knownTHParities;
}}
if (knownTHParities == 0 && unknownTHParities == 1 ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 3 && !this.mTHParityIsPseudo[atom] ) {
if (this.mMol.getAtomPi$I(atom) == 2 && this.mMol.getConnAtoms$I(atom) == 2 ) {
for (var i=0; i < 2; i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(connAtom, j))) return false;

}
} else {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(atom, i))) return false;

}this.mTHParity[atom]=(2|0);
this.mTHESRType[atom]=(1|0);
this.mTHESRGroup[atom]=(0|0);
this.mMol.setAtomParity$I$I$Z(atom, 2, false);
this.mMol.setAtomESR$I$I$I(atom, 1, 0);
var stereoBond=this.mMol.getAtomPreferredStereoBond$I(atom);
this.mMol.setBondType$I$I(stereoBond, 257);
if (this.mMol.getBondAtom$I$I(1, stereoBond) == atom) {
var connAtom=this.mMol.getBondAtom$I$I(0, stereoBond);
this.mMol.setBondAtom$I$I$I(0, stereoBond, atom);
this.mMol.setBondAtom$I$I$I(1, stereoBond, connAtom);
}return true;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] != 0  && !this.mEZParityIsPseudo[bond] ) {
for (var i=0; i < 2; i++) {
var atom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(atom, j))) return false;

}
this.mEZParity[bond]=(2|0);
this.mEZESRType[bond]=(1|0);
this.mEZESRGroup[bond]=(0|0);
this.mMol.setBondParity$I$I$Z(bond, 2, false);
this.mMol.setAtomESR$I$I$I(bond, 1, 0);
var stereoBond=this.mMol.getBondPreferredStereoBond$I(bond);
this.mMol.setBondType$I$I(stereoBond, 257);
if (this.mMol.getBondAtom$I$I(1, stereoBond) == this.mMol.getBondAtom$I$I(0, bond) || this.mMol.getBondAtom$I$I(1, stereoBond) == this.mMol.getBondAtom$I$I(1, bond) ) {
var connAtom=this.mMol.getBondAtom$I$I(0, stereoBond);
this.mMol.setBondAtom$I$I$I(0, stereoBond, this.mMol.getBondAtom$I$I(1, stereoBond));
this.mMol.setBondAtom$I$I$I(1, stereoBond, connAtom);
}return true;
}}
}return false;
});

Clazz_newMeth(C$, 'getIDCode$',  function () {
if (this.mIDCode == null ) {
p$1.generateGraph.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.idGenerateConfigurations.apply(this, []);
p$1.idNormalizeESRGroupNumbers.apply(this, []);
}p$1.idCodeCreate.apply(this, []);
}return this.mIDCode;
});

Clazz_newMeth(C$, 'getFinalRank$',  function () {
return this.mCanRank;
});

Clazz_newMeth(C$, 'getSymmetryRank$I',  function (atom) {
return (this.mCanRankBeforeTieBreaking == null ) ? -1 : this.mCanRankBeforeTieBreaking[atom];
});

Clazz_newMeth(C$, 'getSymmetryRanks$',  function () {
return this.mCanRankBeforeTieBreaking;
});

Clazz_newMeth(C$, 'idCodeCreate',  function () {
p$1.encodeBitsStart$Z.apply(this, [false]);
p$1.encodeBits$J$I.apply(this, [9, 4]);
var nbits=Math.max(C$.getNeededBits$I(this.mMol.getAtoms$()), C$.getNeededBits$I(this.mMol.getBonds$()));
p$1.encodeBits$J$I.apply(this, [nbits, 4]);
if (nbits == 0) {
p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
return;
}var nitrogens;
var oxygens;
var otherAtoms;
var chargedAtoms;
nitrogens=oxygens=otherAtoms=chargedAtoms=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) {
switch (this.mMol.getAtomicNo$I(atom)) {
case 6:
break;
case 7:
++nitrogens;
break;
case 8:
++oxygens;
break;
default:
++otherAtoms;
break;
}
if (this.mMol.getAtomCharge$I(atom) != 0) ++chargedAtoms;
}}
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtoms$(), nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getBonds$(), nbits]);
p$1.encodeBits$J$I.apply(this, [nitrogens, nbits]);
p$1.encodeBits$J$I.apply(this, [oxygens, nbits]);
p$1.encodeBits$J$I.apply(this, [otherAtoms, nbits]);
p$1.encodeBits$J$I.apply(this, [chargedAtoms, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 7 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 8 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 6 && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 7  && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 8  && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomicNo$I(this.mGraphAtom[atom]), 8]);
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomCharge$I(this.mGraphAtom[atom]) != 0 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [8 + this.mMol.getAtomCharge$I(this.mGraphAtom[atom]), 4]);
}
var maxdif=0;
var base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}if (maxdif < dif) maxdif=dif;
}
var dbits=C$.getNeededBits$I(maxdif);
p$1.encodeBits$J$I.apply(this, [dbits, 4]);
base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}p$1.encodeBits$J$I.apply(this, [dif, dbits]);
}
for (var i=0; i < 2 * this.mGraphRings; i++) p$1.encodeBits$J$I.apply(this, [this.mGraphClosure[i], nbits]);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var bondOrder=((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & 130560) != 0 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 32 ) ? 1 : (this.mMol.isDelocalizedBond$I(this.mGraphBond[bond])) ? 0 : Math.min(3, this.mMol.getBondOrder$I(this.mGraphBond[bond]));
p$1.encodeBits$J$I.apply(this, [bondOrder, 2]);
}
var THCount=0;
if ((this.mMode & 2048) == 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mTHConfiguration[this.mGraphAtom[atom]] != 0 && this.mTHConfiguration[this.mGraphAtom[atom]] != 3 ) ++THCount;

}p$1.encodeBits$J$I.apply(this, [THCount, nbits]);
if ((this.mMode & 2048) == 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHConfiguration[this.mGraphAtom[atom]] != 0 && this.mTHConfiguration[this.mGraphAtom[atom]] != 3 ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
if (this.mTHESRType[this.mGraphAtom[atom]] == 0) {
p$1.encodeBits$J$I.apply(this, [this.mTHConfiguration[this.mGraphAtom[atom]], 3]);
} else {
var parity=(this.mTHConfiguration[this.mGraphAtom[atom]] == 1) ? ((this.mTHESRType[this.mGraphAtom[atom]] == 1) ? 4 : 6) : ((this.mTHESRType[this.mGraphAtom[atom]] == 1) ? 5 : 7);
p$1.encodeBits$J$I.apply(this, [parity, 3]);
p$1.encodeBits$J$I.apply(this, [this.mTHESRGroup[this.mGraphAtom[atom]], 3]);
}}}
}var EZCount=0;
if ((this.mMode & 2048) == 0) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mEZConfiguration[this.mGraphBond[bond]] != 0 && this.mEZConfiguration[this.mGraphBond[bond]] != 3  && (!this.mMol.isSmallRingBond$I(this.mGraphBond[bond]) || this.mMol.getBondType$I(this.mGraphBond[bond]) == 1 ) ) ++EZCount;

}p$1.encodeBits$J$I.apply(this, [EZCount, nbits]);
if ((this.mMode & 2048) == 0) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZConfiguration[this.mGraphBond[bond]] != 0 && this.mEZConfiguration[this.mGraphBond[bond]] != 3  && (!this.mMol.isSmallRingBond$I(this.mGraphBond[bond]) || this.mMol.getBondType$I(this.mGraphBond[bond]) == 1 ) ) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 1) {
if (this.mEZESRType[this.mGraphBond[bond]] == 0) {
p$1.encodeBits$J$I.apply(this, [this.mEZConfiguration[this.mGraphBond[bond]], 3]);
} else {
var parity=(this.mEZConfiguration[this.mGraphBond[bond]] == 1) ? ((this.mEZESRType[this.mGraphBond[bond]] == 1) ? 4 : 6) : ((this.mEZESRType[this.mGraphBond[bond]] == 1) ? 5 : 7);
p$1.encodeBits$J$I.apply(this, [parity, 3]);
p$1.encodeBits$J$I.apply(this, [this.mEZESRGroup[this.mGraphBond[bond]], 3]);
}} else {
p$1.encodeBits$J$I.apply(this, [this.mEZConfiguration[this.mGraphBond[bond]], 2]);
}}}
}p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [1]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomMass$I(this.mGraphAtom[atom]), 8]);
}}
}this.mFeatureBlock=0;
if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [0, nbits, 2048, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [3, nbits, 4096, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [4, nbits, 120, 4, 3]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [5, nbits, 70368744177670, 2, 1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [6, nbits, 1, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [7, nbits, 1920, 4, 7]);
count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomList$I(this.mGraphAtom[atom]) != null ) ++count;

if (count > 0) {
p$1.encodeFeatureNo$I.apply(this, [8]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var atomList=this.mMol.getAtomList$I(this.mGraphAtom[atom]);
if (atomList != null ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [atomList.length, 4]);
for (var a, $a = 0, $$a = atomList; $a<$$a.length&&((a=($$a[$a])),1);$a++) p$1.encodeBits$J$I.apply(this, [a, 8]);

}}
}p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [9, nbits, 384, 2, 7]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [10, nbits, 31, 5, 0]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [11, nbits, 8192, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [12, nbits, 130560, 8, 9]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [13, nbits, 114688, 3, 14]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [14, nbits, 4063232, 5, 17]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [16, nbits, 29360128, 3, 22]);
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mAbnormalValence != null  && this.mAbnormalValence[this.mGraphAtom[atom]] != -1 ) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [17]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mAbnormalValence != null  && this.mAbnormalValence[this.mGraphAtom[atom]] != -1 ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mAbnormalValence[this.mGraphAtom[atom]], 4]);
}}
}if ((this.mMode & 8) != 0 || (this.mMode & 1024) != 0 ) {
count=0;
var maxLength=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var label=this.mMol.getAtomCustomLabel$I(this.mGraphAtom[atom]);
if (label != null ) {
++count;
maxLength=Math.max(maxLength, label.length$());
}}
if (count != 0) {
var lbits=C$.getNeededBits$I(maxLength);
p$1.encodeFeatureNo$I.apply(this, [18]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
p$1.encodeBits$J$I.apply(this, [lbits, 4]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var customLabel=this.mMol.getAtomCustomLabel$I(this.mGraphAtom[atom]);
if (customLabel != null ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [customLabel.length$(), lbits]);
for (var i=0; i < customLabel.length$(); i++) p$1.encodeBits$J$I.apply(this, [customLabel.charAt$I(i), 7]);

}}
}}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [19, nbits, 234881024, 3, 25]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [20, nbits, 917504, 3, 17]);
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [21]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) >> 4, 2]);
}}
}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [22, nbits, 268435456, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [23, nbits, 1048576, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [24, nbits, 6291456, 2, 21]);
}if ((this.mMode & 16) != 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.isSelectedAtom$I(this.mGraphAtom[atom])) {
p$1.encodeFeatureNo$I.apply(this, [25]);
for (var a=0; a < this.mMol.getAtoms$(); a++) p$1.encodeBits$J$I.apply(this, [this.mMol.isSelectedAtom$I(this.mGraphAtom[a]) ? 1 : 0, 1]);

break;
}}
}var isAromaticSPBond=p$1.getAromaticSPBonds.apply(this, []);
if (isAromaticSPBond != null ) {
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) ++count;

p$1.encodeFeatureNo$I.apply(this, [26]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

}if (this.mMol.isFragment$()) p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [27, nbits, 536870912, 1, -1]);
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 32) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [28]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 32) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [29, nbits, 3221225472, 2, 30]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [30, nbits, 545460846592, 7, 32]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [32, nbits, 52776558133248, 2, 44]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [33, nbits, 17042430230528, 5, 39]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [34, nbits, 70368744177664, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [35, nbits, 8388608, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [36, nbits, 96, 2, 5]);
}count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 16 ) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [37]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 16 ) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 ? 0 : 1, 1]);
}}
}p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'addAtomQueryFeatures$I$I$J$I$I',  function (codeNo, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask)),0 )) ++count;

if (count == 0) return;
p$1.encodeFeatureNo$I.apply(this, [codeNo]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var feature=Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask);
if (Long.$ne(feature,0 )) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [Long.$sr(feature,qfShift), qfBits]);
}}
}, p$1);

Clazz_newMeth(C$, 'addBondQueryFeatures$I$I$I$I$I',  function (codeNo, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask) != 0) ++count;

if (count == 0) return;
p$1.encodeFeatureNo$I.apply(this, [codeNo]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var feature=this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask;
if (feature != 0) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [feature >> qfShift, qfBits]);
}}
}, p$1);

Clazz_newMeth(C$, 'getAromaticSPBonds',  function () {
var isAromaticSPBond=null;
var ringSet=this.mMol.getRingSet$();
for (var r=0; r < ringSet.getSize$(); r++) {
if (ringSet.isDelocalized$I(r)) {
var count=0;
var ringAtom=ringSet.getRingAtoms$I(r);
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) if (p$1.hasTwoAromaticPiElectrons$I.apply(this, [atom])) ++count;

if (count != 0) {
var ringBond=ringSet.getRingBonds$I(r);
if (isAromaticSPBond == null ) isAromaticSPBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
if (count == ringAtom.length) {
var minIndex=-1;
var minValue=2147483647;
for (var i=0; i < ringAtom.length; i++) {
if (minValue > this.mGraphAtom[ringBond[i]]) {
minValue=this.mGraphAtom[ringBond[i]];
minIndex=i;
}}
while (count > 0){
isAromaticSPBond[ringBond[minIndex]]=true;
minIndex=p$1.validateCyclicIndex$I$I.apply(this, [minIndex + 2, ringAtom.length]);
count-=2;
}
} else {
var index=0;
while (p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))++index;

while (!p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))index=p$1.validateCyclicIndex$I$I.apply(this, [index + 1, ringAtom.length]);

while (count > 0){
isAromaticSPBond[ringBond[index]]=true;
index=p$1.validateCyclicIndex$I$I.apply(this, [index + 2, ringAtom.length]);
count-=2;
while (!p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))index=p$1.validateCyclicIndex$I$I.apply(this, [index + 1, ringAtom.length]);

}
}}}}
return isAromaticSPBond;
}, p$1);

Clazz_newMeth(C$, 'hasTwoAromaticPiElectrons$I',  function (atom) {
if (this.mMol.getAtomPi$I(atom) < 2) return false;
if (this.mMol.getConnAtoms$I(atom) == 2) return true;
var aromaticPi=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.isAromaticBond$I(connBond)) aromaticPi+=this.mMol.getBondOrder$I(connBond) - 1;
}
return aromaticPi > 1;
}, p$1);

Clazz_newMeth(C$, 'validateCyclicIndex$I$I',  function (index, limit) {
return (index < limit) ? index : index - limit;
}, p$1);

Clazz_newMeth(C$, 'invalidateCoordinates$',  function () {
this.mEncodedCoords=null;
});

Clazz_newMeth(C$, 'getEncodedCoordinates$',  function () {
return this.getEncodedCoordinates$Z(this.mZCoordinatesAvailable);
});

Clazz_newMeth(C$, 'getEncodedCoordinates$Z',  function (keepPositionAndScale) {
if (this.mEncodedCoords == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA.apply(this, [keepPositionAndScale, this.mMol.getAtomCoordinates$()]);
}return this.mEncodedCoords;
});

Clazz_newMeth(C$, 'getEncodedCoordinates$Z$com_actelion_research_chem_CoordinatesA',  function (keepPositionAndScale, atomCoordinates) {
if (this.mEncodedCoords == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA.apply(this, [keepPositionAndScale, atomCoordinates]);
}return this.mEncodedCoords;
});

Clazz_newMeth(C$, 'encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA',  function (keepPositionAndScale, coords) {
if (this.mMol.getAtoms$() == 0) {
this.mEncodedCoords="";
return;
}var includeHydrogenCoordinates=false;
if (this.mZCoordinatesAvailable && this.mMol.getAllAtoms$() > this.mMol.getAtoms$()  && !this.mMol.isFragment$() ) {
includeHydrogenCoordinates=true;
for (var i=0; i < this.mMol.getAtoms$(); i++) {
if (this.mMol.getImplicitHydrogens$I(i) != 0) {
includeHydrogenCoordinates=false;
break;
}}
}var resolutionBits=this.mZCoordinatesAvailable ? 16 : 8;
p$1.encodeBitsStart$Z.apply(this, [true]);
this.mEncodingBuffer.append$C(includeHydrogenCoordinates ? "#" : "!");
p$1.encodeBits$J$I.apply(this, [this.mZCoordinatesAvailable ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [keepPositionAndScale ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [(resolutionBits/2|0), 4]);
var maxDelta=0.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) maxDelta=p$1.getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA.apply(this, [this.mGraphAtom[i], (this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]], maxDelta, coords]);

if (includeHydrogenCoordinates) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) maxDelta=p$1.getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA.apply(this, [this.mMol.getConnAtom$I$I(atom, j), atom, maxDelta, coords]);

}
}if (this.mMol.getAtoms$() > 1 && maxDelta == 0.0  ) {
this.mEncodedCoords="";
return;
}var binCount=(1 << resolutionBits);
var increment=maxDelta / (binCount / 2.0 - 1);
var maxDeltaPlusHalfIncrement=maxDelta + increment / 2.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) p$1.encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA.apply(this, [this.mGraphAtom[i], (this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]], maxDeltaPlusHalfIncrement, increment, resolutionBits, coords]);

if (includeHydrogenCoordinates) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) p$1.encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA.apply(this, [this.mMol.getConnAtom$I$I(atom, j), atom, maxDeltaPlusHalfIncrement, increment, resolutionBits, coords]);

}
}if (keepPositionAndScale) {
var avblDefault=this.mZCoordinatesAvailable ? 1.5 : $I$(10).getDefaultAverageBondLength$();
var avbl=this.mMol.getAverageBondLength$I$I$D$com_actelion_research_chem_CoordinatesA(includeHydrogenCoordinates ? this.mMol.getAllAtoms$() : this.mMol.getAtoms$(), includeHydrogenCoordinates ? this.mMol.getAllBonds$() : this.mMol.getBonds$(), avblDefault, coords);
p$1.encodeBits$J$I.apply(this, [p$1.encodeABVL$D$I.apply(this, [avbl, binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].x / avbl, binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].y / avbl, binCount]), resolutionBits]);
if (this.mZCoordinatesAvailable) p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].z / avbl, binCount]), resolutionBits]);
}this.mEncodedCoords=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA',  function (atom, from, maxDelta, coords) {
var deltaX=(from == -1) ? Math.abs(coords[atom].x - coords[this.mGraphAtom[0]].x) / 8.0 : Math.abs(coords[atom].x - coords[from].x);
if (maxDelta < deltaX ) maxDelta=deltaX;
var deltaY=(from == -1) ? Math.abs(coords[atom].y - coords[this.mGraphAtom[0]].y) / 8.0 : Math.abs(coords[atom].y - coords[from].y);
if (maxDelta < deltaY ) maxDelta=deltaY;
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? Math.abs(coords[atom].z - coords[this.mGraphAtom[0]].z) / 8.0 : Math.abs(coords[atom].z - coords[from].z);
if (maxDelta < deltaZ ) maxDelta=deltaZ;
}return maxDelta;
}, p$1);

Clazz_newMeth(C$, 'encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA',  function (atom, from, maxDeltaPlusHalfIncrement, increment, resolutionBits, coords) {
var deltaX=(from == -1) ? (coords[atom].x - coords[this.mGraphAtom[0]].x) / 8.0 : coords[atom].x - coords[from].x;
var deltaY=(from == -1) ? (coords[atom].y - coords[this.mGraphAtom[0]].y) / 8.0 : coords[atom].y - coords[from].y;
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaX) / increment)|0), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaY) / increment)|0), resolutionBits]);
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? (coords[atom].z - coords[this.mGraphAtom[0]].z) / 8.0 : coords[atom].z - coords[from].z;
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaZ) / increment)|0), resolutionBits]);
}}, p$1);

Clazz_newMeth(C$, 'encodeABVL$D$I',  function (value, binCount) {
return Math.min(binCount - 1, Math.max(0, ((0.5 + Math.log10(value / 0.1) / Math.log10(2000.0) * (binCount - 1))|0)));
}, p$1);

Clazz_newMeth(C$, 'encodeShift$D$I',  function (value, binCount) {
var halfBinCount=(binCount/2|0);
var isNegative=(value < 0 );
value=Math.abs(value);
var steepness=(binCount/32|0);
var intValue=Math.min(halfBinCount - 1, Long.$ival(Math.round$D(value * halfBinCount / (value + steepness))));
return isNegative ? halfBinCount + intValue : intValue;
}, p$1);

Clazz_newMeth(C$, 'getEncodedMapping$',  function () {
if (this.mMapping == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeMapping.apply(this, []);
}return this.mMapping;
});

Clazz_newMeth(C$, 'encodeMapping',  function () {
if (this.mMol.getAtoms$() == 0) {
this.mMapping="";
return;
}var maxMapNo=0;
var autoMappingFound=false;
var manualMappingFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (maxMapNo < this.mMol.getAtomMapNo$I(atom)) maxMapNo=this.mMol.getAtomMapNo$I(atom);
if (this.mMol.isAutoMappedAtom$I(atom)) autoMappingFound=true;
 else manualMappingFound=true;
}
if (maxMapNo == 0) {
this.mMapping="";
return;
}var nbits=C$.getNeededBits$I(maxMapNo);
p$1.encodeBitsStart$Z.apply(this, [true]);
p$1.encodeBits$J$I.apply(this, [nbits, 4]);
p$1.encodeBits$J$I.apply(this, [autoMappingFound ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [manualMappingFound ? 1 : 0, 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomMapNo$I(this.mGraphAtom[atom]), nbits]);
if (autoMappingFound && manualMappingFound ) p$1.encodeBits$J$I.apply(this, [this.mMol.isAutoMappedAtom$I(this.mGraphAtom[atom]) ? 1 : 0, 1]);
}
this.mMapping=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'idGenerateConfigurations',  function () {
this.mTHConfiguration=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) {
var inversion=this.mTHParityIsMesoInverted[atom];
if (this.mMol.isCentralAlleneAtom$I(atom)) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var neighbours=0;
var neighbour=Clazz_array(Integer.TYPE, [3]);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) {
neighbour[neighbours]=this.mMol.getConnAtom$I$I(connAtom, j);
if (neighbour[neighbours] != atom) ++neighbours;
}
if (neighbours == 2 && (!!((this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) ^ (this.mGraphIndex[neighbour[0]] < this.mGraphIndex[neighbour[1]]))) ) inversion=!inversion;
}
} else {
for (var i=1; i < this.mMol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var connAtom1=this.mMol.getConnAtom$I$I(atom, i);
var connAtom2=this.mMol.getConnAtom$I$I(atom, j);
if (this.mCanRank[connAtom1] > this.mCanRank[connAtom2]) inversion=!inversion;
if (this.mGraphIndex[connAtom1] < this.mGraphIndex[connAtom2]) inversion=!inversion;
}
}
}this.mTHConfiguration[atom]=(!!((this.mTHParity[atom] == 1) ^ inversion)) ? 1 : (2|0);
} else {
this.mTHConfiguration[atom]=this.mTHParity[atom];
}}
this.mEZConfiguration=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) {
var inversion=false;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var neighbour=Clazz_array(Integer.TYPE, [2]);
var neighbours=0;
for (var j=0; j < 3; j++) if (this.mMol.getConnAtom$I$I(bondAtom, j) != this.mMol.getBondAtom$I$I(1 - i, bond)) neighbour[neighbours++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) inversion=!inversion;
if (this.mGraphIndex[neighbour[0]] < this.mGraphIndex[neighbour[1]]) inversion=!inversion;
}}
this.mEZConfiguration[bond]=(!!((this.mEZParity[bond] == 1) ^ inversion)) ? 1 : (2|0);
} else {
this.mEZConfiguration[bond]=this.mEZParity[bond];
}}
}, p$1);

Clazz_newMeth(C$, 'idNormalizeESRGroupNumbers',  function () {
p$1.idNormalizeESRGroupNumbers$I.apply(this, [1]);
p$1.idNormalizeESRGroupNumbers$I.apply(this, [2]);
}, p$1);

Clazz_newMeth(C$, 'idNormalizeESRGroupNumbers$I',  function (type) {
var groupRank=Clazz_array(Integer.TYPE, [32]);
var groups=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if ((this.mTHConfiguration[atom] == 1 || this.mTHConfiguration[atom] == 2 ) && this.mTHESRType[atom] == type ) {
var group=this.mTHESRGroup[atom];
if (groupRank[group] < this.mCanRank[atom]) {
if (groupRank[group] == 0) ++groups;
groupRank[group]=this.mCanRank[atom];
}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if ((this.mEZConfiguration[bond] == 1 || this.mEZConfiguration[bond] == 2 ) && this.mEZESRType[bond] == type  && this.mMol.getBondType$I(bond) == 1 ) {
var group=this.mEZESRGroup[bond];
var rank=Math.max(this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)], this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]);
if (groupRank[group] < rank) {
if (groupRank[group] == 0) ++groups;
groupRank[group]=rank;
}}}
var canGroup=Clazz_array(Byte.TYPE, [32]);
for (var i=0; i < groups; i++) {
var maxGroup=-1;
var maxRank=0;
for (var j=0; j < 32; j++) {
if (maxRank < groupRank[j]) {
maxRank=groupRank[j];
maxGroup=j;
}}
groupRank[maxGroup]=0;
canGroup[maxGroup]=(i|0);
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if ((this.mTHConfiguration[atom] == 1 || this.mTHConfiguration[atom] == 2 ) && this.mTHESRType[atom] == type ) this.mTHESRGroup[atom]=canGroup[this.mTHESRGroup[atom]];

for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mEZConfiguration[bond] == 1 || this.mEZConfiguration[bond] == 2 ) && this.mEZESRType[bond] == type  && this.mMol.getBondType$I(bond) == 1 ) this.mEZESRGroup[bond]=canGroup[this.mEZESRGroup[bond]];

}, p$1);

Clazz_newMeth(C$, 'encodeBitsStart$Z',  function (avoid127) {
this.mEncodingBuffer=Clazz_new_($I$(11,1));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
this.mEncodeAvoid127=avoid127;
}, p$1);

Clazz_newMeth(C$, 'encodeFeatureNo$I',  function (codeNo) {
for (var i=0; i < this.mFeatureBlock; i++) codeNo-=16;

if (codeNo < 0) System.out.println$S("ERROR in Canonizer: Code unexpectedly low.");
while (codeNo > 15){
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [15, 4]);
codeNo-=16;
++this.mFeatureBlock;
}
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [codeNo, 4]);
}, p$1);

Clazz_newMeth(C$, 'encodeBits$J$I',  function (data, bits) {
while (bits != 0){
if (this.mEncodingBitsAvail == 0) {
if (!this.mEncodeAvoid127 || this.mEncodingTempData != 63 ) this.mEncodingTempData+=64;
this.mEncodingBuffer.append$C(String.fromCharCode(this.mEncodingTempData));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
}this.mEncodingTempData<<=1;
this.mEncodingTempData=Long.$ival(Long.$or(this.mEncodingTempData,((Long.$and(data,1)))));
(data=Long.$sr(data,(1)));
--bits;
--this.mEncodingBitsAvail;
}
}, p$1);

Clazz_newMeth(C$, 'encodeBitsEnd',  function () {
this.mEncodingTempData<<=this.mEncodingBitsAvail;
if (!this.mEncodeAvoid127 || this.mEncodingTempData != 63 ) this.mEncodingTempData+=64;
this.mEncodingBuffer.append$C(String.fromCharCode(this.mEncodingTempData));
return this.mEncodingBuffer.toString();
}, p$1);

Clazz_newMeth(C$, 'getNeededBits$I',  function (maxNo) {
var bits=0;
while (maxNo > 0){
maxNo>>=1;
++bits;
}
return bits;
}, 1);

Clazz_newMeth(C$, 'getTHParity$I',  function (atom) {
return this.mTHParity[atom];
});

Clazz_newMeth(C$, 'getEZParity$I',  function (bond) {
return this.mEZParity[bond];
});

Clazz_newMeth(C$, 'getPseudoStereoGroupCount$',  function () {
return this.mNoOfPseudoGroups;
});

Clazz_newMeth(C$, 'getPseudoEZGroup$I',  function (bond) {
return this.mPseudoEZGroup[bond];
});

Clazz_newMeth(C$, 'getPseudoTHGroup$I',  function (atom) {
return this.mPseudoTHGroup[atom];
});

Clazz_newMeth(C$, 'normalizeEnantiomer$',  function () {
var parityCount=Clazz_array(Integer.TYPE, [this.mNoOfRanks + 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomESRType$I(atom) == 0) {
if (this.mTHParity[atom] == 1) ++parityCount[this.mCanRank[atom]];
 else if (this.mTHParity[atom] == 2) --parityCount[this.mCanRank[atom]];
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1 && this.mMol.getBondESRType$I(bond) == 0 ) {
if (this.mEZParity[bond] == 1) {
++parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)]];
++parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]];
} else if (this.mEZParity[bond] == 2) {
--parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)]];
--parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]];
}}}
for (var rank=1; rank <= this.mNoOfRanks; rank++) {
if (parityCount[rank] != 0) {
var invert=(parityCount[rank] < 0);
if (invert) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomESRType$I(atom) == 0) {
if (this.mTHParity[atom] == 1) this.mTHParity[atom]=(2|0);
 else if (this.mTHParity[atom] == 2) this.mTHParity[atom]=(1|0);
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1 && this.mMol.getBondESRType$I(bond) == 0 ) {
if (this.mEZParity[bond] == 1) this.mEZParity[bond]=(2|0);
 else if (this.mEZParity[bond] == 2) this.mEZParity[bond]=(1|0);
}}
}return invert;
}}
return false;
});

Clazz_newMeth(C$, 'setParities$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) {
var inversion=false;
if (this.mMol.isCentralAlleneAtom$I(atom)) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var neighbours=0;
var neighbour=Clazz_array(Integer.TYPE, [3]);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) {
neighbour[neighbours]=this.mMol.getConnAtom$I$I(connAtom, j);
if (neighbour[neighbours] != atom) ++neighbours;
}
if (neighbours == 2 && (!!((this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) ^ (neighbour[0] < neighbour[1]))) ) inversion=!inversion;
}
} else {
for (var i=1; i < this.mMol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var connAtom1=this.mMol.getConnAtom$I$I(atom, i);
var connAtom2=this.mMol.getConnAtom$I$I(atom, j);
if (this.mCanRank[connAtom1] > this.mCanRank[connAtom2]) inversion=!inversion;
if (connAtom1 < connAtom2) inversion=!inversion;
}
}
}this.mMol.setAtomParity$I$I$Z(atom, (!!((this.mTHParity[atom] == 1) ^ inversion)) ? 1 : 2, this.mTHParityIsPseudo[atom]);
} else {
this.mMol.setAtomParity$I$I$Z(atom, this.mTHParity[atom], this.mTHParityIsPseudo[atom]);
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) {
var inversion=false;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var neighbour=Clazz_array(Integer.TYPE, [2]);
var neighbours=0;
for (var j=0; j < 3; j++) if (this.mMol.getConnAtom$I$I(bondAtom, j) != this.mMol.getBondAtom$I$I(1 - i, bond)) neighbour[neighbours++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) inversion=!inversion;
if (neighbour[0] < neighbour[1]) inversion=!inversion;
}}
this.mMol.setBondParity$I$I$Z(bond, (!!((this.mEZParity[bond] == 1) ^ inversion)) ? 1 : 2, this.mEZParityIsPseudo[bond]);
} else {
this.mMol.setBondParity$I$I$Z(bond, this.mEZParity[bond], this.mEZParityIsPseudo[bond]);
}}
});

Clazz_newMeth(C$, 'setStereoCenters$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mMol.setAtomStereoCenter$I$Z(atom, this.mIsStereoCenter[atom]);
}
});

Clazz_newMeth(C$, 'setCIPParities$',  function () {
if (this.mTHCIPParity != null ) for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mMol.setAtomCIPParity$I$I(atom, this.mTHCIPParity[atom]);

if (this.mEZCIPParity != null ) for (var bond=0; bond < this.mMol.getBonds$(); bond++) this.mMol.setBondCIPParity$I$I(bond, this.mEZCIPParity[bond]);

});

Clazz_newMeth(C$, 'cipCalcTHParity$I',  function (atom) {
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 )) {
var invertedOrder=false;
if (this.mMol.getAtomPi$I(atom) == 2) {
try {
for (var i=0; i < 2; i++) {
var alleneAtom=this.mMol.getConnAtom$I$I(atom, i);
if (this.mMol.getConnAtoms$I(alleneAtom) == 3) {
var connAtom=Clazz_array(Integer.TYPE, [2]);
var count=0;
for (var j=0; j < this.mMol.getConnAtoms$I(alleneAtom); j++) if (this.mMol.getConnBondOrder$I$I(alleneAtom, j) == 1) connAtom[count++]=this.mMol.getConnAtom$I$I(alleneAtom, j);

if (!!((this.mCanRank[connAtom[0]] > this.mCanRank[connAtom[1]]) ^ p$1.cipComparePriority$I$I$I.apply(this, [alleneAtom, connAtom[0], connAtom[1]]))) invertedOrder=!invertedOrder;
}}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mTHCIPParity[atom]=(3|0);
return;
} else {
throw e;
}
}
} else {
var cipConnAtom;
try {
cipConnAtom=p$1.cipGetOrderedConns$I.apply(this, [atom]);
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mTHCIPParity[atom]=(3|0);
return;
} else {
throw e;
}
}
for (var i=1; i < cipConnAtom.length; i++) for (var j=0; j < i; j++) if (this.mCanRank[cipConnAtom[i]] < this.mCanRank[cipConnAtom[j]]) invertedOrder=!invertedOrder;


}if (!!((this.mTHParity[atom] == 1) ^ invertedOrder)) this.mTHCIPParity[atom]=(1|0);
 else this.mTHCIPParity[atom]=(2|0);
}}, p$1);

Clazz_newMeth(C$, 'cipCalcEZParity$I',  function (bond) {
if ((this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) && !this.mMol.isSmallRingBond$I(bond) ) {
var invertedOrder=false;
try {
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var connAtom=Clazz_array(Integer.TYPE, [2]);
var count=0;
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) if (this.mMol.getConnBond$I$I(bondAtom, j) != bond) connAtom[count++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (!!((this.mCanRank[connAtom[0]] > this.mCanRank[connAtom[1]]) ^ p$1.cipComparePriority$I$I$I.apply(this, [bondAtom, connAtom[0], connAtom[1]]))) invertedOrder=!invertedOrder;
}}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mEZCIPParity[bond]=(3|0);
return;
} else {
throw e;
}
}
if (!!((this.mEZParity[bond] == 1) ^ invertedOrder)) this.mEZCIPParity[bond]=(1|0);
 else this.mEZCIPParity[bond]=(2|0);
}}, p$1);

Clazz_newMeth(C$, 'cipGetOrderedConns$I',  function (atom) {
var noOfConns=this.mMol.getAllConnAtoms$I(atom);
var orderedConn=Clazz_array(Integer.TYPE, [noOfConns]);
for (var i=0; i < noOfConns; i++) orderedConn[i]=this.mMol.getConnAtom$I$I(atom, i);

for (var i=noOfConns; i > 1; i--) {
var found=false;
for (var j=1; j < i; j++) {
if (p$1.cipComparePriority$I$I$I.apply(this, [atom, orderedConn[j - 1], orderedConn[j]])) {
found=true;
var temp=orderedConn[j - 1];
orderedConn[j - 1]=orderedConn[j];
orderedConn[j]=temp;
}}
if (!found) break;
}
return orderedConn;
}, p$1);

Clazz_newMeth(C$, 'cipComparePriority$I$I$I',  function (rootAtom, atom1, atom2) {
if (this.mMol.getAtomicNo$I(atom1) != this.mMol.getAtomicNo$I(atom2)) return (this.mMol.getAtomicNo$I(atom1) > this.mMol.getAtomicNo$I(atom2));
if (this.mMol.getAtomMass$I(atom1) != this.mMol.getAtomMass$I(atom2)) {
var mass1=this.mMol.isNaturalAbundance$I(atom1) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom1)] : this.mMol.getAtomMass$I(atom1);
var mass2=this.mMol.isNaturalAbundance$I(atom2) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom2)] : this.mMol.getAtomMass$I(atom2);
return (mass1 > mass2);
}var graphSize=this.mMol.getAtoms$();
var graphAtom=Clazz_array(Integer.TYPE, [graphSize]);
var graphParent=Clazz_array(Integer.TYPE, [graphSize]);
var graphRank=Clazz_array(Integer.TYPE, [graphSize]);
var graphIsPseudo=Clazz_array(Boolean.TYPE, [graphSize]);
var atomUsed=Clazz_array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
graphAtom[0]=rootAtom;
graphAtom[1]=atom1;
graphAtom[2]=atom2;
graphParent[0]=-1;
graphParent[1]=0;
graphParent[2]=0;
atomUsed[rootAtom]=true;
atomUsed[atom1]=true;
atomUsed[atom2]=true;
var current=1;
var highest=2;
var levelStart=Clazz_array(Integer.TYPE, [64]);
levelStart[1]=1;
levelStart[2]=3;
var currentLevel=2;
while (current <= highest){
while (current < levelStart[currentLevel]){
var currentAtom=graphAtom[current];
if (!graphIsPseudo[current]) {
var delocalizedBondCount=0;
var delocalizedMeanAtomicNo=0;
for (var i=0; i < this.mMol.getConnAtoms$I(currentAtom); i++) {
var candidate=this.mMol.getConnAtom$I$I(currentAtom, i);
if (highest + this.mMol.getConnBondOrder$I$I(currentAtom, i) + 1  >= graphSize) {
graphSize+=this.mMol.getAtoms$();
graphAtom=p$1.resize$IA$I.apply(this, [graphAtom, graphSize]);
graphParent=p$1.resize$IA$I.apply(this, [graphParent, graphSize]);
graphRank=p$1.resize$IA$I.apply(this, [graphRank, graphSize]);
graphIsPseudo=p$1.resize$ZA$I.apply(this, [graphIsPseudo, graphSize]);
}if (this.mMol.isDelocalizedBond$I(this.mMol.getConnBond$I$I(currentAtom, i))) {
++delocalizedBondCount;
delocalizedMeanAtomicNo+=this.mMol.getAtomicNo$I(candidate);
} else {
for (var j=1; j < this.mMol.getConnBondOrder$I$I(currentAtom, i); j++) {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
graphIsPseudo[highest]=true;
}
}var parentGraphIndex=graphParent[current];
if (candidate == graphAtom[parentGraphIndex]) continue;
var atomInParentChain=false;
if (atomUsed[candidate]) {
var parent=graphParent[parentGraphIndex];
while (parent != -1){
if (candidate == graphAtom[parent]) {
atomInParentChain=true;
break;
}parent=graphParent[parent];
}
}if (atomInParentChain) {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
graphIsPseudo[highest]=true;
} else {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
atomUsed[candidate]=true;
}}
if (delocalizedBondCount != 0) {
++highest;
graphRank[highest]=((delocalizedMeanAtomicNo << 2)/delocalizedBondCount|0);
graphParent[highest]=current;
graphIsPseudo[highest]=true;
}}++current;
if (current == 10000) {
throw Clazz_new_(Clazz_load('Exception').c$$S,["Emergency break in while loop."]);
}}
if (levelStart.length == currentLevel + 1) levelStart=p$1.resize$IA$I.apply(this, [levelStart, levelStart.length + 64]);
levelStart[currentLevel + 1]=highest + 1;
for (var i=levelStart[currentLevel]; i < levelStart[currentLevel + 1]; i++) {
if (graphRank[i] == 0) graphRank[i]=(this.mMol.getAtomicNo$I(graphAtom[i]) == 151 ? 1 : this.mMol.getAtomicNo$I(graphAtom[i]) == 152 ? 1 : this.mMol.getAtomicNo$I(graphAtom[i])) << 2;
graphRank[i]+=(graphRank[graphParent[i]] << 16);
}
p$1.cipUpdateParentRanking$ZA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, currentLevel]);
if (graphRank[1] != graphRank[2]) return (graphRank[1] > graphRank[2]);
if (currentLevel > 1) p$1.cipCompileRelativeRanks$IA$IA$IA$I.apply(this, [graphRank, graphParent, levelStart, currentLevel]);
++currentLevel;
}
var cipRank=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var isotopDataFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (atomUsed[atom] && !this.mMol.isNaturalAbundance$I(atom) ) {
isotopDataFound=true;
break;
}}
if (isotopDataFound) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) cipRank[atom]=this.mMol.isNaturalAbundance$I(atom) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom)] : this.mMol.getAtomMass$I(atom);

if (p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel])) return (graphRank[1] > graphRank[2]);
}$I$(1).fill$IA$I(cipRank, 0);
var ezDataFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (atomUsed[this.mMol.getBondAtom$I$I(0, bond)] || atomUsed[this.mMol.getBondAtom$I$I(1, bond)] ) {
if (this.mEZCIPParity[bond] == 1) {
cipRank[this.mMol.getBondAtom$I$I(0, bond)]=1;
cipRank[this.mMol.getBondAtom$I$I(1, bond)]=1;
ezDataFound=true;
} else if (this.mEZCIPParity[bond] == 2) {
cipRank[this.mMol.getBondAtom$I$I(0, bond)]=2;
cipRank[this.mMol.getBondAtom$I$I(1, bond)]=2;
ezDataFound=true;
}}}
if (ezDataFound && p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel]) ) return (graphRank[1] > graphRank[2]);
$I$(1).fill$IA$I(cipRank, 0);
var rsDataFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (atomUsed[atom]) {
if (this.mTHCIPParity[atom] == 2) {
cipRank[atom]=1;
rsDataFound=true;
} else if (this.mTHCIPParity[atom] == 1) {
cipRank[atom]=2;
rsDataFound=true;
}}}
if (rsDataFound && p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel]) ) return (graphRank[1] > graphRank[2]);
this.mCIPParityNoDistinctionProblem=true;
throw Clazz_new_(Clazz_load('Exception').c$$S,["no distinction applying CIP rules"]);
}, p$1);

Clazz_newMeth(C$, 'cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I',  function (graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel) {
for (var level=1; level < currentLevel; level++) {
for (var i=levelStart[level]; i < levelStart[level + 1]; i++) graphRank[i]=cipRank[graphAtom[i]] + (graphRank[graphParent[i]] << 8);

p$1.cipUpdateParentRanking$ZA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, level]);
if (graphRank[1] != graphRank[2]) return true;
if (level > 1) p$1.cipCompileRelativeRanks$IA$IA$IA$I.apply(this, [graphRank, graphParent, levelStart, level]);
}
return false;
}, p$1);

Clazz_newMeth(C$, 'resize$IA$I',  function (array, newSize) {
var copy=Clazz_array(Integer.TYPE, [newSize]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, p$1);

Clazz_newMeth(C$, 'resize$ZA$I',  function (array, newSize) {
var copy=Clazz_array(Boolean.TYPE, [newSize]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, p$1);

Clazz_newMeth(C$, 'cipUpdateParentRanking$ZA$IA$IA$IA$IA$I',  function (graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, currentLevel) {
for (var level=currentLevel; level > 1; level--) {
var parentCount=levelStart[level] - levelStart[level - 1];
var rankObject=Clazz_array($I$(12), [parentCount]);
var baseIndex=levelStart[level];
for (var parent=0; parent < parentCount; parent++) {
var parentIndex=levelStart[level - 1] + parent;
var nextBaseIndex=baseIndex;
while (nextBaseIndex < levelStart[level + 1] && graphParent[nextBaseIndex] == parentIndex )++nextBaseIndex;

rankObject[parent]=Clazz_new_(P$.Canonizer$1RankObject.$init$,[this, null]);
rankObject[parent].parentIndex=parentIndex;
rankObject[parent].parentRank=graphRank[parentIndex];
rankObject[parent].parentHCount=graphIsPseudo[parentIndex] ? 0 : this.mMol.getPlainHydrogens$I(graphAtom[parentIndex]);
rankObject[parent].childRank=Clazz_array(Integer.TYPE, [nextBaseIndex - baseIndex]);
for (var i=baseIndex; i < nextBaseIndex; i++) rankObject[parent].childRank[i - baseIndex]=graphRank[i];

$I$(1).sort$IA(rankObject[parent].childRank);
baseIndex=nextBaseIndex;
}
var comparator=((P$.Canonizer$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "Canonizer$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, ['compare$com_actelion_research_chem_Canonizer$1RankObject$com_actelion_research_chem_Canonizer$1RankObject','compare$O$O'],  function (r1, r2) {
if (r1.parentRank != r2.parentRank) return (r1.parentRank > r2.parentRank) ? 1 : -1;
var i1=r1.childRank.length;
var i2=r2.childRank.length;
var count=Math.min(i1, i2);
for (var i=0; i < count; i++) {
--i1;
--i2;
if (r1.childRank[i1] != r2.childRank[i2]) return (r1.childRank[i1] > r2.childRank[i2]) ? 1 : -1;
}
if (i1 != i2) return (i1 > i2) ? 1 : -1;
if (r1.parentHCount != r2.parentHCount) return (r1.parentHCount > r2.parentHCount) ? 1 : -1;
return 0;
});
})()
), Clazz_new_(P$.Canonizer$1.$init$,[this, null]));
$I$(1).sort$OA$java_util_Comparator(rankObject, comparator);
var consolidatedRank=1;
for (var parent=0; parent < parentCount; parent++) {
graphRank[rankObject[parent].parentIndex]=consolidatedRank;
if (parent != parentCount - 1 && comparator.compare$O$O(rankObject[parent], rankObject[parent + 1]) != 0 ) ++consolidatedRank;
}
}
}, p$1);

Clazz_newMeth(C$, 'cipCompileRelativeRanks$IA$IA$IA$I',  function (graphRank, graphParent, levelStart, currentLevel) {
var levelOffset=levelStart[currentLevel];
var count=levelStart[currentLevel + 1] - levelOffset;
var rankObject=Clazz_array($I$(13), [count]);
for (var i=0; i < count; i++) {
rankObject[i]=Clazz_new_(P$.Canonizer$2RankObject.$init$,[this, null]);
rankObject[i].rank=graphRank[i + levelOffset];
rankObject[i].parent=graphParent[i + levelOffset];
rankObject[i].index=i + levelOffset;
}
var comparator=((P$.Canonizer$2||
(function(){/*a*/var C$=Clazz_newClass(P$, "Canonizer$2", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, ['compare$com_actelion_research_chem_Canonizer$2RankObject$com_actelion_research_chem_Canonizer$2RankObject','compare$O$O'],  function (r1, r2) {
if (r1.rank != r2.rank) return (r1.rank > r2.rank) ? 1 : -1;
return 0;
});
})()
), Clazz_new_(P$.Canonizer$2.$init$,[this, null]));
for (var level=currentLevel; level > 1; level--) {
for (var i=0; i < count; i++) {
rankObject[i].rank+=(graphRank[rankObject[i].parent] << 16);
rankObject[i].parent=graphParent[rankObject[i].parent];
}
$I$(1).sort$OA$java_util_Comparator(rankObject, comparator);
var consolidatedRank=1;
for (var i=0; i < count; i++) {
graphRank[rankObject[i].index]=consolidatedRank;
if (i != count - 1 && comparator.compare$O$O(rankObject[i], rankObject[i + 1]) != 0 ) ++consolidatedRank;
}
}
}, p$1);

Clazz_newMeth(C$, 'getGraphAtoms$',  function () {
p$1.generateGraph.apply(this, []);
return this.mGraphAtom;
});

Clazz_newMeth(C$, 'getGraphIndexes$',  function () {
p$1.generateGraph.apply(this, []);
return this.mGraphIndex;
});
var $b$ = new Int8Array(1);
var $k$;
;
(function(){/*l*/var C$=Clazz_newClass(P$, "Canonizer$1RankObject", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, null, 2);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['parentIndex','parentRank','parentHCount'],'O',['childRank','int[]']]]

Clazz_newMeth(C$);
})()
;
(function(){/*l*/var C$=Clazz_newClass(P$, "Canonizer$2RankObject", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, null, 2);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['rank','parent','index']]]

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.Canonizer, "ESRGroup", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['atomList','int[]','+rankList']]]

Clazz_newMeth(C$, 'c$$I$I',  function (type, group) {
;C$.$init$.apply(this);
var count=0;
for (var atom=0; atom < this.b$['com.actelion.research.chem.Canonizer'].mMol.getAtoms$(); atom++) if (this.b$['com.actelion.research.chem.Canonizer'].mTHESRType[atom] == type && this.b$['com.actelion.research.chem.Canonizer'].mTHESRGroup[atom] == group ) ++count;

this.atomList=Clazz_array(Integer.TYPE, [count]);
this.rankList=Clazz_array(Integer.TYPE, [count]);
count=0;
for (var atom=0; atom < this.b$['com.actelion.research.chem.Canonizer'].mMol.getAtoms$(); atom++) {
if (this.b$['com.actelion.research.chem.Canonizer'].mTHESRType[atom] == type && this.b$['com.actelion.research.chem.Canonizer'].mTHESRGroup[atom] == group ) {
this.atomList[count]=atom;
this.rankList[count++]=this.b$['com.actelion.research.chem.Canonizer'].mCanRank[atom];
}}
$I$(1).sort$IA(this.rankList);
}, 1);

Clazz_newMeth(C$, ['compareTo$com_actelion_research_chem_Canonizer_ESRGroup','compareTo$O'],  function (g) {
if (this.rankList.length != g.rankList.length) return this.rankList.length < g.rankList.length ? -1 : 1;
for (var i=0; i < this.rankList.length; i++) if (this.rankList[i] != g.rankList[i]) return this.rankList[i] < g.rankList[i] ? -1 : 1;

return 0;
});

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "CanonizerBaseValue", null, null, 'Comparable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAtom','mIndex','mAvailableBits'],'O',['mValue','long[]']]]

Clazz_newMeth(C$, 'c$$I',  function (size) {
;C$.$init$.apply(this);
this.mValue=Clazz_array(Long.TYPE, [size]);
}, 1);

Clazz_newMeth(C$, 'init$I',  function (atom) {
this.mAtom=atom;
this.mIndex=0;
this.mAvailableBits=63;
$I$(1).fill$JA$J(this.mValue, 0);
});

Clazz_newMeth(C$, 'add$J',  function (data) {
(this.mValue[$k$=this.mIndex]=Long.$add(this.mValue[$k$],(data)));
});

Clazz_newMeth(C$, 'add$I$J',  function (bits, data) {
if (this.mAvailableBits == 0) {
++this.mIndex;
this.mAvailableBits=63;
}if (this.mAvailableBits == 63) {
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],(data)));
this.mAvailableBits-=bits;
} else {
if (this.mAvailableBits >= bits) {
(this.mValue[$k$=this.mIndex]=Long.$sl(this.mValue[$k$],(bits)));
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],(data)));
this.mAvailableBits-=bits;
} else {
(this.mValue[$k$=this.mIndex]=Long.$sl(this.mValue[$k$],(this.mAvailableBits)));
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],((Long.$sr(data,(bits - this.mAvailableBits))))));
bits-=this.mAvailableBits;
++this.mIndex;
this.mAvailableBits=63 - bits;
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],((Long.$and(data,((1 << bits) - 1))))));
}}});

Clazz_newMeth(C$, 'getAtom$',  function () {
return this.mAtom;
});

Clazz_newMeth(C$, ['compareTo$com_actelion_research_chem_CanonizerBaseValue','compareTo$O'],  function (b) {
Clazz_assert(C$, this, function(){return (this.mIndex == b.mIndex)});
for (var i=0; i < this.mIndex; i++) if (Long.$ne(this.mValue[i],b.mValue[i] )) return (Long.$lt(this.mValue[i],b.mValue[i] )) ? -1 : 1;

return (Long.$eq(this.mValue[this.mIndex],b.mValue[this.mIndex] )) ? 0 : (Long.$lt(this.mValue[this.mIndex],b.mValue[this.mIndex] )) ? -1 : 1;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
var $k$;

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "DepictorTransformation");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mOffsetX','mOffsetY','mScaling']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.clear$();
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_DepictorTransformation',  function (t) {
;C$.$init$.apply(this);
this.mScaling=t.mScaling;
this.mOffsetX=t.mOffsetX;
this.mOffsetY=t.mOffsetY;
}, 1);

Clazz_newMeth(C$, 'c$$D$D$D',  function (scaling, offsetX, offsetY) {
;C$.$init$.apply(this);
this.mScaling=scaling;
this.mOffsetX=offsetX;
this.mOffsetY=offsetY;
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_gui_generic_GenericRectangle$com_actelion_research_gui_generic_GenericRectangle$D$I',  function (bounds, view, averageBondLength, mode) {
;C$.$init$.apply(this);
this.clear$();
if (view != null ) {
if ((mode & 196608) == 0) {
if (!view.contains$com_actelion_research_gui_generic_GenericRectangle(bounds)) {
if ((bounds.width > view.width ) || (bounds.height > view.height ) ) {
var hScaling=view.width / bounds.width;
var vScaling=view.height / bounds.height;
this.mScaling=Math.min(hScaling, vScaling);
}if (bounds.x * this.mScaling < view.x ) this.mOffsetX=view.x - bounds.x * this.mScaling;
 else if ((bounds.x + bounds.width) * this.mScaling > view.x + view.width ) this.mOffsetX=view.x + view.width - (bounds.x + bounds.width) * this.mScaling;
if (bounds.y * this.mScaling < view.y ) this.mOffsetY=view.y - bounds.y * this.mScaling;
 else if ((bounds.y + bounds.height) * this.mScaling > view.y + view.height ) this.mOffsetY=view.y + view.height - (bounds.y + bounds.height) * this.mScaling;
}} else {
var hScaling=view.width / bounds.width;
var vScaling=view.height / bounds.height;
var maxAVBL=mode & 65535;
if (maxAVBL == 0 ) maxAVBL=24;
 else if ((mode & 131072) != 0) maxAVBL/=256;
var bScaling=maxAVBL / averageBondLength;
this.mScaling=Math.min(bScaling, Math.min(hScaling, vScaling));
this.mOffsetX=view.x + view.width / 2.0 - this.mScaling * (bounds.x + bounds.width / 2.0);
this.mOffsetY=view.y + view.height / 2.0 - this.mScaling * (bounds.y + bounds.height / 2.0);
}} else if ((mode & 65536) != 0) {
var maxAVBL=((mode & 65535) != 0) ? mode & 65535 : 24;
this.mScaling=maxAVBL / averageBondLength;
}}, 1);

Clazz_newMeth(C$, 'clear$',  function () {
this.mOffsetX=0.0;
this.mOffsetY=0.0;
this.mScaling=1.0;
});

Clazz_newMeth(C$, 'transformX$D',  function (x) {
return x * this.mScaling + this.mOffsetX;
});

Clazz_newMeth(C$, 'transformY$D',  function (y) {
return y * this.mScaling + this.mOffsetY;
});

Clazz_newMeth(C$, 'getScaling$',  function () {
return this.mScaling;
});

Clazz_newMeth(C$, 'getOffsetX$',  function () {
return this.mOffsetX;
});

Clazz_newMeth(C$, 'getOffsetY$',  function () {
return this.mOffsetY;
});

Clazz_newMeth(C$, 'move$D$D',  function (dx, dy) {
this.mOffsetX+=dx;
this.mOffsetY+=dy;
});

Clazz_newMeth(C$, 'setScaling$D',  function (scale) {
this.mScaling=scale;
});

Clazz_newMeth(C$, 'isVoidTransformation$',  function () {
return (this.mScaling == 1.0  && this.mOffsetX == 0.0   && this.mOffsetY == 0.0  );
});

Clazz_newMeth(C$, 'applyTo$com_actelion_research_chem_DepictorTransformation',  function (t) {
t.mScaling*=this.mScaling;
t.mOffsetX=t.mOffsetX * this.mScaling + this.mOffsetX;
t.mOffsetY=t.mOffsetY * this.mScaling + this.mOffsetY;
});

Clazz_newMeth(C$, 'applyTo$com_actelion_research_gui_generic_GenericPoint',  function (p) {
p.x=p.x * this.mScaling + this.mOffsetX;
p.y=p.y * this.mScaling + this.mOffsetY;
});

Clazz_newMeth(C$, 'applyTo$com_actelion_research_gui_generic_GenericRectangle',  function (r) {
r.x=r.x * this.mScaling + this.mOffsetX;
r.y=r.y * this.mScaling + this.mOffsetY;
r.width*=this.mScaling;
r.height*=this.mScaling;
});

Clazz_newMeth(C$, 'applyTo$com_actelion_research_chem_Molecule',  function (m) {
m.scaleCoords$D(this.mScaling);
m.translateCoords$D$D(this.mOffsetX, this.mOffsetY);
});

Clazz_newMeth(C$, 'applyTo$com_actelion_research_chem_AbstractDrawingObject',  function (o) {
o.scale$D(this.mScaling);
o.move$D$D(this.mOffsetX, this.mOffsetY);
});

Clazz_newMeth(C$, 'getInverseTransformation$',  function () {
var t=Clazz_new_(C$);
t.mScaling=1.0 / this.mScaling;
t.mOffsetX=-this.mOffsetX / this.mScaling;
t.mOffsetY=-this.mOffsetY / this.mScaling;
return t;
});

Clazz_newMeth(C$, 'toString',  function () {
return "DepictorTransformation Offset: " + new Double(this.mOffsetX).toString() + "," + new Double(this.mOffsetY).toString() + " Scaling: " + new Double(this.mScaling).toString() ;
});
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Molecule','java.io.BufferedReader','java.io.InputStreamReader','java.io.FileInputStream','com.actelion.research.io.BOMSkipper','java.io.StringReader','java.io.FileReader','java.util.TreeMap','com.actelion.research.chem.AromaticityResolver']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "MolfileParser");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mTreatAnyAsMetalBond','mDeduceMissingCharges','mChiralFlag','mIsV3000','mAssumeChiralTrue'],'I',['mMode'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mAtomIndexMap','java.util.TreeMap','+mBondIndexMap','mHydrogenMap','int[]']]
,['Z',['debug']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mMode=0;
}, 1);

Clazz_newMeth(C$, 'c$$I',  function (mode) {
;C$.$init$.apply(this);
this.mMode=mode;
}, 1);

Clazz_newMeth(C$, 'getHandleHydrogenMap$',  function () {
return this.mHydrogenMap == null  ? this.mMol.getHandleHydrogenMap$() : this.mHydrogenMap;
});

Clazz_newMeth(C$, 'readMoleculeFromBuffer$java_io_BufferedReader',  function (reader) {
var valence=null;
try {
var line;
var natoms;
var nbonds;
var nlists;
this.mHydrogenMap=null;
if (this.mMol != null ) {
this.mMol.clear$();
this.mMol.setFragment$Z(false);
}var name=(line=reader.readLine$());
if (null == name ) {
this.TRACE$S("readMoleculeFromBuffer: No Header Line\n");
return false;
}if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Program Line\n");
return false;
}if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Comment Line\n");
return false;
}this.mTreatAnyAsMetalBond=line.contains$CharSequence("From CSD data. Using bond type \'Any\'");
this.mDeduceMissingCharges=line.contains$CharSequence("From CSD data.");
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Counts Line\n");
return false;
}this.mIsV3000=false;
this.mChiralFlag=this.mAssumeChiralTrue;
try {
natoms=Integer.parseInt$S(line.substring$I$I(0, 3).trim$());
nbonds=Integer.parseInt$S(line.substring$I$I(3, 6).trim$());
nlists=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(6, 9).trim$()]);
this.mChiralFlag=!!(this.mChiralFlag|((1 == p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(12, 15).trim$()]))));
this.mIsV3000=(line.length$() >= 39 && line.startsWith$S$I("V3000", 34) );
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.TRACE$S("Warning [readMoleculeFromBuffer]: Unable to interpret counts line\n");
return false;
} else {
throw e;
}
}
if (this.mIsV3000) {
var res=p$1.readMoleculeV3FromBuffer$java_io_BufferedReader.apply(this, [reader]);
this.mMol.setName$S(name);
return res;
}if (this.mMol == null ) {
this.mMol=Clazz_new_($I$(1,1).c$$I$I,[natoms, nbonds]);
}this.mMol.setName$S(name);
if (!this.mChiralFlag) {
this.mMol.setToRacemate$();
}if (0 == natoms) {
while (line != null  && (!(line.equals$O("M  END") || line.equals$O("$$$$") || line.substring$I(1).equals$O("$")  )) ){
line=reader.readLine$();
}
return true;
}for (var i=0; i < natoms; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Atom Line\n");
return false;
}var x=Float.parseFloat$S(line.substring$I$I(0, 10).trim$());
var y=Float.parseFloat$S(line.substring$I$I(10, 20).trim$());
var z=Float.parseFloat$S(line.substring$I$I(20, 30).trim$());
var atom=this.mMol.addAtom$D$D$D(x, -y, -z);
var label=line.substring$I$I(31, 34).trim$();
if (label.equals$O("A") || label.equals$O("*") ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1, true);
} else if (label.equals$O("Q")) {
var list=Clazz_array(Integer.TYPE, [1]);
list[0]=6;
this.mMol.setAtomList$I$IA$Z(atom, list, true);
} else {
var atomicNo=$I$(2).getAtomicNoFromLabel$S$I(label, 67);
this.mMol.setAtomicNo$I$I(atom, atomicNo);
}var massDif=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(34, 36).trim$()]);
if (massDif != 0) {
this.mMol.setAtomMass$I$I(atom, $I$(2).cRoundedMass[this.mMol.getAtomicNo$I(atom)] + massDif);
}var chargeDif=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(36, 39).trim$()]);
if (chargeDif != 0) {
if (chargeDif == 4) this.mMol.setAtomRadical$I$I(atom, 32);
 else this.mMol.setAtomCharge$I$I(atom, 4 - chargeDif);
}var mapNo=(line.length$() < 63) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(60, 63).trim$()]);
this.mMol.setAtomMapNo$I$I$Z(atom, mapNo, false);
var hCount=(line.length$() < 45) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(42, 45).trim$()]);
switch (hCount) {
case 0:
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 768, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 128, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 384, true);
break;
default:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 896, true);
break;
}
if (line.length$() >= 48 && line.charAt$I(47) == "1" ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8192, true);
}var v=(line.length$() < 51) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(48, 51).trim$()]);
if (v != 0) {
if (valence == null ) valence=Clazz_array(Integer.TYPE, [natoms]);
valence[atom]=v;
}}
for (var i=0; i < nbonds; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]:No Bond Line\n");
return false;
}var atom1=Integer.parseInt$S(line.substring$I$I(0, 3).trim$()) - 1;
var atom2=Integer.parseInt$S(line.substring$I$I(3, 6).trim$()) - 1;
var bondType=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
var stereo=(line.length$() < 12) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(9, 12).trim$()]);
var topology=(line.length$() < 18) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(15, 18).trim$()]);
if (bondType == 8 && (this.mTreatAnyAsMetalBond || this.mMol.isMetalAtom$I(atom1) || this.mMol.isMetalAtom$I(atom2)  ) ) bondType=9;
p$1.buildBond$I$I$I$I$I.apply(this, [atom1, atom2, bondType, stereo, topology]);
}
for (var i=0; i < nlists; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No List Line\n");
return false;
}}
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error ReadMoleculeFromBuffer Missing M END or $$$$\n");
if ((this.mMode & 1) != 0) this.mHydrogenMap=this.mMol.getHandleHydrogenMap$();
p$1.handleValences$IA.apply(this, [valence]);
if (!this.mChiralFlag) this.mMol.ensureHelperArrays$I(15);
return true;
}while (line != null  && (!(line.equals$O("M  END") || line.equals$O("$$$$") )) ){
if (line.startsWith$S("M  CHG")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var charge=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
this.mMol.setAtomCharge$I$I(atom, charge);
}
}}if (line.startsWith$S("M  ISO")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var mass=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
this.mMol.setAtomMass$I$I(atom, mass);
}
}}if (line.startsWith$S("M  RAD")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var radical=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
switch (radical) {
case 1:
this.mMol.setAtomRadical$I$I(atom, 16);
break;
case 2:
this.mMol.setAtomRadical$I$I(atom, 32);
break;
case 3:
this.mMol.setAtomRadical$I$I(atom, 48);
break;
}
}
}}if (line.startsWith$S("M  RBC") || line.startsWith$S("M  RBD") ) {
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
var aaa=10;
var vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var ringState=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
switch (ringState) {
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 104, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 4:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 56, true);
break;
}
}
}}if (line.startsWith$S("M  ALS")) {
var atom=Integer.parseInt$S(line.substring$I$I(7, 10).trim$()) - 1;
if (atom >= 0) {
var no=Integer.parseInt$S(line.substring$I$I(10, 13).trim$());
var bNotList=(line.charAt$I(14) == "T");
var v=Clazz_array(Integer.TYPE, [no]);
var aaa=16;
for (var k=0; k < no; k++, aaa+=4) {
var sym=line.substring$I$I(aaa, aaa + 4).trim$();
v[k]=$I$(2).getAtomicNoFromLabel$S$I(sym, 1);
}
this.mMol.setAtomicNo$I$I(atom, 6);
this.mMol.setAtomList$I$IA$Z(atom, v, bNotList);
}}if (line.startsWith$S("M  SUB")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var substitution=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
if (substitution == -2) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 2048, true);
} else if (substitution > 0) {
var substitutionCount=0;
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondAtom$I$I(0, bond) == atom || this.mMol.getBondAtom$I$I(1, bond) == atom ) {
++substitutionCount;
}}
if (substitution > substitutionCount) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 4096, true);
}}}
}}if (line.startsWith$S("M  RGP")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var rno=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
if (rno >= 1 && rno <= 20 ) {
this.mMol.setAtomicNo$I$I(atom, $I$(2).getAtomicNoFromLabel$S$I("R" + rno, 2));
}}
}}line=reader.readLine$();
}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
e.printStackTrace$();
System.err.println$S("error reading molfile " + e);
return false;
} else {
throw e;
}
}
if (this.mDeduceMissingCharges) {
p$1.introduceObviousMetalBonds.apply(this, []);
p$1.deduceMissingCharges.apply(this, []);
}if ((this.mMode & 1) != 0) this.mHydrogenMap=this.mMol.getHandleHydrogenMap$();
p$1.handleValences$IA.apply(this, [valence]);
this.mMol.ensureHelperArrays$I(15);
return true;
}, p$1);

Clazz_newMeth(C$, 'setAssumeChiralTrue$Z',  function (b) {
this.mAssumeChiralTrue=b;
});

Clazz_newMeth(C$, 'isChiralFlagSet$',  function () {
return this.mChiralFlag;
});

Clazz_newMeth(C$, 'isV3000$',  function () {
return this.mIsV3000;
});

Clazz_newMeth(C$, 'handleValences$IA',  function (valence) {
if (valence != null ) {
this.mMol.ensureHelperArrays$I(1);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (valence[atom] != 0) {
var chargeCorrection=this.mMol.getElectronValenceCorrection$I$I(atom, this.mMol.getOccupiedValence$I(atom));
if (valence[atom] == 15) {
if (chargeCorrection >= 0) this.mMol.setAtomAbnormalValence$I$I(atom, 0);
} else {
if (valence[atom] != this.mMol.getMaxValence$I(atom)) this.mMol.setAtomAbnormalValence$I$I(atom, valence[atom] - chargeCorrection);
}}}
}}, p$1);

Clazz_newMeth(C$, 'readMoleculeV3FromBuffer$java_io_BufferedReader',  function (reader) {
var MODE_CTAB=1;
var MODE_CTAB_ATOM=2;
var MODE_CTAB_BOND=3;
var MODE_CTAB_COLLECTION=4;
if (this.mAtomIndexMap != null ) this.mAtomIndexMap.clear$();
if (this.mBondIndexMap != null ) this.mBondIndexMap.clear$();
var mode=0;
var line=reader.readLine$();
while (line != null  && line.startsWith$S("M  V30 ") ){
line=line.substring$I(7).trim$();
while (line.endsWith$S("-")){
var cont=reader.readLine$();
if (!cont.startsWith$S("M  V30 ")) {
return false;
}line=line.substring$I$I(0, line.length$() - 1).concat$S(cont.substring$I(7)).trim$();
}
if (line.startsWith$S("BEGIN")) {
var modeString=line.substring$I(6).trim$();
if (modeString.startsWith$S("CTAB")) {
mode=1;
} else if (modeString.startsWith$S("ATOM")) {
mode=2;
} else if (modeString.startsWith$S("BOND")) {
mode=3;
} else if (modeString.startsWith$S("COLLECTION")) {
mode=4;
} else {
this.TRACE$S("Error MolfileParser: Unsupported version 3 block\n");
return false;
}} else if (line.startsWith$S("END")) {
mode=0;
} else if (mode == 1) {
p$1.interpretV3CountLine$S.apply(this, [line]);
} else if (mode == 2) {
p$1.interpretV3AtomLine$S.apply(this, [line]);
} else if (mode == 3) {
p$1.interpretV3BondLine$S.apply(this, [line]);
} else if (mode == 4) {
p$1.interpretV3CollectionLine$S.apply(this, [line]);
} else {
this.TRACE$S("Error MolfileParser: Unexpected version 3 line\n");
return false;
}line=reader.readLine$();
}
while (line != null  && (!(line.startsWith$S("M  END") || line.equals$O("$$$$") )) ){
line=reader.readLine$();
}
return true;
}, p$1);

Clazz_newMeth(C$, 'interpretV3CountLine$S',  function (line) {
if (this.mMol == null ) {
if (line.startsWith$S("COUNTS")) {
var index1=7;
var index2=p$1.indexOfNextItem$S$I.apply(this, [line, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 7])]);
var natoms=Integer.parseInt$S(line.substring$I$I(index1, p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1])));
var nbonds=Integer.parseInt$S(line.substring$I$I(index2, p$1.indexOfWhiteSpace$S$I.apply(this, [line, index2])));
this.mMol=Clazz_new_($I$(1,1).c$$I$I,[natoms, nbonds]);
}}}, p$1);

Clazz_newMeth(C$, 'interpretV3AtomLine$S',  function (line) {
var index1=0;
var index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atomIndex=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var label=line.substring$I$I(index1, index2);
var v=null;
var bNotList=false;
var l=p$1.isV3AtomList$S.apply(this, [line]);
if (l != 0) {
v=p$1.interpretV3AtomList$S.apply(this, [line]);
if (l < 0) bNotList=true;
index2=Math.abs(l);
}index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var x=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var y=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var z=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var mapNo=Integer.parseInt$S(line.substring$I$I(index1, index2));
var atom=this.mMol.addAtom$D$D$D(x, -y, -z);
if (atom + 1 != atomIndex) p$1.mapAtomIndex$I$I.apply(this, [atomIndex, atom]);
if (v != null ) {
this.mMol.setAtomicNo$I$I(atom, 6);
this.mMol.setAtomList$I$IA$Z(atom, v, bNotList);
}if (mapNo != 0) {
this.mMol.setAtomMapNo$I$I$Z(atom, mapNo, false);
}if (label.equals$O("A") || label.equals$O("*") ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1, true);
} else if (label.equals$O("Q")) {
var list=Clazz_array(Integer.TYPE, [1]);
list[0]=6;
this.mMol.setAtomList$I$IA$Z(atom, list, true);
} else {
this.mMol.setAtomicNo$I$I(atom, $I$(2).getAtomicNoFromLabel$S$I(label, 67));
}while ((index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2])) != -1){
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var specifier=line.substring$I$I(index1, index2);
var index=specifier.indexOf$I("=");
var field=specifier.substring$I$I(0, index);
var value=Integer.parseInt$S(specifier.substring$I(index + 1));
if (field.equals$O("CHG")) {
this.mMol.setAtomCharge$I$I(atom, value);
} else if (field.equals$O("RAD")) {
switch (value) {
case 1:
this.mMol.setAtomRadical$I$I(atom, 16);
break;
case 2:
this.mMol.setAtomRadical$I$I(atom, 32);
break;
case 3:
this.mMol.setAtomRadical$I$I(atom, 48);
break;
}
} else if (field.equals$O("CFG")) {
} else if (field.equals$O("MASS")) {
this.mMol.setAtomMass$I$I(atom, value);
} else if (field.equals$O("VAL")) {
this.mMol.setAtomAbnormalValence$I$I(atom, (value == -1) ? 0 : (value == 0) ? -1 : value);
} else if (field.equals$O("HCOUNT")) {
switch (value) {
case 0:
break;
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1792, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 128, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 384, true);
break;
default:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 896, true);
break;
}
} else if (field.equals$O("SUBST")) {
if (value == -1) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 2048, true);
} else if (value > 0) {
var substitutionCount=0;
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondAtom$I$I(0, bond) == atom || this.mMol.getBondAtom$I$I(1, bond) == atom ) {
++substitutionCount;
}}
if (value > substitutionCount) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 4096, true);
}}} else if (field.equals$O("RBCNT")) {
switch (value) {
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 104, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 4:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 56, true);
break;
}
} else {
this.TRACE$S("Warning MolfileParser: Unused version 3 atom specifier:" + field + "\n" );
}}
}, p$1);

Clazz_newMeth(C$, 'interpretV3BondLine$S',  function (line) {
var index1=0;
var index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var bondIndex=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var bondType=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atom1=p$1.getUsedAtomIndex$I.apply(this, [Integer.parseInt$S(line.substring$I$I(index1, index2))]);
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atom2=p$1.getUsedAtomIndex$I.apply(this, [Integer.parseInt$S(line.substring$I$I(index1, index2))]);
var stereo=0;
var topology=0;
while ((index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2])) != -1){
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var specifier=line.substring$I$I(index1, index2);
var index=specifier.indexOf$I("=");
var field=specifier.substring$I$I(0, index);
var value=Integer.parseInt$S(specifier.substring$I(index + 1));
if (field.equals$O("CFG")) {
switch (value) {
case 1:
stereo=1;
break;
case 2:
stereo=(bondType == 2) ? 3 : 4;
break;
case 3:
stereo=6;
break;
}
} else if (field.equals$O("TOPO")) {
topology=value;
} else {
this.TRACE$S("Warning MolfileParser: Unused version 3 bond specifier:" + field + "\n" );
}}
var bond=p$1.buildBond$I$I$I$I$I.apply(this, [atom1, atom2, bondType, stereo, topology]);
if (bond + 1 != bondIndex) p$1.mapBondIndex$I$I.apply(this, [bondIndex, bond]);
}, p$1);

Clazz_newMeth(C$, 'interpretV3CollectionLine$S',  function (line) {
var objectType=p$1.interpretObjectType$S.apply(this, [line]);
if (objectType != null ) {
var list=p$1.interpretV3List$S$S.apply(this, [line, objectType]);
if (line.startsWith$S("MDLV30/STEABS")) {
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 0, -1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 0, -1);

} else if (line.startsWith$S("MDLV30/STERAC")) {
var group=Integer.parseInt$S(line.substring$I$I(13, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 13])));
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 1, group - 1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 1, group - 1);

} else if (line.startsWith$S("MDLV30/STEREL")) {
var group=Integer.parseInt$S(line.substring$I$I(13, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 13])));
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 2, group - 1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 2, group - 1);

} else if (line.startsWith$S("MDLV30/HILITE")) {
if (objectType.equals$O("ATOMS")) {
for (var i=0; i < list.length; i++) this.mMol.setAtomColor$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 448);

} else {
for (var i=0; i < list.length; i++) {
var bond=p$1.getUsedBondIndex$I.apply(this, [list[i]]);
this.mMol.setAtomColor$I$I(this.mMol.getBondAtom$I$I(0, bond), 448);
this.mMol.setAtomColor$I$I(this.mMol.getBondAtom$I$I(1, bond), 448);
}
}} else {
this.TRACE$S("Error [readMoleculeFromBuffer]: Unknown version 3 collection type\n");
}}}, p$1);

Clazz_newMeth(C$, 'interpretObjectType$S',  function (line) {
if (line.contains$CharSequence("ATOMS=(")) return "ATOMS";
if (line.contains$CharSequence("BONDS=(")) return "BONDS";
this.TRACE$S("Error [readMoleculeFromBuffer]: Unknown or missing collection object type\n");
return null;
}, p$1);

Clazz_newMeth(C$, 'interpretV3AtomList$S',  function (line) {
var res=null;
var i1=line.indexOf$S("[");
var i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
var atoms=Clazz_array(Integer.TYPE, [16]);
var s=line.substring$I$I(i1 + 1, i2);
var index=0;
var ok=true;
while (ok && index < 16 ){
i1=s.indexOf$S(",");
var l=null;
if (i1 == -1) {
l=s;
ok=false;
} else {
l=s.substring$I$I(0, i1);
s=s.substring$I(i1 + 1);
}atoms[index++]=$I$(2).getAtomicNoFromLabel$S$I(l, 1);
}
res=Clazz_array(Integer.TYPE, [index]);
System.arraycopy$O$I$O$I$I(atoms, 0, res, 0, index);
}return res;
}, p$1);

Clazz_newMeth(C$, 'isV3AtomList$S',  function (line) {
if (line.indexOf$S("[") >= 0) {
var i1=line.indexOf$S(" NOT[");
var i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
return -(i2 + 1);
} else {
i1=line.indexOf$S(" [");
i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
return i2 + 1;
}}i1=line.indexOf$S(" \'NOT[");
i2=line.indexOf$S$I("]\'", i1);
if (i1 >= 0 && i2 > 0 ) {
return -(i2 + 2);
} else {
i1=line.indexOf$S(" \'[");
i2=line.indexOf$S$I("]\'", i1);
if (i1 >= 0 && i2 > 0 ) {
return i2 + 2;
}}System.err.println$S("Warning invalid atom list in line: " + line);
}return 0;
}, p$1);

Clazz_newMeth(C$, 'interpretV3List$S$S',  function (line, type) {
var index1=line.indexOf$S(type + "=(") + type.length$() + 2 ;
var index2=line.indexOf$I$I(")", index1);
var index=p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1]);
var count=Integer.parseInt$S(line.substring$I$I(index1, index));
var list=Clazz_array(Integer.TYPE, [count]);
for (var i=0; i < count; i++) {
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index]);
index=p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1]);
if (index == -1 || index > index2 ) {
index=index2;
}list[i]=Integer.parseInt$S(line.substring$I$I(index1, index));
}
return list;
}, p$1);

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$java_io_File',  function (mol, file) {
this.mMol=mol;
try {
var reader=Clazz_new_([Clazz_new_([Clazz_new_($I$(5,1).c$$java_io_File,[file]), "UTF-8"],$I$(4,1).c$$java_io_InputStream$S)],$I$(3,1).c$$java_io_Reader);
$I$(6).skip$java_io_Reader(reader);
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader]);
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
System.err.println$S("Error reading file " + e);
} else {
throw e;
}
}
return false;
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, molFile) {
return this.parse$com_actelion_research_chem_StereoMolecule$java_io_BufferedReader(mol, Clazz_new_([Clazz_new_($I$(7,1).c$$S,[molFile])],$I$(3,1).c$$java_io_Reader));
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$StringBuffer',  function (mol, molFile) {
return this.parse$com_actelion_research_chem_StereoMolecule$S(mol, molFile.toString());
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$java_io_BufferedReader',  function (m, rd) {
this.mMol=m;
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [rd]);
});

Clazz_newMeth(C$, 'getCompactMolecule$S',  function (molFile) {
this.mMol=null;
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [Clazz_new_([Clazz_new_($I$(7,1).c$$S,[molFile])],$I$(3,1).c$$java_io_Reader)]) ? this.mMol : null;
});

Clazz_newMeth(C$, 'getCompactMolecule$java_io_BufferedReader',  function (reader) {
this.mMol=null;
return (p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader])) ? this.mMol : null;
});

Clazz_newMeth(C$, 'getCompactMolecule$java_io_File',  function (file) {
this.mMol=null;
try {
var reader=Clazz_new_([Clazz_new_($I$(8,1).c$$java_io_File,[file])],$I$(3,1).c$$java_io_Reader);
var success=p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader]);
try {
reader.close$();
} catch (ioe) {
if (Clazz_exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
return success ? this.mMol : null;
} catch (fnfe) {
if (Clazz_exceptionOf(fnfe,"java.io.FileNotFoundException")){
return null;
} else {
throw fnfe;
}
}
});

Clazz_newMeth(C$, 'buildBond$I$I$I$I$I',  function (atom1, atom2, bondType, stereo, topology) {
var realBondType=1;
var isAtomESRAnd=false;
switch (stereo) {
case 1:
realBondType=257;
break;
case 3:
realBondType=386;
break;
case 4:
realBondType=257;
isAtomESRAnd=true;
break;
case 6:
realBondType=129;
break;
default:
switch (bondType) {
case 1:
realBondType=1;
break;
case 2:
realBondType=2;
break;
case 3:
realBondType=4;
break;
case 4:
realBondType=64;
break;
case 9:
realBondType=32;
break;
}
break;
}
var bond=this.mMol.addBond$I$I$I(atom1, atom2, realBondType);
var queryFeatures=0;
if (isAtomESRAnd) {
this.mMol.setAtomESR$I$I$I(atom1, 1, -1);
}if (bondType > 4) {
switch (bondType) {
case 5:
queryFeatures|=3;
break;
case 6:
queryFeatures|=9;
break;
case 7:
queryFeatures|=10;
break;
case 8:
if (realBondType != 32) queryFeatures|=31;
break;
}
}if (topology == 1) {
queryFeatures|=256;
}if (topology == 2) {
queryFeatures|=128;
}if (queryFeatures != 0) {
this.mMol.setBondQueryFeature$I$I$Z(bond, queryFeatures, true);
}return bond;
}, p$1);

Clazz_newMeth(C$, 'mapAtomIndex$I$I',  function (sourceAtomIndex, usedAtomIndex) {
if (this.mAtomIndexMap == null ) this.mAtomIndexMap=Clazz_new_($I$(9,1));
this.mAtomIndexMap.put$O$O( new Integer(sourceAtomIndex),  new Integer(usedAtomIndex));
}, p$1);

Clazz_newMeth(C$, 'mapBondIndex$I$I',  function (sourceBondIndex, usedBondIndex) {
if (this.mBondIndexMap == null ) this.mBondIndexMap=Clazz_new_($I$(9,1));
this.mBondIndexMap.put$O$O( new Integer(sourceBondIndex),  new Integer(usedBondIndex));
}, p$1);

Clazz_newMeth(C$, 'getUsedAtomIndex$I',  function (sourceAtomIndex) {
var ui=(this.mAtomIndexMap == null ) ? null : this.mAtomIndexMap.get$O( new Integer(sourceAtomIndex));
return (ui == null ) ? sourceAtomIndex - 1 : ui.intValue$();
}, p$1);

Clazz_newMeth(C$, 'getUsedBondIndex$I',  function (sourceBondIndex) {
var ui=(this.mBondIndexMap == null ) ? null : this.mBondIndexMap.get$O( new Integer(sourceBondIndex));
return (ui == null ) ? sourceBondIndex - 1 : ui.intValue$();
}, p$1);

Clazz_newMeth(C$, 'parseIntOrSpaces$S',  function (s) {
return (s.length$() == 0) ? 0 : Integer.parseInt$S(s);
}, p$1);

Clazz_newMeth(C$, 'endOfItem$S$I',  function (line, start) {
var end=p$1.indexOfWhiteSpace$S$I.apply(this, [line, start + 1]);
return (end == -1) ? line.length$() : end;
}, p$1);

Clazz_newMeth(C$, 'indexOfWhiteSpace$S$I',  function (line, fromIndex) {
for (var i=fromIndex; i < line.length$(); i++) {
if (line.charAt$I(i) == " " || line.charAt$I(i) == "\t" ) {
return i;
}}
return -1;
}, p$1);

Clazz_newMeth(C$, 'indexOfNextItem$S$I',  function (line, afterPreviousItem) {
if (afterPreviousItem == -1) {
return -1;
}for (var i=afterPreviousItem + 1; i < line.length$(); i++) {
if (line.charAt$I(i) != " " && line.charAt$I(i) != "\t" ) {
return i;
}}
return -1;
}, p$1);

Clazz_newMeth(C$, 'TRACE$S',  function (s) {
if (C$.debug) {
System.out.println$S(s);
}});

Clazz_newMeth(C$, 'introduceObviousMetalBonds',  function () {
var occupiedValence=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) if (this.mMol.getBondType$I(bond) == 64) for (var i=0; i < 2; i++) occupiedValence[this.mMol.getBondAtom$I$I(i, bond)]=1;


for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
var order=this.mMol.getBondOrder$I(bond);
for (var i=0; i < 2; i++) occupiedValence[this.mMol.getBondAtom$I$I(i, bond)]+=order;

}
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1) {
for (var i=0; i < 2; i++) {
var metalAtom=this.mMol.getBondAtom$I$I(1 - i, bond);
if (this.mMol.isMetalAtom$I(metalAtom)) {
var atom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isElectronegative$I(atom) && occupiedValence[atom] > this.mMol.getMaxValence$I(atom) ) {
this.mMol.setBondType$I$I(bond, 32);
continue;
}}}
}}
}, p$1);

Clazz_newMeth(C$, 'deduceMissingCharges',  function () {
var chargeChange=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) chargeChange[atom]=-this.mMol.getAtomCharge$I(atom);

Clazz_new_($I$(10,1).c$$com_actelion_research_chem_ExtendedMolecule,[this.mMol]).locateDelocalizedDoubleBonds$ZA$Z$Z(null, true, false);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) chargeChange[atom]+=this.mMol.getAtomCharge$I(atom);

for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
if (chargeChange[atom] != 0) {
var chargeToDistribute=-chargeChange[atom];
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
for (var i=0; i < 2; i++) {
if (chargeToDistribute > 0 && this.mMol.getBondType$I(bond) == 32  && this.mMol.getBondAtom$I$I(1 - i, bond) == atom ) {
var metal=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isMetalAtom$I(metal)) {
var maxCharge=p$1.getMaxOxidationState$I.apply(this, [metal]);
var charge=this.mMol.getAtomCharge$I(metal);
if (charge < maxCharge) {
var dif=Math.min(chargeToDistribute, maxCharge - charge);
this.mMol.setAtomCharge$I$I(metal, charge + dif);
chargeToDistribute-=dif;
}}}}
}
}}
}, p$1);

Clazz_newMeth(C$, 'getMaxOxidationState$I',  function (metal) {
var atomicNo=this.mMol.getAtomicNo$I(metal);
var os=(atomicNo < $I$(2).cCommonOxidationState.length) ? $I$(2).cCommonOxidationState[atomicNo] : null;
return (os == null ) ? ($b$[0] = 0, $b$[0]) : os[os.length - 1];
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.debug=false;
};
var $b$ = new Int8Array(1);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:18 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.ArrayList','StringBuilder','java.awt.Font','java.awt.image.BufferedImage']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "SVGDepictor", null, 'com.actelion.research.chem.AbstractDepictor');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.lineWidth=1;
this.textSize=10;
this.width=400;
this.height=400;
this.legacyMode=true;
this.currentColor="black";
this.bonds=Clazz_new_($I$(1,1));
this.atoms=Clazz_new_($I$(1,1));
this.buffer=Clazz_new_($I$(2,1));
this.currentFont=Clazz_new_($I$(3,1).c$$S$I$I,["Helvetica", 0, 12]);
},1);

C$.$fields$=[['Z',['legacyMode'],'D',['lineWidth'],'I',['textSize','width','height'],'S',['currentColor','id'],'O',['bonds','java.util.List','+atoms','buffer','StringBuilder','currentFont','java.awt.Font','graphics','java.awt.Graphics2D']]
,['I',['instanceCnt']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S',  function (mol, id) {
C$.c$$com_actelion_research_chem_StereoMolecule$I$S.apply(this, [mol, 0, id]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I$S',  function (mol, displayMode, id) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$I.apply(this,[mol, displayMode]);C$.$init$.apply(this);
this.id=id;
++C$.instanceCnt;
}, 1);

Clazz_newMeth(C$, 'setLegacyMode$Z',  function (b) {
this.legacyMode=b;
});

Clazz_newMeth(C$, 'makeColor$I$I$I',  function (r, g, b) {
return "rgb(" + r + "," + g + "," + b + ")" ;
}, 1);

Clazz_newMeth(C$, 'getId$',  function () {
return this.id != null  ? this.id : ("mol" + C$.instanceCnt);
});

Clazz_newMeth(C$, 'write$S',  function (s) {
this.buffer.append$S("\t");
this.buffer.append$S(s);
this.buffer.append$S("\n");
}, p$1);

Clazz_newMeth(C$, 'drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var x1=(theLine.x1|0);
var x2=(theLine.x2|0);
var y1=(theLine.y1|0);
var y2=(theLine.y2|0);
var s="<line x1=\"" + x1 + "\" " + "y1=\"" + y1 + "\" " + "x2=\"" + x2 + "\" " + "y2=\"" + y2 + "\" " + "style=\"stroke:" + this.currentColor + "; stroke-width:" + new Double(this.lineWidth).toString() + "\"/>" ;
p$1.write$S.apply(this, [s]);
});

Clazz_newMeth(C$, 'drawDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var x1=(theLine.x1|0);
var x2=(theLine.x2|0);
var y1=(theLine.y1|0);
var y2=(theLine.y2|0);
var d=((3 * this.lineWidth)|0);
var s="<line stroke-dasharray=\"" + d + "," + d + "\" " + "x1=\"" + x1 + "\" " + "y1=\"" + y1 + "\" " + "x2=\"" + x2 + "\" " + "y2=\"" + y2 + "\" " + "style=\"stroke:" + this.currentColor + "; stroke-width:" + new Double(this.lineWidth).toString() + "\"/>" ;
p$1.write$S.apply(this, [s]);
});

Clazz_newMeth(C$, 'drawPolygon$com_actelion_research_gui_generic_GenericPolygon',  function (p) {
var s=Clazz_new_(["<polygon points=\""],$I$(2,1).c$$S);
for (var i=0; i < p.getSize$(); i++) {
s.append$J(Math.round$D(p.getX$I(i)));
s.append$S(",");
s.append$J(Math.round$D(p.getY$I(i)));
s.append$S(" ");
}
s.append$S("\" style=\"fill:" + this.currentColor + "; stroke:" + this.currentColor + "; stroke-width:" + new Double(this.lineWidth).toString() + "\"/>" );
p$1.write$S.apply(this, [s.toString()]);
});

Clazz_newMeth(C$, 'drawString$S$D$D',  function (theString, x, y) {
var strWidth=this.getStringWidth$S(theString);
var s="<text x=\"" + ((x - strWidth / 2.0)|0) + "\" " + "y=\"" + ((y + (this.textSize/3|0))|0) + "\" " + "stroke=\"none\" " + "font-size=\"" + this.currentFont.getSize$() + "\" " + "fill=\"" + this.currentColor + "\">" + theString + "</text>" ;
p$1.write$S.apply(this, [s]);
});

Clazz_newMeth(C$, 'fillCircle$D$D$D',  function (x, y, d) {
var s="<circle cx=\"" + ((x + d / 2)|0) + "\" " + "cy=\"" + ((y + d / 2)|0) + "\" " + "r=\"" + ((d / 2)|0) + "\" " + "fill=\"" + this.currentColor + "\" />" ;
p$1.write$S.apply(this, [s]);
});

Clazz_newMeth(C$, 'getLineWidth$',  function () {
return this.lineWidth;
});

Clazz_newMeth(C$, 'getStringWidth$S',  function (theString) {
var ret=this.currentFont.getStringBounds$S$java_awt_font_FontRenderContext(theString, this.graphics.getFontRenderContext$()).getWidth$();
return ret;
});

Clazz_newMeth(C$, 'getTextSize$',  function () {
return this.textSize;
});

Clazz_newMeth(C$, 'setTextSize$I',  function (theSize) {
if (this.textSize != theSize) {
this.textSize=theSize;
this.currentFont=Clazz_new_($I$(3,1).c$$S$I$I,["Helvetica", 0, theSize]);
}});

Clazz_newMeth(C$, 'setLineWidth$D',  function (width) {
this.lineWidth=Long.$dval(Long.$div(Math.round$D(100 * Math.max(width, 1.0)),100));
});

Clazz_newMeth(C$, 'setRGB$I',  function (rgb) {
this.currentColor=C$.makeColor$I$I$I((rgb & 16711680) >> 16, (rgb & 65280) >> 8, rgb & 255);
});

Clazz_newMeth(C$, 'onDrawBond$I$D$D$D$D',  function (bond, x1, y1, x2, y2) {
var s="<line id=\"" + this.getId$() + ":Bond:" + bond + "\" " + "class=\"event\" " + "x1=\"" + ((x1)|0) + "\" " + "y1=\"" + ((y1)|0) + "\" " + "x2=\"" + ((x2)|0) + "\" " + "y2=\"" + ((y2)|0) + "\" " + "stroke-width=\"" + 8 + "\" " + "stroke-opacity=\"0\"" + "/>" ;
this.bonds.add$O(s);
});

Clazz_newMeth(C$, 'onDrawAtom$I$S$D$D',  function (atom, symbol, x, y) {
var r=8;
var s="<circle id=\"" + this.getId$() + ":Atom:" + atom + "\" " + "class=\"event\" " + "cx=\"" + ((x)|0) + "\" " + "cy=\"" + ((y)|0) + "\" " + "r=\"" + r + "\" " + "fill-opacity=\"0\"/>" ;
this.atoms.add$O(s);
});

Clazz_newMeth(C$, 'toString',  function () {
var header="<svg id=\"" + this.getId$() + "\" " + "xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" " + "width=\"" + this.width + "px\" " + "height=\"" + this.height + "px\" " + "viewBox=\"0 0 " + this.width + " " + this.height + "\">\n" ;
var footer="</svg>";
var style=this.legacyMode ? "<style> #" + this.getId$() + " {pointer-events:none; } " + " #" + this.getId$() + " .event " + " { pointer-events:all;} " + " </style>\n"  : "<g style=\"font-size:" + this.getTextSize$() + "px; fill-opacity:1; stroke-opacity:1; fill:black; stroke:black;" + " font-weight:normal; text-rendering:optimizeLegibility; font-family:sans-serif;" + " stroke-linejoin:round; stroke-linecap:round; stroke-dashoffset:0;\">" ;
header+="\t";
header+=style;
if (this.legacyMode) {
for (var b, $b = this.bonds.iterator$(); $b.hasNext$()&&((b=($b.next$())),1);) p$1.write$S.apply(this, [b]);

for (var a, $a = this.atoms.iterator$(); $a.hasNext$()&&((a=($a.next$())),1);) p$1.write$S.apply(this, [a]);

}if (!this.legacyMode) p$1.write$S.apply(this, ["</g>"]);
return header + this.buffer.toString() + footer ;
});

Clazz_newMeth(C$, 'simpleValidateView$com_actelion_research_gui_generic_GenericRectangle$I',  function (viewRect, mode) {
this.width=(viewRect.getWidth$()|0);
this.height=(viewRect.getHeight$()|0);
var img=Clazz_new_($I$(4,1).c$$I$I$I,[this.width, this.height, 2]);
this.graphics=img.createGraphics$();
return C$.superclazz.prototype.simpleValidateView$com_actelion_research_gui_generic_GenericRectangle$I.apply(this, [viewRect, mode]);
});

C$.$static$=function(){C$.$static$=0;
C$.instanceCnt=0;
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:18 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.gui.generic"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "GenericPoint");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x','y']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$D$D',  function (x, y) {
;C$.$init$.apply(this);
this.x=x;
this.y=y;
}, 1);

Clazz_newMeth(C$, 'getX$',  function () {
return this.x;
});

Clazz_newMeth(C$, 'getY$',  function () {
return this.y;
});

Clazz_newMeth(C$, 'distance$com_actelion_research_gui_generic_GenericPoint',  function (p) {
var dx=this.x - p.x;
var dy=this.y - p.y;
return Math.sqrt(dx * dx + dy * dy);
});

Clazz_newMeth(C$, 'toString',  function () {
return "x:" + new Double(this.x).toString() + " y:" + new Double(this.y).toString() ;
});
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:33 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.gui.generic"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "GenericRectangle", null, null, 'com.actelion.research.gui.generic.GenericShape');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x','y','width','height']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$D$D$D$D',  function (x, y, w, h) {
;C$.$init$.apply(this);
this.x=x;
this.y=y;
this.width=w;
this.height=h;
}, 1);

Clazz_newMeth(C$, 'contains$D$D',  function (x, y) {
return x >= this.x  && x <= this.x + this.width   && y >= this.y   && y <= this.y + this.height  ;
});

Clazz_newMeth(C$, 'contains$com_actelion_research_gui_generic_GenericRectangle',  function (r) {
return this.contains$D$D(r.x, r.y) && this.contains$D$D(r.x + r.width, r.y + r.height) ;
});

Clazz_newMeth(C$, 'set$D$D$D$D',  function (x, y, w, h) {
this.x=x;
this.y=y;
this.width=w;
this.height=h;
});

Clazz_newMeth(C$, 'union$com_actelion_research_gui_generic_GenericRectangle',  function (r) {
var x=Math.min(this.x, r.x);
var y=Math.min(this.y, r.y);
var w=Math.max(this.x + this.width, r.x + r.width) - x;
var h=Math.max(this.y + this.height, r.y + r.height) - y;
return Clazz_new_(C$.c$$D$D$D$D,[x, y, w, h]);
});

Clazz_newMeth(C$, 'intersects$com_actelion_research_gui_generic_GenericRectangle',  function (r) {
return (this.x < r.x + r.width ) && (this.y < r.y + r.height ) && (r.x < this.x + this.width ) && (r.y < this.y + this.height )  ;
});

Clazz_newMeth(C$, 'intersection$com_actelion_research_gui_generic_GenericRectangle',  function (r) {
if (!this.intersects$com_actelion_research_gui_generic_GenericRectangle(r)) return null;
var x=Math.max(this.x, r.x);
var y=Math.max(this.y, r.y);
var w=Math.min(this.x + this.width, r.x + r.width) - x;
var h=Math.min(this.y + this.height, r.y + r.height) - y;
return Clazz_new_(C$.c$$D$D$D$D,[x, y, w, h]);
});

Clazz_newMeth(C$, 'getX$',  function () {
return this.x;
});

Clazz_newMeth(C$, 'getY$',  function () {
return this.y;
});

Clazz_newMeth(C$, 'getWidth$',  function () {
return this.width;
});

Clazz_newMeth(C$, 'getHeight$',  function () {
return this.height;
});

Clazz_newMeth(C$, 'getCenterX$',  function () {
return this.x + this.width / 2.0;
});

Clazz_newMeth(C$, 'getCenterY$',  function () {
return this.y + this.height / 2.0;
});

Clazz_newMeth(C$, 'toString',  function () {
return "x:" + new Double(this.x).toString() + " y:" + new Double(this.y).toString() + " w:" + new Double(this.width).toString() + " h:" + new Double(this.height).toString() ;
});
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:33 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.gui.generic"),I$=[];
/*i*/var C$=Clazz_newInterface(P$, "GenericShape");
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:33 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.util"),I$=[[0,'java.awt.Color']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ColorHelper");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['PERCEIVED_BRIGHTNESS','float[]']]]

Clazz_newMeth(C$, 'intermediateColor$java_awt_Color$java_awt_Color$F',  function (c1, c2, ratio) {
return Clazz_new_([((c1.getRed$() + ratio * (c2.getRed$() - c1.getRed$()))|0), ((c1.getGreen$() + ratio * (c2.getGreen$() - c1.getGreen$()))|0), ((c1.getBlue$() + ratio * (c2.getBlue$() - c1.getBlue$()))|0)],$I$(1,1).c$$I$I$I);
}, 1);

Clazz_newMeth(C$, 'intermediateColor$I$I$F',  function (rgb1, rgb2, ratio) {
var r1=(rgb1 & 16711680) >> 16;
var g1=(rgb1 & 65280) >> 8;
var b1=rgb1 & 255;
var r2=(rgb2 & 16711680) >> 16;
var g2=(rgb2 & 65280) >> 8;
var b2=rgb2 & 255;
return (r1 + (Math.round(ratio * (r2 - r1))) << 16) + (g1 + (Math.round(ratio * (g2 - g1))) << 8) + b1 + (Math.round(ratio * (b2 - b1))) ;
}, 1);

Clazz_newMeth(C$, 'brighter$java_awt_Color$F',  function (c, factor) {
var r=c.getRed$();
var g=c.getGreen$();
var b=c.getBlue$();
var alpha=c.getAlpha$();
var i=((1.0 / (1.0 - factor))|0);
if (r == 0 && g == 0  && b == 0 ) {
return Clazz_new_($I$(1,1).c$$I$I$I$I,[i, i, i, alpha]);
}if (r > 0 && r < i ) r=i;
if (g > 0 && g < i ) g=i;
if (b > 0 && b < i ) b=i;
return Clazz_new_([Math.min(((r / factor)|0), 255), Math.min(((g / factor)|0), 255), Math.min(((b / factor)|0), 255), alpha],$I$(1,1).c$$I$I$I$I);
}, 1);

Clazz_newMeth(C$, 'brighter$I$F',  function (argb, factor) {
var alpha=argb & -16777216;
var r=(argb & 16711680) >> 16;
var g=(argb & 65280) >> 8;
var b=argb & 255;
var i=((1.0 / (1.0 - factor))|0);
if (r == 0 && g == 0  && b == 0 ) return alpha | (i << 16) | (i << 8) | i ;
if (r > 0 && r < i ) r=i;
if (g > 0 && g < i ) g=i;
if (b > 0 && b < i ) b=i;
return alpha | (Math.min(((r / factor)|0), 255) << 16) | (Math.min(((g / factor)|0), 255) << 8) | Math.min(((b / factor)|0), 255) ;
}, 1);

Clazz_newMeth(C$, 'darker$java_awt_Color$F',  function (c, factor) {
return Clazz_new_([Math.max(((c.getRed$() * factor)|0), 0), Math.max(((c.getGreen$() * factor)|0), 0), Math.max(((c.getBlue$() * factor)|0), 0), c.getAlpha$()],$I$(1,1).c$$I$I$I$I);
}, 1);

Clazz_newMeth(C$, 'darker$I$F',  function (argb, factor) {
return (argb & -16777216) | (Math.round(factor * ((argb & 16711680) >> 16)) << 16) | (Math.round(factor * ((argb & 65280) >> 8)) << 8) | Math.round(factor * (argb & 255)) ;
}, 1);

Clazz_newMeth(C$, 'perceivedBrightness$java_awt_Color',  function (c) {
return (c == null ) ? 1.0 : (C$.PERCEIVED_BRIGHTNESS[0] * c.getRed$() + C$.PERCEIVED_BRIGHTNESS[1] * c.getGreen$() + C$.PERCEIVED_BRIGHTNESS[2] * c.getBlue$()) / 255.0;
}, 1);

Clazz_newMeth(C$, 'perceivedBrightness$FA',  function (cc) {
return C$.PERCEIVED_BRIGHTNESS[0] * cc[0] + C$.PERCEIVED_BRIGHTNESS[1] * cc[1] + C$.PERCEIVED_BRIGHTNESS[2] * cc[2];
}, 1);

Clazz_newMeth(C$, 'perceivedBrightness$I',  function (argb) {
return (C$.PERCEIVED_BRIGHTNESS[0] * ((argb & 16711680) >> 16) + C$.PERCEIVED_BRIGHTNESS[1] * ((argb & 65280) >> 8) + C$.PERCEIVED_BRIGHTNESS[2] * (argb & 255)) / 255.0;
}, 1);

Clazz_newMeth(C$, 'createColor$java_awt_Color$F',  function (c, perceivedBrightness) {
var cc=c.getRGBComponents$FA(null);
C$.createColor$FA$F(cc, perceivedBrightness);
return Clazz_new_($I$(1,1).c$$F$F$F$F,[cc[0], cc[1], cc[2], cc[3]]);
}, 1);

Clazz_newMeth(C$, 'createColor$I$F',  function (argb, perceivedBrightness) {
var cc=Clazz_array(Float.TYPE, [4]);
var f=0.003921569;
cc[0]=f * ((argb & 16711680) >> 16);
cc[1]=f * ((argb & 65280) >> 8);
cc[2]=f * (argb & 255);
C$.createColor$FA$F(cc, perceivedBrightness);
return (argb & -16777216) | (Math.round(cc[0] * 255) << 16) | (Math.round(cc[1] * 255) << 8) | Math.round(cc[2] * 255) ;
}, 1);

Clazz_newMeth(C$, 'createColor$FA$F',  function (cc, perceivedBrightness) {
var pb=C$.perceivedBrightness$FA(cc);
if (pb == 0.0 ) {
cc[0]=0.0;
cc[1]=0.0;
cc[2]=0.0;
return;
}var f=perceivedBrightness / pb;
var surplusBrightness=0.0;
var sum=0.0;
for (var i=0; i < 3; i++) {
cc[i]*=f;
if (cc[i] < 1.0 ) {
sum+=C$.PERCEIVED_BRIGHTNESS[i];
} else {
surplusBrightness+=(cc[i] - 1.0) * C$.PERCEIVED_BRIGHTNESS[i];
cc[i]=1.0;
}}
if (surplusBrightness != 0 ) {
var remainingBrightness=0.0;
for (var i=0; i < 3; i++) {
if (cc[i] < 1.0 ) {
cc[i]+=surplusBrightness / sum;
if (cc[i] > 1.0 ) {
remainingBrightness+=(cc[i] - 1.0) * C$.PERCEIVED_BRIGHTNESS[i];
cc[i]=1.0;
}}}
if (remainingBrightness != 0.0 ) {
for (var i=0; i < 3; i++) {
if (cc[i] < 1.0 ) {
cc[i]+=remainingBrightness / C$.PERCEIVED_BRIGHTNESS[i];
if (cc[i] > 1.0 ) {
cc[i]=1.0;
}}}
}}}, 1);

Clazz_newMeth(C$, 'getContrastColor$java_awt_Color$java_awt_Color',  function (fg, bg) {
var bgb=C$.perceivedBrightness$java_awt_Color(bg);
var fgb=C$.perceivedBrightness$java_awt_Color(fg);
var contrast=Math.abs(bgb - fgb);
if (contrast > 0.3 ) return fg;
var hsbBG=$I$(1,"RGBtoHSB$I$I$I$FA",[bg.getRed$(), bg.getGreen$(), bg.getBlue$(), null]);
var hsbFG=$I$(1,"RGBtoHSB$I$I$I$FA",[fg.getRed$(), fg.getGreen$(), fg.getBlue$(), null]);
var hueDif=Math.abs(hsbFG[0] - hsbBG[0]);
if (hueDif > 0.5 ) hueDif=1.0 - hueDif;
var saturationFactor=1 - Math.max(hsbFG[1], hsbBG[1]);
var brightnessFactor=Math.abs(fgb + bgb - 1);
var hueDifferenceFactor=Math.cos(3.141592653589793 * hueDif * 3 );
var neededContrast=0.3 * Math.max(saturationFactor, Math.max(brightnessFactor, hueDifferenceFactor));
if (contrast > neededContrast ) return fg;
var darken=(fgb > bgb ) ? (fgb + neededContrast > 1.0 ) : (fgb - neededContrast > 0.0 );
return C$.createColor$java_awt_Color$F(fg, darken ? bgb - neededContrast : bgb + neededContrast);
}, 1);

Clazz_newMeth(C$, 'getContrastColor$I$I',  function (fgRGB, bgRGB) {
var bgb=C$.perceivedBrightness$I(bgRGB);
var fgb=C$.perceivedBrightness$I(fgRGB);
var contrast=Math.abs(bgb - fgb);
if (contrast > 0.3 ) return fgRGB;
var hsbBG=$I$(1,"RGBtoHSB$I$I$I$FA",[(bgRGB & 16711680) >> 16, (bgRGB & 65280) >> 8, bgRGB & 255, null]);
var hsbFG=$I$(1,"RGBtoHSB$I$I$I$FA",[(fgRGB & 16711680) >> 16, (fgRGB & 65280) >> 8, fgRGB & 255, null]);
var hueDif=Math.abs(hsbFG[0] - hsbBG[0]);
if (hueDif > 0.5 ) hueDif=1.0 - hueDif;
var saturationFactor=1 - Math.max(hsbFG[1], hsbBG[1]);
var brightnessFactor=Math.abs(fgb + bgb - 1);
var hueDifferenceFactor=Math.cos(3.141592653589793 * hueDif * 3 );
var neededContrast=0.3 * Math.max(saturationFactor, Math.max(brightnessFactor, hueDifferenceFactor));
if (contrast > neededContrast ) return fgRGB;
var darken=(fgb > bgb ) ? (fgb + neededContrast > 1.0 ) : (fgb - neededContrast > 0.0 );
return C$.createColor$I$F(fgRGB, darken ? bgb - neededContrast : bgb + neededContrast);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.PERCEIVED_BRIGHTNESS=Clazz_array(Float.TYPE, -1, [0.299, 0.587, 0.114]);
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:36 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=java.io,p$1={},I$=[[0,'StringBuffer','java.util.stream.StreamSupport','java.util.Spliterators']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "BufferedReader", null, 'java.io.Reader');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.markedChar=-1;
this.readAheadLimit=0;
this.skipLF=false;
this.markedSkipLF=false;
},1);

C$.$fields$=[['Z',['skipLF','markedSkipLF'],'I',['nChars','nextChar','markedChar','readAheadLimit'],'O',['$in','java.io.Reader','cb','char[]']]
,['I',['defaultCharBufferSize','defaultExpectedLineLength']]]

Clazz_newMeth(C$, 'c$$java_io_Reader$I',  function ($in, sz) {
;C$.superclazz.c$$O.apply(this,[$in]);C$.$init$.apply(this);
if (sz <= 0) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Buffer size <= 0"]);
this.$in=$in;
this.cb=Clazz_array(Character.TYPE, [sz]);
this.nextChar=this.nChars=0;
}, 1);

Clazz_newMeth(C$, 'c$$java_io_Reader',  function ($in) {
C$.c$$java_io_Reader$I.apply(this, [$in, C$.defaultCharBufferSize]);
}, 1);

Clazz_newMeth(C$, 'ensureOpen',  function () {
if (this.$in == null ) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,["Stream closed"]);
}, p$1);

Clazz_newMeth(C$, 'fill',  function () {
var dst;
if (this.markedChar <= -1) {
dst=0;
} else {
var delta=this.nextChar - this.markedChar;
if (delta >= this.readAheadLimit) {
this.markedChar=-2;
this.readAheadLimit=0;
dst=0;
} else {
if (this.readAheadLimit <= this.cb.length) {
System.arraycopy$O$I$O$I$I(this.cb, this.markedChar, this.cb, 0, delta);
this.markedChar=0;
dst=delta;
} else {
var ncb=Clazz_array(Character.TYPE, [this.readAheadLimit]);
System.arraycopy$O$I$O$I$I(this.cb, this.markedChar, ncb, 0, delta);
this.cb=ncb;
this.markedChar=0;
dst=delta;
}this.nextChar=this.nChars=delta;
}}var n;
do {
n=this.$in.read$CA$I$I(this.cb, dst, this.cb.length - dst);
} while (n == 0);
if (n > 0) {
this.nChars=dst + n;
this.nextChar=dst;
}}, p$1);

Clazz_newMeth(C$, 'read$',  function () {
{
p$1.ensureOpen.apply(this, []);
for (; ; ) {
if (this.nextChar >= this.nChars) {
p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) return -1;
}if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
continue;
}}return this.cb[this.nextChar++].$c();
}
}});

Clazz_newMeth(C$, 'read1$CA$I$I',  function (cbuf, off, len) {
if (this.nextChar >= this.nChars) {
if (len >= this.cb.length && this.markedChar <= -1  && !this.skipLF ) {
return this.$in.read$CA$I$I(cbuf, off, len);
}p$1.fill.apply(this, []);
}if (this.nextChar >= this.nChars) return -1;
if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) return -1;
}}var n=Math.min(len, this.nChars - this.nextChar);
System.arraycopy$O$I$O$I$I(this.cb, this.nextChar, cbuf, off, n);
this.nextChar+=n;
return n;
}, p$1);

Clazz_newMeth(C$, 'read$CA$I$I',  function (cbuf, off, len) {
{
p$1.ensureOpen.apply(this, []);
if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
} else if (len == 0) {
return 0;
}var n=p$1.read1$CA$I$I.apply(this, [cbuf, off, len]);
if (n <= 0) return n;
while ((n < len) && this.$in.ready$() ){
var n1=p$1.read1$CA$I$I.apply(this, [cbuf, off + n, len - n]);
if (n1 <= 0) break;
n+=n1;
}
return n;
}});

Clazz_newMeth(C$, 'readLine$Z',  function (ignoreLF) {
var s=null;
var startChar;
{
p$1.ensureOpen.apply(this, []);
var omitLF=ignoreLF || this.skipLF ;
 bufferLoop : for (; ; ) {
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) {
if (s != null  && s.length$() > 0 ) return s.toString();
 else return null;
}var eol=false;
var c=String.fromCharCode(0);
var i;
if (omitLF && (this.cb[this.nextChar] == "\n") ) ++this.nextChar;
this.skipLF=false;
omitLF=false;
 charLoop : for (i=this.nextChar; i < this.nChars; i++) {
c=this.cb[i];
if ((c == "\n") || (c == "\r") ) {
eol=true;
break charLoop;
}}
startChar=this.nextChar;
this.nextChar=i;
if (eol) {
var str;
if (s == null ) {
str= String.instantialize(this.cb, startChar, i - startChar);
} else {
s.append$CA$I$I(this.cb, startChar, i - startChar);
str=s.toString();
}++this.nextChar;
if (c == "\r") {
this.skipLF=true;
}return str;
}if (s == null ) s=Clazz_new_($I$(1,1).c$$I,[C$.defaultExpectedLineLength]);
s.append$CA$I$I(this.cb, startChar, i - startChar);
}
}});

Clazz_newMeth(C$, 'readLine$',  function () {
return this.readLine$Z(false);
});

Clazz_newMeth(C$, 'skip$J',  function (n) {
if (Long.$lt(n,0 )) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["skip value is negative"]);
}{
p$1.ensureOpen.apply(this, []);
var r=n;
while (Long.$gt(r,0 )){
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) break;
if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
}}var d=this.nChars - this.nextChar;
if (Long.$le(r,d )) {
this.nextChar=Long.$ival(Long.$add(this.nextChar,(r)));
r=0;
break;
} else {
(r=Long.$sub(r,(d)));
this.nextChar=this.nChars;
}}
return Long.$sub(n,r);
}});

Clazz_newMeth(C$, 'ready$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.skipLF) {
if (this.nextChar >= this.nChars && this.$in.ready$() ) {
p$1.fill.apply(this, []);
}if (this.nextChar < this.nChars) {
if (this.cb[this.nextChar] == "\n") ++this.nextChar;
this.skipLF=false;
}}return (this.nextChar < this.nChars) || this.$in.ready$() ;
}});

Clazz_newMeth(C$, 'markSupported$',  function () {
return true;
});

Clazz_newMeth(C$, 'mark$I',  function (readAheadLimit) {
if (readAheadLimit < 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Read-ahead limit < 0"]);
}{
p$1.ensureOpen.apply(this, []);
this.readAheadLimit=readAheadLimit;
this.markedChar=this.nextChar;
this.markedSkipLF=this.skipLF;
}});

Clazz_newMeth(C$, 'reset$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.markedChar < 0) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,[(this.markedChar == -2) ? "Mark invalid" : "Stream not marked"]);
this.nextChar=this.markedChar;
this.skipLF=this.markedSkipLF;
}});

Clazz_newMeth(C$, 'close$',  function () {
{
if (this.$in == null ) return;
try {
this.$in.close$();
} finally {
this.$in=null;
this.cb=null;
}
}});

Clazz_newMeth(C$, 'lines$',  function () {
var iter=((P$.BufferedReader$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "BufferedReader$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Iterator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.nextLine=null;
},1);

C$.$fields$=[['S',['nextLine']]]

Clazz_newMeth(C$, 'hasNext$',  function () {
if (this.nextLine != null ) {
return true;
} else {
try {
this.nextLine=this.b$['java.io.BufferedReader'].readLine$.apply(this.b$['java.io.BufferedReader'], []);
return (this.nextLine != null );
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
throw Clazz_new_(Clazz_load('java.io.UncheckedIOException').c$$java_io_IOException,[e]);
} else {
throw e;
}
}
}});

Clazz_newMeth(C$, 'next$',  function () {
if (this.nextLine != null  || this.hasNext$() ) {
var line=this.nextLine;
this.nextLine=null;
return line;
} else {
throw Clazz_new_(Clazz_load('java.util.NoSuchElementException'));
}});
})()
), Clazz_new_(P$.BufferedReader$1.$init$,[this, null]));
return $I$(2,"stream$java_util_Spliterator$Z",[$I$(3).spliteratorUnknownSize$java_util_Iterator$I(iter, 272), false]);
});

C$.$static$=function(){C$.$static$=0;
C$.defaultCharBufferSize=8192;
C$.defaultExpectedLineLength=80;
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "Closeable", null, null, 'AutoCloseable');

C$.$clinit$=2;
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[[0,'java.util.Objects']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Reader", null, null, ['Readable', 'java.io.Closeable']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['lock','java.lang.Object']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.lock=this;
}, 1);

Clazz_newMeth(C$, 'c$$O',  function (lock) {
;C$.$init$.apply(this);
if (lock != null ) this.lock="";
 else throw Clazz_new_(Clazz_load('NullPointerException'));
}, 1);

Clazz_newMeth(C$, 'transferTo$java_io_Writer',  function (out) {
$I$(1).requireNonNull$O$S(out, "out");
var transferred=0;
var buffer=Clazz_array(Character.TYPE, [8192]);
var nRead;
while ((nRead=this.read$CA$I$I(buffer, 0, 8192)) >= 0){
out.write$CA$I$I(buffer, 0, nRead);
(transferred=Long.$add(transferred,(nRead)));
}
return transferred;
});

Clazz_newMeth(C$, 'mark$I',  function (readLimit) {
throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'markSupported$',  function () {
return false;
});

Clazz_newMeth(C$, 'read$',  function () {
{
var charArray=Clazz_array(Character.TYPE, [1]);
if (this.read$CA$I$I(charArray, 0, 1) != -1) return charArray[0].$c();
return -1;
}});

Clazz_newMeth(C$, 'read$CA',  function (buf) {
return this.read$CA$I$I(buf, 0, buf.length);
});

Clazz_newMeth(C$, 'ready$',  function () {
return false;
});

Clazz_newMeth(C$, 'reset$',  function () {
throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'skip$J',  function (count) {
if (Long.$ge(count,0 )) {
{
var skipped=0;
var toRead=Long.$lt(count,512 ) ? Long.$ival(count) : 512;
var charsSkipped=Clazz_array(Character.TYPE, [toRead]);
while (Long.$lt(skipped,count )){
var read=this.read$CA$I$I(charsSkipped, 0, toRead);
if (read == -1) {
return skipped;
}(skipped=Long.$add(skipped,(read)));
if (read < toRead) {
return skipped;
}if (Long.$lt(Long.$sub(count,skipped),toRead )) {
toRead=Long.$ival((Long.$sub(count,skipped)));
}}
return skipped;
}}throw Clazz_new_(Clazz_load('IllegalArgumentException'));
});

Clazz_newMeth(C$, 'read$java_nio_CharBuffer',  function (target) {
if (null == target ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}var length=target.length$();
var buf=Clazz_array(Character.TYPE, [length]);
length=Math.min(length, this.read$CA(buf));
if (length > 0) {
target.put$CA$I$I(buf, 0, length);
}return length;
});
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:01 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={};
/*c*/var C$=Clazz_newClass(P$, "StringReader", null, 'java.io.Reader');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.next=0;
this.mark=0;
},1);

C$.$fields$=[['I',['length','next','mark'],'S',['str']]]

Clazz_newMeth(C$, 'c$$S',  function (s) {
Clazz_super_(C$, this);
this.str=s;
this.length=s.length$();
}, 1);

Clazz_newMeth(C$, 'ensureOpen',  function () {
if (this.str == null ) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,["Stream closed"]);
}, p$1);

Clazz_newMeth(C$, 'read$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.next >= this.length) return -1;
return this.str.charAt$I(this.next++).$c();
}});

Clazz_newMeth(C$, 'read$CA$I$I',  function (cbuf, off, len) {
{
p$1.ensureOpen.apply(this, []);
if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
} else if (len == 0) {
return 0;
}if (this.next >= this.length) return -1;
var n=Math.min(this.length - this.next, len);
this.str.getChars$I$I$CA$I(this.next, this.next + n, cbuf, off);
this.next+=n;
return n;
}});

Clazz_newMeth(C$, 'skip$J',  function (ns) {
{
p$1.ensureOpen.apply(this, []);
if (this.next >= this.length) return 0;
var n=Math.min$J$J(this.length - this.next, ns);
n=Math.max$J$J(-this.next, n);
this.next=Long.$ival(Long.$add(this.next,(n)));
return n;
}});

Clazz_newMeth(C$, 'ready$',  function () {
{
p$1.ensureOpen.apply(this, []);
return true;
}});

Clazz_newMeth(C$, 'markSupported$',  function () {
return true;
});

Clazz_newMeth(C$, 'mark$I',  function (readAheadLimit) {
if (readAheadLimit < 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Read-ahead limit < 0"]);
}{
p$1.ensureOpen.apply(this, []);
this.mark=this.next;
}});

Clazz_newMeth(C$, 'reset$',  function () {
{
p$1.ensureOpen.apply(this, []);
this.next=this.mark;
}});

Clazz_newMeth(C$, 'close$',  function () {
this.str=null;
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:01 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "AutoCloseable");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:02 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "Readable");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:03 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.util,p$1={};
/*c*/var C$=Clazz_newClass(P$, "ComparableTimSort");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.minGallop=7;
this.stackSize=0;
},1);

C$.$fields$=[['I',['minGallop','tmpBase','tmpLen','stackSize'],'O',['a','Object[]','+tmp','runBase','int[]','+runLen']]]

Clazz_newMeth(C$, 'c$$OA$OA$I$I',  function (a, work, workBase, workLen) {
;C$.$init$.apply(this);
this.a=a;
var len=a.length;
var tlen=(len < 512) ? len >>> 1 : 256;
if (work == null  || workLen < tlen  || workBase + tlen > work.length ) {
this.tmp=Clazz_array(java.lang.Object, [tlen]);
this.tmpBase=0;
this.tmpLen=tlen;
} else {
this.tmp=work;
this.tmpBase=workBase;
this.tmpLen=workLen;
}var stackLen=(len < 120 ? 5 : len < 1542 ? 10 : len < 119151 ? 24 : 49);
this.runBase=Clazz_array(Integer.TYPE, [stackLen]);
this.runLen=Clazz_array(Integer.TYPE, [stackLen]);
}, 1);

Clazz_newMeth(C$, 'sort$OA$I$I$OA$I$I',  function (a, lo, hi, work, workBase, workLen) {
Clazz_assert(C$, this, function(){return a != null  && lo >= 0  && lo <= hi  && hi <= a.length });
var nRemaining=hi - lo;
if (nRemaining < 2) return;
if (nRemaining < 32) {
var initRunLen=C$.countRunAndMakeAscending$OA$I$I(a, lo, hi);
C$.binarySort$OA$I$I$I(a, lo, hi, lo + initRunLen);
return;
}var ts=Clazz_new_(C$.c$$OA$OA$I$I,[a, work, workBase, workLen]);
var minRun=C$.minRunLength$I(nRemaining);
do {
var runLen=C$.countRunAndMakeAscending$OA$I$I(a, lo, hi);
if (runLen < minRun) {
var force=nRemaining <= minRun ? nRemaining : minRun;
C$.binarySort$OA$I$I$I(a, lo, lo + force, lo + runLen);
runLen=force;
}p$1.pushRun$I$I.apply(ts, [lo, runLen]);
p$1.mergeCollapse.apply(ts, []);
lo+=runLen;
nRemaining-=runLen;
} while (nRemaining != 0);
Clazz_assert(C$, this, function(){return lo == hi});
p$1.mergeForceCollapse.apply(ts, []);
Clazz_assert(C$, this, function(){return ts.stackSize == 1});
}, 1);

Clazz_newMeth(C$, 'binarySort$OA$I$I$I',  function (a, lo, hi, start) {
Clazz_assert(C$, this, function(){return lo <= start && start <= hi });
if (start == lo) ++start;
for (; start < hi; start++) {
var pivot=a[start];
var left=lo;
var right=start;
Clazz_assert(C$, this, function(){return left <= right});
while (left < right){
var mid=(left + right) >>> 1;
if (pivot.compareTo$O(a[mid]) < 0) right=mid;
 else left=mid + 1;
}
Clazz_assert(C$, this, function(){return left == right});
var n=start - left;
switch (n) {
case 2:
a[left + 2]=a[left + 1];
case 1:
a[left + 1]=a[left];
break;
default:
System.arraycopy$O$I$O$I$I(a, left, a, left + 1, n);
}
a[left]=pivot;
}
}, 1);

Clazz_newMeth(C$, 'countRunAndMakeAscending$OA$I$I',  function (a, lo, hi) {
Clazz_assert(C$, this, function(){return lo < hi});
var runHi=lo + 1;
if (runHi == hi) return 1;
if ((a[runHi++]).compareTo$O(a[lo]) < 0) {
while (runHi < hi && (a[runHi]).compareTo$O(a[runHi - 1]) < 0 )++runHi;

C$.reverseRange$OA$I$I(a, lo, runHi);
} else {
while (runHi < hi && (a[runHi]).compareTo$O(a[runHi - 1]) >= 0 )++runHi;

}return runHi - lo;
}, 1);

Clazz_newMeth(C$, 'reverseRange$OA$I$I',  function (a, lo, hi) {
--hi;
while (lo < hi){
var t=a[lo];
a[lo++]=a[hi];
a[hi--]=t;
}
}, 1);

Clazz_newMeth(C$, 'minRunLength$I',  function (n) {
Clazz_assert(C$, this, function(){return n >= 0});
var r=0;
while (n >= 32){
r|=(n & 1);
n>>=1;
}
return n + r;
}, 1);

Clazz_newMeth(C$, 'pushRun$I$I',  function (runBase, runLen) {
this.runBase[this.stackSize]=runBase;
this.runLen[this.stackSize]=runLen;
++this.stackSize;
}, p$1);

Clazz_newMeth(C$, 'mergeCollapse',  function () {
while (this.stackSize > 1){
var n=this.stackSize - 2;
if (n > 0 && this.runLen[n - 1] <= this.runLen[n] + this.runLen[n + 1] ) {
if (this.runLen[n - 1] < this.runLen[n + 1]) --n;
p$1.mergeAt$I.apply(this, [n]);
} else if (this.runLen[n] <= this.runLen[n + 1]) {
p$1.mergeAt$I.apply(this, [n]);
} else {
break;
}}
}, p$1);

Clazz_newMeth(C$, 'mergeForceCollapse',  function () {
while (this.stackSize > 1){
var n=this.stackSize - 2;
if (n > 0 && this.runLen[n - 1] < this.runLen[n + 1] ) --n;
p$1.mergeAt$I.apply(this, [n]);
}
}, p$1);

Clazz_newMeth(C$, 'mergeAt$I',  function (i) {
Clazz_assert(C$, this, function(){return this.stackSize >= 2});
Clazz_assert(C$, this, function(){return i >= 0});
Clazz_assert(C$, this, function(){return i == this.stackSize - 2 || i == this.stackSize - 3 });
var base1=this.runBase[i];
var len1=this.runLen[i];
var base2=this.runBase[i + 1];
var len2=this.runLen[i + 1];
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0 });
Clazz_assert(C$, this, function(){return base1 + len1 == base2});
this.runLen[i]=len1 + len2;
if (i == this.stackSize - 3) {
this.runBase[i + 1]=this.runBase[i + 2];
this.runLen[i + 1]=this.runLen[i + 2];
}--this.stackSize;
var k=C$.gallopRight$Comparable$OA$I$I$I(this.a[base2], this.a, base1, len1, 0);
Clazz_assert(C$, this, function(){return k >= 0});
base1+=k;
len1-=k;
if (len1 == 0) return;
len2=C$.gallopLeft$Comparable$OA$I$I$I(this.a[base1 + len1 - 1], this.a, base2, len2, len2 - 1);
Clazz_assert(C$, this, function(){return len2 >= 0});
if (len2 == 0) return;
if (len1 <= len2) p$1.mergeLo$I$I$I$I.apply(this, [base1, len1, base2, len2]);
 else p$1.mergeHi$I$I$I$I.apply(this, [base1, len1, base2, len2]);
}, p$1);

Clazz_newMeth(C$, 'gallopLeft$Comparable$OA$I$I$I',  function (key, a, base, len, hint) {
Clazz_assert(C$, this, function(){return len > 0 && hint >= 0  && hint < len });
var lastOfs=0;
var ofs=1;
if (key.compareTo$O(a[base + hint]) > 0) {
var maxOfs=len - hint;
while (ofs < maxOfs && key.compareTo$O(a[base + hint + ofs ]) > 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
lastOfs+=hint;
ofs+=hint;
} else {
var maxOfs=hint + 1;
while (ofs < maxOfs && key.compareTo$O(a[base + hint - ofs]) <= 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
var tmp=lastOfs;
lastOfs=hint - ofs;
ofs=hint - tmp;
}Clazz_assert(C$, this, function(){return -1 <= lastOfs && lastOfs < ofs  && ofs <= len });
++lastOfs;
while (lastOfs < ofs){
var m=lastOfs + ((ofs - lastOfs) >>> 1);
if (key.compareTo$O(a[base + m]) > 0) lastOfs=m + 1;
 else ofs=m;
}
Clazz_assert(C$, this, function(){return lastOfs == ofs});
return ofs;
}, 1);

Clazz_newMeth(C$, 'gallopRight$Comparable$OA$I$I$I',  function (key, a, base, len, hint) {
Clazz_assert(C$, this, function(){return len > 0 && hint >= 0  && hint < len });
var ofs=1;
var lastOfs=0;
if (key.compareTo$O(a[base + hint]) < 0) {
var maxOfs=hint + 1;
while (ofs < maxOfs && key.compareTo$O(a[base + hint - ofs]) < 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
var tmp=lastOfs;
lastOfs=hint - ofs;
ofs=hint - tmp;
} else {
var maxOfs=len - hint;
while (ofs < maxOfs && key.compareTo$O(a[base + hint + ofs ]) >= 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
lastOfs+=hint;
ofs+=hint;
}Clazz_assert(C$, this, function(){return -1 <= lastOfs && lastOfs < ofs  && ofs <= len });
++lastOfs;
while (lastOfs < ofs){
var m=lastOfs + ((ofs - lastOfs) >>> 1);
if (key.compareTo$O(a[base + m]) < 0) ofs=m;
 else lastOfs=m + 1;
}
Clazz_assert(C$, this, function(){return lastOfs == ofs});
return ofs;
}, 1);

Clazz_newMeth(C$, 'mergeLo$I$I$I$I',  function (base1, len1, base2, len2) {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0  && base1 + len1 == base2 });
var a=this.a;
var tmp=p$1.ensureCapacity$I.apply(this, [len1]);
var cursor1=this.tmpBase;
var cursor2=base2;
var dest=base1;
System.arraycopy$O$I$O$I$I(a, base1, tmp, cursor1, len1);
a[dest++]=a[cursor2++];
if (--len2 == 0) {
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, len1);
return;
}if (len1 == 1) {
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, len2);
a[dest + len2]=tmp[cursor1];
return;
}var minGallop=this.minGallop;
 outer : while (true){
var count1=0;
var count2=0;
do {
Clazz_assert(C$, this, function(){return len1 > 1 && len2 > 0 });
if ((a[cursor2]).compareTo$O(tmp[cursor1]) < 0) {
a[dest++]=a[cursor2++];
++count2;
count1=0;
if (--len2 == 0) break outer;
} else {
a[dest++]=tmp[cursor1++];
++count1;
count2=0;
if (--len1 == 1) break outer;
}} while ((count1 | count2) < minGallop);
do {
Clazz_assert(C$, this, function(){return len1 > 1 && len2 > 0 });
count1=C$.gallopRight$Comparable$OA$I$I$I(a[cursor2], tmp, cursor1, len1, 0);
if (count1 != 0) {
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, count1);
dest+=count1;
cursor1+=count1;
len1-=count1;
if (len1 <= 1) break outer;
}a[dest++]=a[cursor2++];
if (--len2 == 0) break outer;
count2=C$.gallopLeft$Comparable$OA$I$I$I(tmp[cursor1], a, cursor2, len2, 0);
if (count2 != 0) {
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, count2);
dest+=count2;
cursor2+=count2;
len2-=count2;
if (len2 == 0) break outer;
}a[dest++]=tmp[cursor1++];
if (--len1 == 1) break outer;
--minGallop;
} while (!!(count1 >= 7 | count2 >= 7));
if (minGallop < 0) minGallop=0;
minGallop+=2;
}
this.minGallop=minGallop < 1 ? 1 : minGallop;
if (len1 == 1) {
Clazz_assert(C$, this, function(){return len2 > 0});
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, len2);
a[dest + len2]=tmp[cursor1];
} else if (len1 == 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Comparison method violates its general contract!"]);
} else {
Clazz_assert(C$, this, function(){return len2 == 0});
Clazz_assert(C$, this, function(){return len1 > 1});
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, len1);
}}, p$1);

Clazz_newMeth(C$, 'mergeHi$I$I$I$I',  function (base1, len1, base2, len2) {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0  && base1 + len1 == base2 });
var a=this.a;
var tmp=p$1.ensureCapacity$I.apply(this, [len2]);
var tmpBase=this.tmpBase;
System.arraycopy$O$I$O$I$I(a, base2, tmp, tmpBase, len2);
var cursor1=base1 + len1 - 1;
var cursor2=tmpBase + len2 - 1;
var dest=base2 + len2 - 1;
a[dest--]=a[cursor1--];
if (--len1 == 0) {
System.arraycopy$O$I$O$I$I(tmp, tmpBase, a, dest - (len2 - 1), len2);
return;
}if (len2 == 1) {
dest-=len1;
cursor1-=len1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, len1);
a[dest]=tmp[cursor2];
return;
}var minGallop=this.minGallop;
 outer : while (true){
var count1=0;
var count2=0;
do {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 1 });
if ((tmp[cursor2]).compareTo$O(a[cursor1]) < 0) {
a[dest--]=a[cursor1--];
++count1;
count2=0;
if (--len1 == 0) break outer;
} else {
a[dest--]=tmp[cursor2--];
++count2;
count1=0;
if (--len2 == 1) break outer;
}} while ((count1 | count2) < minGallop);
do {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 1 });
count1=len1 - C$.gallopRight$Comparable$OA$I$I$I(tmp[cursor2], a, base1, len1, len1 - 1);
if (count1 != 0) {
dest-=count1;
cursor1-=count1;
len1-=count1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, count1);
if (len1 == 0) break outer;
}a[dest--]=tmp[cursor2--];
if (--len2 == 1) break outer;
count2=len2 - C$.gallopLeft$Comparable$OA$I$I$I(a[cursor1], tmp, tmpBase, len2, len2 - 1);
if (count2 != 0) {
dest-=count2;
cursor2-=count2;
len2-=count2;
System.arraycopy$O$I$O$I$I(tmp, cursor2 + 1, a, dest + 1, count2);
if (len2 <= 1) break outer;
}a[dest--]=a[cursor1--];
if (--len1 == 0) break outer;
--minGallop;
} while (!!(count1 >= 7 | count2 >= 7));
if (minGallop < 0) minGallop=0;
minGallop+=2;
}
this.minGallop=minGallop < 1 ? 1 : minGallop;
if (len2 == 1) {
Clazz_assert(C$, this, function(){return len1 > 0});
dest-=len1;
cursor1-=len1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, len1);
a[dest]=tmp[cursor2];
} else if (len2 == 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Comparison method violates its general contract!"]);
} else {
Clazz_assert(C$, this, function(){return len1 == 0});
Clazz_assert(C$, this, function(){return len2 > 0});
System.arraycopy$O$I$O$I$I(tmp, tmpBase, a, dest - (len2 - 1), len2);
}}, p$1);

Clazz_newMeth(C$, 'ensureCapacity$I',  function (minCapacity) {
if (this.tmpLen < minCapacity) {
var newSize=minCapacity;
newSize|=newSize >> 1;
newSize|=newSize >> 2;
newSize|=newSize >> 4;
newSize|=newSize >> 8;
newSize|=newSize >> 16;
++newSize;
if (newSize < 0) newSize=minCapacity;
 else newSize=Math.min(newSize, this.a.length >>> 1);
var newArray=Clazz_array(java.lang.Object, [newSize]);
this.tmp=newArray;
this.tmpLen=newSize;
this.tmpBase=0;
}return this.tmp;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:19 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.util,I$=[];
/*c*/var C$=Clazz_newClass(P$, "DualPivotQuicksort");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'sort$IA$I$I$IA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Integer.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$IA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$IA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$IA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$IA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$IA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$IA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$JA$I$I$JA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (Long.$lt(a[k],a[k + 1] )) {
while (++k <= right && Long.$le(a[k - 1],a[k] ) );
} else if (Long.$gt(a[k],a[k + 1] )) {
while (++k <= right && Long.$ge(a[k - 1],a[k] ) );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && Long.$eq(a[k - 1],a[k] ) ; ) {
if (--m == 0) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Long.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && Long.$le(a[p + ao],a[q + ao] )  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$JA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (Long.$lt(ai,a[j] )){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (Long.$ge(a[++left],a[left - 1] ));
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (Long.$lt(a1,a2 )) {
a2=a1;
a1=a[left];
}while (Long.$lt(a1,a[--k] )){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (Long.$lt(a2,a[--k] )){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (Long.$lt(last,a[--right] )){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (Long.$lt(a[e2],a[e1] )) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (Long.$lt(a[e3],a[e2] )) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}if (Long.$lt(a[e4],a[e3] )) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (Long.$lt(t,a[e2] )) {
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}}if (Long.$lt(a[e5],a[e4] )) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (Long.$lt(t,a[e3] )) {
a[e4]=a[e3];
a[e3]=t;
if (Long.$lt(t,a[e2] )) {
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (Long.$ne(a[e1],a[e2] ) && Long.$ne(a[e2],a[e3] )  && Long.$ne(a[e3],a[e4] )  && Long.$ne(a[e4],a[e5] ) ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (Long.$lt(a[++less],pivot1 ));
while (Long.$gt(a[--great],pivot2 ));
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (Long.$lt(ak,pivot1 )) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (Long.$gt(ak,pivot2 )) {
while (Long.$gt(a[great],pivot2 )){
if (great-- == k) {
break outer;
}}
if (Long.$lt(a[great],pivot1 )) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$JA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$JA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (Long.$eq(a[less],pivot1 )){
++less;
}
while (Long.$eq(a[great],pivot2 )){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (Long.$eq(ak,pivot1 )) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (Long.$eq(ak,pivot2 )) {
while (Long.$eq(a[great],pivot2 )){
if (great-- == k) {
break outer;
}}
if (Long.$eq(a[great],pivot1 )) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$JA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (Long.$eq(a[k],pivot )) {
continue;
}var ak=a[k];
if (Long.$lt(ak,pivot )) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (Long.$gt(a[great],pivot )){
--great;
}
if (Long.$lt(a[great],pivot )) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$JA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$JA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$HA$I$I$HA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left > 3200) {
var count=Clazz_array(Integer.TYPE, [65536]);
for (var i=left - 1; ++i <= right; count[a[i] - -32768]++) ;
for (var i=65536, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=($s$[0] = (i + -32768), $s$[0]);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
C$.doSort$HA$I$I$HA$I$I(a, left, right, work, workBase, workLen);
}}, 1);

Clazz_newMeth(C$, 'doSort$HA$I$I$HA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Short.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$HA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$HA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$HA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$HA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$HA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$HA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$CA$I$I$CA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left > 3200) {
var count=Clazz_array(Integer.TYPE, [65536]);
for (var i=left - 1; ++i <= right; count[(a[i]).$c()]++) ;
for (var i=65536, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=String.fromCharCode(i);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
C$.doSort$CA$I$I$CA$I$I(a, left, right, work, workBase, workLen);
}}, 1);

Clazz_newMeth(C$, 'doSort$CA$I$I$CA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Character.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$CA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$CA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$CA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$CA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$CA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$CA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$BA$I$I',  function (a, left, right) {
if (right - left > 29) {
var count=Clazz_array(Integer.TYPE, [256]);
for (var i=left - 1; ++i <= right; count[a[i] - -128]++) ;
for (var i=256, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=($b$[0] = (i + -128), $b$[0]);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
}}, 1);

Clazz_newMeth(C$, 'sort$FA$I$I$FA$I$I',  function (a, left, right, work, workBase, workLen) {
while (left <= right && Float.isNaN$F(a[right]) ){
--right;
}
for (var k=right; --k >= left; ) {
var ak=a[k];
if (ak != ak ) {
a[k]=a[right];
a[right]=ak;
--right;
}}
C$.doSort$FA$I$I$FA$I$I(a, left, right, work, workBase, workLen);
var hi=right;
while (left < hi){
var middle=(left + hi) >>> 1;
var middleValue=a[middle];
if (middleValue < 0.0 ) {
left=middle + 1;
} else {
hi=middle;
}}
while (left <= right && Float.floatToRawIntBits$F(a[left]) < 0 ){
++left;
}
for (var k=left, p=left - 1; ++k <= right; ) {
var ak=a[k];
if (ak != 0.0 ) {
break;
}if (Float.floatToRawIntBits$F(ak) < 0) {
a[k]=0.0;
a[++p]=-0.0;
}}
}, 1);

Clazz_newMeth(C$, 'doSort$FA$I$I$FA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1] ) {
while (++k <= right && a[k - 1] <= a[k]  );
} else if (a[k] > a[k + 1] ) {
while (++k <= right && a[k - 1] >= a[k]  );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k]  ; ) {
if (--m == 0) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Float.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]   ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$FA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j] ){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1] );
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2 ) {
a2=a1;
a1=a[left];
}while (a1 < a[--k] ){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k] ){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right] ){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1] ) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2] ) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3] ) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4] ) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3] ) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2]  && a[e2] != a[e3]   && a[e3] != a[e4]   && a[e4] != a[e5]  ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1 );
while (a[--great] > pivot2 );
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2 ) {
while (a[great] > pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$FA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$FA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1 ){
++less;
}
while (a[great] == pivot2 ){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2 ) {
while (a[great] == pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$FA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot ) {
continue;
}var ak=a[k];
if (ak < pivot ) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot ){
--great;
}
if (a[great] < pivot ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
C$.sort$FA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$FA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$DA$I$I$DA$I$I',  function (a, left, right, work, workBase, workLen) {
while (left <= right && Double.isNaN$D(a[right]) ){
--right;
}
for (var k=right; --k >= left; ) {
var ak=a[k];
if (ak != ak ) {
a[k]=a[right];
a[right]=ak;
--right;
}}
C$.doSort$DA$I$I$DA$I$I(a, left, right, work, workBase, workLen);
var hi=right;
while (left < hi){
var middle=(left + hi) >>> 1;
var middleValue=a[middle];
if (middleValue < 0.0 ) {
left=middle + 1;
} else {
hi=middle;
}}
while (left <= right && Long.$lt(Double.doubleToRawLongBits$D(a[left]),0 ) ){
++left;
}
for (var k=left, p=left - 1; ++k <= right; ) {
var ak=a[k];
if (ak != 0.0 ) {
break;
}if (Long.$lt(Double.doubleToRawLongBits$D(ak),0 )) {
a[k]=0.0;
a[++p]=-0.0;
}}
}, 1);

Clazz_newMeth(C$, 'doSort$DA$I$I$DA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1] ) {
while (++k <= right && a[k - 1] <= a[k]  );
} else if (a[k] > a[k + 1] ) {
while (++k <= right && a[k - 1] >= a[k]  );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k]  ; ) {
if (--m == 0) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Double.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]   ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$DA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j] ){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1] );
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2 ) {
a2=a1;
a1=a[left];
}while (a1 < a[--k] ){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k] ){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right] ){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1] ) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2] ) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3] ) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4] ) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3] ) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2]  && a[e2] != a[e3]   && a[e3] != a[e4]   && a[e4] != a[e5]  ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1 );
while (a[--great] > pivot2 );
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2 ) {
while (a[great] > pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$DA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$DA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1 ){
++less;
}
while (a[great] == pivot2 ){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2 ) {
while (a[great] == pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$DA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot ) {
continue;
}var ak=a[k];
if (ak < pivot ) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot ){
--great;
}
if (a[great] < pivot ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
C$.sort$DA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$DA$I$I$Z(a, great + 1, right, false);
}}, 1);
var $b$ = new Int8Array(1);
var $s$ = new Int16Array(1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:19 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ChemicalMimeType");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['typeName','url','molfile']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'molfile$S',  function (separator) {
return C$.typeName + separator + C$.molfile ;
}, 1);

Clazz_newMeth(C$, 'chemicalMimeTag$',  function () {
return C$.molfile$S(":");
}, 1);

Clazz_newMeth(C$, 'extractEmbeddedChemicalString$S',  function (svg) {
var result=null;
var tag=C$.chemicalMimeTag$();
var tagStart=svg.indexOf$S(tag);
if (tagStart > 0) {
var molStart=svg.indexOf$S$I(">", tagStart) + 1;
var molEnd=svg.indexOf$S$I("</" + tag, molStart);
if (molEnd - molStart > 20) {
result=svg.substring$I$I(molStart, molEnd);
}}if (result == null ) return null;
if (result.indexOf$I("\n") < 0) result=result.replaceAll$S$S("\\\n", "\n");
return $I$(1).unwrapCData$S(result);
}, 1);

Clazz_newMeth(C$, 'additionalNameSpaces$S',  function (post) {
return "xmlns:" + C$.typeName + "=\"" + C$.url + "\"" + post ;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.typeName="chemical";
C$.url="http://www.ch.ic.ac.uk/chemime/";
C$.molfile="x-mdl-molfile";
};
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-25 03:18:17 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil','jme.io.ChemicalMimeType']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "JMESVGWriter", null, 'com.actelion.research.chem.SVGDepictor');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['mdlMOL','tag']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S',  function (mol, mdlMol) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$S.apply(this,[mol, ""]);C$.$init$.apply(this);
if (mdlMol != null  && mdlMol.length$() > 0 ) this.mdlMOL=mdlMol;
var mode=224;
this.setDisplayMode$I(mode);
}, 1);

Clazz_newMeth(C$, 'additionalMetaInfo$S',  function (indent) {
var result="";
if (this.mdlMOL != null ) {
var molData=$I$(1).wrapCDATA$S(this.mdlMOL);
result=indent + "<" + $I$(2).chemicalMimeTag$() + ">" + molData + "</" + $I$(2).chemicalMimeTag$() + ">\n" ;
}return result;
});

Clazz_newMeth(C$, 'toString',  function () {
var svg=C$.superclazz.prototype.toString.apply(this, []);
if (this.mdlMOL != null ) {
var pt=svg.lastIndexOf$S("</");
if (pt > 0) {
svg=svg.substring$I$I(0, pt) + this.additionalMetaInfo$S("") + svg.substring$I(pt) ;
}pt=svg.indexOf$S("xmlns");
if (pt > 0) {
svg=svg.substring$I$I(0, pt) + $I$(2).additionalNameSpaces$S(" ") + svg.substring$I(pt) ;
}}return svg;
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-25 03:18:17 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
})(Clazz,Clazz.setTVer,Clazz.toLong,Clazz.incrAN,Clazz.array,Clazz.assert,Clazz.clone,Clazz.exceptionOf,Clazz.forName,Clazz.getClass,Clazz.instanceOf,Clazz.load,Clazz.new_,Clazz.newClass,Clazz.newEnumConst,Clazz.newInstance,Clazz.newInterface,Clazz.newMeth,Clazz.newPackage,Clazz.super_);
