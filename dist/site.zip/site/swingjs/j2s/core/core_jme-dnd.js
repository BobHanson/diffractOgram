(function(Clazz,Clazz_setTVer,Clazz_toLong,Clazz_incrAN,Clazz_array,Clazz_assert,Clazz_clone,Clazz_exceptionOf,Clazz_forName,Clazz_getClass,Clazz_instanceOf,Clazz_load,Clazz_new_,Clazz_newClass,Clazz_newEnumConst,Clazz_newInstance,Clazz_newInterface,Clazz_newMeth,Clazz_newPackage,Clazz_super_){(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.Arrays','com.actelion.research.chem.CanonizerMesoHelper','java.util.ArrayList','com.actelion.research.chem.CanonizerBond','com.actelion.research.chem.CanonizerBaseValue','com.actelion.research.chem.SortedStringList','com.actelion.research.chem.CanonizerFragment','com.actelion.research.chem.EZHalfParity','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Molecule','StringBuilder','com.actelion.research.chem.Canonizer$1RankObject','com.actelion.research.chem.Canonizer$2RankObject']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Canonizer", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['ESRGroup',0]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mIsMeso','mStereoCentersFound','mIsOddParityRound','mZCoordinatesAvailable','mCIPParityNoDistinctionProblem','mEncodeAvoid127','mGraphGenerated'],'I',['mMode','mNoOfRanks','mNoOfPseudoGroups','mGraphRings','mFeatureBlock','mEncodingBitsAvail','mEncodingTempData','mAtomBits','mMaxConnAtoms'],'S',['mIDCode','mEncodedCoords','mMapping'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mCanRank','int[]','+mCanRankBeforeTieBreaking','+mPseudoTHGroup','+mPseudoEZGroup','mTHParity','byte[]','+mEZParity','+mTHConfiguration','+mEZConfiguration','+mTHCIPParity','+mEZCIPParity','+mTHESRType','+mTHESRGroup','+mEZESRType','+mEZESRGroup','+mAbnormalValence','mCanBase','com.actelion.research.chem.CanonizerBaseValue[]','mMesoHelper','com.actelion.research.chem.CanonizerMesoHelper','mIsStereoCenter','boolean[]','+mTHParityIsMesoInverted','+mTHParityNeedsNormalization','+mTHESRTypeNeedsNormalization','+mTHParityRoundIsOdd','+mEZParityRoundIsOdd','+mTHParityIsPseudo','+mEZParityIsPseudo','+mProTHAtomsInSameFragment','+mProEZAtomsInSameFragment','+mNitrogenQualifiesForParity','mFragmentList','java.util.ArrayList','+mTHParityNormalizationGroupList','mGraphAtom','int[]','+mGraphIndex','+mGraphBond','+mGraphFrom','+mGraphClosure','mEncodingBuffer','StringBuilder']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, 0]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, mode) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMode=mode;
this.mMol.ensureHelperArrays$I(7);
this.mAtomBits=C$.getNeededBits$I(this.mMol.getAtoms$());
if ((this.mMode & 2048) == 0) p$1.canFindNitrogenQualifyingForParity.apply(this, []);
this.mZCoordinatesAvailable=((mode & 64) != 0) || this.mMol.is3D$() ;
if ((this.mMode & 2048) == 0) {
this.mTHParity=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityIsPseudo=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityRoundIsOdd=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mEZParity=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
this.mEZParityRoundIsOdd=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mEZParityIsPseudo=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
}this.mCIPParityNoDistinctionProblem=false;
p$1.canInitializeRanking.apply(this, []);
if ((this.mMode & 2048) == 0) p$1.canRankStereo.apply(this, []);
p$1.canRankFinal.apply(this, []);
}, 1);

Clazz_newMeth(C$, 'hasCIPParityDistinctionProblem$',  function () {
return this.mCIPParityNoDistinctionProblem;
});

Clazz_newMeth(C$, 'canFindNitrogenQualifyingForParity',  function () {
this.mNitrogenQualifiesForParity=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomicNo$I(atom) == 7) {
if (this.mMol.getConnAtoms$I(atom) == 4) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getConnAtoms$I(atom) == 3) {
if (this.mMol.getAtomRingSize$I(atom) == 3) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getAtomCharge$I(atom) == 1) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.isFlatNitrogen$I(atom)) continue;
if ((this.mMode & 32) != 0) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}if (this.mMol.getAtomRingBondCount$I(atom) != 3) continue;
var smallRingSize=this.mMol.getAtomRingSize$I(atom);
if (smallRingSize > 7) continue;
var ringSet=this.mMol.getRingSet$();
var smallRingNo=0;
while (smallRingNo < ringSet.getSize$()){
if (ringSet.getRingSize$I(smallRingNo) == smallRingSize && ringSet.isAtomMember$I$I(smallRingNo, atom) ) break;
++smallRingNo;
}
if (smallRingNo >= 1024 && smallRingNo == ringSet.getSize$() ) continue;
var firstBridgeAtom=-1;
var firstBridgeBond=-1;
for (var i=0; i < 3; i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (!ringSet.isBondMember$I$I(smallRingNo, connBond)) {
firstBridgeAtom=this.mMol.getConnAtom$I$I(atom, i);
firstBridgeBond=connBond;
break;
}}
var neglectBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
neglectBond[firstBridgeBond]=true;
var pathAtom=Clazz_array(Integer.TYPE, [11]);
var pathLength=this.mMol.getPath$IA$I$I$I$ZA(pathAtom, firstBridgeAtom, atom, 10, neglectBond);
if (pathLength == -1) continue;
var bridgeAtomCount=1;
while (!ringSet.isAtomMember$I$I(smallRingNo, pathAtom[bridgeAtomCount]))++bridgeAtomCount;

var bondCountToBridgeHead=pathLength - bridgeAtomCount;
var bridgeHead=pathAtom[bridgeAtomCount];
if (smallRingSize == 6 && bondCountToBridgeHead == 2  && bridgeAtomCount == 3 ) {
if (this.mMol.getAtomRingBondCount$I(pathAtom[1]) >= 3) {
var isAdamantane=false;
var ringAtom=ringSet.getRingAtoms$I(smallRingNo);
for (var i=0; i < 6; i++) {
if (atom == ringAtom[i]) {
var potentialOtherBridgeHeadIndex=ringSet.validateMemberIndex$I$I(smallRingNo, (bridgeHead == ringAtom[ringSet.validateMemberIndex$I$I(smallRingNo, i + 2)]) ? i - 2 : i + 2);
var potentialOtherBridgeHead=ringAtom[potentialOtherBridgeHeadIndex];
if (this.mMol.getAtomRingBondCount$I(potentialOtherBridgeHead) >= 3 && this.mMol.getPathLength$I$I$I$ZA(pathAtom[1], potentialOtherBridgeHead, 2, null) == 2 ) isAdamantane=true;
break;
}}
if (isAdamantane) {
this.mNitrogenQualifiesForParity[atom]=true;
continue;
}}}var bridgeHeadIsFlat=(this.mMol.getAtomPi$I(bridgeHead) == 1 || this.mMol.isAromaticAtom$I(bridgeHead)  || this.mMol.isFlatNitrogen$I(bridgeHead) );
var bridgeHeadMayInvert=!bridgeHeadIsFlat && this.mMol.getAtomicNo$I(bridgeHead) == 7  && this.mMol.getAtomCharge$I(bridgeHead) != 1 ;
if (bondCountToBridgeHead == 1) {
if (!bridgeHeadIsFlat && !bridgeHeadMayInvert && smallRingSize <= 4   && bridgeAtomCount <= 3 ) this.mNitrogenQualifiesForParity[atom]=true;
continue;
}switch (smallRingSize) {
case 4:
if (!bridgeHeadIsFlat && !bridgeHeadMayInvert ) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}break;
case 5:
if (bridgeHeadMayInvert) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
} else if (!bridgeHeadIsFlat) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}break;
case 6:
if (bondCountToBridgeHead == 2) {
if (bridgeHeadIsFlat) {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
} else if (!bridgeHeadMayInvert) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
}} else if (bondCountToBridgeHead == 3) {
if (bridgeHeadIsFlat) {
if (bridgeAtomCount <= 6) this.mNitrogenQualifiesForParity[atom]=true;
} else {
if (bridgeAtomCount <= 4) this.mNitrogenQualifiesForParity[atom]=true;
}}break;
case 7:
if (bondCountToBridgeHead == 3) {
if (bridgeAtomCount <= 3) this.mNitrogenQualifiesForParity[atom]=true;
}break;
}
}}}
}, p$1);

Clazz_newMeth(C$, 'canCalcImplicitAbnormalValence$I',  function (atom) {
var explicitAbnormalValence=this.mMol.getAtomAbnormalValence$I(atom);
var implicitHigherValence=this.mMol.getImplicitHigherValence$I$Z(atom, false);
var newImplicitHigherValence=this.mMol.getImplicitHigherValence$I$Z(atom, true);
var valence=-1;
if (implicitHigherValence != newImplicitHigherValence) {
if (explicitAbnormalValence != -1 && explicitAbnormalValence > implicitHigherValence ) valence=($b$[0] = explicitAbnormalValence, $b$[0]);
 else valence=($b$[0] = implicitHigherValence, $b$[0]);
} else if (explicitAbnormalValence != -1) {
if (explicitAbnormalValence > newImplicitHigherValence || (explicitAbnormalValence < newImplicitHigherValence && explicitAbnormalValence >= this.mMol.getOccupiedValence$I(atom) ) ) valence=($b$[0] = explicitAbnormalValence, $b$[0]);
} else if (!this.mMol.supportsImplicitHydrogen$I(atom) && this.mMol.getExplicitHydrogens$I(atom) != 0 ) {
valence=this.mMol.getOccupiedValence$I(atom);
valence-=this.mMol.getElectronValenceCorrection$I$I(atom, valence);
}p$1.canSetAbnormalValence$I$I.apply(this, [atom, valence]);
return valence;
}, p$1);

Clazz_newMeth(C$, 'canSetAbnormalValence$I$I',  function (atom, valence) {
if (this.mAbnormalValence == null ) {
this.mAbnormalValence=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
$I$(1).fill$BA$B(this.mAbnormalValence, -1);
}this.mAbnormalValence[atom]=(valence|0);
}, p$1);

Clazz_newMeth(C$, 'canRankStereo',  function () {
var noOfRanksWithoutStereo=this.mNoOfRanks;
var canRankWithoutStereo=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
if (!this.mMol.isFragment$()) {
p$1.canRecursivelyFindCIPParities.apply(this, []);
p$1.initializeParities$I$IA.apply(this, [noOfRanksWithoutStereo, canRankWithoutStereo]);
}this.mTHESRType=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mTHESRGroup=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mTHESRType[atom]=(this.mMol.getAtomESRType$I(atom)|0);
this.mTHESRGroup[atom]=(this.mMol.getAtomESRGroup$I(atom)|0);
}
this.mEZESRType=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
this.mEZESRGroup=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mEZESRType[bond]=(this.mMol.getBondESRType$I(bond)|0);
this.mEZESRGroup[bond]=(this.mMol.getBondESRGroup$I(bond)|0);
}
p$1.canRecursivelyFindAllParities.apply(this, []);
this.mStereoCentersFound=false;
this.mIsStereoCenter=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0) {
this.mIsStereoCenter[atom]=true;
this.mStereoCentersFound=true;
}}
p$1.canRemoveOverspecifiedESRGroups.apply(this, []);
this.mMesoHelper=null;
this.mTHESRTypeNeedsNormalization=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
if (this.mStereoCentersFound) {
this.mMesoHelper=Clazz_new_($I$(2,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$ZA$BA$BA$BA$BA$BA$BA$ZA$ZA$ZA,[this.mMol, canRankWithoutStereo, this.mIsStereoCenter, this.mTHParity, this.mEZParity, this.mTHESRType, this.mTHESRGroup, this.mEZESRType, this.mEZESRGroup, this.mTHParityRoundIsOdd, this.mEZParityRoundIsOdd, this.mTHESRTypeNeedsNormalization]);
this.mMesoHelper.normalizeESRGroups$();
}this.mTHParityIsMesoInverted=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityNeedsNormalization=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mTHParityNormalizationGroupList=Clazz_new_($I$(3,1));
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
p$1.canMarkESRGroupsForParityNormalization.apply(this, []);
p$1.initializeParities$I$IA.apply(this, [noOfRanksWithoutStereo, canRankWithoutStereo]);
p$1.canRecursivelyFindCanonizedParities.apply(this, []);
if (this.mMesoHelper != null ) this.mIsMeso=this.mMesoHelper.isMeso$();
p$1.determineChirality$IA.apply(this, [canRankWithoutStereo]);
}, p$1);

Clazz_newMeth(C$, 'canRankFinal',  function () {
if ((this.mMode & 1) != 0 && (this.mMode & 2) == 0 ) {
this.mCanRankBeforeTieBreaking=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
}if ((this.mMode & 2048) == 0) {
this.mProTHAtomsInSameFragment=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mProEZAtomsInSameFragment=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
if (this.mNoOfRanks < this.mMol.getAtoms$()) {
p$1.canBreakTiesByHeteroTopicity.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}}}if (this.mCanRankBeforeTieBreaking == null  && (this.mMode & 1) != 0  && (this.mMode & 2) != 0 ) this.mCanRankBeforeTieBreaking=$I$(1,"copyOf$IA$I",[this.mCanRank, this.mMol.getAtoms$()]);
while (this.mNoOfRanks < this.mMol.getAtoms$()){
p$1.canBreakTiesRandomly.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}}
if ((this.mMode & 2048) == 0) {
p$1.canNormalizeGroupParities.apply(this, []);
p$1.canFindPseudoParities.apply(this, []);
p$1.flagStereoProblems.apply(this, []);
}}, p$1);

Clazz_newMeth(C$, 'canBreakTiesByHeteroTopicity',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
var found=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) found=!!(found|(p$1.canCalcTHParity$I$I.apply(this, [atom, 3])));

for (var bond=0; bond < this.mMol.getBonds$(); bond++) found=!!(found|(p$1.canCalcEZParity$I$I.apply(this, [bond, 3])));

if (!found) return false;
while (this.mNoOfRanks < this.mMol.getAtoms$()){
found=p$1.canInnerBreakTiesByHeteroTopicity.apply(this, []);
if (!found) break;
p$1.canNormalizeGroupParities.apply(this, []);
if (this.mMesoHelper != null ) this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank);
}
return true;
}, p$1);

Clazz_newMeth(C$, 'canInnerBreakTiesByHeteroTopicity',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
for (var rank=1; rank <= this.mNoOfRanks; rank++) {
var found=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] == rank) found=!!(found|(p$1.canCalcTHParity$I$I.apply(this, [atom, 2])));

if (found) {
var oldRanks=this.mNoOfRanks;
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks != oldRanks) return true;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
}}
var rankedBond=Clazz_array($I$(4), [this.mMol.getBonds$()]);
for (var i=0; i < rankedBond.length; i++) rankedBond[i]=Clazz_new_([this.mCanRank[this.mMol.getBondAtom$I$I(0, i)], this.mCanRank[this.mMol.getBondAtom$I$I(1, i)], i],$I$(4,1).c$$I$I$I);

$I$(1).sort$OA(rankedBond);
for (var i=0; i < rankedBond.length; i++) {
if (p$1.canCalcEZParity$I$I.apply(this, [rankedBond[i].bond, 2])) {
while (i + 1 < rankedBond.length && rankedBond[i].compareTo$com_actelion_research_chem_CanonizerBond(rankedBond[i + 1]) == 0 )p$1.canCalcEZParity$I$I.apply(this, [rankedBond[++i].bond, 2]);

var oldRanks=this.mNoOfRanks;
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks != oldRanks) return true;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J((2 * this.mAtomBits + 4), Long.$sl(this.mCanRank[atom],(this.mAtomBits + 4)));
}
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'canBreakTiesRandomly',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits + 1, 2 * this.mCanRank[atom]);
}
var rankCount=Clazz_array(Integer.TYPE, [this.mNoOfRanks + 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) ++rankCount[this.mCanRank[atom]];

var rank=1;
while (rankCount[rank] == 1)++rank;

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mCanRank[atom] == rank) {
this.mCanBase[atom].add$J(1);
break;
}}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'initializeParities$I$IA',  function (noOfRanksWithoutStereo, canRankWithoutStereo) {
this.mNoOfRanks=noOfRanksWithoutStereo;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanRank[atom]=canRankWithoutStereo[atom];
this.mTHParity[atom]=(0|0);
this.mTHParityRoundIsOdd[atom]=false;
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mEZParity[bond]=(0|0);
this.mEZParityRoundIsOdd[bond]=false;
}
}, p$1);

Clazz_newMeth(C$, 'canInitializeRanking',  function () {
var bondQueryFeaturesPresent=false;
if (this.mMol.isFragment$()) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondQueryFeatures$I(bond) != 0) {
bondQueryFeaturesPresent=true;
break;
}}
}this.mMaxConnAtoms=2;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mMaxConnAtoms=Math.max(this.mMaxConnAtoms, this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom));

var baseValueSize=Math.max(2, bondQueryFeaturesPresent ? ((62 + this.mAtomBits + this.mMaxConnAtoms * (this.mAtomBits + 23) )/63|0) : ((62 + this.mAtomBits + this.mMaxConnAtoms * (this.mAtomBits + 5) )/63|0));
this.mCanRank=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
this.mCanBase=Clazz_array($I$(5), [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mCanBase[atom]=Clazz_new_($I$(5,1).c$$I,[baseValueSize]);

var atomListFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
if ((Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) || this.mMol.getAtomList$I(atom) != null  ) this.mCanBase[atom].add$I$J(8, 6);
 else this.mCanBase[atom].add$I$J(8, this.mMol.getAtomicNo$I(atom));
this.mCanBase[atom].add$I$J(8, this.mMol.getAtomMass$I(atom));
this.mCanBase[atom].add$I$J(2, this.mMol.getAtomPi$I(atom));
this.mCanBase[atom].add$I$J(4, this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom));
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) this.mCanBase[atom].add$I$J(4, 8);
 else this.mCanBase[atom].add$I$J(4, 8 + this.mMol.getAtomCharge$I(atom));
this.mCanBase[atom].add$I$J(5, Math.min(31, this.mMol.getAtomRingSize$I(atom)));
this.mCanBase[atom].add$I$J(4, p$1.canCalcImplicitAbnormalValence$I.apply(this, [atom]) + 1);
this.mCanBase[atom].add$I$J(2, this.mMol.getAtomRadical$I(atom) >> 4);
if (this.mMol.isFragment$()) {
this.mCanBase[atom].add$I$J(46, this.mMol.getAtomQueryFeatures$I(atom));
if (this.mMol.getAtomList$I(atom) != null ) atomListFound=true;
}}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks < this.mMol.getAtoms$()) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var bondRingSize=Clazz_array(Integer.TYPE, [this.mMol.getConnAtoms$I(atom)]);
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
bondRingSize[i]=this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)] << 5;
bondRingSize[i]|=Math.min(31, this.mMol.getBondRingSize$I(this.mMol.getConnBond$I$I(atom, i)));
}
$I$(1).sort$IA(bondRingSize);
for (var i=this.mMaxConnAtoms; i > bondRingSize.length; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 5, 0);

for (var i=bondRingSize.length - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 5, bondRingSize[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if (atomListFound && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var atomList=this.mMol.getAtomList$I(atom);
var listLength=(atomList == null ) ? 0 : Math.min(12, atomList.length);
for (var i=12; i > listLength; i--) this.mCanBase[atom].add$I$J(8, 0);

for (var i=listLength - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(8, atomList[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if (bondQueryFeaturesPresent && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var bondQFList=Clazz_array(Long.TYPE, [this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom)]);
var index=0;
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
bondQFList[index]=this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)];
(bondQFList[$k$=index]=Long.$sl(bondQFList[$k$],(23)));
(bondQFList[$k$=index]=Long.$or(bondQFList[$k$],(this.mMol.getBondQueryFeatures$I(this.mMol.getConnBond$I$I(atom, i)))));
++index;
}}
$I$(1).sort$JA(bondQFList);
for (var i=this.mMaxConnAtoms; i > bondQFList.length; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 23, 0);

for (var i=bondQFList.length - 1; i >= 0; i--) this.mCanBase[atom].add$I$J(this.mAtomBits + 23, bondQFList[i]);

}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 8) != 0 && this.mNoOfRanks < this.mMol.getAtoms$() ) {
var list=Clazz_new_($I$(6,1));
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomCustomLabel$I(atom) != null ) list.addString$S(this.mMol.getAtomCustomLabel$I(atom));

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var rank=(this.mMol.getAtomCustomLabel$I(atom) == null ) ? 0 : 1 + list.getListIndex$S(this.mMol.getAtomCustomLabel$I(atom));
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(this.mAtomBits, rank);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 16) != 0 && this.mNoOfRanks < this.mMol.getAtoms$() ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(1, this.mMol.isSelectedAtom$I(atom) ? 1 : 0);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}if ((this.mMode & 512) != 0 && this.mMol.isFragment$() ) p$1.canBreakFreeValenceAtomTies.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'canBreakFreeValenceAtomTies',  function () {
while (true){
var isFreeValenceRank=Clazz_array(Boolean.TYPE, [this.mNoOfRanks + 1]);
var highestSharedFreeValenceRank=-1;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getLowestFreeValence$I(atom) != 0) {
if (isFreeValenceRank[this.mCanRank[atom]] && highestSharedFreeValenceRank < this.mCanRank[atom] ) highestSharedFreeValenceRank=this.mCanRank[atom];
isFreeValenceRank[this.mCanRank[atom]]=true;
}}
if (highestSharedFreeValenceRank == -1) break;
var increment=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var value=0;
if (this.mCanRank[atom] == highestSharedFreeValenceRank) value=++increment;
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(8, value);
}
this.mNoOfRanks=p$1.canPerformRanking.apply(this, []);
}
}, p$1);

Clazz_newMeth(C$, 'canRemoveOverspecifiedESRGroups',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (!this.mIsStereoCenter[atom] || this.mTHParity[atom] == 3 ) this.mTHESRType[atom]=(0|0);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(bond) != 1 || this.mEZParity[bond] == 0  || this.mEZParity[bond] == 3 ) this.mEZESRType[bond]=(0|0);

}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindAllParities',  function () {
this.mIsOddParityRound=true;
var paritiesFound=p$1.canFindParities$Z.apply(this, [false]);
var parityInfoBits=9;
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && paritiesFound ){
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
var thParityInfo=this.mTHParity[atom] << (7);
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) && this.mTHESRType[atom] != 0 ) {
thParityInfo|=(this.mTHESRType[atom] << 5);
thParityInfo|=this.mTHESRGroup[atom];
}this.mCanBase[atom].add$I$J(18, thParityInfo << 9);
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var ezParityInfo=this.mEZParity[bond] << (7);
if ((this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) && this.mMol.getBondType$I(bond) == 1  && this.mEZESRType[bond] != 0 ) {
ezParityInfo|=(this.mEZESRType[bond] << 5);
ezParityInfo|=this.mEZESRGroup[bond];
}this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(ezParityInfo);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(ezParityInfo);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
paritiesFound=p$1.canFindParities$Z.apply(this, [false]);
}
}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindCIPParities',  function () {
this.mIsOddParityRound=true;
this.mTHCIPParity=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
this.mEZCIPParity=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
var paritiesFound=p$1.canFindParities$Z.apply(this, [true]);
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && paritiesFound ){
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits + 4, (this.mCanRank[atom] << 4) | (this.mTHParity[atom] << 2));
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(this.mEZParity[bond]);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(this.mEZParity[bond]);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
paritiesFound=p$1.canFindParities$Z.apply(this, [true]);
}
}, p$1);

Clazz_newMeth(C$, 'canRecursivelyFindCanonizedParities',  function () {
this.mIsOddParityRound=true;
var esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
if (this.mMesoHelper != null  && this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank) ) esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
if (p$1.canFindParities$Z.apply(this, [false])) p$1.canNormalizeGroupParities.apply(this, []);
var newStereoInfoAvailable=true;
while ((this.mNoOfRanks < this.mMol.getAtoms$()) && newStereoInfoAvailable ){
var groupRank=p$1.canGetESRGroupRank$IAAA.apply(this, [esrGroupMember]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
this.mCanBase[atom].add$I$J(20, 0);
if (!this.mTHESRTypeNeedsNormalization[atom] && this.mTHESRType[atom] != 0 ) this.mCanBase[atom].add$J((this.mTHESRType[atom] << 18) + (groupRank[(this.mTHESRType[atom] == 1) ? 0 : 1][this.mTHESRGroup[atom]] << 8));
var parity=this.mTHParity[atom];
if (this.mTHParityIsMesoInverted[atom]) {
if (parity == 1) parity=2;
 else if (parity == 2) parity=1;
}this.mCanBase[atom].add$J(parity << 4);
}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
this.mCanBase[this.mMol.getBondAtom$I$I(0, bond)].add$J(this.mEZParity[bond]);
this.mCanBase[this.mMol.getBondAtom$I$I(1, bond)].add$J(this.mEZParity[bond]);
}
var newNoOfRanks=p$1.canPerformRanking.apply(this, []);
if (this.mNoOfRanks == newNoOfRanks) break;
this.mNoOfRanks=newNoOfRanks;
newStereoInfoAvailable=false;
if (this.mMesoHelper != null  && this.mMesoHelper.normalizeESRGroupSwappingAndRemoval$IA(this.mCanRank) ) {
newStereoInfoAvailable=true;
esrGroupMember=p$1.compileESRGroupMembers.apply(this, []);
}if (p$1.canFindParities$Z.apply(this, [false])) {
newStereoInfoAvailable=true;
p$1.canNormalizeGroupParities.apply(this, []);
}}
}, p$1);

Clazz_newMeth(C$, 'compileESRGroupMembers',  function () {
var esrGroupMember=Clazz_array(Integer.TYPE, [2, 32, null]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsStereoCenter[atom]) {
if (this.mTHESRType[atom] == 1) esrGroupMember[0][this.mTHESRGroup[atom]]=$I$(2).addToIntArray$IA$I(esrGroupMember[0][this.mTHESRGroup[atom]], atom);
 else if (this.mTHESRType[atom] == 2) esrGroupMember[1][this.mTHESRGroup[atom]]=$I$(2).addToIntArray$IA$I(esrGroupMember[0][this.mTHESRGroup[atom]], atom);
}}
return esrGroupMember;
}, p$1);

Clazz_newMeth(C$, 'canNormalizeGroupParities',  function () {
var groupNormalized=false;
for (var i=0; i < this.mTHParityNormalizationGroupList.size$(); i++) {
var groupAtom=this.mTHParityNormalizationGroupList.get$I(i);
var allParitiesDetermined=true;
var maxRank=-1;
var invertParities=false;
for (var j=0; j < groupAtom.length; j++) {
var atom=groupAtom[j];
if (this.mTHParity[atom] == 0) {
allParitiesDetermined=false;
break;
}if (this.mTHParity[atom] != 3) {
var isUniqueRank=true;
for (var k=0; k < groupAtom.length; k++) {
if (k != j && this.mCanRank[atom] == this.mCanRank[groupAtom[k]] ) {
isUniqueRank=false;
break;
}}
if (isUniqueRank && maxRank < this.mCanRank[atom] ) {
maxRank=this.mCanRank[atom];
invertParities=(this.mTHParity[atom] == 1);
}}}
if (allParitiesDetermined && maxRank != -1 ) {
for (var atom, $atom = 0, $$atom = groupAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 )) this.mTHParityIsMesoInverted[atom]=invertParities;
this.mTHParityNeedsNormalization[atom]=false;
}
this.mTHParityNormalizationGroupList.remove$O(groupAtom);
groupNormalized=true;
--i;
}}
return groupNormalized;
}, p$1);

Clazz_newMeth(C$, 'canMarkESRGroupsForParityNormalization',  function () {
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mTHESRType[atom] != 0 && (this.mTHESRType[atom] != 2 || (this.mMode & 256) == 0 ) ) ++count;

if (count == 0) return;
var parity=Clazz_array(Integer.TYPE, [count]);
count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHESRType[atom] != 0 && (this.mTHESRType[atom] != 2 || (this.mMode & 256) == 0 ) ) {
parity[count]=(this.mTHESRType[atom] << 29) | (this.mTHESRGroup[atom] << 24) | (this.mCanRank[atom] << 12) | atom ;
++count;
}}
$I$(1).sort$IA(parity);
var groupBase=0;
var nextGroupBase=0;
var groupID=parity[0] & -16777216;
while (true){
++nextGroupBase;
if (nextGroupBase == parity.length || groupID != (parity[nextGroupBase] & -16777216) ) {
var atomList=Clazz_array(Integer.TYPE, [nextGroupBase - groupBase]);
for (var i=groupBase; i < nextGroupBase; i++) {
var atom=parity[i] & 4095;
atomList[i - groupBase]=atom;
this.mTHParityNeedsNormalization[atom]=true;
}
this.mTHParityNormalizationGroupList.add$O(atomList);
if (nextGroupBase == parity.length) break;
groupID=(parity[nextGroupBase] & -16777216);
groupBase=nextGroupBase;
}}
}, p$1);

Clazz_newMeth(C$, 'canGetESRGroupRank$IAAA',  function (groupMember) {
var groupRank=Clazz_array(Integer.TYPE, [2, 32]);
for (var groupTypeIndex=0; groupTypeIndex < 2; groupTypeIndex++) {
var atomRank=Clazz_array(Integer.TYPE, [32, null]);
var rankCount=0;
for (var group=0; group < 32; group++) {
if (groupMember[groupTypeIndex][group] != null ) {
var memberCount=groupMember[groupTypeIndex][group].length;
atomRank[group]=Clazz_array(Integer.TYPE, [memberCount]);
for (var i=0; i < memberCount; i++) atomRank[group][i]=this.mCanRank[groupMember[groupTypeIndex][group][i]];

$I$(1).sort$IA(atomRank[group]);
++rankCount;
}}
for (var rank=rankCount; rank > 0; rank--) {
var maxGroup=0;
var maxAtomRank=null;
for (var group=0; group < 32; group++) {
if (atomRank[group] != null ) {
if (maxAtomRank == null  || maxAtomRank.length < atomRank[group].length ) {
maxAtomRank=atomRank[group];
maxGroup=group;
} else if (maxAtomRank.length == atomRank[group].length) {
for (var i=maxAtomRank.length - 1; i >= 0; i--) {
if (maxAtomRank[i] < atomRank[group][i]) {
maxAtomRank=atomRank[group];
maxGroup=group;
break;
}}
}}}
groupRank[groupTypeIndex][maxGroup]=rank;
atomRank[maxGroup]=null;
}
}
return groupRank;
}, p$1);

Clazz_newMeth(C$, 'canFindParities$Z',  function (doCIP) {
var ezFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (p$1.canCalcEZParity$I$I.apply(this, [bond, 1])) {
this.mEZParityRoundIsOdd[bond]=this.mIsOddParityRound;
if (doCIP) p$1.cipCalcEZParity$I.apply(this, [bond]);
ezFound=true;
}
var thFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (p$1.canCalcTHParity$I$I.apply(this, [atom, 1])) {
this.mTHParityRoundIsOdd[atom]=this.mIsOddParityRound;
if (doCIP) p$1.cipCalcTHParity$I.apply(this, [atom]);
thFound=true;
}
if (thFound) this.mIsOddParityRound=!this.mIsOddParityRound;
return ezFound || thFound ;
}, p$1);

Clazz_newMeth(C$, 'determineChirality$IA',  function (canRankWithoutStereo) {
var stereoCenters=0;
var stereoCentersUnknown=0;
var stereoCentersTypeAbs=0;
var stereoCentersTypeAbsInMesoFragment=0;
var stereoCentersTypeAndGroup0=0;
var stereoCentersTypeOrGroup0=0;
var typeAndGroups=0;
var typeAndInMesoFragmentFound=false;
var andGroupUsed=Clazz_array(Boolean.TYPE, [32]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0) {
++stereoCenters;
if (this.mTHParity[atom] == 3) {
++stereoCentersUnknown;
} else {
if (this.mTHESRType[atom] == 0) {
++stereoCentersTypeAbs;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(atom) ) ++stereoCentersTypeAbsInMesoFragment;
} else if (this.mTHESRType[atom] == 2) {
if (this.mTHESRGroup[atom] == 0) ++stereoCentersTypeOrGroup0;
} else if (this.mTHESRType[atom] == 1) {
var group=this.mTHESRGroup[atom];
if (!andGroupUsed[group]) {
++typeAndGroups;
andGroupUsed[group]=true;
}if (this.mTHESRGroup[atom] == 0) ++stereoCentersTypeAndGroup0;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(atom) ) typeAndInMesoFragmentFound=true;
}}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] != 0 && this.mMol.getBondType$I(bond) == 1 ) {
++stereoCenters;
if (this.mEZParity[bond] == 3) {
++stereoCentersUnknown;
} else {
if (this.mEZESRType[bond] == 0) {
++stereoCentersTypeAbs;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(0, bond))  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(1, bond)) ) ++stereoCentersTypeAbsInMesoFragment;
} else if (this.mEZESRType[bond] == 2) {
if (this.mEZESRGroup[bond] == 0) ++stereoCentersTypeOrGroup0;
} else if (this.mEZESRType[bond] == 1) {
var group=this.mEZESRGroup[bond];
if (!andGroupUsed[group]) {
++typeAndGroups;
andGroupUsed[group]=true;
}if (this.mEZESRGroup[bond] == 0) ++stereoCentersTypeAndGroup0;
if (this.mMesoHelper != null  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(0, bond))  && this.mMesoHelper.isInMesoFragment$I(this.mMol.getBondAtom$I$I(1, bond)) ) typeAndInMesoFragmentFound=true;
}}}}
if (stereoCenters == 0) {
this.mMol.setChirality$I(65536);
return;
}if (stereoCentersUnknown != 0) {
this.mMol.setChirality$I(0);
return;
}if (this.mIsMeso) {
this.mMol.setChirality$I(131072 + (1 << typeAndGroups));
return;
}if (stereoCentersTypeAndGroup0 + stereoCentersTypeAbsInMesoFragment == stereoCenters && !typeAndInMesoFragmentFound ) {
this.mMol.setChirality$I(196608);
} else if (stereoCentersTypeAbs == stereoCenters) {
this.mMol.setChirality$I(262144);
} else if (stereoCentersTypeOrGroup0 == stereoCenters) {
this.mMol.setChirality$I(327680);
} else if (stereoCentersTypeAbs == stereoCenters - 1 && stereoCentersTypeAndGroup0 == 1 ) {
this.mMol.setChirality$I(393216);
} else {
this.mMol.setChirality$I(458752 + (1 << typeAndGroups));
}}, p$1);

Clazz_newMeth(C$, 'canFindPseudoParities',  function () {
var isFreshPseudoParityAtom=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var isFreshPseudoParityBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
var anyPseudoParityCount=0;
var pseudoParity1Or2Found=false;
if ((this.mMode & 128) != 0) {
this.mPseudoTHGroup=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mPseudoEZGroup=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
}for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mProTHAtomsInSameFragment[atom]) {
if (!this.mTHParityIsPseudo[atom]) {
if (p$1.canCalcTHParity$I$I.apply(this, [atom, 1])) {
this.mTHParityIsPseudo[atom]=true;
isFreshPseudoParityAtom[atom]=true;
++anyPseudoParityCount;
}}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mProEZAtomsInSameFragment[bond]) {
if (!this.mEZParityIsPseudo[bond]) {
if (p$1.canCalcEZParity$I$I.apply(this, [bond, 1])) {
this.mEZParityIsPseudo[bond]=true;
isFreshPseudoParityBond[bond]=true;
++anyPseudoParityCount;
}}}}
if (anyPseudoParityCount == 1) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (isFreshPseudoParityAtom[atom]) {
this.mTHParity[atom]=(0|0);
break;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (isFreshPseudoParityBond[bond]) {
this.mEZParity[bond]=(0|0);
break;
}}
} else if (anyPseudoParityCount > 1) {
p$1.canEnsureFragments.apply(this, []);
this.mNoOfPseudoGroups=0;
for (var f, $f = this.mFragmentList.iterator$(); $f.hasNext$()&&((f=($f.next$())),1);) {
var pseudoParitiesInGroup=0;
var pseudoParity1Or2InGroup=0;
var highRankingTHAtom=0;
var highRankingEZBond=0;
var highTHAtomRank=-1;
var highEZBondRank=-1;
for (var i=0; i < f.atom.length; i++) {
if (isFreshPseudoParityAtom[f.atom[i]]) {
++pseudoParitiesInGroup;
if (this.mTHParity[f.atom[i]] == 1 || this.mTHParity[f.atom[i]] == 2 ) {
++pseudoParity1Or2InGroup;
pseudoParity1Or2Found=true;
if (highTHAtomRank < this.mCanRank[f.atom[i]]) {
highTHAtomRank=this.mCanRank[f.atom[i]];
highRankingTHAtom=f.atom[i];
}}}}
for (var i=0; i < f.bond.length; i++) {
if (isFreshPseudoParityBond[f.bond[i]]) {
++pseudoParitiesInGroup;
var rank1=this.mCanRank[this.mMol.getBondAtom$I$I(0, f.bond[i])];
var rank2=this.mCanRank[this.mMol.getBondAtom$I$I(1, f.bond[i])];
var higherRank=(rank1 > rank2) ? (rank1 << 16) + rank2 : (rank2 << 16) + rank1;
if (this.mEZParity[f.bond[i]] == 1 || this.mEZParity[f.bond[i]] == 2 ) {
++pseudoParity1Or2InGroup;
pseudoParity1Or2Found=true;
if (highEZBondRank < higherRank) {
highEZBondRank=higherRank;
highRankingEZBond=f.bond[i];
}}}}
if (pseudoParitiesInGroup == 0) continue;
if (pseudoParitiesInGroup == 1) {
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mTHParity[f.atom[i]]=(0|0);

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mEZParity[f.bond[i]]=(0|0);

} else {
if (pseudoParity1Or2InGroup == 1) {
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mTHParity[f.atom[i]]=(3|0);

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mEZParity[f.bond[i]]=(3|0);

} else {
if ((this.mMode & 128) != 0) {
++this.mNoOfPseudoGroups;
for (var i=0; i < f.atom.length; i++) if (isFreshPseudoParityAtom[f.atom[i]]) this.mPseudoTHGroup[f.atom[i]]=this.mNoOfPseudoGroups;

for (var i=0; i < f.bond.length; i++) if (isFreshPseudoParityBond[f.bond[i]]) this.mPseudoEZGroup[f.bond[i]]=this.mNoOfPseudoGroups;

}var invertFragmentsStereoFeatures=false;
if (highTHAtomRank != -1) {
if (this.mTHParity[highRankingTHAtom] == 2) invertFragmentsStereoFeatures=true;
} else {
if (this.mEZParity[highRankingEZBond] == 2) invertFragmentsStereoFeatures=true;
}if (invertFragmentsStereoFeatures) {
for (var i=0; i < f.atom.length; i++) {
if (isFreshPseudoParityAtom[f.atom[i]]) {
switch (this.mTHParity[f.atom[i]]) {
case 1:
this.mTHParity[f.atom[i]]=(2|0);
break;
case 2:
this.mTHParity[f.atom[i]]=(1|0);
break;
}
}}
for (var i=0; i < f.bond.length; i++) {
if (isFreshPseudoParityBond[f.bond[i]]) {
switch (this.mEZParity[f.bond[i]]) {
case 1:
this.mEZParity[f.bond[i]]=(2|0);
break;
case 2:
this.mEZParity[f.bond[i]]=(1|0);
break;
}
}}
}}}}
}return pseudoParity1Or2Found;
}, p$1);

Clazz_newMeth(C$, 'canEnsureFragments',  function () {
if (this.mFragmentList != null ) return;
this.mFragmentList=Clazz_new_($I$(3,1));
var fragmentCount=0;
var fragmentNo=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var fragmentAtom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var fragmentBond=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (fragmentNo[atom] == 0 && (this.mMol.isRingAtom$I(atom) || this.mMol.getAtomPi$I(atom) == 1 ) ) {
fragmentAtom[0]=atom;
var fragmentAtoms=1;
var fragmentBonds=0;
fragmentNo[atom]=++fragmentCount;
var bondHandled=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
for (var current=0; current < fragmentAtoms; current++) {
for (var i=0; i < this.mMol.getConnAtoms$I(fragmentAtom[current]); i++) {
var connBond=this.mMol.getConnBond$I$I(fragmentAtom[current], i);
if (this.mMol.isRingBond$I(connBond) || this.mMol.getBondOrder$I(connBond) == 2  || this.mMol.isBINAPChiralityBond$I(connBond) ) {
var connAtom=this.mMol.getConnAtom$I$I(fragmentAtom[current], i);
if (!bondHandled[connBond]) {
fragmentBond[fragmentBonds++]=connBond;
bondHandled[connBond]=true;
}if (fragmentNo[connAtom] == 0) {
fragmentAtom[fragmentAtoms++]=connAtom;
fragmentNo[connAtom]=fragmentCount;
}}}
}
this.mFragmentList.add$O(Clazz_new_($I$(7,1).c$$IA$I$IA$I,[fragmentAtom, fragmentAtoms, fragmentBond, fragmentBonds]));
}}
}, p$1);

Clazz_newMeth(C$, 'canPerformRanking',  function () {
var oldNoOfRanks;
var newNoOfRanks;
newNoOfRanks=p$1.canConsolidate.apply(this, []);
do {
oldNoOfRanks=newNoOfRanks;
p$1.canCalcNextBaseValues.apply(this, []);
newNoOfRanks=p$1.canConsolidate.apply(this, []);
} while (oldNoOfRanks != newNoOfRanks);
return newNoOfRanks;
}, p$1);

Clazz_newMeth(C$, 'canCalcNextBaseValues',  function () {
var connRank=Clazz_array(Integer.TYPE, [this.mMaxConnAtoms]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var neighbours=this.mMol.getConnAtoms$I(atom) + this.mMol.getMetalBondedConnAtoms$I(atom);
var neighbour=0;
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
var rank=2 * this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)];
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.getBondOrder$I(connBond) == 2) if (!this.mMol.isAromaticBond$I(connBond)) ++rank;
var j;
for (j=0; j < neighbour; j++) if (rank < connRank[j]) break;

for (var k=neighbour; k > j; k--) connRank[k]=connRank[k - 1];

connRank[j]=rank;
++neighbour;
}}
this.mCanBase[atom].init$I(atom);
this.mCanBase[atom].add$I$J(this.mAtomBits, this.mCanRank[atom]);
for (var i=neighbours; i < this.mMaxConnAtoms; i++) this.mCanBase[atom].add$I$J(this.mAtomBits + 1, 0);

for (var i=0; i < neighbours; i++) this.mCanBase[atom].add$I$J(this.mAtomBits + 1, connRank[i]);

}
}, p$1);

Clazz_newMeth(C$, 'canConsolidate',  function () {
var canRank=0;
$I$(1).sort$OA(this.mCanBase);
for (var i=0; i < this.mCanBase.length; i++) {
if (i == 0 || this.mCanBase[i].compareTo$com_actelion_research_chem_CanonizerBaseValue(this.mCanBase[i - 1]) != 0 ) ++canRank;
this.mCanRank[this.mCanBase[i].getAtom$()]=canRank;
}
return canRank;
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity$I$I',  function (atom, mode) {
if (this.mTHParity[atom] != 0) return false;
if (this.mMol.getAtomicNo$I(atom) != 5 && this.mMol.getAtomicNo$I(atom) != 6  && this.mMol.getAtomicNo$I(atom) != 7  && this.mMol.getAtomicNo$I(atom) != 14  && this.mMol.getAtomicNo$I(atom) != 15  && this.mMol.getAtomicNo$I(atom) != 16 ) return false;
if (this.mMol.getAtomPi$I(atom) != 0) {
if (this.mMol.isCentralAlleneAtom$I(atom)) return p$1.canCalcAlleneParity$I$I.apply(this, [atom, mode]);
if (this.mMol.getAtomicNo$I(atom) != 15 && this.mMol.getAtomicNo$I(atom) != 16 ) return false;
}if (this.mMol.getConnAtoms$I(atom) < 3 || this.mMol.getAllConnAtoms$I(atom) > 4 ) return false;
if (this.mMol.getAtomCharge$I(atom) > 0 && this.mMol.getAtomicNo$I(atom) == 6 ) return false;
if (this.mMol.getAtomicNo$I(atom) == 5 && this.mMol.getAllConnAtoms$I(atom) != 4 ) return false;
if (this.mMol.getAtomicNo$I(atom) == 7 && !this.mNitrogenQualifiesForParity[atom] ) return false;
var remappedConn=Clazz_array(Integer.TYPE, [4]);
var remappedRank=Clazz_array(Integer.TYPE, [4]);
var neighbourUsed=Clazz_array(Boolean.TYPE, [4]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var highestRank=-1;
var highestConn=0;
for (var j=0; j < this.mMol.getAllConnAtoms$I(atom); j++) {
if (!neighbourUsed[j]) {
if (highestRank < this.mCanRank[this.mMol.getConnAtom$I$I(atom, j)]) {
highestRank=this.mCanRank[this.mMol.getConnAtom$I$I(atom, j)];
highestConn=j;
}}}
remappedConn[i]=highestConn;
remappedRank[i]=highestRank;
neighbourUsed[highestConn]=true;
}
if (this.mMol.getAllConnAtoms$I(atom) == 4 && remappedRank[0] == remappedRank[1]  && remappedRank[2] == remappedRank[3] ) return false;
if ((this.mMol.getAllConnAtoms$I(atom) == 4) && (remappedRank[0] == remappedRank[2] || remappedRank[1] == remappedRank[3] ) ) return false;
if (this.mMol.getAllConnAtoms$I(atom) == 3 && remappedRank[0] == remappedRank[2] ) return false;
var proTHAtom1=0;
var proTHAtom2=0;
var proTHAtomsFound=false;
for (var i=1; i < this.mMol.getAllConnAtoms$I(atom); i++) {
if (remappedRank[i - 1] == remappedRank[i]) {
if (mode == 1 || remappedRank[i] == 0 ) return false;
proTHAtom1=this.mMol.getConnAtom$I$I(atom, remappedConn[i - 1]);
proTHAtom2=this.mMol.getConnAtom$I$I(atom, remappedConn[i]);
if (mode == 3 && this.mMol.isRingBond$I(this.mMol.getConnBond$I$I(atom, remappedConn[i])) ) this.mProTHAtomsInSameFragment[atom]=true;
proTHAtomsFound=true;
}}
if (mode != 1 && !proTHAtomsFound ) return false;
var atomTHParity=(this.mZCoordinatesAvailable) ? p$1.canCalcTHParity3D$I$IA.apply(this, [atom, remappedConn]) : p$1.canCalcTHParity2D$I$IA.apply(this, [atom, remappedConn]);
if (mode == 1) {
this.mTHParity[atom]=atomTHParity;
} else if (mode == 2) {
if (atomTHParity == 1) {
this.mCanBase[proTHAtom1].add$J(this.mCanRank[atom]);
} else if (atomTHParity == 2) {
this.mCanBase[proTHAtom2].add$J(this.mCanRank[atom]);
}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity2D$I$IA',  function (atom, remappedConn) {
var up_down=Clazz_array(Integer.TYPE, -2, [Clazz_array(Integer.TYPE, -1, [2, 1, 2, 1]), Clazz_array(Integer.TYPE, -1, [1, 2, 2, 1]), Clazz_array(Integer.TYPE, -1, [1, 1, 2, 2]), Clazz_array(Integer.TYPE, -1, [2, 1, 1, 2]), Clazz_array(Integer.TYPE, -1, [2, 2, 1, 1]), Clazz_array(Integer.TYPE, -1, [1, 2, 1, 2])]);
var angle=Clazz_array(Double.TYPE, [this.mMol.getAllConnAtoms$I(atom)]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) angle[i]=this.mMol.getBondAngle$I$I(this.mMol.getConnAtom$I$I(atom, remappedConn[i]), atom);

var parity=($b$[0] = this.mMol.getFisherProjectionParity$I$IA$DA$IA(atom, remappedConn, angle, null), $b$[0]);
if (parity != 3) return parity;
var stereoBond=0;
var stereoType=0;
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var bnd=this.mMol.getConnBond$I$I(atom, remappedConn[i]);
if (this.mMol.getBondAtom$I$I(0, bnd) == atom) {
if (this.mMol.getBondType$I(bnd) == 129) {
if (stereoType != 0) this.mMol.setStereoProblem$I(atom);
stereoBond=i;
stereoType=1;
}if (this.mMol.getBondType$I(bnd) == 257) {
if (stereoType != 0) this.mMol.setStereoProblem$I(atom);
stereoBond=i;
stereoType=2;
}}}
if (stereoType == 0) return $b$[0] = 3, $b$[0];
for (var i=1; i < this.mMol.getAllConnAtoms$I(atom); i++) if (angle[i] < angle[0] ) angle[i]+=6.283185307179586;

if (this.mMol.getAllConnAtoms$I(atom) == 3) {
switch (stereoBond) {
case 0:
if (((angle[1] < angle[2] ) && (angle[2] - angle[1] < 3.141592653589793 ) ) || ((angle[1] > angle[2] ) && (angle[1] - angle[2] > 3.141592653589793 ) ) ) stereoType=3 - stereoType;
break;
case 1:
if (angle[2] - angle[0] > 3.141592653589793 ) stereoType=3 - stereoType;
break;
case 2:
if (angle[1] - angle[0] < 3.141592653589793 ) stereoType=3 - stereoType;
break;
}
return (stereoType == 1) ? 2 : ($b$[0] = 1, $b$[0]);
}var order=0;
if (angle[1] <= angle[2]  && angle[2] <= angle[3]  ) order=0;
 else if (angle[1] <= angle[3]  && angle[3] <= angle[2]  ) order=1;
 else if (angle[2] <= angle[1]  && angle[1] <= angle[3]  ) order=2;
 else if (angle[2] <= angle[3]  && angle[3] <= angle[1]  ) order=3;
 else if (angle[3] <= angle[1]  && angle[1] <= angle[2]  ) order=4;
 else if (angle[3] <= angle[2]  && angle[2] <= angle[1]  ) order=5;
return (up_down[order][stereoBond] == stereoType) ? 2 : ($b$[0] = 1, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcTHParity3D$I$IA',  function (atom, remappedConn) {
var atomList=Clazz_array(Integer.TYPE, [4]);
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) atomList[i]=this.mMol.getConnAtom$I$I(atom, remappedConn[i]);

if (this.mMol.getAllConnAtoms$I(atom) == 3) atomList[3]=atom;
var coords=Clazz_array(Double.TYPE, [3, 3]);
for (var i=0; i < 3; i++) {
coords[i][0]=this.mMol.getAtomX$I(atomList[i + 1]) - this.mMol.getAtomX$I(atomList[0]);
coords[i][1]=this.mMol.getAtomY$I(atomList[i + 1]) - this.mMol.getAtomY$I(atomList[0]);
coords[i][2]=this.mMol.getAtomZ$I(atomList[i + 1]) - this.mMol.getAtomZ$I(atomList[0]);
}
var n=Clazz_array(Double.TYPE, [3]);
n[0]=coords[0][1] * coords[1][2] - coords[0][2] * coords[1][1];
n[1]=coords[0][2] * coords[1][0] - coords[0][0] * coords[1][2];
n[2]=coords[0][0] * coords[1][1] - coords[0][1] * coords[1][0];
var cosa=(coords[2][0] * n[0] + coords[2][1] * n[1] + coords[2][2] * n[2]) / (Math.sqrt(coords[2][0] * coords[2][0] + coords[2][1] * coords[2][1] + coords[2][2] * coords[2][2]) * Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]));
return (cosa > 0.0 ) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity$I$I',  function (atom, mode) {
if (this.mMol.getAtomicNo$I(atom) != 6 && this.mMol.getAtomicNo$I(atom) != 7 ) return false;
var atom1=this.mMol.getConnAtom$I$I(atom, 0);
var atom2=this.mMol.getConnAtom$I$I(atom, 1);
if (this.mMol.getAtomPi$I(atom1) != 1 || this.mMol.getAtomPi$I(atom2) != 1 ) return false;
if (this.mMol.getConnAtoms$I(atom1) == 1 || this.mMol.getConnAtoms$I(atom2) == 1 ) return false;
if ((this.mMol.getAllConnAtoms$I(atom1) > 3) || (this.mMol.getAllConnAtoms$I(atom2) > 3) ) return false;
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom, atom1]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom, atom2]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual && halfParity1.mInSameFragment ) this.mProTHAtomsInSameFragment[atom]=true;
if (halfParity2.mRanksEqual && halfParity2.mInSameFragment ) this.mProTHAtomsInSameFragment[atom]=true;
}var alleneParity=this.mZCoordinatesAvailable ? p$1.canCalcAlleneParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcAlleneParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mTHParity[atom]=alleneParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (alleneParity == 1) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[atom1]);
} else {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[atom1]);
}}if (halfParity2.mRanksEqual) {
if (alleneParity == 2) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[atom2]);
} else {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[atom2]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var hp1=halfParity1.getValue$();
var hp2=halfParity2.getValue$();
if (hp1 == -1 || hp2 == -1  || ((hp1 + hp2) & 1) == 0 ) return $b$[0] = 3, $b$[0];
var alleneParity=($b$[0] = 0, $b$[0]);
switch (hp1 + hp2) {
case 3:
case 7:
alleneParity=($b$[0] = 2, $b$[0]);
break;
case 5:
alleneParity=($b$[0] = 1, $b$[0]);
break;
}
return alleneParity;
}, p$1);

Clazz_newMeth(C$, 'canCalcAlleneParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var atom=Clazz_array(Integer.TYPE, [4]);
atom[0]=halfParity1.mHighConn;
atom[1]=halfParity1.mCentralAxialAtom;
atom[2]=halfParity2.mCentralAxialAtom;
atom[3]=halfParity2.mHighConn;
var torsion=this.mMol.calculateTorsion$IA(atom);
if (Math.abs(torsion) < 0.3  || Math.abs(torsion) > 2.8415926535897933  ) return $b$[0] = 3, $b$[0];
if (torsion < 0 ) return $b$[0] = 2, $b$[0];
 else return $b$[0] = 1, $b$[0];
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity$I$I',  function (bond, mode) {
if (!this.mMol.isBINAPChiralityBond$I(bond)) return false;
var atom1=this.mMol.getBondAtom$I$I(0, bond);
var atom2=this.mMol.getBondAtom$I$I(1, bond);
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom1, atom2]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, atom2, atom1]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual) this.mProEZAtomsInSameFragment[bond]=p$1.hasSecondBINAPBond$I.apply(this, [atom2]);
if (halfParity2.mRanksEqual) this.mProEZAtomsInSameFragment[bond]=p$1.hasSecondBINAPBond$I.apply(this, [atom1]);
}var axialParity=this.mZCoordinatesAvailable ? p$1.canCalcBINAPParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcBINAPParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mEZParity[bond]=axialParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (axialParity == 2) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[atom2]);
} else {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[atom2]);
}}if (halfParity2.mRanksEqual) {
if (axialParity == 2) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[atom1]);
} else {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[atom1]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var hp1=halfParity1.getValue$();
var hp2=halfParity2.getValue$();
if (hp1 == -1 || hp2 == -1  || ((hp1 + hp2) & 1) == 0 ) return $b$[0] = 3, $b$[0];
var axialParity=($b$[0] = 0, $b$[0]);
switch (hp1 + hp2) {
case 3:
case 7:
axialParity=($b$[0] = 1, $b$[0]);
break;
case 5:
axialParity=($b$[0] = 2, $b$[0]);
break;
}
return axialParity;
}, p$1);

Clazz_newMeth(C$, 'canCalcBINAPParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var atom=Clazz_array(Integer.TYPE, [4]);
atom[0]=halfParity1.mHighConn;
atom[1]=halfParity1.mCentralAxialAtom;
atom[2]=halfParity2.mCentralAxialAtom;
atom[3]=halfParity2.mHighConn;
var torsion=this.mMol.calculateTorsion$IA(atom);
if (Math.abs(torsion) < 0.3  || Math.abs(torsion) > 2.8415926535897933  ) return $b$[0] = 3, $b$[0];
if (torsion < 0 ) return $b$[0] = 1, $b$[0];
 else return $b$[0] = 2, $b$[0];
}, p$1);

Clazz_newMeth(C$, 'hasSecondBINAPBond$I',  function (atom) {
var ringSet=this.mMol.getRingSet$();
for (var i=0; i < ringSet.getSize$(); i++) {
if (ringSet.isAromatic$I(i) && ringSet.isAtomMember$I$I(i, atom) ) {
for (var j, $j = 0, $$j = ringSet.getRingAtoms$I(i); $j<$$j.length&&((j=($$j[$j])),1);$j++) if (j != atom) for (var k=0; k < this.mMol.getConnAtoms$I(j); k++) if (this.mMol.isBINAPChiralityBond$I(this.mMol.getConnBond$I$I(j, k))) return true;


return false;
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity$I$I',  function (bond, mode) {
if (this.mEZParity[bond] != 0) return false;
if (this.mMol.getBondOrder$I(bond) == 1) return p$1.canCalcBINAPParity$I$I.apply(this, [bond, mode]);
if (this.mMol.getBondOrder$I(bond) != 2) return false;
if (this.mMol.isAromaticBond$I(bond)) return false;
var dbAtom1=this.mMol.getBondAtom$I$I(0, bond);
var dbAtom2=this.mMol.getBondAtom$I$I(1, bond);
if (this.mMol.getConnAtoms$I(dbAtom1) == 1 || this.mMol.getConnAtoms$I(dbAtom2) == 1 ) return false;
if ((this.mMol.getConnAtoms$I(dbAtom1) > 3) || (this.mMol.getConnAtoms$I(dbAtom2) > 3) ) return false;
if (this.mMol.getAtomPi$I(dbAtom1) == 2 || this.mMol.getAtomPi$I(dbAtom2) == 2 ) return false;
var halfParity1=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, dbAtom2, dbAtom1]);
if (halfParity1.mRanksEqual && mode == 1 ) return false;
var halfParity2=Clazz_new_($I$(8,1).c$$com_actelion_research_chem_ExtendedMolecule$IA$I$I,[this.mMol, this.mCanRank, dbAtom1, dbAtom2]);
if (halfParity2.mRanksEqual && mode == 1 ) return false;
if (halfParity1.mRanksEqual && halfParity2.mRanksEqual ) return false;
if (mode == 3) {
if (halfParity1.mRanksEqual && halfParity1.mInSameFragment ) this.mProEZAtomsInSameFragment[bond]=true;
if (halfParity2.mRanksEqual && halfParity2.mInSameFragment ) this.mProEZAtomsInSameFragment[bond]=true;
}var bondDBParity=this.mMol.isBondParityUnknownOrNone$I(bond) ? ($b$[0] = 3, $b$[0]) : (this.mZCoordinatesAvailable) ? p$1.canCalcEZParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]) : p$1.canCalcEZParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity.apply(this, [halfParity1, halfParity2]);
if (mode == 1) {
this.mEZParity[bond]=bondDBParity;
} else if (mode == 2) {
if (halfParity1.mRanksEqual) {
if (bondDBParity == 1) {
this.mCanBase[halfParity1.mHighConn].add$J(this.mCanRank[dbAtom1]);
} else if (bondDBParity == 2) {
this.mCanBase[halfParity1.mLowConn].add$J(this.mCanRank[dbAtom1]);
}}if (halfParity2.mRanksEqual) {
if (bondDBParity == 1) {
this.mCanBase[halfParity2.mHighConn].add$J(this.mCanRank[dbAtom2]);
} else if (bondDBParity == 2) {
this.mCanBase[halfParity2.mLowConn].add$J(this.mCanRank[dbAtom2]);
}}}return true;
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity2D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
if (halfParity1.getValue$() == -1 || halfParity2.getValue$() == -1 ) return $b$[0] = 3, $b$[0];
if (((halfParity1.getValue$() | halfParity2.getValue$()) & 1) != 0) return $b$[0] = 3, $b$[0];
return (halfParity1.getValue$() == halfParity2.getValue$()) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'canCalcEZParity3D$com_actelion_research_chem_EZHalfParity$com_actelion_research_chem_EZHalfParity',  function (halfParity1, halfParity2) {
var db=Clazz_array(Double.TYPE, [3]);
db[0]=this.mMol.getAtomX$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomX$I(halfParity1.mCentralAxialAtom);
db[1]=this.mMol.getAtomY$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomY$I(halfParity1.mCentralAxialAtom);
db[2]=this.mMol.getAtomZ$I(halfParity2.mCentralAxialAtom) - this.mMol.getAtomZ$I(halfParity1.mCentralAxialAtom);
var s1=Clazz_array(Double.TYPE, [3]);
s1[0]=this.mMol.getAtomX$I(halfParity1.mHighConn) - this.mMol.getAtomX$I(halfParity1.mCentralAxialAtom);
s1[1]=this.mMol.getAtomY$I(halfParity1.mHighConn) - this.mMol.getAtomY$I(halfParity1.mCentralAxialAtom);
s1[2]=this.mMol.getAtomZ$I(halfParity1.mHighConn) - this.mMol.getAtomZ$I(halfParity1.mCentralAxialAtom);
var s2=Clazz_array(Double.TYPE, [3]);
s2[0]=this.mMol.getAtomX$I(halfParity2.mHighConn) - this.mMol.getAtomX$I(halfParity2.mCentralAxialAtom);
s2[1]=this.mMol.getAtomY$I(halfParity2.mHighConn) - this.mMol.getAtomY$I(halfParity2.mCentralAxialAtom);
s2[2]=this.mMol.getAtomZ$I(halfParity2.mHighConn) - this.mMol.getAtomZ$I(halfParity2.mCentralAxialAtom);
var n1=Clazz_array(Double.TYPE, [3]);
n1[0]=db[1] * s1[2] - db[2] * s1[1];
n1[1]=db[2] * s1[0] - db[0] * s1[2];
n1[2]=db[0] * s1[1] - db[1] * s1[0];
var n2=Clazz_array(Double.TYPE, [3]);
n2[0]=db[1] * n1[2] - db[2] * n1[1];
n2[1]=db[2] * n1[0] - db[0] * n1[2];
n2[2]=db[0] * n1[1] - db[1] * n1[0];
var cosa=(s1[0] * n2[0] + s1[1] * n2[1] + s1[2] * n2[2]) / (Math.sqrt(s1[0] * s1[0] + s1[1] * s1[1] + s1[2] * s1[2]) * Math.sqrt(n2[0] * n2[0] + n2[1] * n2[1] + n2[2] * n2[2]));
var cosb=(s2[0] * n2[0] + s2[1] * n2[1] + s2[2] * n2[2]) / (Math.sqrt(s2[0] * s2[0] + s2[1] * s2[1] + s2[2] * s2[2]) * Math.sqrt(n2[0] * n2[0] + n2[1] * n2[1] + n2[2] * n2[2]));
return (!!((cosa < 0.0 ) ^ (cosb < 0.0 ))) ? 1 : ($b$[0] = 2, $b$[0]);
}, p$1);

Clazz_newMeth(C$, 'flagStereoProblems',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 3 && !this.mMol.isAtomConfigurationUnknown$I(atom) ) this.mMol.setStereoProblem$I(atom);
if ((this.mMol.getAtomESRType$I(atom) == 1 || this.mMol.getAtomESRType$I(atom) == 2 ) && (this.mTHParity[atom] == 3) ) this.mMol.setStereoProblem$I(atom);
if (this.mMol.isAtomConfigurationUnknown$I(atom) && this.mTHParity[atom] != 3  && !p$1.isUnknownBINAPBondAtom$I.apply(this, [atom]) ) this.mMol.setStereoProblem$I(atom);
}
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) if (this.mMol.isStereoBond$I(bond) && !p$1.isJustifiedStereoBond$I.apply(this, [bond]) ) this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 2) {
if (this.mMol.isBondParityUnknownOrNone$I(bond) && (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) ) {
this.mEZParity[bond]=(3|0);
this.mMol.setBondType$I$I(bond, 386);
}if (this.mEZParity[bond] == 3 && !this.mEZParityIsPseudo[bond] ) {
if (this.mMol.getBondType$I(bond) != 386) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}}}if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] == 3  && !this.mMol.isAtomConfigurationUnknown$I(this.mMol.getBondAtom$I$I(0, bond))  && !this.mMol.isAtomConfigurationUnknown$I(this.mMol.getBondAtom$I$I(1, bond)) ) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}if ((this.mMol.getBondESRType$I(bond) == 1 || this.mMol.getBondESRType$I(bond) == 2 ) && (this.mMol.getBondType$I(bond) != 1 || (this.mEZParity[bond] != 1 && this.mEZParity[bond] != 2 ) ) ) {
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(0, bond));
this.mMol.setStereoProblem$I(this.mMol.getBondAtom$I$I(1, bond));
}}
}, p$1);

Clazz_newMeth(C$, 'isUnknownBINAPBondAtom$I',  function (atom) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mEZParity[this.mMol.getConnBond$I$I(atom, i)] == 3 && this.mMol.getConnBondOrder$I$I(atom, i) == 1 ) return true;

return false;
}, p$1);

Clazz_newMeth(C$, 'isJustifiedStereoBond$I',  function (bond) {
var atom=this.mMol.getBondAtom$I$I(0, bond);
if (atom >= this.mMol.getAtoms$()) return false;
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) return true;
if (this.mTHParity[atom] == 3) return false;
var binapBond=this.mMol.findBINAPChiralityBond$I(atom);
if (binapBond != -1) return this.mEZParity[binapBond] == 1 || this.mEZParity[binapBond] == 2 ;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
if (this.mMol.getConnBondOrder$I$I(atom, i) == 2) {
if (this.mTHParity[this.mMol.getConnAtom$I$I(atom, i)] == 1 || this.mTHParity[this.mMol.getConnAtom$I$I(atom, i)] == 2 ) return true;
}}
return false;
}, p$1);

Clazz_newMeth(C$, 'generateGraph',  function () {
if (this.mMol.getAtoms$() == 0) return;
if (this.mGraphGenerated) return;
this.mGraphRings=0;
var startAtom=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] > this.mCanRank[startAtom]) startAtom=atom;

var atomHandled=Clazz_array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var bondHandled=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mGraphIndex=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphAtom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphFrom=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphBond=Clazz_array(Integer.TYPE, [this.mMol.getBonds$()]);
this.mGraphAtom[0]=startAtom;
this.mGraphIndex[startAtom]=0;
atomHandled[startAtom]=true;
var atomsWithoutParents=1;
var firstUnhandled=0;
var firstUnused=1;
var graphBonds=0;
while (firstUnhandled < this.mMol.getAtoms$()){
if (firstUnhandled < firstUnused) {
while (true){
var highestRankingConnAtom=0;
var highestRankingConnBond=0;
var highestRank=-1;
var atom=this.mGraphAtom[firstUnhandled];
for (var i=0; i < this.mMol.getAllConnAtomsPlusMetalBonds$I(atom); i++) {
if (i < this.mMol.getConnAtoms$I(atom) || i >= this.mMol.getAllConnAtoms$I(atom) ) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
if (!atomHandled[connAtom] && this.mCanRank[connAtom] > highestRank ) {
highestRankingConnAtom=connAtom;
highestRankingConnBond=this.mMol.getConnBond$I$I(atom, i);
highestRank=this.mCanRank[connAtom];
}}}
if (highestRank == -1) break;
this.mGraphIndex[highestRankingConnAtom]=firstUnused;
this.mGraphFrom[firstUnused]=firstUnhandled;
this.mGraphAtom[firstUnused++]=highestRankingConnAtom;
this.mGraphBond[graphBonds++]=highestRankingConnBond;
atomHandled[highestRankingConnAtom]=true;
bondHandled[highestRankingConnBond]=true;
}
++firstUnhandled;
} else {
var highestRankingAtom=0;
var highestRank=-1;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (!atomHandled[atom] && this.mCanRank[atom] > highestRank ) {
highestRankingAtom=atom;
highestRank=this.mCanRank[atom];
}}
++atomsWithoutParents;
this.mGraphIndex[highestRankingAtom]=firstUnused;
this.mGraphFrom[firstUnused]=-1;
this.mGraphAtom[firstUnused++]=highestRankingAtom;
atomHandled[highestRankingAtom]=true;
}}
this.mGraphClosure=Clazz_array(Integer.TYPE, [2 * (this.mMol.getBonds$() - graphBonds)]);
while (true){
var lowAtomNo1=this.mMol.getMaxAtoms$();
var lowAtomNo2=this.mMol.getMaxAtoms$();
var lowBond=-1;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var loAtom;
var hiAtom;
if (!bondHandled[bond]) {
if (this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)] < this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)]) {
loAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)];
hiAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)];
} else {
loAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(1, bond)];
hiAtom=this.mGraphIndex[this.mMol.getBondAtom$I$I(0, bond)];
}if (loAtom < lowAtomNo1 || (loAtom == lowAtomNo1 && hiAtom < lowAtomNo2 ) ) {
lowAtomNo1=loAtom;
lowAtomNo2=hiAtom;
lowBond=bond;
}}}
if (lowBond == -1) break;
bondHandled[lowBond]=true;
this.mGraphBond[graphBonds++]=lowBond;
this.mGraphClosure[2 * this.mGraphRings]=lowAtomNo1;
this.mGraphClosure[2 * this.mGraphRings + 1]=lowAtomNo2;
++this.mGraphRings;
}
this.mGraphGenerated=true;
}, p$1);

Clazz_newMeth(C$, 'getCanMolecule$',  function () {
return this.getCanMolecule$Z(false);
});

Clazz_newMeth(C$, 'getCanMolecule$Z',  function (includeExplicitHydrogen) {
p$1.generateGraph.apply(this, []);
var mol=Clazz_new_([this.mMol.getAtoms$(), this.mMol.getBonds$()],$I$(9,1).c$$I$I);
mol.setFragment$Z(this.mMol.isFragment$());
for (var i=0; i < this.mMol.getAtoms$(); i++) {
this.mMol.copyAtom$com_actelion_research_chem_Molecule$I$I$I(mol, this.mGraphAtom[i], 0, 0);
mol.setAtomESR$I$I$I(i, this.mTHESRType[this.mGraphAtom[i]], this.mTHESRGroup[this.mGraphAtom[i]]);
}
for (var i=0; i < this.mMol.getBonds$(); i++) {
this.mMol.copyBond$com_actelion_research_chem_Molecule$I$I$I$IA$Z(mol, this.mGraphBond[i], 0, 0, this.mGraphIndex, false);
if (!mol.isStereoBond$I(i) && mol.getBondAtom$I$I(0, i) > mol.getBondAtom$I$I(1, i) ) {
var temp=mol.getBondAtom$I$I(0, i);
mol.setBondAtom$I$I$I(0, i, mol.getBondAtom$I$I(1, i));
mol.setBondAtom$I$I$I(1, i, temp);
}mol.setBondESR$I$I$I(i, this.mEZESRType[this.mGraphBond[i]], this.mEZESRGroup[this.mGraphBond[i]]);
}
if (includeExplicitHydrogen) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) {
var hydrogen=this.mMol.copyAtom$com_actelion_research_chem_Molecule$I$I$I(mol, this.mMol.getConnAtom$I$I(atom, j), 0, 0);
this.mMol.copyBond$com_actelion_research_chem_Molecule$I$I$I$I$I$Z(mol, this.mMol.getConnBond$I$I(atom, j), 0, 0, this.mGraphIndex[atom], hydrogen, false);
}
}
}for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var atom=mol.getBondAtom$I$I(0, bond);
if (this.mTHParityIsMesoInverted[this.mGraphAtom[atom]]) {
if (mol.getBondType$I(bond) == 257) mol.setBondType$I$I(bond, 129);
 else if (mol.getBondType$I(bond) == 129) mol.setBondType$I$I(bond, 257);
}}
this.mMol.copyMoleculeProperties$com_actelion_research_chem_Molecule(mol);
this.mMol.invalidateHelperArrays$I(8);
return mol;
});

Clazz_newMeth(C$, 'setUnknownParitiesToExplicitlyUnknown$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (!this.mMol.isAtomConfigurationUnknown$I(atom) && this.mTHParity[atom] == 3 ) this.mMol.setAtomConfigurationUnknown$I$Z(atom, true);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 3) {
var order=this.mMol.getBondOrder$I(bond);
if (order == 1) {
this.mMol.setAtomConfigurationUnknown$I$Z(this.mMol.getBondAtom$I$I(0, bond), true);
} else if (order == 2) {
this.mMol.setBondType$I$I(bond, 386);
}}}
});

Clazz_newMeth(C$, 'setSingleUnknownAsRacemicParity$',  function () {
var unknownTHParities=0;
var knownTHParities=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] != 0 && !this.mTHParityIsPseudo[atom] ) {
if (this.mTHParity[atom] == 3) ++unknownTHParities;
 else ++knownTHParities;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] != 0  && !this.mEZParityIsPseudo[bond] ) {
if (this.mEZParity[bond] == 3) ++unknownTHParities;
 else ++knownTHParities;
}}
if (knownTHParities == 0 && unknownTHParities == 1 ) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 3 && !this.mTHParityIsPseudo[atom] ) {
if (this.mMol.getAtomPi$I(atom) == 2 && this.mMol.getConnAtoms$I(atom) == 2 ) {
for (var i=0; i < 2; i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(connAtom, j))) return false;

}
} else {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(atom, i))) return false;

}this.mTHParity[atom]=(2|0);
this.mTHESRType[atom]=(1|0);
this.mTHESRGroup[atom]=(0|0);
this.mMol.setAtomParity$I$I$Z(atom, 2, false);
this.mMol.setAtomESR$I$I$I(atom, 1, 0);
var stereoBond=this.mMol.getAtomPreferredStereoBond$I(atom);
this.mMol.setBondType$I$I(stereoBond, 257);
if (this.mMol.getBondAtom$I$I(1, stereoBond) == atom) {
var connAtom=this.mMol.getBondAtom$I$I(0, stereoBond);
this.mMol.setBondAtom$I$I$I(0, stereoBond, atom);
this.mMol.setBondAtom$I$I$I(1, stereoBond, connAtom);
}return true;
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 1 && this.mEZParity[bond] != 0  && !this.mEZParityIsPseudo[bond] ) {
for (var i=0; i < 2; i++) {
var atom=this.mMol.getBondAtom$I$I(i, bond);
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) if (this.mMol.isStereoBond$I(this.mMol.getConnBond$I$I(atom, j))) return false;

}
this.mEZParity[bond]=(2|0);
this.mEZESRType[bond]=(1|0);
this.mEZESRGroup[bond]=(0|0);
this.mMol.setBondParity$I$I$Z(bond, 2, false);
this.mMol.setAtomESR$I$I$I(bond, 1, 0);
var stereoBond=this.mMol.getBondPreferredStereoBond$I(bond);
this.mMol.setBondType$I$I(stereoBond, 257);
if (this.mMol.getBondAtom$I$I(1, stereoBond) == this.mMol.getBondAtom$I$I(0, bond) || this.mMol.getBondAtom$I$I(1, stereoBond) == this.mMol.getBondAtom$I$I(1, bond) ) {
var connAtom=this.mMol.getBondAtom$I$I(0, stereoBond);
this.mMol.setBondAtom$I$I$I(0, stereoBond, this.mMol.getBondAtom$I$I(1, stereoBond));
this.mMol.setBondAtom$I$I$I(1, stereoBond, connAtom);
}return true;
}}
}return false;
});

Clazz_newMeth(C$, 'getIDCode$',  function () {
if (this.mIDCode == null ) {
p$1.generateGraph.apply(this, []);
if ((this.mMode & 2048) == 0) {
p$1.idGenerateConfigurations.apply(this, []);
p$1.idNormalizeESRGroupNumbers.apply(this, []);
}p$1.idCodeCreate.apply(this, []);
}return this.mIDCode;
});

Clazz_newMeth(C$, 'getFinalRank$',  function () {
return this.mCanRank;
});

Clazz_newMeth(C$, 'getSymmetryRank$I',  function (atom) {
return (this.mCanRankBeforeTieBreaking == null ) ? -1 : this.mCanRankBeforeTieBreaking[atom];
});

Clazz_newMeth(C$, 'getSymmetryRanks$',  function () {
return this.mCanRankBeforeTieBreaking;
});

Clazz_newMeth(C$, 'idCodeCreate',  function () {
p$1.encodeBitsStart$Z.apply(this, [false]);
p$1.encodeBits$J$I.apply(this, [9, 4]);
var nbits=Math.max(C$.getNeededBits$I(this.mMol.getAtoms$()), C$.getNeededBits$I(this.mMol.getBonds$()));
p$1.encodeBits$J$I.apply(this, [nbits, 4]);
if (nbits == 0) {
p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
return;
}var nitrogens;
var oxygens;
var otherAtoms;
var chargedAtoms;
nitrogens=oxygens=otherAtoms=chargedAtoms=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) {
switch (this.mMol.getAtomicNo$I(atom)) {
case 6:
break;
case 7:
++nitrogens;
break;
case 8:
++oxygens;
break;
default:
++otherAtoms;
break;
}
if (this.mMol.getAtomCharge$I(atom) != 0) ++chargedAtoms;
}}
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtoms$(), nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getBonds$(), nbits]);
p$1.encodeBits$J$I.apply(this, [nitrogens, nbits]);
p$1.encodeBits$J$I.apply(this, [oxygens, nbits]);
p$1.encodeBits$J$I.apply(this, [otherAtoms, nbits]);
p$1.encodeBits$J$I.apply(this, [chargedAtoms, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 7 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 8 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 6 && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 7  && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 8  && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomicNo$I(this.mGraphAtom[atom]), 8]);
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomCharge$I(this.mGraphAtom[atom]) != 0 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [8 + this.mMol.getAtomCharge$I(this.mGraphAtom[atom]), 4]);
}
var maxdif=0;
var base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}if (maxdif < dif) maxdif=dif;
}
var dbits=C$.getNeededBits$I(maxdif);
p$1.encodeBits$J$I.apply(this, [dbits, 4]);
base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}p$1.encodeBits$J$I.apply(this, [dif, dbits]);
}
for (var i=0; i < 2 * this.mGraphRings; i++) p$1.encodeBits$J$I.apply(this, [this.mGraphClosure[i], nbits]);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var bondOrder=((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & 130560) != 0 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 32 ) ? 1 : (this.mMol.isDelocalizedBond$I(this.mGraphBond[bond])) ? 0 : Math.min(3, this.mMol.getBondOrder$I(this.mGraphBond[bond]));
p$1.encodeBits$J$I.apply(this, [bondOrder, 2]);
}
var THCount=0;
if ((this.mMode & 2048) == 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mTHConfiguration[this.mGraphAtom[atom]] != 0 && this.mTHConfiguration[this.mGraphAtom[atom]] != 3 ) ++THCount;

}p$1.encodeBits$J$I.apply(this, [THCount, nbits]);
if ((this.mMode & 2048) == 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHConfiguration[this.mGraphAtom[atom]] != 0 && this.mTHConfiguration[this.mGraphAtom[atom]] != 3 ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
if (this.mTHESRType[this.mGraphAtom[atom]] == 0) {
p$1.encodeBits$J$I.apply(this, [this.mTHConfiguration[this.mGraphAtom[atom]], 3]);
} else {
var parity=(this.mTHConfiguration[this.mGraphAtom[atom]] == 1) ? ((this.mTHESRType[this.mGraphAtom[atom]] == 1) ? 4 : 6) : ((this.mTHESRType[this.mGraphAtom[atom]] == 1) ? 5 : 7);
p$1.encodeBits$J$I.apply(this, [parity, 3]);
p$1.encodeBits$J$I.apply(this, [this.mTHESRGroup[this.mGraphAtom[atom]], 3]);
}}}
}var EZCount=0;
if ((this.mMode & 2048) == 0) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mEZConfiguration[this.mGraphBond[bond]] != 0 && this.mEZConfiguration[this.mGraphBond[bond]] != 3  && (!this.mMol.isSmallRingBond$I(this.mGraphBond[bond]) || this.mMol.getBondType$I(this.mGraphBond[bond]) == 1 ) ) ++EZCount;

}p$1.encodeBits$J$I.apply(this, [EZCount, nbits]);
if ((this.mMode & 2048) == 0) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZConfiguration[this.mGraphBond[bond]] != 0 && this.mEZConfiguration[this.mGraphBond[bond]] != 3  && (!this.mMol.isSmallRingBond$I(this.mGraphBond[bond]) || this.mMol.getBondType$I(this.mGraphBond[bond]) == 1 ) ) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 1) {
if (this.mEZESRType[this.mGraphBond[bond]] == 0) {
p$1.encodeBits$J$I.apply(this, [this.mEZConfiguration[this.mGraphBond[bond]], 3]);
} else {
var parity=(this.mEZConfiguration[this.mGraphBond[bond]] == 1) ? ((this.mEZESRType[this.mGraphBond[bond]] == 1) ? 4 : 6) : ((this.mEZESRType[this.mGraphBond[bond]] == 1) ? 5 : 7);
p$1.encodeBits$J$I.apply(this, [parity, 3]);
p$1.encodeBits$J$I.apply(this, [this.mEZESRGroup[this.mGraphBond[bond]], 3]);
}} else {
p$1.encodeBits$J$I.apply(this, [this.mEZConfiguration[this.mGraphBond[bond]], 2]);
}}}
}p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [1]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomMass$I(this.mGraphAtom[atom]), 8]);
}}
}this.mFeatureBlock=0;
if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [0, nbits, 2048, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [3, nbits, 4096, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [4, nbits, 120, 4, 3]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [5, nbits, 70368744177670, 2, 1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [6, nbits, 1, 1, -1]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [7, nbits, 1920, 4, 7]);
count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomList$I(this.mGraphAtom[atom]) != null ) ++count;

if (count > 0) {
p$1.encodeFeatureNo$I.apply(this, [8]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var atomList=this.mMol.getAtomList$I(this.mGraphAtom[atom]);
if (atomList != null ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [atomList.length, 4]);
for (var a, $a = 0, $$a = atomList; $a<$$a.length&&((a=($$a[$a])),1);$a++) p$1.encodeBits$J$I.apply(this, [a, 8]);

}}
}p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [9, nbits, 384, 2, 7]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [10, nbits, 31, 5, 0]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [11, nbits, 8192, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [12, nbits, 130560, 8, 9]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [13, nbits, 114688, 3, 14]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [14, nbits, 4063232, 5, 17]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [16, nbits, 29360128, 3, 22]);
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mAbnormalValence != null  && this.mAbnormalValence[this.mGraphAtom[atom]] != -1 ) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [17]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mAbnormalValence != null  && this.mAbnormalValence[this.mGraphAtom[atom]] != -1 ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mAbnormalValence[this.mGraphAtom[atom]], 4]);
}}
}if ((this.mMode & 8) != 0 || (this.mMode & 1024) != 0 ) {
count=0;
var maxLength=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var label=this.mMol.getAtomCustomLabel$I(this.mGraphAtom[atom]);
if (label != null ) {
++count;
maxLength=Math.max(maxLength, label.length$());
}}
if (count != 0) {
var lbits=C$.getNeededBits$I(maxLength);
p$1.encodeFeatureNo$I.apply(this, [18]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
p$1.encodeBits$J$I.apply(this, [lbits, 4]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var customLabel=this.mMol.getAtomCustomLabel$I(this.mGraphAtom[atom]);
if (customLabel != null ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [customLabel.length$(), lbits]);
for (var i=0; i < customLabel.length$(); i++) p$1.encodeBits$J$I.apply(this, [customLabel.charAt$I(i), 7]);

}}
}}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [19, nbits, 234881024, 3, 25]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [20, nbits, 917504, 3, 17]);
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [21]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) >> 4, 2]);
}}
}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [22, nbits, 268435456, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [23, nbits, 1048576, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [24, nbits, 6291456, 2, 21]);
}if ((this.mMode & 16) != 0) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.isSelectedAtom$I(this.mGraphAtom[atom])) {
p$1.encodeFeatureNo$I.apply(this, [25]);
for (var a=0; a < this.mMol.getAtoms$(); a++) p$1.encodeBits$J$I.apply(this, [this.mMol.isSelectedAtom$I(this.mGraphAtom[a]) ? 1 : 0, 1]);

break;
}}
}var isAromaticSPBond=p$1.getAromaticSPBonds.apply(this, []);
if (isAromaticSPBond != null ) {
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) ++count;

p$1.encodeFeatureNo$I.apply(this, [26]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

}if (this.mMol.isFragment$()) p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [27, nbits, 536870912, 1, -1]);
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 32) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [28]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 32) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

}if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [29, nbits, 3221225472, 2, 30]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [30, nbits, 545460846592, 7, 32]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [32, nbits, 52776558133248, 2, 44]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [33, nbits, 17042430230528, 5, 39]);
p$1.addAtomQueryFeatures$I$I$J$I$I.apply(this, [34, nbits, 70368744177664, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [35, nbits, 8388608, 1, -1]);
p$1.addBondQueryFeatures$I$I$I$I$I.apply(this, [36, nbits, 96, 2, 5]);
}count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 16 ) ++count;

if (count != 0) {
p$1.encodeFeatureNo$I.apply(this, [37]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 16 ) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getBondType$I(this.mGraphBond[bond]) == 8 ? 0 : 1, 1]);
}}
}p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'addAtomQueryFeatures$I$I$J$I$I',  function (codeNo, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask)),0 )) ++count;

if (count == 0) return;
p$1.encodeFeatureNo$I.apply(this, [codeNo]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var feature=Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask);
if (Long.$ne(feature,0 )) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [Long.$sr(feature,qfShift), qfBits]);
}}
}, p$1);

Clazz_newMeth(C$, 'addBondQueryFeatures$I$I$I$I$I',  function (codeNo, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask) != 0) ++count;

if (count == 0) return;
p$1.encodeFeatureNo$I.apply(this, [codeNo]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var feature=this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask;
if (feature != 0) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [feature >> qfShift, qfBits]);
}}
}, p$1);

Clazz_newMeth(C$, 'getAromaticSPBonds',  function () {
var isAromaticSPBond=null;
var ringSet=this.mMol.getRingSet$();
for (var r=0; r < ringSet.getSize$(); r++) {
if (ringSet.isDelocalized$I(r)) {
var count=0;
var ringAtom=ringSet.getRingAtoms$I(r);
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) if (p$1.hasTwoAromaticPiElectrons$I.apply(this, [atom])) ++count;

if (count != 0) {
var ringBond=ringSet.getRingBonds$I(r);
if (isAromaticSPBond == null ) isAromaticSPBond=Clazz_array(Boolean.TYPE, [this.mMol.getBonds$()]);
if (count == ringAtom.length) {
var minIndex=-1;
var minValue=2147483647;
for (var i=0; i < ringAtom.length; i++) {
if (minValue > this.mGraphAtom[ringBond[i]]) {
minValue=this.mGraphAtom[ringBond[i]];
minIndex=i;
}}
while (count > 0){
isAromaticSPBond[ringBond[minIndex]]=true;
minIndex=p$1.validateCyclicIndex$I$I.apply(this, [minIndex + 2, ringAtom.length]);
count-=2;
}
} else {
var index=0;
while (p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))++index;

while (!p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))index=p$1.validateCyclicIndex$I$I.apply(this, [index + 1, ringAtom.length]);

while (count > 0){
isAromaticSPBond[ringBond[index]]=true;
index=p$1.validateCyclicIndex$I$I.apply(this, [index + 2, ringAtom.length]);
count-=2;
while (!p$1.hasTwoAromaticPiElectrons$I.apply(this, [ringAtom[index]]))index=p$1.validateCyclicIndex$I$I.apply(this, [index + 1, ringAtom.length]);

}
}}}}
return isAromaticSPBond;
}, p$1);

Clazz_newMeth(C$, 'hasTwoAromaticPiElectrons$I',  function (atom) {
if (this.mMol.getAtomPi$I(atom) < 2) return false;
if (this.mMol.getConnAtoms$I(atom) == 2) return true;
var aromaticPi=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.isAromaticBond$I(connBond)) aromaticPi+=this.mMol.getBondOrder$I(connBond) - 1;
}
return aromaticPi > 1;
}, p$1);

Clazz_newMeth(C$, 'validateCyclicIndex$I$I',  function (index, limit) {
return (index < limit) ? index : index - limit;
}, p$1);

Clazz_newMeth(C$, 'invalidateCoordinates$',  function () {
this.mEncodedCoords=null;
});

Clazz_newMeth(C$, 'getEncodedCoordinates$',  function () {
return this.getEncodedCoordinates$Z(this.mZCoordinatesAvailable);
});

Clazz_newMeth(C$, 'getEncodedCoordinates$Z',  function (keepPositionAndScale) {
if (this.mEncodedCoords == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA.apply(this, [keepPositionAndScale, this.mMol.getAtomCoordinates$()]);
}return this.mEncodedCoords;
});

Clazz_newMeth(C$, 'getEncodedCoordinates$Z$com_actelion_research_chem_CoordinatesA',  function (keepPositionAndScale, atomCoordinates) {
if (this.mEncodedCoords == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA.apply(this, [keepPositionAndScale, atomCoordinates]);
}return this.mEncodedCoords;
});

Clazz_newMeth(C$, 'encodeCoordinates$Z$com_actelion_research_chem_CoordinatesA',  function (keepPositionAndScale, coords) {
if (this.mMol.getAtoms$() == 0) {
this.mEncodedCoords="";
return;
}var includeHydrogenCoordinates=false;
if (this.mZCoordinatesAvailable && this.mMol.getAllAtoms$() > this.mMol.getAtoms$()  && !this.mMol.isFragment$() ) {
includeHydrogenCoordinates=true;
for (var i=0; i < this.mMol.getAtoms$(); i++) {
if (this.mMol.getImplicitHydrogens$I(i) != 0) {
includeHydrogenCoordinates=false;
break;
}}
}var resolutionBits=this.mZCoordinatesAvailable ? 16 : 8;
p$1.encodeBitsStart$Z.apply(this, [true]);
this.mEncodingBuffer.append$C(includeHydrogenCoordinates ? "#" : "!");
p$1.encodeBits$J$I.apply(this, [this.mZCoordinatesAvailable ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [keepPositionAndScale ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [(resolutionBits/2|0), 4]);
var maxDelta=0.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) maxDelta=p$1.getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA.apply(this, [this.mGraphAtom[i], (this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]], maxDelta, coords]);

if (includeHydrogenCoordinates) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) maxDelta=p$1.getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA.apply(this, [this.mMol.getConnAtom$I$I(atom, j), atom, maxDelta, coords]);

}
}if (this.mMol.getAtoms$() > 1 && maxDelta == 0.0  ) {
this.mEncodedCoords="";
return;
}var binCount=(1 << resolutionBits);
var increment=maxDelta / (binCount / 2.0 - 1);
var maxDeltaPlusHalfIncrement=maxDelta + increment / 2.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) p$1.encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA.apply(this, [this.mGraphAtom[i], (this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]], maxDeltaPlusHalfIncrement, increment, resolutionBits, coords]);

if (includeHydrogenCoordinates) {
for (var i=0; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
for (var j=this.mMol.getConnAtoms$I(atom); j < this.mMol.getAllConnAtoms$I(atom); j++) p$1.encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA.apply(this, [this.mMol.getConnAtom$I$I(atom, j), atom, maxDeltaPlusHalfIncrement, increment, resolutionBits, coords]);

}
}if (keepPositionAndScale) {
var avblDefault=this.mZCoordinatesAvailable ? 1.5 : $I$(10).getDefaultAverageBondLength$();
var avbl=this.mMol.getAverageBondLength$I$I$D$com_actelion_research_chem_CoordinatesA(includeHydrogenCoordinates ? this.mMol.getAllAtoms$() : this.mMol.getAtoms$(), includeHydrogenCoordinates ? this.mMol.getAllBonds$() : this.mMol.getBonds$(), avblDefault, coords);
p$1.encodeBits$J$I.apply(this, [p$1.encodeABVL$D$I.apply(this, [avbl, binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].x / avbl, binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].y / avbl, binCount]), resolutionBits]);
if (this.mZCoordinatesAvailable) p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [coords[this.mGraphAtom[0]].z / avbl, binCount]), resolutionBits]);
}this.mEncodedCoords=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'getMaxDelta$I$I$D$com_actelion_research_chem_CoordinatesA',  function (atom, from, maxDelta, coords) {
var deltaX=(from == -1) ? Math.abs(coords[atom].x - coords[this.mGraphAtom[0]].x) / 8.0 : Math.abs(coords[atom].x - coords[from].x);
if (maxDelta < deltaX ) maxDelta=deltaX;
var deltaY=(from == -1) ? Math.abs(coords[atom].y - coords[this.mGraphAtom[0]].y) / 8.0 : Math.abs(coords[atom].y - coords[from].y);
if (maxDelta < deltaY ) maxDelta=deltaY;
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? Math.abs(coords[atom].z - coords[this.mGraphAtom[0]].z) / 8.0 : Math.abs(coords[atom].z - coords[from].z);
if (maxDelta < deltaZ ) maxDelta=deltaZ;
}return maxDelta;
}, p$1);

Clazz_newMeth(C$, 'encodeCoords$I$I$D$D$I$com_actelion_research_chem_CoordinatesA',  function (atom, from, maxDeltaPlusHalfIncrement, increment, resolutionBits, coords) {
var deltaX=(from == -1) ? (coords[atom].x - coords[this.mGraphAtom[0]].x) / 8.0 : coords[atom].x - coords[from].x;
var deltaY=(from == -1) ? (coords[atom].y - coords[this.mGraphAtom[0]].y) / 8.0 : coords[atom].y - coords[from].y;
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaX) / increment)|0), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaY) / increment)|0), resolutionBits]);
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? (coords[atom].z - coords[this.mGraphAtom[0]].z) / 8.0 : coords[atom].z - coords[from].z;
p$1.encodeBits$J$I.apply(this, [(((maxDeltaPlusHalfIncrement + deltaZ) / increment)|0), resolutionBits]);
}}, p$1);

Clazz_newMeth(C$, 'encodeABVL$D$I',  function (value, binCount) {
return Math.min(binCount - 1, Math.max(0, ((0.5 + Math.log10(value / 0.1) / Math.log10(2000.0) * (binCount - 1))|0)));
}, p$1);

Clazz_newMeth(C$, 'encodeShift$D$I',  function (value, binCount) {
var halfBinCount=(binCount/2|0);
var isNegative=(value < 0 );
value=Math.abs(value);
var steepness=(binCount/32|0);
var intValue=Math.min(halfBinCount - 1, Long.$ival(Math.round$D(value * halfBinCount / (value + steepness))));
return isNegative ? halfBinCount + intValue : intValue;
}, p$1);

Clazz_newMeth(C$, 'getEncodedMapping$',  function () {
if (this.mMapping == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeMapping.apply(this, []);
}return this.mMapping;
});

Clazz_newMeth(C$, 'encodeMapping',  function () {
if (this.mMol.getAtoms$() == 0) {
this.mMapping="";
return;
}var maxMapNo=0;
var autoMappingFound=false;
var manualMappingFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (maxMapNo < this.mMol.getAtomMapNo$I(atom)) maxMapNo=this.mMol.getAtomMapNo$I(atom);
if (this.mMol.isAutoMappedAtom$I(atom)) autoMappingFound=true;
 else manualMappingFound=true;
}
if (maxMapNo == 0) {
this.mMapping="";
return;
}var nbits=C$.getNeededBits$I(maxMapNo);
p$1.encodeBitsStart$Z.apply(this, [true]);
p$1.encodeBits$J$I.apply(this, [nbits, 4]);
p$1.encodeBits$J$I.apply(this, [autoMappingFound ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [manualMappingFound ? 1 : 0, 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomMapNo$I(this.mGraphAtom[atom]), nbits]);
if (autoMappingFound && manualMappingFound ) p$1.encodeBits$J$I.apply(this, [this.mMol.isAutoMappedAtom$I(this.mGraphAtom[atom]) ? 1 : 0, 1]);
}
this.mMapping=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'idGenerateConfigurations',  function () {
this.mTHConfiguration=Clazz_array(Byte.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) {
var inversion=this.mTHParityIsMesoInverted[atom];
if (this.mMol.isCentralAlleneAtom$I(atom)) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var neighbours=0;
var neighbour=Clazz_array(Integer.TYPE, [3]);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) {
neighbour[neighbours]=this.mMol.getConnAtom$I$I(connAtom, j);
if (neighbour[neighbours] != atom) ++neighbours;
}
if (neighbours == 2 && (!!((this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) ^ (this.mGraphIndex[neighbour[0]] < this.mGraphIndex[neighbour[1]]))) ) inversion=!inversion;
}
} else {
for (var i=1; i < this.mMol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var connAtom1=this.mMol.getConnAtom$I$I(atom, i);
var connAtom2=this.mMol.getConnAtom$I$I(atom, j);
if (this.mCanRank[connAtom1] > this.mCanRank[connAtom2]) inversion=!inversion;
if (this.mGraphIndex[connAtom1] < this.mGraphIndex[connAtom2]) inversion=!inversion;
}
}
}this.mTHConfiguration[atom]=(!!((this.mTHParity[atom] == 1) ^ inversion)) ? 1 : (2|0);
} else {
this.mTHConfiguration[atom]=this.mTHParity[atom];
}}
this.mEZConfiguration=Clazz_array(Byte.TYPE, [this.mMol.getBonds$()]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) {
var inversion=false;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var neighbour=Clazz_array(Integer.TYPE, [2]);
var neighbours=0;
for (var j=0; j < 3; j++) if (this.mMol.getConnAtom$I$I(bondAtom, j) != this.mMol.getBondAtom$I$I(1 - i, bond)) neighbour[neighbours++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) inversion=!inversion;
if (this.mGraphIndex[neighbour[0]] < this.mGraphIndex[neighbour[1]]) inversion=!inversion;
}}
this.mEZConfiguration[bond]=(!!((this.mEZParity[bond] == 1) ^ inversion)) ? 1 : (2|0);
} else {
this.mEZConfiguration[bond]=this.mEZParity[bond];
}}
}, p$1);

Clazz_newMeth(C$, 'idNormalizeESRGroupNumbers',  function () {
p$1.idNormalizeESRGroupNumbers$I.apply(this, [1]);
p$1.idNormalizeESRGroupNumbers$I.apply(this, [2]);
}, p$1);

Clazz_newMeth(C$, 'idNormalizeESRGroupNumbers$I',  function (type) {
var groupRank=Clazz_array(Integer.TYPE, [32]);
var groups=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if ((this.mTHConfiguration[atom] == 1 || this.mTHConfiguration[atom] == 2 ) && this.mTHESRType[atom] == type ) {
var group=this.mTHESRGroup[atom];
if (groupRank[group] < this.mCanRank[atom]) {
if (groupRank[group] == 0) ++groups;
groupRank[group]=this.mCanRank[atom];
}}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if ((this.mEZConfiguration[bond] == 1 || this.mEZConfiguration[bond] == 2 ) && this.mEZESRType[bond] == type  && this.mMol.getBondType$I(bond) == 1 ) {
var group=this.mEZESRGroup[bond];
var rank=Math.max(this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)], this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]);
if (groupRank[group] < rank) {
if (groupRank[group] == 0) ++groups;
groupRank[group]=rank;
}}}
var canGroup=Clazz_array(Byte.TYPE, [32]);
for (var i=0; i < groups; i++) {
var maxGroup=-1;
var maxRank=0;
for (var j=0; j < 32; j++) {
if (maxRank < groupRank[j]) {
maxRank=groupRank[j];
maxGroup=j;
}}
groupRank[maxGroup]=0;
canGroup[maxGroup]=(i|0);
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if ((this.mTHConfiguration[atom] == 1 || this.mTHConfiguration[atom] == 2 ) && this.mTHESRType[atom] == type ) this.mTHESRGroup[atom]=canGroup[this.mTHESRGroup[atom]];

for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mEZConfiguration[bond] == 1 || this.mEZConfiguration[bond] == 2 ) && this.mEZESRType[bond] == type  && this.mMol.getBondType$I(bond) == 1 ) this.mEZESRGroup[bond]=canGroup[this.mEZESRGroup[bond]];

}, p$1);

Clazz_newMeth(C$, 'encodeBitsStart$Z',  function (avoid127) {
this.mEncodingBuffer=Clazz_new_($I$(11,1));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
this.mEncodeAvoid127=avoid127;
}, p$1);

Clazz_newMeth(C$, 'encodeFeatureNo$I',  function (codeNo) {
for (var i=0; i < this.mFeatureBlock; i++) codeNo-=16;

if (codeNo < 0) System.out.println$S("ERROR in Canonizer: Code unexpectedly low.");
while (codeNo > 15){
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [15, 4]);
codeNo-=16;
++this.mFeatureBlock;
}
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [codeNo, 4]);
}, p$1);

Clazz_newMeth(C$, 'encodeBits$J$I',  function (data, bits) {
while (bits != 0){
if (this.mEncodingBitsAvail == 0) {
if (!this.mEncodeAvoid127 || this.mEncodingTempData != 63 ) this.mEncodingTempData+=64;
this.mEncodingBuffer.append$C(String.fromCharCode(this.mEncodingTempData));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
}this.mEncodingTempData<<=1;
this.mEncodingTempData=Long.$ival(Long.$or(this.mEncodingTempData,((Long.$and(data,1)))));
(data=Long.$sr(data,(1)));
--bits;
--this.mEncodingBitsAvail;
}
}, p$1);

Clazz_newMeth(C$, 'encodeBitsEnd',  function () {
this.mEncodingTempData<<=this.mEncodingBitsAvail;
if (!this.mEncodeAvoid127 || this.mEncodingTempData != 63 ) this.mEncodingTempData+=64;
this.mEncodingBuffer.append$C(String.fromCharCode(this.mEncodingTempData));
return this.mEncodingBuffer.toString();
}, p$1);

Clazz_newMeth(C$, 'getNeededBits$I',  function (maxNo) {
var bits=0;
while (maxNo > 0){
maxNo>>=1;
++bits;
}
return bits;
}, 1);

Clazz_newMeth(C$, 'getTHParity$I',  function (atom) {
return this.mTHParity[atom];
});

Clazz_newMeth(C$, 'getEZParity$I',  function (bond) {
return this.mEZParity[bond];
});

Clazz_newMeth(C$, 'getPseudoStereoGroupCount$',  function () {
return this.mNoOfPseudoGroups;
});

Clazz_newMeth(C$, 'getPseudoEZGroup$I',  function (bond) {
return this.mPseudoEZGroup[bond];
});

Clazz_newMeth(C$, 'getPseudoTHGroup$I',  function (atom) {
return this.mPseudoTHGroup[atom];
});

Clazz_newMeth(C$, 'normalizeEnantiomer$',  function () {
var parityCount=Clazz_array(Integer.TYPE, [this.mNoOfRanks + 1]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomESRType$I(atom) == 0) {
if (this.mTHParity[atom] == 1) ++parityCount[this.mCanRank[atom]];
 else if (this.mTHParity[atom] == 2) --parityCount[this.mCanRank[atom]];
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1 && this.mMol.getBondESRType$I(bond) == 0 ) {
if (this.mEZParity[bond] == 1) {
++parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)]];
++parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]];
} else if (this.mEZParity[bond] == 2) {
--parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(0, bond)]];
--parityCount[this.mCanRank[this.mMol.getBondAtom$I$I(1, bond)]];
}}}
for (var rank=1; rank <= this.mNoOfRanks; rank++) {
if (parityCount[rank] != 0) {
var invert=(parityCount[rank] < 0);
if (invert) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomESRType$I(atom) == 0) {
if (this.mTHParity[atom] == 1) this.mTHParity[atom]=(2|0);
 else if (this.mTHParity[atom] == 2) this.mTHParity[atom]=(1|0);
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1 && this.mMol.getBondESRType$I(bond) == 0 ) {
if (this.mEZParity[bond] == 1) this.mEZParity[bond]=(2|0);
 else if (this.mEZParity[bond] == 2) this.mEZParity[bond]=(1|0);
}}
}return invert;
}}
return false;
});

Clazz_newMeth(C$, 'setParities$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 ) {
var inversion=false;
if (this.mMol.isCentralAlleneAtom$I(atom)) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var neighbours=0;
var neighbour=Clazz_array(Integer.TYPE, [3]);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) {
neighbour[neighbours]=this.mMol.getConnAtom$I$I(connAtom, j);
if (neighbour[neighbours] != atom) ++neighbours;
}
if (neighbours == 2 && (!!((this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) ^ (neighbour[0] < neighbour[1]))) ) inversion=!inversion;
}
} else {
for (var i=1; i < this.mMol.getConnAtoms$I(atom); i++) {
for (var j=0; j < i; j++) {
var connAtom1=this.mMol.getConnAtom$I$I(atom, i);
var connAtom2=this.mMol.getConnAtom$I$I(atom, j);
if (this.mCanRank[connAtom1] > this.mCanRank[connAtom2]) inversion=!inversion;
if (connAtom1 < connAtom2) inversion=!inversion;
}
}
}this.mMol.setAtomParity$I$I$Z(atom, (!!((this.mTHParity[atom] == 1) ^ inversion)) ? 1 : 2, this.mTHParityIsPseudo[atom]);
} else {
this.mMol.setAtomParity$I$I$Z(atom, this.mTHParity[atom], this.mTHParityIsPseudo[atom]);
}}
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) {
var inversion=false;
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var neighbour=Clazz_array(Integer.TYPE, [2]);
var neighbours=0;
for (var j=0; j < 3; j++) if (this.mMol.getConnAtom$I$I(bondAtom, j) != this.mMol.getBondAtom$I$I(1 - i, bond)) neighbour[neighbours++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (this.mCanRank[neighbour[0]] > this.mCanRank[neighbour[1]]) inversion=!inversion;
if (neighbour[0] < neighbour[1]) inversion=!inversion;
}}
this.mMol.setBondParity$I$I$Z(bond, (!!((this.mEZParity[bond] == 1) ^ inversion)) ? 1 : 2, this.mEZParityIsPseudo[bond]);
} else {
this.mMol.setBondParity$I$I$Z(bond, this.mEZParity[bond], this.mEZParityIsPseudo[bond]);
}}
});

Clazz_newMeth(C$, 'setStereoCenters$',  function () {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mMol.setAtomStereoCenter$I$Z(atom, this.mIsStereoCenter[atom]);
}
});

Clazz_newMeth(C$, 'setCIPParities$',  function () {
if (this.mTHCIPParity != null ) for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mMol.setAtomCIPParity$I$I(atom, this.mTHCIPParity[atom]);

if (this.mEZCIPParity != null ) for (var bond=0; bond < this.mMol.getBonds$(); bond++) this.mMol.setBondCIPParity$I$I(bond, this.mEZCIPParity[bond]);

});

Clazz_newMeth(C$, 'cipCalcTHParity$I',  function (atom) {
if ((this.mTHParity[atom] == 1 || this.mTHParity[atom] == 2 )) {
var invertedOrder=false;
if (this.mMol.getAtomPi$I(atom) == 2) {
try {
for (var i=0; i < 2; i++) {
var alleneAtom=this.mMol.getConnAtom$I$I(atom, i);
if (this.mMol.getConnAtoms$I(alleneAtom) == 3) {
var connAtom=Clazz_array(Integer.TYPE, [2]);
var count=0;
for (var j=0; j < this.mMol.getConnAtoms$I(alleneAtom); j++) if (this.mMol.getConnBondOrder$I$I(alleneAtom, j) == 1) connAtom[count++]=this.mMol.getConnAtom$I$I(alleneAtom, j);

if (!!((this.mCanRank[connAtom[0]] > this.mCanRank[connAtom[1]]) ^ p$1.cipComparePriority$I$I$I.apply(this, [alleneAtom, connAtom[0], connAtom[1]]))) invertedOrder=!invertedOrder;
}}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mTHCIPParity[atom]=(3|0);
return;
} else {
throw e;
}
}
} else {
var cipConnAtom;
try {
cipConnAtom=p$1.cipGetOrderedConns$I.apply(this, [atom]);
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mTHCIPParity[atom]=(3|0);
return;
} else {
throw e;
}
}
for (var i=1; i < cipConnAtom.length; i++) for (var j=0; j < i; j++) if (this.mCanRank[cipConnAtom[i]] < this.mCanRank[cipConnAtom[j]]) invertedOrder=!invertedOrder;


}if (!!((this.mTHParity[atom] == 1) ^ invertedOrder)) this.mTHCIPParity[atom]=(1|0);
 else this.mTHCIPParity[atom]=(2|0);
}}, p$1);

Clazz_newMeth(C$, 'cipCalcEZParity$I',  function (bond) {
if ((this.mEZParity[bond] == 1 || this.mEZParity[bond] == 2 ) && !this.mMol.isSmallRingBond$I(bond) ) {
var invertedOrder=false;
try {
for (var i=0; i < 2; i++) {
var bondAtom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.getConnAtoms$I(bondAtom) == 3) {
var connAtom=Clazz_array(Integer.TYPE, [2]);
var count=0;
for (var j=0; j < this.mMol.getConnAtoms$I(bondAtom); j++) if (this.mMol.getConnBond$I$I(bondAtom, j) != bond) connAtom[count++]=this.mMol.getConnAtom$I$I(bondAtom, j);

if (!!((this.mCanRank[connAtom[0]] > this.mCanRank[connAtom[1]]) ^ p$1.cipComparePriority$I$I$I.apply(this, [bondAtom, connAtom[0], connAtom[1]]))) invertedOrder=!invertedOrder;
}}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.mEZCIPParity[bond]=(3|0);
return;
} else {
throw e;
}
}
if (!!((this.mEZParity[bond] == 1) ^ invertedOrder)) this.mEZCIPParity[bond]=(1|0);
 else this.mEZCIPParity[bond]=(2|0);
}}, p$1);

Clazz_newMeth(C$, 'cipGetOrderedConns$I',  function (atom) {
var noOfConns=this.mMol.getAllConnAtoms$I(atom);
var orderedConn=Clazz_array(Integer.TYPE, [noOfConns]);
for (var i=0; i < noOfConns; i++) orderedConn[i]=this.mMol.getConnAtom$I$I(atom, i);

for (var i=noOfConns; i > 1; i--) {
var found=false;
for (var j=1; j < i; j++) {
if (p$1.cipComparePriority$I$I$I.apply(this, [atom, orderedConn[j - 1], orderedConn[j]])) {
found=true;
var temp=orderedConn[j - 1];
orderedConn[j - 1]=orderedConn[j];
orderedConn[j]=temp;
}}
if (!found) break;
}
return orderedConn;
}, p$1);

Clazz_newMeth(C$, 'cipComparePriority$I$I$I',  function (rootAtom, atom1, atom2) {
if (this.mMol.getAtomicNo$I(atom1) != this.mMol.getAtomicNo$I(atom2)) return (this.mMol.getAtomicNo$I(atom1) > this.mMol.getAtomicNo$I(atom2));
if (this.mMol.getAtomMass$I(atom1) != this.mMol.getAtomMass$I(atom2)) {
var mass1=this.mMol.isNaturalAbundance$I(atom1) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom1)] : this.mMol.getAtomMass$I(atom1);
var mass2=this.mMol.isNaturalAbundance$I(atom2) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom2)] : this.mMol.getAtomMass$I(atom2);
return (mass1 > mass2);
}var graphSize=this.mMol.getAtoms$();
var graphAtom=Clazz_array(Integer.TYPE, [graphSize]);
var graphParent=Clazz_array(Integer.TYPE, [graphSize]);
var graphRank=Clazz_array(Integer.TYPE, [graphSize]);
var graphIsPseudo=Clazz_array(Boolean.TYPE, [graphSize]);
var atomUsed=Clazz_array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
graphAtom[0]=rootAtom;
graphAtom[1]=atom1;
graphAtom[2]=atom2;
graphParent[0]=-1;
graphParent[1]=0;
graphParent[2]=0;
atomUsed[rootAtom]=true;
atomUsed[atom1]=true;
atomUsed[atom2]=true;
var current=1;
var highest=2;
var levelStart=Clazz_array(Integer.TYPE, [64]);
levelStart[1]=1;
levelStart[2]=3;
var currentLevel=2;
while (current <= highest){
while (current < levelStart[currentLevel]){
var currentAtom=graphAtom[current];
if (!graphIsPseudo[current]) {
var delocalizedBondCount=0;
var delocalizedMeanAtomicNo=0;
for (var i=0; i < this.mMol.getConnAtoms$I(currentAtom); i++) {
var candidate=this.mMol.getConnAtom$I$I(currentAtom, i);
if (highest + this.mMol.getConnBondOrder$I$I(currentAtom, i) + 1  >= graphSize) {
graphSize+=this.mMol.getAtoms$();
graphAtom=p$1.resize$IA$I.apply(this, [graphAtom, graphSize]);
graphParent=p$1.resize$IA$I.apply(this, [graphParent, graphSize]);
graphRank=p$1.resize$IA$I.apply(this, [graphRank, graphSize]);
graphIsPseudo=p$1.resize$ZA$I.apply(this, [graphIsPseudo, graphSize]);
}if (this.mMol.isDelocalizedBond$I(this.mMol.getConnBond$I$I(currentAtom, i))) {
++delocalizedBondCount;
delocalizedMeanAtomicNo+=this.mMol.getAtomicNo$I(candidate);
} else {
for (var j=1; j < this.mMol.getConnBondOrder$I$I(currentAtom, i); j++) {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
graphIsPseudo[highest]=true;
}
}var parentGraphIndex=graphParent[current];
if (candidate == graphAtom[parentGraphIndex]) continue;
var atomInParentChain=false;
if (atomUsed[candidate]) {
var parent=graphParent[parentGraphIndex];
while (parent != -1){
if (candidate == graphAtom[parent]) {
atomInParentChain=true;
break;
}parent=graphParent[parent];
}
}if (atomInParentChain) {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
graphIsPseudo[highest]=true;
} else {
++highest;
graphAtom[highest]=candidate;
graphParent[highest]=current;
atomUsed[candidate]=true;
}}
if (delocalizedBondCount != 0) {
++highest;
graphRank[highest]=((delocalizedMeanAtomicNo << 2)/delocalizedBondCount|0);
graphParent[highest]=current;
graphIsPseudo[highest]=true;
}}++current;
if (current == 10000) {
throw Clazz_new_(Clazz_load('Exception').c$$S,["Emergency break in while loop."]);
}}
if (levelStart.length == currentLevel + 1) levelStart=p$1.resize$IA$I.apply(this, [levelStart, levelStart.length + 64]);
levelStart[currentLevel + 1]=highest + 1;
for (var i=levelStart[currentLevel]; i < levelStart[currentLevel + 1]; i++) {
if (graphRank[i] == 0) graphRank[i]=(this.mMol.getAtomicNo$I(graphAtom[i]) == 151 ? 1 : this.mMol.getAtomicNo$I(graphAtom[i]) == 152 ? 1 : this.mMol.getAtomicNo$I(graphAtom[i])) << 2;
graphRank[i]+=(graphRank[graphParent[i]] << 16);
}
p$1.cipUpdateParentRanking$ZA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, currentLevel]);
if (graphRank[1] != graphRank[2]) return (graphRank[1] > graphRank[2]);
if (currentLevel > 1) p$1.cipCompileRelativeRanks$IA$IA$IA$I.apply(this, [graphRank, graphParent, levelStart, currentLevel]);
++currentLevel;
}
var cipRank=Clazz_array(Integer.TYPE, [this.mMol.getAtoms$()]);
var isotopDataFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (atomUsed[atom] && !this.mMol.isNaturalAbundance$I(atom) ) {
isotopDataFound=true;
break;
}}
if (isotopDataFound) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) cipRank[atom]=this.mMol.isNaturalAbundance$I(atom) ? $I$(10).cRoundedMass[this.mMol.getAtomicNo$I(atom)] : this.mMol.getAtomMass$I(atom);

if (p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel])) return (graphRank[1] > graphRank[2]);
}$I$(1).fill$IA$I(cipRank, 0);
var ezDataFound=false;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (atomUsed[this.mMol.getBondAtom$I$I(0, bond)] || atomUsed[this.mMol.getBondAtom$I$I(1, bond)] ) {
if (this.mEZCIPParity[bond] == 1) {
cipRank[this.mMol.getBondAtom$I$I(0, bond)]=1;
cipRank[this.mMol.getBondAtom$I$I(1, bond)]=1;
ezDataFound=true;
} else if (this.mEZCIPParity[bond] == 2) {
cipRank[this.mMol.getBondAtom$I$I(0, bond)]=2;
cipRank[this.mMol.getBondAtom$I$I(1, bond)]=2;
ezDataFound=true;
}}}
if (ezDataFound && p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel]) ) return (graphRank[1] > graphRank[2]);
$I$(1).fill$IA$I(cipRank, 0);
var rsDataFound=false;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (atomUsed[atom]) {
if (this.mTHCIPParity[atom] == 2) {
cipRank[atom]=1;
rsDataFound=true;
} else if (this.mTHCIPParity[atom] == 1) {
cipRank[atom]=2;
rsDataFound=true;
}}}
if (rsDataFound && p$1.cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel]) ) return (graphRank[1] > graphRank[2]);
this.mCIPParityNoDistinctionProblem=true;
throw Clazz_new_(Clazz_load('Exception').c$$S,["no distinction applying CIP rules"]);
}, p$1);

Clazz_newMeth(C$, 'cipTryDistinguishBranches$ZA$IA$IA$IA$IA$IA$I',  function (graphIsPseudo, graphRank, graphParent, graphAtom, cipRank, levelStart, currentLevel) {
for (var level=1; level < currentLevel; level++) {
for (var i=levelStart[level]; i < levelStart[level + 1]; i++) graphRank[i]=cipRank[graphAtom[i]] + (graphRank[graphParent[i]] << 8);

p$1.cipUpdateParentRanking$ZA$IA$IA$IA$IA$I.apply(this, [graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, level]);
if (graphRank[1] != graphRank[2]) return true;
if (level > 1) p$1.cipCompileRelativeRanks$IA$IA$IA$I.apply(this, [graphRank, graphParent, levelStart, level]);
}
return false;
}, p$1);

Clazz_newMeth(C$, 'resize$IA$I',  function (array, newSize) {
var copy=Clazz_array(Integer.TYPE, [newSize]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, p$1);

Clazz_newMeth(C$, 'resize$ZA$I',  function (array, newSize) {
var copy=Clazz_array(Boolean.TYPE, [newSize]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, p$1);

Clazz_newMeth(C$, 'cipUpdateParentRanking$ZA$IA$IA$IA$IA$I',  function (graphIsPseudo, graphRank, graphParent, graphAtom, levelStart, currentLevel) {
for (var level=currentLevel; level > 1; level--) {
var parentCount=levelStart[level] - levelStart[level - 1];
var rankObject=Clazz_array($I$(12), [parentCount]);
var baseIndex=levelStart[level];
for (var parent=0; parent < parentCount; parent++) {
var parentIndex=levelStart[level - 1] + parent;
var nextBaseIndex=baseIndex;
while (nextBaseIndex < levelStart[level + 1] && graphParent[nextBaseIndex] == parentIndex )++nextBaseIndex;

rankObject[parent]=Clazz_new_(P$.Canonizer$1RankObject.$init$,[this, null]);
rankObject[parent].parentIndex=parentIndex;
rankObject[parent].parentRank=graphRank[parentIndex];
rankObject[parent].parentHCount=graphIsPseudo[parentIndex] ? 0 : this.mMol.getPlainHydrogens$I(graphAtom[parentIndex]);
rankObject[parent].childRank=Clazz_array(Integer.TYPE, [nextBaseIndex - baseIndex]);
for (var i=baseIndex; i < nextBaseIndex; i++) rankObject[parent].childRank[i - baseIndex]=graphRank[i];

$I$(1).sort$IA(rankObject[parent].childRank);
baseIndex=nextBaseIndex;
}
var comparator=((P$.Canonizer$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "Canonizer$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, ['compare$com_actelion_research_chem_Canonizer$1RankObject$com_actelion_research_chem_Canonizer$1RankObject','compare$O$O'],  function (r1, r2) {
if (r1.parentRank != r2.parentRank) return (r1.parentRank > r2.parentRank) ? 1 : -1;
var i1=r1.childRank.length;
var i2=r2.childRank.length;
var count=Math.min(i1, i2);
for (var i=0; i < count; i++) {
--i1;
--i2;
if (r1.childRank[i1] != r2.childRank[i2]) return (r1.childRank[i1] > r2.childRank[i2]) ? 1 : -1;
}
if (i1 != i2) return (i1 > i2) ? 1 : -1;
if (r1.parentHCount != r2.parentHCount) return (r1.parentHCount > r2.parentHCount) ? 1 : -1;
return 0;
});
})()
), Clazz_new_(P$.Canonizer$1.$init$,[this, null]));
$I$(1).sort$OA$java_util_Comparator(rankObject, comparator);
var consolidatedRank=1;
for (var parent=0; parent < parentCount; parent++) {
graphRank[rankObject[parent].parentIndex]=consolidatedRank;
if (parent != parentCount - 1 && comparator.compare$O$O(rankObject[parent], rankObject[parent + 1]) != 0 ) ++consolidatedRank;
}
}
}, p$1);

Clazz_newMeth(C$, 'cipCompileRelativeRanks$IA$IA$IA$I',  function (graphRank, graphParent, levelStart, currentLevel) {
var levelOffset=levelStart[currentLevel];
var count=levelStart[currentLevel + 1] - levelOffset;
var rankObject=Clazz_array($I$(13), [count]);
for (var i=0; i < count; i++) {
rankObject[i]=Clazz_new_(P$.Canonizer$2RankObject.$init$,[this, null]);
rankObject[i].rank=graphRank[i + levelOffset];
rankObject[i].parent=graphParent[i + levelOffset];
rankObject[i].index=i + levelOffset;
}
var comparator=((P$.Canonizer$2||
(function(){/*a*/var C$=Clazz_newClass(P$, "Canonizer$2", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, ['compare$com_actelion_research_chem_Canonizer$2RankObject$com_actelion_research_chem_Canonizer$2RankObject','compare$O$O'],  function (r1, r2) {
if (r1.rank != r2.rank) return (r1.rank > r2.rank) ? 1 : -1;
return 0;
});
})()
), Clazz_new_(P$.Canonizer$2.$init$,[this, null]));
for (var level=currentLevel; level > 1; level--) {
for (var i=0; i < count; i++) {
rankObject[i].rank+=(graphRank[rankObject[i].parent] << 16);
rankObject[i].parent=graphParent[rankObject[i].parent];
}
$I$(1).sort$OA$java_util_Comparator(rankObject, comparator);
var consolidatedRank=1;
for (var i=0; i < count; i++) {
graphRank[rankObject[i].index]=consolidatedRank;
if (i != count - 1 && comparator.compare$O$O(rankObject[i], rankObject[i + 1]) != 0 ) ++consolidatedRank;
}
}
}, p$1);

Clazz_newMeth(C$, 'getGraphAtoms$',  function () {
p$1.generateGraph.apply(this, []);
return this.mGraphAtom;
});

Clazz_newMeth(C$, 'getGraphIndexes$',  function () {
p$1.generateGraph.apply(this, []);
return this.mGraphIndex;
});
var $b$ = new Int8Array(1);
var $k$;
;
(function(){/*l*/var C$=Clazz_newClass(P$, "Canonizer$1RankObject", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, null, 2);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['parentIndex','parentRank','parentHCount'],'O',['childRank','int[]']]]

Clazz_newMeth(C$);
})()
;
(function(){/*l*/var C$=Clazz_newClass(P$, "Canonizer$2RankObject", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, null, 2);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['rank','parent','index']]]

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.Canonizer, "ESRGroup", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['atomList','int[]','+rankList']]]

Clazz_newMeth(C$, 'c$$I$I',  function (type, group) {
;C$.$init$.apply(this);
var count=0;
for (var atom=0; atom < this.b$['com.actelion.research.chem.Canonizer'].mMol.getAtoms$(); atom++) if (this.b$['com.actelion.research.chem.Canonizer'].mTHESRType[atom] == type && this.b$['com.actelion.research.chem.Canonizer'].mTHESRGroup[atom] == group ) ++count;

this.atomList=Clazz_array(Integer.TYPE, [count]);
this.rankList=Clazz_array(Integer.TYPE, [count]);
count=0;
for (var atom=0; atom < this.b$['com.actelion.research.chem.Canonizer'].mMol.getAtoms$(); atom++) {
if (this.b$['com.actelion.research.chem.Canonizer'].mTHESRType[atom] == type && this.b$['com.actelion.research.chem.Canonizer'].mTHESRGroup[atom] == group ) {
this.atomList[count]=atom;
this.rankList[count++]=this.b$['com.actelion.research.chem.Canonizer'].mCanRank[atom];
}}
$I$(1).sort$IA(this.rankList);
}, 1);

Clazz_newMeth(C$, ['compareTo$com_actelion_research_chem_Canonizer_ESRGroup','compareTo$O'],  function (g) {
if (this.rankList.length != g.rankList.length) return this.rankList.length < g.rankList.length ? -1 : 1;
for (var i=0; i < this.rankList.length; i++) if (this.rankList[i] != g.rankList[i]) return this.rankList[i] < g.rankList[i] ? -1 : 1;

return 0;
});

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "CanonizerBaseValue", null, null, 'Comparable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mAtom','mIndex','mAvailableBits'],'O',['mValue','long[]']]]

Clazz_newMeth(C$, 'c$$I',  function (size) {
;C$.$init$.apply(this);
this.mValue=Clazz_array(Long.TYPE, [size]);
}, 1);

Clazz_newMeth(C$, 'init$I',  function (atom) {
this.mAtom=atom;
this.mIndex=0;
this.mAvailableBits=63;
$I$(1).fill$JA$J(this.mValue, 0);
});

Clazz_newMeth(C$, 'add$J',  function (data) {
(this.mValue[$k$=this.mIndex]=Long.$add(this.mValue[$k$],(data)));
});

Clazz_newMeth(C$, 'add$I$J',  function (bits, data) {
if (this.mAvailableBits == 0) {
++this.mIndex;
this.mAvailableBits=63;
}if (this.mAvailableBits == 63) {
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],(data)));
this.mAvailableBits-=bits;
} else {
if (this.mAvailableBits >= bits) {
(this.mValue[$k$=this.mIndex]=Long.$sl(this.mValue[$k$],(bits)));
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],(data)));
this.mAvailableBits-=bits;
} else {
(this.mValue[$k$=this.mIndex]=Long.$sl(this.mValue[$k$],(this.mAvailableBits)));
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],((Long.$sr(data,(bits - this.mAvailableBits))))));
bits-=this.mAvailableBits;
++this.mIndex;
this.mAvailableBits=63 - bits;
(this.mValue[$k$=this.mIndex]=Long.$or(this.mValue[$k$],((Long.$and(data,((1 << bits) - 1))))));
}}});

Clazz_newMeth(C$, 'getAtom$',  function () {
return this.mAtom;
});

Clazz_newMeth(C$, ['compareTo$com_actelion_research_chem_CanonizerBaseValue','compareTo$O'],  function (b) {
Clazz_assert(C$, this, function(){return (this.mIndex == b.mIndex)});
for (var i=0; i < this.mIndex; i++) if (Long.$ne(this.mValue[i],b.mValue[i] )) return (Long.$lt(this.mValue[i],b.mValue[i] )) ? -1 : 1;

return (Long.$eq(this.mValue[this.mIndex],b.mValue[this.mIndex] )) ? 0 : (Long.$lt(this.mValue[this.mIndex],b.mValue[this.mIndex] )) ? -1 : 1;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
var $k$;

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'StringBuilder','java.text.DecimalFormat','java.text.DecimalFormatSymbols','java.util.Locale','com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "MolfileCreator");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mBuilder','StringBuilder','mDoubleFormat','java.text.DecimalFormat']]]

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_ExtendedMolecule$Z.apply(this, [mol, true]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$Z',  function (mol, allowScaling) {
C$.c$$com_actelion_research_chem_ExtendedMolecule$Z$StringBuilder.apply(this, [mol, allowScaling, Clazz_new_($I$(1,1).c$$I,[32768])]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$Z$StringBuilder',  function (mol, allowScaling, builder) {
C$.c$$com_actelion_research_chem_ExtendedMolecule$Z$D$StringBuilder.apply(this, [mol, allowScaling, 0.0, builder]);
}, 1);

Clazz_newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$Z$D$StringBuilder',  function (mol, allowScaling, scalingFactor, builder) {
;C$.$init$.apply(this);
this.mDoubleFormat=Clazz_new_(["0.0000", Clazz_new_([$I$(4).ENGLISH],$I$(3,1).c$$java_util_Locale)],$I$(2,1).c$$S$java_text_DecimalFormatSymbols);
var nl=System.lineSeparator$();
mol.ensureHelperArrays$I(15);
var isRacemic=true;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomParity$I(atom) != 0 && mol.getAtomParity$I(atom) != 3  && mol.getAtomESRType$I(atom) != 1 ) {
isRacemic=false;
break;
}}
var maxESRGroup=-1;
if (isRacemic) {
var esrGroupCount=Clazz_array(Integer.TYPE, [32]);
var maxGroupCount=0;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomParity$I(atom) != 0 && mol.getAtomParity$I(atom) != 3  && mol.getAtomESRType$I(atom) == 1 ) {
var group=mol.getAtomESRGroup$I(atom);
++esrGroupCount[group];
if (maxGroupCount < esrGroupCount[group]) {
maxGroupCount=esrGroupCount[group];
maxESRGroup=group;
}break;
}}
}this.mBuilder=(builder == null ) ? Clazz_new_($I$(1,1)) : builder;
var name=(mol.getName$() != null ) ? mol.getName$() : "";
this.mBuilder.append$S(name + nl);
this.mBuilder.append$S("Actelion Java MolfileCreator 1.0" + nl + nl );
p$1.appendThreeDigitInt$I.apply(this, [mol.getAllAtoms$()]);
p$1.appendThreeDigitInt$I.apply(this, [mol.getAllBonds$()]);
this.mBuilder.append$S("  0  0");
p$1.appendThreeDigitInt$I.apply(this, [(!isRacemic) ? 1 : 0]);
this.mBuilder.append$S("  0  0  0  0  0999 V2000" + nl);
var hasCoordinates=(mol.getAllAtoms$() == 1);
for (var atom=1; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAtomX$I(atom) != mol.getAtomX$I(0)  || mol.getAtomY$I(atom) != mol.getAtomY$I(0)   || mol.getAtomZ$I(atom) != mol.getAtomZ$I(0)  ) {
hasCoordinates=true;
break;
}}
var grafac=1.0;
if (hasCoordinates) {
if (scalingFactor != 0 ) {
grafac=scalingFactor;
} else if (allowScaling) {
var avbl=mol.getAverageBondLength$();
if (avbl != 0.0 ) {
if (avbl < 1.0  || avbl > 3.0  ) grafac=1.5 / avbl;
} else {
var minDistance=1.7976931348623157E308;
for (var atom1=1; atom1 < mol.getAllAtoms$(); atom1++) {
for (var atom2=0; atom2 < atom1; atom2++) {
var dx=mol.getAtomX$I(atom2) - mol.getAtomX$I(atom1);
var dy=mol.getAtomY$I(atom2) - mol.getAtomY$I(atom1);
var dz=mol.getAtomZ$I(atom2) - mol.getAtomZ$I(atom1);
var distance=dx * dx + dy * dy + dz * dz;
if (minDistance > distance ) minDistance=distance;
}
}
grafac=3.0 / minDistance;
}}}for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (hasCoordinates) {
p$1.appendTenDigitDouble$D.apply(this, [grafac * mol.getAtomX$I(atom)]);
p$1.appendTenDigitDouble$D.apply(this, [grafac * -mol.getAtomY$I(atom)]);
p$1.appendTenDigitDouble$D.apply(this, [grafac * -mol.getAtomZ$I(atom)]);
} else {
this.mBuilder.append$S("    0.0000    0.0000    0.0000");
}if (mol.getAtomList$I(atom) != null ) this.mBuilder.append$S(" L  ");
 else if (Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),1)),0 )) this.mBuilder.append$S(" A  ");
 else if ((mol.getAtomicNo$I(atom) >= 129 && mol.getAtomicNo$I(atom) <= 144 ) || mol.getAtomicNo$I(atom) == 154 ) this.mBuilder.append$S(" R# ");
 else {
var atomLabel=mol.getAtomLabel$I(atom);
this.mBuilder.append$S(" " + atomLabel);
if (atomLabel.length$() == 1) this.mBuilder.append$S("  ");
 else if (atomLabel.length$() == 2) this.mBuilder.append$S(" ");
}this.mBuilder.append$S(" 0  0  0");
var hydrogenFlags=Long.$and(1920,mol.getAtomQueryFeatures$I(atom));
if (Long.$eq(hydrogenFlags,0 )) this.mBuilder.append$S("  0");
 else if (Long.$eq(hydrogenFlags,(384) )) this.mBuilder.append$S("  3");
 else if (Long.$eq(hydrogenFlags,128 )) this.mBuilder.append$S("  2");
 else if (Long.$eq(hydrogenFlags,(1792) )) this.mBuilder.append$S("  1");
 else if (Long.$eq(hydrogenFlags,(1664) )) this.mBuilder.append$S("  2");
this.mBuilder.append$S((Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),8192)),0 )) ? "  1" : "  0");
var valence=mol.getAtomAbnormalValence$I(atom);
if (valence == -1) this.mBuilder.append$S("  0");
 else if (valence == 0) this.mBuilder.append$S(" 15");
 else p$1.appendThreeDigitInt$I.apply(this, [valence]);
this.mBuilder.append$S("  0  0  0");
p$1.appendThreeDigitInt$I.apply(this, [mol.getAtomMapNo$I(atom)]);
this.mBuilder.append$S("  0  0" + nl);
}
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var order;
var stereo;
switch (mol.getBondType$I(bond)) {
case 1:
order=1;
stereo=0;
break;
case 2:
order=2;
stereo=0;
break;
case 4:
order=3;
stereo=0;
break;
case 129:
order=1;
stereo=6;
break;
case 257:
order=1;
stereo=1;
break;
case 386:
order=2;
stereo=3;
break;
case 64:
order=4;
stereo=0;
break;
case 32:
order=8;
stereo=0;
break;
default:
order=1;
stereo=0;
break;
}
if (isRacemic && (stereo == 1 || stereo == 6 ) ) {
var atom=mol.getBondAtom$I$I(0, bond);
if (mol.getAtomESRType$I(atom) == 2) stereo=0;
 else if (mol.getAtomESRType$I(atom) == 1 && mol.getAtomESRGroup$I(atom) != maxESRGroup ) stereo=4;
}var bondType=mol.getBondQueryFeatures$I(bond) & 31;
if (bondType != 0) {
if (bondType == 8) order=4;
 else if (bondType == (3)) order=5;
 else if (bondType == (9)) order=6;
 else if (bondType == (10)) order=7;
 else order=8;
}var ringState=mol.getBondQueryFeatures$I(bond) & 384;
var topology=(ringState == 0) ? 0 : (ringState == 256) ? 1 : 2;
p$1.appendThreeDigitInt$I.apply(this, [1 + mol.getBondAtom$I$I(0, bond)]);
p$1.appendThreeDigitInt$I.apply(this, [1 + mol.getBondAtom$I$I(1, bond)]);
p$1.appendThreeDigitInt$I.apply(this, [order]);
p$1.appendThreeDigitInt$I.apply(this, [stereo]);
this.mBuilder.append$S("  0");
p$1.appendThreeDigitInt$I.apply(this, [topology]);
this.mBuilder.append$S("  0" + nl);
}
var no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (mol.getAtomCharge$I(atom) != 0) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAtomCharge$I(atom) != 0) {
if (count == 0) {
this.mBuilder.append$S("M  CHG");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
var charge=mol.getAtomCharge$I(atom);
if (charge < 0) {
this.mBuilder.append$S("  -");
charge=-charge;
} else this.mBuilder.append$S("   ");
this.mBuilder.append$C(String.fromCharCode((48 + charge)));
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (!mol.isNaturalAbundance$I(atom)) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (!mol.isNaturalAbundance$I(atom)) {
if (count == 0) {
this.mBuilder.append$S("M  ISO");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [mol.getAtomMass$I(atom)]);
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (mol.getAtomRadical$I(atom) != 0) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAtomRadical$I(atom) != 0) {
if (count == 0) {
this.mBuilder.append$S("M  RAD");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
switch (mol.getAtomRadical$I(atom)) {
case 16:
this.mBuilder.append$S("   1");
break;
case 32:
this.mBuilder.append$S("   2");
break;
case 48:
this.mBuilder.append$S("   3");
break;
}
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) >= 129 && mol.getAtomicNo$I(atom) <= 144 ) || mol.getAtomicNo$I(atom) == 154 ) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var atomicNo=mol.getAtomicNo$I(atom);
if ((atomicNo >= 129 && atomicNo <= 144 ) || atomicNo == 154 ) {
if (count == 0) {
this.mBuilder.append$S("M  RGP");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atomicNo == 154 ? 0 : atomicNo >= 142 ? atomicNo - 141 : atomicNo - 125]);
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}if (mol.isFragment$()) {
no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),120)),0 )) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var ringFeatures=Long.$and(mol.getAtomQueryFeatures$I(atom),120);
if (Long.$ne(ringFeatures,0 )) {
if (count == 0) {
this.mBuilder.append$S("M  RBC");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
if (Long.$eq(ringFeatures,(112) )) this.mBuilder.append$S("  -1");
 else if (Long.$eq(ringFeatures,8 )) this.mBuilder.append$S("   1");
 else if (Long.$eq(ringFeatures,(104) )) this.mBuilder.append$S("   2");
 else if (Long.$eq(ringFeatures,(88) )) this.mBuilder.append$S("   3");
 else if (Long.$eq(ringFeatures,(56) )) this.mBuilder.append$S("   4");
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var atomList=mol.getAtomList$I(atom);
if (atomList != null ) {
this.mBuilder.append$S("M  ALS ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
p$1.appendThreeDigitInt$I.apply(this, [atomList.length]);
this.mBuilder.append$S((Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),1)),0 )) ? " T " : " F ");
for (var i=0; i < atomList.length; i++) {
var label=$I$(5).cAtomLabel[atomList[i]];
switch (label.length$()) {
case 1:
this.mBuilder.append$S(label + "   ");
break;
case 2:
this.mBuilder.append$S(label + "  ");
break;
case 3:
this.mBuilder.append$S(label + " ");
break;
default:
this.mBuilder.append$S("   ?");
break;
}
}
this.mBuilder.append$S(nl);
}}
no=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),(6144))),0 )) ++no;

if (no != 0) {
var count=0;
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var substitution=Long.$and(mol.getAtomQueryFeatures$I(atom),(6144));
if (Long.$ne(substitution,0 )) {
if (count == 0) {
this.mBuilder.append$S("M  SUB");
p$1.appendThreeDigitInt$I.apply(this, [Math.min(8, no)]);
}this.mBuilder.append$S(" ");
p$1.appendThreeDigitInt$I.apply(this, [atom + 1]);
if (Long.$ne((Long.$and(substitution,4096)),0 )) this.mBuilder.append$S("   " + (mol.getAllConnAtoms$I(atom) + 1));
 else this.mBuilder.append$S("  -2");
--no;
if (++count == 8 || no == 0 ) {
count=0;
this.mBuilder.append$S(nl);
}}}
}}this.mBuilder.append$S("M  END" + nl);
}, 1);

Clazz_newMeth(C$, 'getMolfile$',  function () {
return this.mBuilder.toString();
});

Clazz_newMeth(C$, 'writeMolfile$java_io_Writer',  function (theWriter) {
theWriter.write$S(this.mBuilder.toString());
});

Clazz_newMeth(C$, 'appendThreeDigitInt$I',  function (data) {
if (data < 0 || data > 999 ) {
this.mBuilder.append$S("  ?");
return;
}var digitFound=false;
for (var i=0; i < 3; i++) {
var theChar=(data/100|0);
if (theChar == 0) {
if (i == 2 || digitFound ) this.mBuilder.append$C("0");
 else this.mBuilder.append$C(" ");
} else {
this.mBuilder.append$C(String.fromCharCode((48 + theChar)));
digitFound=true;
}data=10 * (data % 100);
}
}, p$1);

Clazz_newMeth(C$, 'appendTenDigitDouble$D',  function (theDouble) {
var val=this.mDoubleFormat.format$D(theDouble);
for (var i=val.length$(); i < 10; i++) this.mBuilder.append$C(" ");

this.mBuilder.append$S(val);
}, p$1);

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:17 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Molecule','java.io.BufferedReader','java.io.InputStreamReader','java.io.FileInputStream','com.actelion.research.io.BOMSkipper','java.io.StringReader','java.io.FileReader','java.util.TreeMap','com.actelion.research.chem.AromaticityResolver']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "MolfileParser");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mTreatAnyAsMetalBond','mDeduceMissingCharges','mChiralFlag','mIsV3000','mAssumeChiralTrue'],'I',['mMode'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mAtomIndexMap','java.util.TreeMap','+mBondIndexMap','mHydrogenMap','int[]']]
,['Z',['debug']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mMode=0;
}, 1);

Clazz_newMeth(C$, 'c$$I',  function (mode) {
;C$.$init$.apply(this);
this.mMode=mode;
}, 1);

Clazz_newMeth(C$, 'getHandleHydrogenMap$',  function () {
return this.mHydrogenMap == null  ? this.mMol.getHandleHydrogenMap$() : this.mHydrogenMap;
});

Clazz_newMeth(C$, 'readMoleculeFromBuffer$java_io_BufferedReader',  function (reader) {
var valence=null;
try {
var line;
var natoms;
var nbonds;
var nlists;
this.mHydrogenMap=null;
if (this.mMol != null ) {
this.mMol.clear$();
this.mMol.setFragment$Z(false);
}var name=(line=reader.readLine$());
if (null == name ) {
this.TRACE$S("readMoleculeFromBuffer: No Header Line\n");
return false;
}if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Program Line\n");
return false;
}if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Comment Line\n");
return false;
}this.mTreatAnyAsMetalBond=line.contains$CharSequence("From CSD data. Using bond type \'Any\'");
this.mDeduceMissingCharges=line.contains$CharSequence("From CSD data.");
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Counts Line\n");
return false;
}this.mIsV3000=false;
this.mChiralFlag=this.mAssumeChiralTrue;
try {
natoms=Integer.parseInt$S(line.substring$I$I(0, 3).trim$());
nbonds=Integer.parseInt$S(line.substring$I$I(3, 6).trim$());
nlists=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(6, 9).trim$()]);
this.mChiralFlag=!!(this.mChiralFlag|((1 == p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(12, 15).trim$()]))));
this.mIsV3000=(line.length$() >= 39 && line.startsWith$S$I("V3000", 34) );
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
this.TRACE$S("Warning [readMoleculeFromBuffer]: Unable to interpret counts line\n");
return false;
} else {
throw e;
}
}
if (this.mIsV3000) {
var res=p$1.readMoleculeV3FromBuffer$java_io_BufferedReader.apply(this, [reader]);
this.mMol.setName$S(name);
return res;
}if (this.mMol == null ) {
this.mMol=Clazz_new_($I$(1,1).c$$I$I,[natoms, nbonds]);
}this.mMol.setName$S(name);
if (!this.mChiralFlag) {
this.mMol.setToRacemate$();
}if (0 == natoms) {
while (line != null  && (!(line.equals$O("M  END") || line.equals$O("$$$$") || line.substring$I(1).equals$O("$")  )) ){
line=reader.readLine$();
}
return true;
}for (var i=0; i < natoms; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No Atom Line\n");
return false;
}var x=Float.parseFloat$S(line.substring$I$I(0, 10).trim$());
var y=Float.parseFloat$S(line.substring$I$I(10, 20).trim$());
var z=Float.parseFloat$S(line.substring$I$I(20, 30).trim$());
var atom=this.mMol.addAtom$D$D$D(x, -y, -z);
var label=line.substring$I$I(31, 34).trim$();
if (label.equals$O("A") || label.equals$O("*") ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1, true);
} else if (label.equals$O("Q")) {
var list=Clazz_array(Integer.TYPE, [1]);
list[0]=6;
this.mMol.setAtomList$I$IA$Z(atom, list, true);
} else {
var atomicNo=$I$(2).getAtomicNoFromLabel$S$I(label, 67);
this.mMol.setAtomicNo$I$I(atom, atomicNo);
}var massDif=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(34, 36).trim$()]);
if (massDif != 0) {
this.mMol.setAtomMass$I$I(atom, $I$(2).cRoundedMass[this.mMol.getAtomicNo$I(atom)] + massDif);
}var chargeDif=p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(36, 39).trim$()]);
if (chargeDif != 0) {
if (chargeDif == 4) this.mMol.setAtomRadical$I$I(atom, 32);
 else this.mMol.setAtomCharge$I$I(atom, 4 - chargeDif);
}var mapNo=(line.length$() < 63) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(60, 63).trim$()]);
this.mMol.setAtomMapNo$I$I$Z(atom, mapNo, false);
var hCount=(line.length$() < 45) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(42, 45).trim$()]);
switch (hCount) {
case 0:
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 768, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 128, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 384, true);
break;
default:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 896, true);
break;
}
if (line.length$() >= 48 && line.charAt$I(47) == "1" ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8192, true);
}var v=(line.length$() < 51) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(48, 51).trim$()]);
if (v != 0) {
if (valence == null ) valence=Clazz_array(Integer.TYPE, [natoms]);
valence[atom]=v;
}}
for (var i=0; i < nbonds; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]:No Bond Line\n");
return false;
}var atom1=Integer.parseInt$S(line.substring$I$I(0, 3).trim$()) - 1;
var atom2=Integer.parseInt$S(line.substring$I$I(3, 6).trim$()) - 1;
var bondType=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
var stereo=(line.length$() < 12) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(9, 12).trim$()]);
var topology=(line.length$() < 18) ? 0 : p$1.parseIntOrSpaces$S.apply(this, [line.substring$I$I(15, 18).trim$()]);
if (bondType == 8 && (this.mTreatAnyAsMetalBond || this.mMol.isMetalAtom$I(atom1) || this.mMol.isMetalAtom$I(atom2)  ) ) bondType=9;
p$1.buildBond$I$I$I$I$I.apply(this, [atom1, atom2, bondType, stereo, topology]);
}
for (var i=0; i < nlists; i++) {
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error [readMoleculeFromBuffer]: No List Line\n");
return false;
}}
if (null == (line=reader.readLine$()) ) {
this.TRACE$S("Error ReadMoleculeFromBuffer Missing M END or $$$$\n");
if ((this.mMode & 1) != 0) this.mHydrogenMap=this.mMol.getHandleHydrogenMap$();
p$1.handleValences$IA.apply(this, [valence]);
if (!this.mChiralFlag) this.mMol.ensureHelperArrays$I(15);
return true;
}while (line != null  && (!(line.equals$O("M  END") || line.equals$O("$$$$") )) ){
if (line.startsWith$S("M  CHG")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var charge=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
this.mMol.setAtomCharge$I$I(atom, charge);
}
}}if (line.startsWith$S("M  ISO")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var mass=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
this.mMol.setAtomMass$I$I(atom, mass);
}
}}if (line.startsWith$S("M  RAD")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var radical=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
switch (radical) {
case 1:
this.mMol.setAtomRadical$I$I(atom, 16);
break;
case 2:
this.mMol.setAtomRadical$I$I(atom, 32);
break;
case 3:
this.mMol.setAtomRadical$I$I(atom, 48);
break;
}
}
}}if (line.startsWith$S("M  RBC") || line.startsWith$S("M  RBD") ) {
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
var aaa=10;
var vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var ringState=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
switch (ringState) {
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 104, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 4:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 56, true);
break;
}
}
}}if (line.startsWith$S("M  ALS")) {
var atom=Integer.parseInt$S(line.substring$I$I(7, 10).trim$()) - 1;
if (atom >= 0) {
var no=Integer.parseInt$S(line.substring$I$I(10, 13).trim$());
var bNotList=(line.charAt$I(14) == "T");
var v=Clazz_array(Integer.TYPE, [no]);
var aaa=16;
for (var k=0; k < no; k++, aaa+=4) {
var sym=line.substring$I$I(aaa, aaa + 4).trim$();
v[k]=$I$(2).getAtomicNoFromLabel$S$I(sym, 1);
}
this.mMol.setAtomicNo$I$I(atom, 6);
this.mMol.setAtomList$I$IA$Z(atom, v, bNotList);
}}if (line.startsWith$S("M  SUB")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var substitution=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
if (substitution == -2) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 2048, true);
} else if (substitution > 0) {
var substitutionCount=0;
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondAtom$I$I(0, bond) == atom || this.mMol.getBondAtom$I$I(1, bond) == atom ) {
++substitutionCount;
}}
if (substitution > substitutionCount) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 4096, true);
}}}
}}if (line.startsWith$S("M  RGP")) {
var aaa;
var vvv;
var j=Integer.parseInt$S(line.substring$I$I(6, 9).trim$());
if (j > 0) {
aaa=10;
vvv=14;
for (var k=1; k <= j; k++, aaa+=8, vvv+=8) {
var atom=Integer.parseInt$S(line.substring$I$I(aaa, aaa + 3).trim$()) - 1;
var rno=Integer.parseInt$S(line.substring$I$I(vvv, vvv + 3).trim$());
if (rno >= 1 && rno <= 20 ) {
this.mMol.setAtomicNo$I$I(atom, $I$(2).getAtomicNoFromLabel$S$I("R" + rno, 2));
}}
}}line=reader.readLine$();
}
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
e.printStackTrace$();
System.err.println$S("error reading molfile " + e);
return false;
} else {
throw e;
}
}
if (this.mDeduceMissingCharges) {
p$1.introduceObviousMetalBonds.apply(this, []);
p$1.deduceMissingCharges.apply(this, []);
}if ((this.mMode & 1) != 0) this.mHydrogenMap=this.mMol.getHandleHydrogenMap$();
p$1.handleValences$IA.apply(this, [valence]);
this.mMol.ensureHelperArrays$I(15);
return true;
}, p$1);

Clazz_newMeth(C$, 'setAssumeChiralTrue$Z',  function (b) {
this.mAssumeChiralTrue=b;
});

Clazz_newMeth(C$, 'isChiralFlagSet$',  function () {
return this.mChiralFlag;
});

Clazz_newMeth(C$, 'isV3000$',  function () {
return this.mIsV3000;
});

Clazz_newMeth(C$, 'handleValences$IA',  function (valence) {
if (valence != null ) {
this.mMol.ensureHelperArrays$I(1);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (valence[atom] != 0) {
var chargeCorrection=this.mMol.getElectronValenceCorrection$I$I(atom, this.mMol.getOccupiedValence$I(atom));
if (valence[atom] == 15) {
if (chargeCorrection >= 0) this.mMol.setAtomAbnormalValence$I$I(atom, 0);
} else {
if (valence[atom] != this.mMol.getMaxValence$I(atom)) this.mMol.setAtomAbnormalValence$I$I(atom, valence[atom] - chargeCorrection);
}}}
}}, p$1);

Clazz_newMeth(C$, 'readMoleculeV3FromBuffer$java_io_BufferedReader',  function (reader) {
var MODE_CTAB=1;
var MODE_CTAB_ATOM=2;
var MODE_CTAB_BOND=3;
var MODE_CTAB_COLLECTION=4;
if (this.mAtomIndexMap != null ) this.mAtomIndexMap.clear$();
if (this.mBondIndexMap != null ) this.mBondIndexMap.clear$();
var mode=0;
var line=reader.readLine$();
while (line != null  && line.startsWith$S("M  V30 ") ){
line=line.substring$I(7).trim$();
while (line.endsWith$S("-")){
var cont=reader.readLine$();
if (!cont.startsWith$S("M  V30 ")) {
return false;
}line=line.substring$I$I(0, line.length$() - 1).concat$S(cont.substring$I(7)).trim$();
}
if (line.startsWith$S("BEGIN")) {
var modeString=line.substring$I(6).trim$();
if (modeString.startsWith$S("CTAB")) {
mode=1;
} else if (modeString.startsWith$S("ATOM")) {
mode=2;
} else if (modeString.startsWith$S("BOND")) {
mode=3;
} else if (modeString.startsWith$S("COLLECTION")) {
mode=4;
} else {
this.TRACE$S("Error MolfileParser: Unsupported version 3 block\n");
return false;
}} else if (line.startsWith$S("END")) {
mode=0;
} else if (mode == 1) {
p$1.interpretV3CountLine$S.apply(this, [line]);
} else if (mode == 2) {
p$1.interpretV3AtomLine$S.apply(this, [line]);
} else if (mode == 3) {
p$1.interpretV3BondLine$S.apply(this, [line]);
} else if (mode == 4) {
p$1.interpretV3CollectionLine$S.apply(this, [line]);
} else {
this.TRACE$S("Error MolfileParser: Unexpected version 3 line\n");
return false;
}line=reader.readLine$();
}
while (line != null  && (!(line.startsWith$S("M  END") || line.equals$O("$$$$") )) ){
line=reader.readLine$();
}
return true;
}, p$1);

Clazz_newMeth(C$, 'interpretV3CountLine$S',  function (line) {
if (this.mMol == null ) {
if (line.startsWith$S("COUNTS")) {
var index1=7;
var index2=p$1.indexOfNextItem$S$I.apply(this, [line, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 7])]);
var natoms=Integer.parseInt$S(line.substring$I$I(index1, p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1])));
var nbonds=Integer.parseInt$S(line.substring$I$I(index2, p$1.indexOfWhiteSpace$S$I.apply(this, [line, index2])));
this.mMol=Clazz_new_($I$(1,1).c$$I$I,[natoms, nbonds]);
}}}, p$1);

Clazz_newMeth(C$, 'interpretV3AtomLine$S',  function (line) {
var index1=0;
var index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atomIndex=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var label=line.substring$I$I(index1, index2);
var v=null;
var bNotList=false;
var l=p$1.isV3AtomList$S.apply(this, [line]);
if (l != 0) {
v=p$1.interpretV3AtomList$S.apply(this, [line]);
if (l < 0) bNotList=true;
index2=Math.abs(l);
}index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var x=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var y=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var z=Float.parseFloat$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var mapNo=Integer.parseInt$S(line.substring$I$I(index1, index2));
var atom=this.mMol.addAtom$D$D$D(x, -y, -z);
if (atom + 1 != atomIndex) p$1.mapAtomIndex$I$I.apply(this, [atomIndex, atom]);
if (v != null ) {
this.mMol.setAtomicNo$I$I(atom, 6);
this.mMol.setAtomList$I$IA$Z(atom, v, bNotList);
}if (mapNo != 0) {
this.mMol.setAtomMapNo$I$I$Z(atom, mapNo, false);
}if (label.equals$O("A") || label.equals$O("*") ) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1, true);
} else if (label.equals$O("Q")) {
var list=Clazz_array(Integer.TYPE, [1]);
list[0]=6;
this.mMol.setAtomList$I$IA$Z(atom, list, true);
} else {
this.mMol.setAtomicNo$I$I(atom, $I$(2).getAtomicNoFromLabel$S$I(label, 67));
}while ((index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2])) != -1){
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var specifier=line.substring$I$I(index1, index2);
var index=specifier.indexOf$I("=");
var field=specifier.substring$I$I(0, index);
var value=Integer.parseInt$S(specifier.substring$I(index + 1));
if (field.equals$O("CHG")) {
this.mMol.setAtomCharge$I$I(atom, value);
} else if (field.equals$O("RAD")) {
switch (value) {
case 1:
this.mMol.setAtomRadical$I$I(atom, 16);
break;
case 2:
this.mMol.setAtomRadical$I$I(atom, 32);
break;
case 3:
this.mMol.setAtomRadical$I$I(atom, 48);
break;
}
} else if (field.equals$O("CFG")) {
} else if (field.equals$O("MASS")) {
this.mMol.setAtomMass$I$I(atom, value);
} else if (field.equals$O("VAL")) {
this.mMol.setAtomAbnormalValence$I$I(atom, (value == -1) ? 0 : (value == 0) ? -1 : value);
} else if (field.equals$O("HCOUNT")) {
switch (value) {
case 0:
break;
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 1792, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 128, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 384, true);
break;
default:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 896, true);
break;
}
} else if (field.equals$O("SUBST")) {
if (value == -1) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 2048, true);
} else if (value > 0) {
var substitutionCount=0;
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondAtom$I$I(0, bond) == atom || this.mMol.getBondAtom$I$I(1, bond) == atom ) {
++substitutionCount;
}}
if (value > substitutionCount) {
this.mMol.setAtomQueryFeature$I$J$Z(atom, 4096, true);
}}} else if (field.equals$O("RBCNT")) {
switch (value) {
case -1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 1:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 8, true);
break;
case 2:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 104, true);
break;
case 3:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 112, true);
break;
case 4:
this.mMol.setAtomQueryFeature$I$J$Z(atom, 56, true);
break;
}
} else {
this.TRACE$S("Warning MolfileParser: Unused version 3 atom specifier:" + field + "\n" );
}}
}, p$1);

Clazz_newMeth(C$, 'interpretV3BondLine$S',  function (line) {
var index1=0;
var index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var bondIndex=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var bondType=Integer.parseInt$S(line.substring$I$I(index1, index2));
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atom1=p$1.getUsedAtomIndex$I.apply(this, [Integer.parseInt$S(line.substring$I$I(index1, index2))]);
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2]);
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var atom2=p$1.getUsedAtomIndex$I.apply(this, [Integer.parseInt$S(line.substring$I$I(index1, index2))]);
var stereo=0;
var topology=0;
while ((index1=p$1.indexOfNextItem$S$I.apply(this, [line, index2])) != -1){
index2=p$1.endOfItem$S$I.apply(this, [line, index1]);
var specifier=line.substring$I$I(index1, index2);
var index=specifier.indexOf$I("=");
var field=specifier.substring$I$I(0, index);
var value=Integer.parseInt$S(specifier.substring$I(index + 1));
if (field.equals$O("CFG")) {
switch (value) {
case 1:
stereo=1;
break;
case 2:
stereo=(bondType == 2) ? 3 : 4;
break;
case 3:
stereo=6;
break;
}
} else if (field.equals$O("TOPO")) {
topology=value;
} else {
this.TRACE$S("Warning MolfileParser: Unused version 3 bond specifier:" + field + "\n" );
}}
var bond=p$1.buildBond$I$I$I$I$I.apply(this, [atom1, atom2, bondType, stereo, topology]);
if (bond + 1 != bondIndex) p$1.mapBondIndex$I$I.apply(this, [bondIndex, bond]);
}, p$1);

Clazz_newMeth(C$, 'interpretV3CollectionLine$S',  function (line) {
var objectType=p$1.interpretObjectType$S.apply(this, [line]);
if (objectType != null ) {
var list=p$1.interpretV3List$S$S.apply(this, [line, objectType]);
if (line.startsWith$S("MDLV30/STEABS")) {
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 0, -1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 0, -1);

} else if (line.startsWith$S("MDLV30/STERAC")) {
var group=Integer.parseInt$S(line.substring$I$I(13, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 13])));
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 1, group - 1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 1, group - 1);

} else if (line.startsWith$S("MDLV30/STEREL")) {
var group=Integer.parseInt$S(line.substring$I$I(13, p$1.indexOfWhiteSpace$S$I.apply(this, [line, 13])));
if (objectType.equals$O("ATOMS")) for (var i=0; i < list.length; i++) this.mMol.setAtomESR$I$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 2, group - 1);

 else for (var i=0; i < list.length; i++) this.mMol.setBondESR$I$I$I(p$1.getUsedBondIndex$I.apply(this, [list[i]]), 2, group - 1);

} else if (line.startsWith$S("MDLV30/HILITE")) {
if (objectType.equals$O("ATOMS")) {
for (var i=0; i < list.length; i++) this.mMol.setAtomColor$I$I(p$1.getUsedAtomIndex$I.apply(this, [list[i]]), 448);

} else {
for (var i=0; i < list.length; i++) {
var bond=p$1.getUsedBondIndex$I.apply(this, [list[i]]);
this.mMol.setAtomColor$I$I(this.mMol.getBondAtom$I$I(0, bond), 448);
this.mMol.setAtomColor$I$I(this.mMol.getBondAtom$I$I(1, bond), 448);
}
}} else {
this.TRACE$S("Error [readMoleculeFromBuffer]: Unknown version 3 collection type\n");
}}}, p$1);

Clazz_newMeth(C$, 'interpretObjectType$S',  function (line) {
if (line.contains$CharSequence("ATOMS=(")) return "ATOMS";
if (line.contains$CharSequence("BONDS=(")) return "BONDS";
this.TRACE$S("Error [readMoleculeFromBuffer]: Unknown or missing collection object type\n");
return null;
}, p$1);

Clazz_newMeth(C$, 'interpretV3AtomList$S',  function (line) {
var res=null;
var i1=line.indexOf$S("[");
var i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
var atoms=Clazz_array(Integer.TYPE, [16]);
var s=line.substring$I$I(i1 + 1, i2);
var index=0;
var ok=true;
while (ok && index < 16 ){
i1=s.indexOf$S(",");
var l=null;
if (i1 == -1) {
l=s;
ok=false;
} else {
l=s.substring$I$I(0, i1);
s=s.substring$I(i1 + 1);
}atoms[index++]=$I$(2).getAtomicNoFromLabel$S$I(l, 1);
}
res=Clazz_array(Integer.TYPE, [index]);
System.arraycopy$O$I$O$I$I(atoms, 0, res, 0, index);
}return res;
}, p$1);

Clazz_newMeth(C$, 'isV3AtomList$S',  function (line) {
if (line.indexOf$S("[") >= 0) {
var i1=line.indexOf$S(" NOT[");
var i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
return -(i2 + 1);
} else {
i1=line.indexOf$S(" [");
i2=line.indexOf$S$I("]", i1);
if (i1 >= 0 && i2 > 0 ) {
return i2 + 1;
}}i1=line.indexOf$S(" \'NOT[");
i2=line.indexOf$S$I("]\'", i1);
if (i1 >= 0 && i2 > 0 ) {
return -(i2 + 2);
} else {
i1=line.indexOf$S(" \'[");
i2=line.indexOf$S$I("]\'", i1);
if (i1 >= 0 && i2 > 0 ) {
return i2 + 2;
}}System.err.println$S("Warning invalid atom list in line: " + line);
}return 0;
}, p$1);

Clazz_newMeth(C$, 'interpretV3List$S$S',  function (line, type) {
var index1=line.indexOf$S(type + "=(") + type.length$() + 2 ;
var index2=line.indexOf$I$I(")", index1);
var index=p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1]);
var count=Integer.parseInt$S(line.substring$I$I(index1, index));
var list=Clazz_array(Integer.TYPE, [count]);
for (var i=0; i < count; i++) {
index1=p$1.indexOfNextItem$S$I.apply(this, [line, index]);
index=p$1.indexOfWhiteSpace$S$I.apply(this, [line, index1]);
if (index == -1 || index > index2 ) {
index=index2;
}list[i]=Integer.parseInt$S(line.substring$I$I(index1, index));
}
return list;
}, p$1);

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$java_io_File',  function (mol, file) {
this.mMol=mol;
try {
var reader=Clazz_new_([Clazz_new_([Clazz_new_($I$(5,1).c$$java_io_File,[file]), "UTF-8"],$I$(4,1).c$$java_io_InputStream$S)],$I$(3,1).c$$java_io_Reader);
$I$(6).skip$java_io_Reader(reader);
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader]);
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
System.err.println$S("Error reading file " + e);
} else {
throw e;
}
}
return false;
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, molFile) {
return this.parse$com_actelion_research_chem_StereoMolecule$java_io_BufferedReader(mol, Clazz_new_([Clazz_new_($I$(7,1).c$$S,[molFile])],$I$(3,1).c$$java_io_Reader));
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$StringBuffer',  function (mol, molFile) {
return this.parse$com_actelion_research_chem_StereoMolecule$S(mol, molFile.toString());
});

Clazz_newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$java_io_BufferedReader',  function (m, rd) {
this.mMol=m;
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [rd]);
});

Clazz_newMeth(C$, 'getCompactMolecule$S',  function (molFile) {
this.mMol=null;
return p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [Clazz_new_([Clazz_new_($I$(7,1).c$$S,[molFile])],$I$(3,1).c$$java_io_Reader)]) ? this.mMol : null;
});

Clazz_newMeth(C$, 'getCompactMolecule$java_io_BufferedReader',  function (reader) {
this.mMol=null;
return (p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader])) ? this.mMol : null;
});

Clazz_newMeth(C$, 'getCompactMolecule$java_io_File',  function (file) {
this.mMol=null;
try {
var reader=Clazz_new_([Clazz_new_($I$(8,1).c$$java_io_File,[file])],$I$(3,1).c$$java_io_Reader);
var success=p$1.readMoleculeFromBuffer$java_io_BufferedReader.apply(this, [reader]);
try {
reader.close$();
} catch (ioe) {
if (Clazz_exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
return success ? this.mMol : null;
} catch (fnfe) {
if (Clazz_exceptionOf(fnfe,"java.io.FileNotFoundException")){
return null;
} else {
throw fnfe;
}
}
});

Clazz_newMeth(C$, 'buildBond$I$I$I$I$I',  function (atom1, atom2, bondType, stereo, topology) {
var realBondType=1;
var isAtomESRAnd=false;
switch (stereo) {
case 1:
realBondType=257;
break;
case 3:
realBondType=386;
break;
case 4:
realBondType=257;
isAtomESRAnd=true;
break;
case 6:
realBondType=129;
break;
default:
switch (bondType) {
case 1:
realBondType=1;
break;
case 2:
realBondType=2;
break;
case 3:
realBondType=4;
break;
case 4:
realBondType=64;
break;
case 9:
realBondType=32;
break;
}
break;
}
var bond=this.mMol.addBond$I$I$I(atom1, atom2, realBondType);
var queryFeatures=0;
if (isAtomESRAnd) {
this.mMol.setAtomESR$I$I$I(atom1, 1, -1);
}if (bondType > 4) {
switch (bondType) {
case 5:
queryFeatures|=3;
break;
case 6:
queryFeatures|=9;
break;
case 7:
queryFeatures|=10;
break;
case 8:
if (realBondType != 32) queryFeatures|=31;
break;
}
}if (topology == 1) {
queryFeatures|=256;
}if (topology == 2) {
queryFeatures|=128;
}if (queryFeatures != 0) {
this.mMol.setBondQueryFeature$I$I$Z(bond, queryFeatures, true);
}return bond;
}, p$1);

Clazz_newMeth(C$, 'mapAtomIndex$I$I',  function (sourceAtomIndex, usedAtomIndex) {
if (this.mAtomIndexMap == null ) this.mAtomIndexMap=Clazz_new_($I$(9,1));
this.mAtomIndexMap.put$O$O( new Integer(sourceAtomIndex),  new Integer(usedAtomIndex));
}, p$1);

Clazz_newMeth(C$, 'mapBondIndex$I$I',  function (sourceBondIndex, usedBondIndex) {
if (this.mBondIndexMap == null ) this.mBondIndexMap=Clazz_new_($I$(9,1));
this.mBondIndexMap.put$O$O( new Integer(sourceBondIndex),  new Integer(usedBondIndex));
}, p$1);

Clazz_newMeth(C$, 'getUsedAtomIndex$I',  function (sourceAtomIndex) {
var ui=(this.mAtomIndexMap == null ) ? null : this.mAtomIndexMap.get$O( new Integer(sourceAtomIndex));
return (ui == null ) ? sourceAtomIndex - 1 : ui.intValue$();
}, p$1);

Clazz_newMeth(C$, 'getUsedBondIndex$I',  function (sourceBondIndex) {
var ui=(this.mBondIndexMap == null ) ? null : this.mBondIndexMap.get$O( new Integer(sourceBondIndex));
return (ui == null ) ? sourceBondIndex - 1 : ui.intValue$();
}, p$1);

Clazz_newMeth(C$, 'parseIntOrSpaces$S',  function (s) {
return (s.length$() == 0) ? 0 : Integer.parseInt$S(s);
}, p$1);

Clazz_newMeth(C$, 'endOfItem$S$I',  function (line, start) {
var end=p$1.indexOfWhiteSpace$S$I.apply(this, [line, start + 1]);
return (end == -1) ? line.length$() : end;
}, p$1);

Clazz_newMeth(C$, 'indexOfWhiteSpace$S$I',  function (line, fromIndex) {
for (var i=fromIndex; i < line.length$(); i++) {
if (line.charAt$I(i) == " " || line.charAt$I(i) == "\t" ) {
return i;
}}
return -1;
}, p$1);

Clazz_newMeth(C$, 'indexOfNextItem$S$I',  function (line, afterPreviousItem) {
if (afterPreviousItem == -1) {
return -1;
}for (var i=afterPreviousItem + 1; i < line.length$(); i++) {
if (line.charAt$I(i) != " " && line.charAt$I(i) != "\t" ) {
return i;
}}
return -1;
}, p$1);

Clazz_newMeth(C$, 'TRACE$S',  function (s) {
if (C$.debug) {
System.out.println$S(s);
}});

Clazz_newMeth(C$, 'introduceObviousMetalBonds',  function () {
var occupiedValence=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) if (this.mMol.getBondType$I(bond) == 64) for (var i=0; i < 2; i++) occupiedValence[this.mMol.getBondAtom$I$I(i, bond)]=1;


for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
var order=this.mMol.getBondOrder$I(bond);
for (var i=0; i < 2; i++) occupiedValence[this.mMol.getBondAtom$I$I(i, bond)]+=order;

}
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
if (this.mMol.getBondOrder$I(bond) == 1) {
for (var i=0; i < 2; i++) {
var metalAtom=this.mMol.getBondAtom$I$I(1 - i, bond);
if (this.mMol.isMetalAtom$I(metalAtom)) {
var atom=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isElectronegative$I(atom) && occupiedValence[atom] > this.mMol.getMaxValence$I(atom) ) {
this.mMol.setBondType$I$I(bond, 32);
continue;
}}}
}}
}, p$1);

Clazz_newMeth(C$, 'deduceMissingCharges',  function () {
var chargeChange=Clazz_array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) chargeChange[atom]=-this.mMol.getAtomCharge$I(atom);

Clazz_new_($I$(10,1).c$$com_actelion_research_chem_ExtendedMolecule,[this.mMol]).locateDelocalizedDoubleBonds$ZA$Z$Z(null, true, false);
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) chargeChange[atom]+=this.mMol.getAtomCharge$I(atom);

for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
if (chargeChange[atom] != 0) {
var chargeToDistribute=-chargeChange[atom];
for (var bond=0; bond < this.mMol.getAllBonds$(); bond++) {
for (var i=0; i < 2; i++) {
if (chargeToDistribute > 0 && this.mMol.getBondType$I(bond) == 32  && this.mMol.getBondAtom$I$I(1 - i, bond) == atom ) {
var metal=this.mMol.getBondAtom$I$I(i, bond);
if (this.mMol.isMetalAtom$I(metal)) {
var maxCharge=p$1.getMaxOxidationState$I.apply(this, [metal]);
var charge=this.mMol.getAtomCharge$I(metal);
if (charge < maxCharge) {
var dif=Math.min(chargeToDistribute, maxCharge - charge);
this.mMol.setAtomCharge$I$I(metal, charge + dif);
chargeToDistribute-=dif;
}}}}
}
}}
}, p$1);

Clazz_newMeth(C$, 'getMaxOxidationState$I',  function (metal) {
var atomicNo=this.mMol.getAtomicNo$I(metal);
var os=(atomicNo < $I$(2).cCommonOxidationState.length) ? $I$(2).cCommonOxidationState[atomicNo] : null;
return (os == null ) ? ($b$[0] = 0, $b$[0]) : os[os.length - 1];
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.debug=false;
};
var $b$ = new Int8Array(1);
})();
;Clazz_setTVer('3.3.1-v5');//Created 2023-02-09 07:26:18 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
(function(){var P$=Clazz_newPackage("java.awt.datatransfer"),p$1={},I$=[[0,'java.io.InputStream','java.awt.datatransfer.MimeTypeParameterList','java.awt.datatransfer.MimeType','sun.awt.datatransfer.DataTransferer',['java.awt.datatransfer.DataFlavor','.TextFlavorComparator'],'java.util.Collections','java.util.Arrays','java.io.StringReader','java.io.CharArrayReader','java.io.ByteArrayInputStream','java.io.InputStreamReader','java.io.Reader','java.util.List']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "DataFlavor", function(){
Clazz_newInstance(this, arguments,0,C$);
}, null, 'Cloneable');
C$.$classes$=[['TextFlavorComparator',8]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['atom'],'S',['humanPresentableName'],'O',['mimeType','java.awt.datatransfer.MimeType','representationClass','Class']]
,['O',['ioInputStreamClass','Class','stringFlavor','java.awt.datatransfer.DataFlavor','+imageFlavor','+plainTextFlavor','+javaFileListFlavor','textFlavorComparator','java.util.Comparator']]]

Clazz_newMeth(C$, 'tryToLoadClass$S$ClassLoader',  function (className, fallback) {
return Clazz_forName(className);
}, 1);

Clazz_newMeth(C$, 'createConstant$Class$S',  function (rc, prn) {
try {
return Clazz_new_(C$.c$$Class$S,[rc, prn]);
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz_newMeth(C$, 'createConstant$S$S',  function (mt, prn) {
try {
return Clazz_new_(C$.c$$S$S,[mt, prn]);
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$S$S$java_awt_datatransfer_MimeTypeParameterList$Class$S',  function (primaryType, subType, params, representationClass, humanPresentableName) {
;C$.$init$.apply(this);
if (primaryType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["primaryType"]);
}if (subType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["subType"]);
}if (representationClass == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["representationClass"]);
}if (params == null ) params=Clazz_new_($I$(2,1));
params.set$S$S("class", representationClass.getName$());
if (humanPresentableName == null ) {
humanPresentableName=params.get$S("humanPresentableName");
if (humanPresentableName == null ) humanPresentableName=primaryType + "/" + subType ;
}try {
this.mimeType=Clazz_new_($I$(3,1).c$$S$S$java_awt_datatransfer_MimeTypeParameterList,[primaryType, subType, params]);
} catch (mtpe) {
if (Clazz_exceptionOf(mtpe,"java.awt.datatransfer.MimeTypeParseException")){
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["MimeType Parse Exception: " + mtpe.getMessage$()]);
} else {
throw mtpe;
}
}
this.representationClass=representationClass;
this.humanPresentableName=humanPresentableName;
this.mimeType.removeParameter$S("humanPresentableName");
}, 1);

Clazz_newMeth(C$, 'c$$Class$S',  function (representationClass, humanPresentableName) {
C$.c$$S$S$java_awt_datatransfer_MimeTypeParameterList$Class$S.apply(this, ["application", "x-java-serialized-object", null, representationClass, humanPresentableName]);
if (representationClass == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["representationClass"]);
}}, 1);

Clazz_newMeth(C$, 'c$$S$S',  function (mimeType, humanPresentableName) {
;C$.$init$.apply(this);
if (mimeType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["mimeType"]);
}try {
p$1.initialize$S$S$ClassLoader.apply(this, [mimeType, humanPresentableName, this.getClass$().getClassLoader$()]);
} catch (e$$) {
if (Clazz_exceptionOf(e$$,"java.awt.datatransfer.MimeTypeParseException")){
var mtpe = e$$;
{
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["failed to parse:" + mimeType]);
}
} else if (Clazz_exceptionOf(e$$,"ClassNotFoundException")){
var cnfe = e$$;
{
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["can't find specified class: " + cnfe.getMessage$()]);
}
} else {
throw e$$;
}
}
}, 1);

Clazz_newMeth(C$, 'c$$S$S$ClassLoader',  function (mimeType, humanPresentableName, classLoader) {
;C$.$init$.apply(this);
if (mimeType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["mimeType"]);
}try {
p$1.initialize$S$S$ClassLoader.apply(this, [mimeType, humanPresentableName, classLoader]);
} catch (mtpe) {
if (Clazz_exceptionOf(mtpe,"java.awt.datatransfer.MimeTypeParseException")){
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["failed to parse:" + mimeType]);
} else {
throw mtpe;
}
}
}, 1);

Clazz_newMeth(C$, 'c$$S',  function (mimeType) {
;C$.$init$.apply(this);
if (mimeType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["mimeType"]);
}try {
p$1.initialize$S$S$ClassLoader.apply(this, [mimeType, null, this.getClass$().getClassLoader$()]);
} catch (mtpe) {
if (Clazz_exceptionOf(mtpe,"java.awt.datatransfer.MimeTypeParseException")){
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["failed to parse:" + mimeType]);
} else {
throw mtpe;
}
}
}, 1);

Clazz_newMeth(C$, 'initialize$S$S$ClassLoader',  function (mimeType, humanPresentableName, classLoader) {
if (mimeType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["mimeType"]);
}this.mimeType=Clazz_new_($I$(3,1).c$$S,[mimeType]);
var rcn=this.getParameter$S("class");
if (rcn == null ) {
if ("application/x-java-serialized-object".equals$O(this.mimeType.getBaseType$())) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["no representation class specified for:" + mimeType]);
 else this.representationClass=Clazz_getClass($I$(1));
} else {
this.representationClass=C$.tryToLoadClass$S$ClassLoader(rcn, classLoader);
}this.mimeType.setParameter$S$S("class", this.representationClass.getName$());
if (humanPresentableName == null ) {
humanPresentableName=this.mimeType.getParameter$S("humanPresentableName");
if (humanPresentableName == null ) humanPresentableName=this.mimeType.getPrimaryType$() + "/" + this.mimeType.getSubType$() ;
}this.humanPresentableName=humanPresentableName;
this.mimeType.removeParameter$S("humanPresentableName");
}, p$1);

Clazz_newMeth(C$, 'toString',  function () {
var string=this.getClass$().getName$();
string+="[" + p$1.paramString.apply(this, []) + "]" ;
return string;
});

Clazz_newMeth(C$, 'paramString',  function () {
var params="";
params+="mimetype=";
if (this.mimeType == null ) {
params+="null";
} else {
params+=this.mimeType.getBaseType$();
}params+=";representationclass=";
if (this.representationClass == null ) {
params+="null";
} else {
params+=this.representationClass.getName$();
}return params;
}, p$1);

Clazz_newMeth(C$, 'getTextPlainUnicodeFlavor$',  function () {
var encoding=null;
var transferer=$I$(4).getInstance$();
if (transferer != null ) {
encoding=transferer.getDefaultUnicodeEncoding$();
}return Clazz_new_(C$.c$$S$S,["text/plain;charset=" + encoding + ";class=java.io.InputStream" , "Plain Text"]);
}, 1);

Clazz_newMeth(C$, 'selectBestTextFlavor$java_awt_datatransfer_DataFlavorA',  function (availableFlavors) {
if (availableFlavors == null  || availableFlavors.length == 0 ) {
return null;
}if (C$.textFlavorComparator == null ) {
C$.textFlavorComparator=Clazz_new_($I$(5,1));
}var bestFlavor=$I$(6,"max$java_util_Collection$java_util_Comparator",[$I$(7).asList$OA(availableFlavors), C$.textFlavorComparator]);
if (!bestFlavor.isFlavorTextType$()) {
return null;
}return bestFlavor;
}, 1);

Clazz_newMeth(C$, 'getReaderForText$java_awt_datatransfer_Transferable',  function (transferable) {
var transferObject=transferable.getTransferData$java_awt_datatransfer_DataFlavor(this);
if (transferObject == null ) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["getTransferData() returned null"]);
}if (Clazz_instanceOf(transferObject, "java.io.Reader")) {
return transferObject;
} else if (Clazz_instanceOf(transferObject, "java.lang.String")) {
return Clazz_new_($I$(8,1).c$$S,[transferObject]);
} else if (Clazz_instanceOf(transferObject, Clazz_array(Character.TYPE, -1))) {
return Clazz_new_($I$(9,1).c$$CA,[transferObject]);
}var stream=null;
if (Clazz_instanceOf(transferObject, "java.io.InputStream")) {
stream=transferObject;
} else if (Clazz_instanceOf(transferObject, Clazz_array(Byte.TYPE, -1))) {
stream=Clazz_new_($I$(10,1).c$$BA,[transferObject]);
}if (stream == null ) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["transfer data is not Reader, String, CharBuffer, char array, InputStream, ByteBuffer, or byte array"]);
}var encoding=this.getParameter$S("charset");
return (encoding == null ) ? Clazz_new_($I$(11,1).c$$java_io_InputStream,[stream]) : Clazz_new_($I$(11,1).c$$java_io_InputStream$S,[stream, encoding]);
});

Clazz_newMeth(C$, 'getMimeType$',  function () {
return (this.mimeType != null ) ? this.mimeType.toString() : null;
});

Clazz_newMeth(C$, 'getRepresentationClass$',  function () {
return this.representationClass;
});

Clazz_newMeth(C$, 'getHumanPresentableName$',  function () {
return this.humanPresentableName;
});

Clazz_newMeth(C$, 'getPrimaryType$',  function () {
return (this.mimeType != null ) ? this.mimeType.getPrimaryType$() : null;
});

Clazz_newMeth(C$, 'getSubType$',  function () {
return (this.mimeType != null ) ? this.mimeType.getSubType$() : null;
});

Clazz_newMeth(C$, 'getParameter$S',  function (paramName) {
if (paramName.equals$O("humanPresentableName")) {
return this.humanPresentableName;
} else {
return (this.mimeType != null ) ? this.mimeType.getParameter$S(paramName) : null;
}});

Clazz_newMeth(C$, 'setHumanPresentableName$S',  function (humanPresentableName) {
this.humanPresentableName=humanPresentableName;
});

Clazz_newMeth(C$, 'equals$O',  function (o) {
return ((Clazz_instanceOf(o, "java.awt.datatransfer.DataFlavor")) && this.equals$java_awt_datatransfer_DataFlavor(o) );
});

Clazz_newMeth(C$, 'equals$java_awt_datatransfer_DataFlavor',  function (that) {
if (that == null ) {
return false;
}if (this === that ) {
return true;
}if (this.representationClass == null ) {
if (that.getRepresentationClass$() != null ) {
return false;
}} else {
if (!this.representationClass.equals$O(that.getRepresentationClass$())) {
return false;
}}if (this.mimeType == null ) {
if (that.mimeType != null ) {
return false;
}} else {
if (!this.mimeType.match$java_awt_datatransfer_MimeType(that.mimeType)) {
return false;
}if ("text".equals$O(this.getPrimaryType$()) && $I$(4).doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor(this) && this.representationClass != null    && !(this.isRepresentationClassReader$() || Clazz_getClass(String).equals$O(this.representationClass) || this.isRepresentationClassCharBuffer$() || $I$(4).charArrayClass.equals$O(this.representationClass)  ) ) {
}}return true;
});

Clazz_newMeth(C$, 'equals$S',  function (s) {
if (s == null  || this.mimeType == null  ) return false;
return this.isMimeTypeEqual$S(s);
});

Clazz_newMeth(C$, 'hashCode$',  function () {
var total=0;
if (this.representationClass != null ) {
total+=this.representationClass.hashCode$();
}if (this.mimeType != null ) {
var primaryType=this.mimeType.getPrimaryType$();
if (primaryType != null ) {
total+=primaryType.hashCode$();
}if ("text".equals$O(primaryType) && $I$(4).doesSubtypeSupportCharset$java_awt_datatransfer_DataFlavor(this) && this.representationClass != null    && !(this.isRepresentationClassReader$() || Clazz_getClass(String).equals$O(this.representationClass) || this.isRepresentationClassCharBuffer$() || $I$(4).charArrayClass.equals$O(this.representationClass)  ) ) {
}}return total;
});

Clazz_newMeth(C$, 'match$java_awt_datatransfer_DataFlavor',  function (that) {
return this.equals$java_awt_datatransfer_DataFlavor(that);
});

Clazz_newMeth(C$, 'isMimeTypeEqual$S',  function (mimeType) {
if (mimeType == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["mimeType"]);
}if (this.mimeType == null ) {
return false;
}try {
return this.mimeType.match$java_awt_datatransfer_MimeType(Clazz_new_($I$(3,1).c$$S,[mimeType]));
} catch (mtpe) {
if (Clazz_exceptionOf(mtpe,"java.awt.datatransfer.MimeTypeParseException")){
return false;
} else {
throw mtpe;
}
}
});

Clazz_newMeth(C$, 'isMimeTypeEqual$java_awt_datatransfer_DataFlavor',  function (dataFlavor) {
return p$1.isMimeTypeEqual$java_awt_datatransfer_MimeType.apply(this, [dataFlavor.mimeType]);
});

Clazz_newMeth(C$, 'isMimeTypeEqual$java_awt_datatransfer_MimeType',  function (mtype) {
if (this.mimeType == null ) {
return (mtype == null );
}return this.mimeType.match$java_awt_datatransfer_MimeType(mtype);
}, p$1);

Clazz_newMeth(C$, 'isMimeTypeSerializedObject$',  function () {
return this.isMimeTypeEqual$S("application/x-java-serialized-object");
});

Clazz_newMeth(C$, 'getDefaultRepresentationClass$',  function () {
return C$.ioInputStreamClass;
});

Clazz_newMeth(C$, 'getDefaultRepresentationClassAsString$',  function () {
return this.getDefaultRepresentationClass$().getName$();
});

Clazz_newMeth(C$, 'isRepresentationClassInputStream$',  function () {
return C$.ioInputStreamClass.isAssignableFrom$Class(this.representationClass);
});

Clazz_newMeth(C$, 'isRepresentationClassReader$',  function () {
return Clazz_getClass($I$(12)).isAssignableFrom$Class(this.representationClass);
});

Clazz_newMeth(C$, 'isRepresentationClassCharBuffer$',  function () {
return false;
});

Clazz_newMeth(C$, 'isRepresentationClassByteBuffer$',  function () {
return false;
});

Clazz_newMeth(C$, 'isRepresentationClassSerializable$',  function () {
return Clazz_getClass(java.io.Serializable,[]).isAssignableFrom$Class(this.representationClass);
});

Clazz_newMeth(C$, 'isRepresentationClassRemote$',  function () {
return false;
});

Clazz_newMeth(C$, 'isFlavorSerializedObjectType$',  function () {
return false;
});

Clazz_newMeth(C$, 'isFlavorRemoteObjectType$',  function () {
return this.isRepresentationClassRemote$() && this.isRepresentationClassSerializable$() && this.isMimeTypeEqual$S("application/x-java-remote-object")  ;
});

Clazz_newMeth(C$, 'isFlavorJavaFileListType$',  function () {
if (this.mimeType == null  || this.representationClass == null  ) return false;
return Clazz_getClass($I$(13),['add$O','add$I$O','addAll$java_util_Collection','addAll$I$java_util_Collection','clear$','contains$O','containsAll$java_util_Collection','copyOf$java_util_Collection','equals$O','get$I','hashCode$','indexOf$O','isEmpty$','iterator$','lastIndexOf$O','listIterator$','listIterator$I','of$','of$O','of$O$O','of$O$O$O','of$O$O$O$O','of$O$O$O$O$O','of$O$O$O$O$O$O','of$O$O$O$O$O$O$O','of$O$O$O$O$O$O$O$O','of$O$O$O$O$O$O$O$O$O','of$O$O$O$O$O$O$O$O$O$O','of$OA','remove$O','remove$I','removeAll$java_util_Collection','replaceAll$java_util_function_UnaryOperator','retainAll$java_util_Collection','set$I$O','size$','sort$java_util_Comparator','spliterator$','subList$I$I','toArray$','toArray$OA']).isAssignableFrom$Class(this.representationClass) && this.mimeType.match$java_awt_datatransfer_MimeType(C$.javaFileListFlavor.mimeType) ;
});

Clazz_newMeth(C$, 'isFlavorTextType$',  function () {
return ($I$(4).isFlavorCharsetTextType$java_awt_datatransfer_DataFlavor(this) || $I$(4).isFlavorNoncharsetTextType$java_awt_datatransfer_DataFlavor(this) );
});

Clazz_newMeth(C$, 'clone$',  function () {
var newObj=Clazz_clone(this);
if (this.mimeType != null ) {
(newObj).mimeType=this.mimeType.clone$();
}return newObj;
});

Clazz_newMeth(C$, 'normalizeMimeTypeParameter$S$S',  function (parameterName, parameterValue) {
return parameterValue;
});

Clazz_newMeth(C$, 'normalizeMimeType$S',  function (mimeType) {
return mimeType;
});

C$.$static$=function(){C$.$static$=0;
C$.ioInputStreamClass=Clazz_getClass($I$(1));
C$.stringFlavor=C$.createConstant$Class$S(Clazz_getClass(String), "Unicode String");
C$.imageFlavor=C$.createConstant$S$S("image/x-java-image; class=java.awt.Image", "Image");
C$.plainTextFlavor=C$.createConstant$S$S("text/plain; charset=unicode; class=java.io.InputStream", "Plain Text");
C$.javaFileListFlavor=C$.createConstant$S$S("application/x-java-file-list;class=java.util.List", null);
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.DataFlavor, "TextFlavorComparator", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['sun.awt.datatransfer.DataTransferer','.DataFlavorComparator']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'compare$O$O',  function (obj1, obj2) {
var flavor1=obj1;
var flavor2=obj2;
if (flavor1.isFlavorTextType$()) {
if (flavor2.isFlavorTextType$()) {
return C$.superclazz.prototype.compare$O$O.apply(this, [obj1, obj2]);
} else {
return 1;
}} else if (flavor2.isFlavorTextType$()) {
return -1;
} else {
return 0;
}});

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.datatransfer"),p$1={},I$=[[0,'java.awt.datatransfer.MimeTypeParameterList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "MimeType", null, null, 'Cloneable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['primaryType','subType'],'O',['parameters','java.awt.datatransfer.MimeTypeParameterList']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$S',  function (rawdata) {
;C$.$init$.apply(this);
p$1.parse$S.apply(this, [rawdata]);
}, 1);

Clazz_newMeth(C$, 'c$$S$S',  function (primary, sub) {
C$.c$$S$S$java_awt_datatransfer_MimeTypeParameterList.apply(this, [primary, sub, Clazz_new_($I$(1,1))]);
}, 1);

Clazz_newMeth(C$, 'c$$S$S$java_awt_datatransfer_MimeTypeParameterList',  function (primary, sub, mtpl) {
;C$.$init$.apply(this);
if (p$1.isValidToken$S.apply(this, [primary])) {
this.primaryType=primary.toLowerCase$();
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Primary type is invalid."]);
}if (p$1.isValidToken$S.apply(this, [sub])) {
this.subType=sub.toLowerCase$();
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Sub type is invalid."]);
}this.parameters=mtpl.clone$();
}, 1);

Clazz_newMeth(C$, 'hashCode$',  function () {
var code=0;
code+=this.primaryType.hashCode$();
code+=this.subType.hashCode$();
code+=this.parameters.hashCode$();
return code;
});

Clazz_newMeth(C$, 'equals$O',  function (thatObject) {
if (!(Clazz_instanceOf(thatObject, "java.awt.datatransfer.MimeType"))) {
return false;
}var that=thatObject;
var isIt=((this.primaryType.equals$O(that.primaryType)) && (this.subType.equals$O(that.subType)) && (this.parameters.equals$O(that.parameters))  );
return isIt;
});

Clazz_newMeth(C$, 'parse$S',  function (rawdata) {
var slashIndex=rawdata.indexOf$I("/");
var semIndex=rawdata.indexOf$I(";");
if ((slashIndex < 0) && (semIndex < 0) ) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Unable to find a sub type."]);
} else if ((slashIndex < 0) && (semIndex >= 0) ) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Unable to find a sub type."]);
} else if ((slashIndex >= 0) && (semIndex < 0) ) {
this.primaryType=rawdata.substring$I$I(0, slashIndex).trim$().toLowerCase$();
this.subType=rawdata.substring$I(slashIndex + 1).trim$().toLowerCase$();
this.parameters=Clazz_new_($I$(1,1));
} else if (slashIndex < semIndex) {
this.primaryType=rawdata.substring$I$I(0, slashIndex).trim$().toLowerCase$();
this.subType=rawdata.substring$I$I(slashIndex + 1, semIndex).trim$().toLowerCase$();
this.parameters=Clazz_new_([rawdata.substring$I(semIndex)],$I$(1,1).c$$S);
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Unable to find a sub type."]);
}if (!p$1.isValidToken$S.apply(this, [this.primaryType])) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Primary type is invalid."]);
}if (!p$1.isValidToken$S.apply(this, [this.subType])) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Sub type is invalid."]);
}}, p$1);

Clazz_newMeth(C$, 'getPrimaryType$',  function () {
return this.primaryType;
});

Clazz_newMeth(C$, 'getSubType$',  function () {
return this.subType;
});

Clazz_newMeth(C$, 'getParameters$',  function () {
return this.parameters.clone$();
});

Clazz_newMeth(C$, 'getParameter$S',  function (name) {
return this.parameters.get$S(name);
});

Clazz_newMeth(C$, 'setParameter$S$S',  function (name, value) {
this.parameters.set$S$S(name, value);
});

Clazz_newMeth(C$, 'removeParameter$S',  function (name) {
this.parameters.remove$S(name);
});

Clazz_newMeth(C$, 'toString',  function () {
return this.getBaseType$() + this.parameters.toString();
});

Clazz_newMeth(C$, 'getBaseType$',  function () {
return this.primaryType + "/" + this.subType ;
});

Clazz_newMeth(C$, 'match$java_awt_datatransfer_MimeType',  function (type) {
if (type == null ) return false;
return this.primaryType.equals$O(type.getPrimaryType$()) && (this.subType.equals$O("*") || type.getSubType$().equals$O("*") || (this.subType.equals$O(type.getSubType$()))  ) ;
});

Clazz_newMeth(C$, 'match$S',  function (rawdata) {
if (rawdata == null ) return false;
return this.match$java_awt_datatransfer_MimeType(Clazz_new_(C$.c$$S,[rawdata]));
});

Clazz_newMeth(C$, 'clone$',  function () {
var newObj=null;
try {
newObj=Clazz_clone(this);
} catch (cannotHappen) {
if (Clazz_exceptionOf(cannotHappen,"CloneNotSupportedException")){
} else {
throw cannotHappen;
}
}
newObj.parameters=this.parameters.clone$();
return newObj;
});

Clazz_newMeth(C$, 'isTokenChar$C',  function (c) {
return ((c.$c() > 32 ) && (c.$c() < 127 ) ) && ("()<>@,;:\\\"/[]?=".indexOf$I(c) < 0) ;
}, 1);

Clazz_newMeth(C$, 'isValidToken$S',  function (s) {
var len=s.length$();
if (len > 0) {
for (var i=0; i < len; ++i) {
var c=s.charAt$I(i);
if (!C$.isTokenChar$C(c)) {
return false;
}}
return true;
} else {
return false;
}}, p$1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.datatransfer"),I$=[[0,'java.util.Hashtable','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "MimeTypeParameterList", null, null, 'Cloneable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['parameters','java.util.Hashtable']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.parameters=Clazz_new_($I$(1,1));
}, 1);

Clazz_newMeth(C$, 'c$$S',  function (rawdata) {
;C$.$init$.apply(this);
this.parameters=Clazz_new_($I$(1,1));
this.parse$S(rawdata);
}, 1);

Clazz_newMeth(C$, 'hashCode$',  function () {
var code=47721858;
var paramName=null;
var enum_=this.getNames$();
while (enum_.hasMoreElements$()){
paramName=enum_.nextElement$();
code+=paramName.hashCode$();
code+=this.get$S(paramName).hashCode$();
}
return code;
});

Clazz_newMeth(C$, 'equals$O',  function (thatObject) {
if (!(Clazz_instanceOf(thatObject, "java.awt.datatransfer.MimeTypeParameterList"))) {
return false;
}var that=thatObject;
if (this.size$() != that.size$()) {
return false;
}var name=null;
var thisValue=null;
var thatValue=null;
var entries=this.parameters.entrySet$();
var iterator=entries.iterator$();
var entry=null;
while (iterator.hasNext$()){
entry=iterator.next$();
name=entry.getKey$();
thisValue=entry.getValue$();
thatValue=that.parameters.get$O(name);
if ((thisValue == null ) || (thatValue == null ) ) {
if (thisValue != thatValue) {
return false;
}} else if (!thisValue.equals$O(thatValue)) {
return false;
}}
return true;
});

Clazz_newMeth(C$, 'parse$S',  function (rawdata) {
var length=rawdata.length$();
if (length > 0) {
var currentIndex=C$.skipWhiteSpace$S$I(rawdata, 0);
var lastIndex=0;
if (currentIndex < length) {
var currentChar=rawdata.charAt$I(currentIndex);
while ((currentIndex < length) && (currentChar == ";") ){
var name;
var value;
var foundit;
++currentIndex;
currentIndex=C$.skipWhiteSpace$S$I(rawdata, currentIndex);
if (currentIndex < length) {
lastIndex=currentIndex;
currentChar=rawdata.charAt$I(currentIndex);
while ((currentIndex < length) && C$.isTokenChar$C(currentChar) ){
++currentIndex;
currentChar=rawdata.charAt$I(currentIndex);
}
name=rawdata.substring$I$I(lastIndex, currentIndex).toLowerCase$();
currentIndex=C$.skipWhiteSpace$S$I(rawdata, currentIndex);
if ((currentIndex < length) && (rawdata.charAt$I(currentIndex) == "=") ) {
++currentIndex;
currentIndex=C$.skipWhiteSpace$S$I(rawdata, currentIndex);
if (currentIndex < length) {
currentChar=rawdata.charAt$I(currentIndex);
if (currentChar == "\"") {
++currentIndex;
lastIndex=currentIndex;
if (currentIndex < length) {
foundit=false;
while ((currentIndex < length) && !foundit ){
currentChar=rawdata.charAt$I(currentIndex);
if (currentChar == "\\") {
currentIndex+=2;
} else if (currentChar == "\"") {
foundit=true;
} else {
++currentIndex;
}}
if (currentChar == "\"") {
value=C$.unquote$S(rawdata.substring$I$I(lastIndex, currentIndex));
++currentIndex;
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Encountered unterminated quoted parameter value."]);
}} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Encountered unterminated quoted parameter value."]);
}} else if (C$.isTokenChar$C(currentChar)) {
lastIndex=currentIndex;
foundit=false;
while ((currentIndex < length) && !foundit ){
currentChar=rawdata.charAt$I(currentIndex);
if (C$.isTokenChar$C(currentChar)) {
++currentIndex;
} else {
foundit=true;
}}
value=rawdata.substring$I$I(lastIndex, currentIndex);
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Unexpected character encountered at index " + currentIndex]);
}this.parameters.put$O$O(name, value);
} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Couldn't find a value for parameter named " + name]);
}} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Couldn\'t find the \'=\' that separates a parameter name from its value."]);
}} else {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["Couldn\'t find parameter name"]);
}currentIndex=C$.skipWhiteSpace$S$I(rawdata, currentIndex);
if (currentIndex < length) {
currentChar=rawdata.charAt$I(currentIndex);
}}
if (currentIndex < length) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.MimeTypeParseException').c$$S,["More characters encountered in input than expected."]);
}}}});

Clazz_newMeth(C$, 'size$',  function () {
return this.parameters.size$();
});

Clazz_newMeth(C$, 'isEmpty$',  function () {
return this.parameters.isEmpty$();
});

Clazz_newMeth(C$, 'get$S',  function (name) {
return this.parameters.get$O(name.trim$().toLowerCase$());
});

Clazz_newMeth(C$, 'set$S$S',  function (name, value) {
this.parameters.put$O$O(name.trim$().toLowerCase$(), value);
});

Clazz_newMeth(C$, 'remove$S',  function (name) {
this.parameters.remove$O(name.trim$().toLowerCase$());
});

Clazz_newMeth(C$, 'getNames$',  function () {
return this.parameters.keys$();
});

Clazz_newMeth(C$, 'toString',  function () {
var buffer=Clazz_new_([this.parameters.size$() * 16],$I$(2,1).c$$I);
var keys=this.parameters.keys$();
while (keys.hasMoreElements$()){
buffer.append$S("; ");
var key=keys.nextElement$();
buffer.append$S(key);
buffer.append$C("=");
buffer.append$S(C$.quote$S(this.parameters.get$O(key)));
}
return buffer.toString();
});

Clazz_newMeth(C$, 'clone$',  function () {
var newObj=null;
try {
newObj=Clazz_clone(this);
} catch (cannotHappen) {
if (Clazz_exceptionOf(cannotHappen,"CloneNotSupportedException")){
} else {
throw cannotHappen;
}
}
newObj.parameters=this.parameters.clone$();
return newObj;
});

Clazz_newMeth(C$, 'isTokenChar$C',  function (c) {
return ((c.$c() > 32 ) && (c.$c() < 127 ) ) && ("()<>@,;:\\\"/[]?=".indexOf$I(c) < 0) ;
}, 1);

Clazz_newMeth(C$, 'skipWhiteSpace$S$I',  function (rawdata, i) {
var length=rawdata.length$();
if (i < length) {
var c=rawdata.charAt$I(i);
while ((i < length) && Character.isWhitespace$C(c) ){
++i;
c=rawdata.charAt$I(i);
}
}return i;
}, 1);

Clazz_newMeth(C$, 'quote$S',  function (value) {
var needsQuotes=false;
var length=value.length$();
for (var i=0; (i < length) && !needsQuotes ; ++i) {
needsQuotes=!C$.isTokenChar$C(value.charAt$I(i));
}
if (needsQuotes) {
var buffer=Clazz_new_([((length * 1.5)|0)],$I$(2,1).c$$I);
buffer.append$C("\"");
for (var i=0; i < length; ++i) {
var c=value.charAt$I(i);
if ((c == "\\") || (c == "\"") ) {
buffer.append$C("\\");
}buffer.append$C(c);
}
buffer.append$C("\"");
return buffer.toString();
} else {
return value;
}}, 1);

Clazz_newMeth(C$, 'unquote$S',  function (value) {
var valueLength=value.length$();
var buffer=Clazz_new_($I$(2,1).c$$I,[valueLength]);
var escaped=false;
for (var i=0; i < valueLength; ++i) {
var currentChar=value.charAt$I(i);
if (!escaped && (currentChar != "\\") ) {
buffer.append$C(currentChar);
} else if (escaped) {
buffer.append$C(currentChar);
escaped=false;
} else {
escaped=true;
}}
return buffer.toString();
}, 1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.datatransfer"),I$=[];
/*i*/var C$=Clazz_newInterface(P$, "Transferable");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.datatransfer"),p$1={},I$=[[0,'java.awt.datatransfer.DataFlavor','swingjs.JSUtil','sun.awt.EventListenerAggregate','java.awt.datatransfer.FlavorListener','java.awt.EventQueue','java.awt.datatransfer.FlavorEvent','java.util.HashSet','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Clipboard");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name'],'O',['owner','java.awt.datatransfer.ClipboardOwner','contents','java.awt.datatransfer.Transferable','flavorListeners','sun.awt.EventListenerAggregate','currentDataFlavors','java.util.Set']]]

Clazz_newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.name=name;
}, 1);

Clazz_newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz_newMeth(C$, 'setContents$java_awt_datatransfer_Transferable$java_awt_datatransfer_ClipboardOwner',  function (contents, owner) {
var oldOwner=this.owner;
var oldContents=this.contents;
this.owner=owner;
this.contents=contents;
if ("System".equals$O(this.name) && contents.isDataFlavorSupported$java_awt_datatransfer_DataFlavor($I$(1).stringFlavor) ) {
try {
var s=contents.getTransferData$java_awt_datatransfer_DataFlavor($I$(1).stringFlavor);
$I$(2).setClipboardContents$S(s);
} catch (e) {
if (Clazz_exceptionOf(e,"java.awt.datatransfer.UnsupportedFlavorException") || Clazz_exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
}p$1.fireFlavorsChanged.apply(this, []);
});

Clazz_newMeth(C$, 'getContents$O',  function (requestor) {
return this.contents;
});

Clazz_newMeth(C$, 'getAvailableDataFlavors$',  function () {
var cntnts=this.getContents$O(null);
if (cntnts == null ) {
return Clazz_array($I$(1), [0]);
}return cntnts.getTransferDataFlavors$();
});

Clazz_newMeth(C$, 'isDataFlavorAvailable$java_awt_datatransfer_DataFlavor',  function (flavor) {
if (flavor == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["flavor"]);
}var cntnts=this.getContents$O(null);
if (cntnts == null ) {
return false;
}return cntnts.isDataFlavorSupported$java_awt_datatransfer_DataFlavor(flavor);
});

Clazz_newMeth(C$, 'getData$java_awt_datatransfer_DataFlavor',  function (flavor) {
if (flavor == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["flavor"]);
}var cntnts=this.getContents$O(null);
if (cntnts == null ) {
throw Clazz_new_(Clazz_load('java.awt.datatransfer.UnsupportedFlavorException').c$$java_awt_datatransfer_DataFlavor,[flavor]);
}return cntnts.getTransferData$java_awt_datatransfer_DataFlavor(flavor);
});

Clazz_newMeth(C$, 'addFlavorListener$java_awt_datatransfer_FlavorListener',  function (listener) {
if (listener == null ) {
return;
}if (this.flavorListeners == null ) {
this.currentDataFlavors=p$1.getAvailableDataFlavorSet.apply(this, []);
this.flavorListeners=Clazz_new_([Clazz_getClass($I$(4),['flavorsChanged$java_awt_datatransfer_FlavorEvent'])],$I$(3,1).c$$Class);
}this.flavorListeners.add$java_util_EventListener(listener);
});

Clazz_newMeth(C$, 'removeFlavorListener$java_awt_datatransfer_FlavorListener',  function (listener) {
if (listener == null  || this.flavorListeners == null  ) {
return;
}this.flavorListeners.remove$java_util_EventListener(listener);
});

Clazz_newMeth(C$, 'getFlavorListeners$',  function () {
return this.flavorListeners == null  ? Clazz_array($I$(4), [0]) : this.flavorListeners.getListenersCopy$();
});

Clazz_newMeth(C$, 'fireFlavorsChanged',  function () {
if (this.flavorListeners == null ) {
return;
}var prevDataFlavors=this.currentDataFlavors;
this.currentDataFlavors=p$1.getAvailableDataFlavorSet.apply(this, []);
if (prevDataFlavors.equals$O(this.currentDataFlavors)) {
return;
}var flavorListenerArray=this.flavorListeners.getListenersInternal$();
for (var i=0; i < flavorListenerArray.length; i++) {
var listener=flavorListenerArray[i];
$I$(5,"invokeLater$Runnable",[((P$.Clipboard$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "Clipboard$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'run$',  function () {
this.$finals$.listener.flavorsChanged$java_awt_datatransfer_FlavorEvent(Clazz_new_($I$(6,1).c$$java_awt_datatransfer_Clipboard,[this.b$['java.awt.datatransfer.Clipboard']]));
});
})()
), Clazz_new_(P$.Clipboard$1.$init$,[this, {listener:listener}]))]);
}
}, p$1);

Clazz_newMeth(C$, 'getAvailableDataFlavorSet',  function () {
var set=Clazz_new_($I$(7,1));
var contents=this.getContents$O(null);
if (contents != null ) {
var flavors=contents.getTransferDataFlavors$();
if (flavors != null ) {
set.addAll$java_util_Collection($I$(8).asList$OA(flavors));
}}return set;
}, p$1);

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:53 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.dnd"),I$=[[0,'java.awt.Point']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "DropTargetDropEvent", null, 'java.awt.dnd.DropTargetEvent');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.location=C$.zero;
this.actions=0;
this.dropAction=0;
this.isLocalTx=false;
},1);

C$.$fields$=[['Z',['isLocalTx'],'I',['actions','dropAction'],'O',['+location']]
,['O',['zero','java.awt.Point']]]

Clazz_newMeth(C$, 'c$$java_awt_dnd_DropTargetContext$java_awt_Point$I$I',  function (dtc, cursorLocn, dropAction, srcActions) {
;C$.superclazz.c$$java_awt_dnd_DropTargetContext.apply(this,[dtc]);C$.$init$.apply(this);
if (cursorLocn == null ) throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["cursorLocn"]);
if (dropAction != 0 && dropAction != 1  && dropAction != 2  && dropAction != 1073741824 ) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["dropAction = " + dropAction]);
if ((srcActions & ~(1073741827)) != 0) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["srcActions"]);
this.location=cursorLocn;
this.actions=srcActions;
this.dropAction=dropAction;
}, 1);

Clazz_newMeth(C$, 'c$$java_awt_dnd_DropTargetContext$java_awt_Point$I$I$Z',  function (dtc, cursorLocn, dropAction, srcActions, isLocal) {
C$.c$$java_awt_dnd_DropTargetContext$java_awt_Point$I$I.apply(this, [dtc, cursorLocn, dropAction, srcActions]);
this.isLocalTx=isLocal;
}, 1);

Clazz_newMeth(C$, 'getLocation$',  function () {
return this.location;
});

Clazz_newMeth(C$, 'getCurrentDataFlavors$',  function () {
return this.getDropTargetContext$().getCurrentDataFlavors$();
});

Clazz_newMeth(C$, 'getCurrentDataFlavorsAsList$',  function () {
return this.getDropTargetContext$().getCurrentDataFlavorsAsList$();
});

Clazz_newMeth(C$, 'isDataFlavorSupported$java_awt_datatransfer_DataFlavor',  function (df) {
return this.getDropTargetContext$().isDataFlavorSupported$java_awt_datatransfer_DataFlavor(df);
});

Clazz_newMeth(C$, 'getSourceActions$',  function () {
return this.actions;
});

Clazz_newMeth(C$, 'getDropAction$',  function () {
return this.dropAction;
});

Clazz_newMeth(C$, 'getTransferable$',  function () {
return this.getDropTargetContext$().getTransferable$();
});

Clazz_newMeth(C$, 'acceptDrop$I',  function (dropAction) {
this.getDropTargetContext$().acceptDrop$I(dropAction);
});

Clazz_newMeth(C$, 'rejectDrop$',  function () {
this.getDropTargetContext$().rejectDrop$();
});

Clazz_newMeth(C$, 'dropComplete$Z',  function (success) {
this.getDropTargetContext$().dropComplete$Z(success);
});

Clazz_newMeth(C$, 'isLocalTransfer$',  function () {
return this.isLocalTx;
});

C$.$static$=function(){C$.$static$=0;
C$.zero=Clazz_new_($I$(1,1).c$$I$I,[0, 0]);
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:54 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.dnd"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "DropTargetEvent", null, 'java.util.EventObject');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['context','java.awt.dnd.DropTargetContext']]]

Clazz_newMeth(C$, 'c$$java_awt_dnd_DropTargetContext',  function (dtc) {
;C$.superclazz.c$$O.apply(this,[dtc.getDropTarget$()]);C$.$init$.apply(this);
this.context=dtc;
}, 1);

Clazz_newMeth(C$, 'getDropTargetContext$',  function () {
return this.context;
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:54 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.awt.dnd.peer"),I$=[];
/*i*/var C$=Clazz_newInterface(P$, "DropTargetContextPeer");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:03:54 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={},I$=[[0,'StringBuffer','java.util.stream.StreamSupport','java.util.Spliterators']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "BufferedReader", null, 'java.io.Reader');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.markedChar=-1;
this.readAheadLimit=0;
this.skipLF=false;
this.markedSkipLF=false;
},1);

C$.$fields$=[['Z',['skipLF','markedSkipLF'],'I',['nChars','nextChar','markedChar','readAheadLimit'],'O',['$in','java.io.Reader','cb','char[]']]
,['I',['defaultCharBufferSize','defaultExpectedLineLength']]]

Clazz_newMeth(C$, 'c$$java_io_Reader$I',  function ($in, sz) {
;C$.superclazz.c$$O.apply(this,[$in]);C$.$init$.apply(this);
if (sz <= 0) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Buffer size <= 0"]);
this.$in=$in;
this.cb=Clazz_array(Character.TYPE, [sz]);
this.nextChar=this.nChars=0;
}, 1);

Clazz_newMeth(C$, 'c$$java_io_Reader',  function ($in) {
C$.c$$java_io_Reader$I.apply(this, [$in, C$.defaultCharBufferSize]);
}, 1);

Clazz_newMeth(C$, 'ensureOpen',  function () {
if (this.$in == null ) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,["Stream closed"]);
}, p$1);

Clazz_newMeth(C$, 'fill',  function () {
var dst;
if (this.markedChar <= -1) {
dst=0;
} else {
var delta=this.nextChar - this.markedChar;
if (delta >= this.readAheadLimit) {
this.markedChar=-2;
this.readAheadLimit=0;
dst=0;
} else {
if (this.readAheadLimit <= this.cb.length) {
System.arraycopy$O$I$O$I$I(this.cb, this.markedChar, this.cb, 0, delta);
this.markedChar=0;
dst=delta;
} else {
var ncb=Clazz_array(Character.TYPE, [this.readAheadLimit]);
System.arraycopy$O$I$O$I$I(this.cb, this.markedChar, ncb, 0, delta);
this.cb=ncb;
this.markedChar=0;
dst=delta;
}this.nextChar=this.nChars=delta;
}}var n;
do {
n=this.$in.read$CA$I$I(this.cb, dst, this.cb.length - dst);
} while (n == 0);
if (n > 0) {
this.nChars=dst + n;
this.nextChar=dst;
}}, p$1);

Clazz_newMeth(C$, 'read$',  function () {
{
p$1.ensureOpen.apply(this, []);
for (; ; ) {
if (this.nextChar >= this.nChars) {
p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) return -1;
}if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
continue;
}}return this.cb[this.nextChar++].$c();
}
}});

Clazz_newMeth(C$, 'read1$CA$I$I',  function (cbuf, off, len) {
if (this.nextChar >= this.nChars) {
if (len >= this.cb.length && this.markedChar <= -1  && !this.skipLF ) {
return this.$in.read$CA$I$I(cbuf, off, len);
}p$1.fill.apply(this, []);
}if (this.nextChar >= this.nChars) return -1;
if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) return -1;
}}var n=Math.min(len, this.nChars - this.nextChar);
System.arraycopy$O$I$O$I$I(this.cb, this.nextChar, cbuf, off, n);
this.nextChar+=n;
return n;
}, p$1);

Clazz_newMeth(C$, 'read$CA$I$I',  function (cbuf, off, len) {
{
p$1.ensureOpen.apply(this, []);
if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
} else if (len == 0) {
return 0;
}var n=p$1.read1$CA$I$I.apply(this, [cbuf, off, len]);
if (n <= 0) return n;
while ((n < len) && this.$in.ready$() ){
var n1=p$1.read1$CA$I$I.apply(this, [cbuf, off + n, len - n]);
if (n1 <= 0) break;
n+=n1;
}
return n;
}});

Clazz_newMeth(C$, 'readLine$Z',  function (ignoreLF) {
var s=null;
var startChar;
{
p$1.ensureOpen.apply(this, []);
var omitLF=ignoreLF || this.skipLF ;
 bufferLoop : for (; ; ) {
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) {
if (s != null  && s.length$() > 0 ) return s.toString();
 else return null;
}var eol=false;
var c=String.fromCharCode(0);
var i;
if (omitLF && (this.cb[this.nextChar] == "\n") ) ++this.nextChar;
this.skipLF=false;
omitLF=false;
 charLoop : for (i=this.nextChar; i < this.nChars; i++) {
c=this.cb[i];
if ((c == "\n") || (c == "\r") ) {
eol=true;
break charLoop;
}}
startChar=this.nextChar;
this.nextChar=i;
if (eol) {
var str;
if (s == null ) {
str= String.instantialize(this.cb, startChar, i - startChar);
} else {
s.append$CA$I$I(this.cb, startChar, i - startChar);
str=s.toString();
}++this.nextChar;
if (c == "\r") {
this.skipLF=true;
}return str;
}if (s == null ) s=Clazz_new_($I$(1,1).c$$I,[C$.defaultExpectedLineLength]);
s.append$CA$I$I(this.cb, startChar, i - startChar);
}
}});

Clazz_newMeth(C$, 'readLine$',  function () {
return this.readLine$Z(false);
});

Clazz_newMeth(C$, 'skip$J',  function (n) {
if (Long.$lt(n,0 )) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["skip value is negative"]);
}{
p$1.ensureOpen.apply(this, []);
var r=n;
while (Long.$gt(r,0 )){
if (this.nextChar >= this.nChars) p$1.fill.apply(this, []);
if (this.nextChar >= this.nChars) break;
if (this.skipLF) {
this.skipLF=false;
if (this.cb[this.nextChar] == "\n") {
++this.nextChar;
}}var d=this.nChars - this.nextChar;
if (Long.$le(r,d )) {
this.nextChar=Long.$ival(Long.$add(this.nextChar,(r)));
r=0;
break;
} else {
(r=Long.$sub(r,(d)));
this.nextChar=this.nChars;
}}
return Long.$sub(n,r);
}});

Clazz_newMeth(C$, 'ready$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.skipLF) {
if (this.nextChar >= this.nChars && this.$in.ready$() ) {
p$1.fill.apply(this, []);
}if (this.nextChar < this.nChars) {
if (this.cb[this.nextChar] == "\n") ++this.nextChar;
this.skipLF=false;
}}return (this.nextChar < this.nChars) || this.$in.ready$() ;
}});

Clazz_newMeth(C$, 'markSupported$',  function () {
return true;
});

Clazz_newMeth(C$, 'mark$I',  function (readAheadLimit) {
if (readAheadLimit < 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Read-ahead limit < 0"]);
}{
p$1.ensureOpen.apply(this, []);
this.readAheadLimit=readAheadLimit;
this.markedChar=this.nextChar;
this.markedSkipLF=this.skipLF;
}});

Clazz_newMeth(C$, 'reset$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.markedChar < 0) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,[(this.markedChar == -2) ? "Mark invalid" : "Stream not marked"]);
this.nextChar=this.markedChar;
this.skipLF=this.markedSkipLF;
}});

Clazz_newMeth(C$, 'close$',  function () {
{
if (this.$in == null ) return;
try {
this.$in.close$();
} finally {
this.$in=null;
this.cb=null;
}
}});

Clazz_newMeth(C$, 'lines$',  function () {
var iter=((P$.BufferedReader$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "BufferedReader$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Iterator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.nextLine=null;
},1);

C$.$fields$=[['S',['nextLine']]]

Clazz_newMeth(C$, 'hasNext$',  function () {
if (this.nextLine != null ) {
return true;
} else {
try {
this.nextLine=this.b$['java.io.BufferedReader'].readLine$.apply(this.b$['java.io.BufferedReader'], []);
return (this.nextLine != null );
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
throw Clazz_new_(Clazz_load('java.io.UncheckedIOException').c$$java_io_IOException,[e]);
} else {
throw e;
}
}
}});

Clazz_newMeth(C$, 'next$',  function () {
if (this.nextLine != null  || this.hasNext$() ) {
var line=this.nextLine;
this.nextLine=null;
return line;
} else {
throw Clazz_new_(Clazz_load('java.util.NoSuchElementException'));
}});
})()
), Clazz_new_(P$.BufferedReader$1.$init$,[this, null]));
return $I$(2,"stream$java_util_Spliterator$Z",[$I$(3).spliteratorUnknownSize$java_util_Iterator$I(iter, 272), false]);
});

C$.$static$=function(){C$.$static$=0;
C$.defaultCharBufferSize=8192;
C$.defaultExpectedLineLength=80;
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io;
/*c*/var C$=Clazz_newClass(P$, "ByteArrayInputStream", null, 'java.io.InputStream');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['pos','mark','count'],'O',['buf','byte[]']]]

Clazz_newMeth(C$, 'c$$BA',  function (buf) {
Clazz_super_(C$, this);
this.mark=0;
this.buf=buf;
this.count=buf.length;
}, 1);

Clazz_newMeth(C$, 'c$$BA$I$I',  function (buf, offset, length) {
Clazz_super_(C$, this);
this.buf=buf;
this.pos=offset >= buf.length ? buf.length : offset;
this.mark=this.pos;
this.count=length + this.pos > buf.length ? buf.length : length + this.pos;
}, 1);

Clazz_newMeth(C$, 'available$',  function () {
return this.count - this.pos;
});

Clazz_newMeth(C$, 'close$',  function () {
});

Clazz_newMeth(C$, 'mark$I',  function (readlimit) {
this.mark=this.pos;
});

Clazz_newMeth(C$, 'markSupported$',  function () {
return true;
});

Clazz_newMeth(C$, 'read$',  function () {
return this.pos < this.count ? this.buf[this.pos++] & 255 : -1;
});

Clazz_newMeth(C$, 'read$BA$I$I',  function (b, offset, length) {
if (this.pos >= this.count) {
return -1;
}if (b != null ) {
if (0 <= offset && offset <= b.length  && 0 <= length  && length <= b.length - offset ) {
if (length == 0) {
return 0;
}var copylen=this.count - this.pos < length ? this.count - this.pos : length;
System.arraycopy$O$I$O$I$I(this.buf, this.pos, b, offset, copylen);
this.pos+=copylen;
return copylen;
}throw Clazz_new_(Clazz_load('ArrayIndexOutOfBoundsException'));
}throw Clazz_new_(Clazz_load('NullPointerException'));
});

Clazz_newMeth(C$, 'reset$',  function () {
this.pos=this.mark;
});

Clazz_newMeth(C$, 'skip$J',  function (n) {
if (Long.$le(n,0 )) {
return 0;
}var temp=this.pos;
this.pos=Long.$lt(this.count - this.pos,n ) ? this.count : Long.$ival((Long.$add(this.pos,n)));
return this.pos - temp;
});

Clazz_newMeth(C$, 'transferTo$java_io_OutputStream',  function (out) {
var b=(this.pos == 0 ? this.buf : this.readAllBytes$());
out.write$BA(b);
return b.length;
});

Clazz_newMeth(C$, 'readAllBytes$',  function () {
return (this.pos == 0 ? this.buf : C$.superclazz.prototype.readAllBytes$.apply(this, []));
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={},I$=[[0,'java.util.Arrays','OutOfMemoryError']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ByteArrayOutputStream", null, 'java.io.OutputStream');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['count'],'O',['buf','byte[]']]]

Clazz_newMeth(C$, '秘setBytes$BA',  function (b) {
this.buf=b;
this.count=b.length;
return true;
});

Clazz_newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [32]);
}, 1);

Clazz_newMeth(C$, 'c$$I',  function (size) {
Clazz_super_(C$, this);
if (size < 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Negative initial size: " + size]);
}this.buf=Clazz_array(Byte.TYPE, [size]);
}, 1);

Clazz_newMeth(C$, 'ensureCapacity$I',  function (minCapacity) {
if (minCapacity - this.buf.length > 0) p$1.grow$I.apply(this, [minCapacity]);
}, p$1);

Clazz_newMeth(C$, 'grow$I',  function (minCapacity) {
var oldCapacity=this.buf.length;
var newCapacity=oldCapacity << 1;
if (newCapacity - minCapacity < 0) newCapacity=minCapacity;
if (newCapacity - 2147483639 > 0) newCapacity=C$.hugeCapacity$I(minCapacity);
this.buf=$I$(1).copyOf$BA$I(this.buf, newCapacity);
}, p$1);

Clazz_newMeth(C$, 'hugeCapacity$I',  function (minCapacity) {
if (minCapacity < 0) throw Clazz_new_($I$(2,1));
return (minCapacity > 2147483639) ? 2147483647 : 2147483639;
}, 1);

Clazz_newMeth(C$, 'write$I',  function (b) {
p$1.ensureCapacity$I.apply(this, [this.count + 1]);
this.buf[this.count]=(b|0);
this.count+=1;
});

Clazz_newMeth(C$, 'write$BA$I$I',  function (b, off, len) {
if ((off < 0) || (off > b.length) || (len < 0) || ((off + len) - b.length > 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
}p$1.ensureCapacity$I.apply(this, [this.count + len]);
System.arraycopy$O$I$O$I$I(b, off, this.buf, this.count, len);
this.count+=len;
});

Clazz_newMeth(C$, 'writeTo$java_io_OutputStream',  function (out) {
out.write$BA$I$I(this.buf, 0, this.count);
});

Clazz_newMeth(C$, 'reset$',  function () {
this.count=0;
});

Clazz_newMeth(C$, 'toByteArray$',  function () {
return (this.count == this.buf.length ? this.buf : $I$(1).copyOf$BA$I(this.buf, this.count));
});

Clazz_newMeth(C$, 'size$',  function () {
return this.count;
});

Clazz_newMeth(C$, 'toString',  function () {
return  String.instantialize(this.buf, 0, this.count);
});

Clazz_newMeth(C$, 'toString$S',  function (charsetName) {
return  String.instantialize(this.buf, 0, this.count, charsetName);
});

Clazz_newMeth(C$, 'toString$java_nio_charset_Charset',  function (charset) {
return  String.instantialize(this.buf, 0, this.count, charset);
});

Clazz_newMeth(C$, 'toString$I',  function (hibyte) {
return  String.instantialize(this.buf, hibyte, 0, this.count);
});

Clazz_newMeth(C$, 'close$',  function () {
});

Clazz_newMeth(C$, 'hashCode$',  function () {
return this.buf.hashCode$();
});
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "Closeable", null, null, 'AutoCloseable');

C$.$clinit$=2;
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={},I$=[[0,'java.io.FileSystem','java.net.URL','java.net.URI','Error','java.util.ArrayList','java.util.Random','java.nio.file.FileSystems']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "File", null, null, 'Comparable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['秘isTempFile'],'I',['prefixLength'],'J',['lastModified'],'S',['path'],'O',['秘bytes','byte[]','filePath','java.nio.file.Path']]
,['C',['separatorChar'],'S',['separator','temporaryDirectory'],'O',['fs','java.io.FileSystem']]]

Clazz_newMeth(C$, 'getPrefixLength$',  function () {
return this.prefixLength;
});

Clazz_newMeth(C$, 'c$$S',  function (pathname) {
C$.c$$S$S.apply(this, ["", pathname]);
}, 1);

Clazz_newMeth(C$, 'c$$S$S',  function (parent, child) {
;C$.$init$.apply(this);
if (child == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}if (parent != null ) {
if (parent.equals$O("") && !child.startsWith$S("/") ) {
this.path=p$1.resolve$S$S.apply(this, [".", C$.fs.normalize$S(child)]);
} else {
this.path=p$1.resolve$S$S.apply(this, [C$.fs.normalize$S(parent), C$.fs.normalize$S(child)]);
}} else {
this.path=p$1.resolve$S$S.apply(this, [".", C$.fs.normalize$S(child)]);
}this.prefixLength=this.path.lastIndexOf$S("/") + 1;
}, 1);

Clazz_newMeth(C$, 'c$$java_io_File$S',  function (parent, child) {
C$.c$$S$S.apply(this, [parent == null  ? null : parent.getPath$(), child]);
}, 1);

Clazz_newMeth(C$, 'c$$java_net_URI',  function (uri) {
;C$.$init$.apply(this);
var err=null;
var scheme;
var p;
if (!uri.isAbsolute$()) err=("URI is not absolute");
 else if (uri.isOpaque$()) err=("URI is not hierarchical");
 else if (((scheme=uri.getScheme$()) == null ) || !scheme.equalsIgnoreCase$S("file") ) err=("URI scheme is not \"file\"");
 else if (uri.getAuthority$() != null ) err=("URI has an authority component");
 else if (uri.getFragment$() != null ) err=("URI has a fragment component");
 else if (uri.getQuery$() != null ) err=("URI has a query component");
 else if ((p=uri.getPath$()).equals$O("")) err=("URI path component is empty");
 else {
p=C$.fs.fromURIPath$S(p);
this.path=(p);
this.prefixLength=C$.fs.prefixLength$S(this.path);
this.秘bytes=uri.秘bytes;
return;
}throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,[err]);
}, 1);

Clazz_newMeth(C$, 'c$$S$I',  function (pathname, prefixLength) {
;C$.$init$.apply(this);
this.path=pathname;
this.prefixLength=prefixLength;
}, 1);

Clazz_newMeth(C$, 'c$$S$java_io_File',  function (child, parent) {
;C$.$init$.apply(this);
this.path=p$1.resolve$S$S.apply(this, [parent.path, child]);
this.prefixLength=parent.prefixLength;
}, 1);

Clazz_newMeth(C$, 'resolve$S$S',  function (path, child) {
if (path === "."  && child.startsWith$S("./") ) return child;
if (child.length$() > 0 && !child.startsWith$S("/")  && !path.endsWith$S("/") ) path+="/";
path=path + child;
this.秘isTempFile=path.startsWith$S(C$.temporaryDirectory);
return path;
}, p$1);

Clazz_newMeth(C$, 'getName$',  function () {
var index=this.path.lastIndexOf$I(C$.separatorChar);
if (index < this.prefixLength) return this.path.substring$I(this.prefixLength);
return this.path.substring$I(index + 1);
});

Clazz_newMeth(C$, 'getParent$',  function () {
var index=this.path.lastIndexOf$I(C$.separatorChar);
if (index < this.prefixLength) {
if ((this.prefixLength > 0) && (this.path.length$() > this.prefixLength) ) return this.path.substring$I$I(0, this.prefixLength);
return null;
}return this.path.substring$I$I(0, index);
});

Clazz_newMeth(C$, 'getParentFile$',  function () {
var p=this.getParent$();
if (p == null ) return null;
return Clazz_new_(C$.c$$S$I,[p, this.prefixLength]);
});

Clazz_newMeth(C$, 'getPath$',  function () {
return this.path;
});

Clazz_newMeth(C$, 'isAbsolute$',  function () {
switch (this.path.indexOf$S("/")) {
case 0:
return true;
case 2:
return this.path.indexOf$S(":") == 1;
}
return false;
});

Clazz_newMeth(C$, 'getAbsolutePath$',  function () {
return C$.fs.resolve$java_io_File(this);
});

Clazz_newMeth(C$, 'getAbsoluteFile$',  function () {
var absPath=this.getAbsolutePath$();
return Clazz_new_(C$.c$$S$I,[absPath, C$.fs.prefixLength$S(absPath)]);
});

Clazz_newMeth(C$, 'getCanonicalPath$',  function () {
return this.path.replaceAll$S$S("\\\\", "/");
});

Clazz_newMeth(C$, 'getCanonicalFile$',  function () {
return this;
});

Clazz_newMeth(C$, 'slashify$S$Z',  function (path, isDirectory) {
var p=path;
p=p.replaceAll$S$S("\\\\", "/");
if (!p.startsWith$S("/")) p="/" + p;
if (!p.endsWith$S("/") && isDirectory ) p=p + "/";
return p;
}, 1);

Clazz_newMeth(C$, 'toURL$',  function () {
return Clazz_new_(["file", "", C$.slashify$S$Z(this.getAbsolutePath$(), false)],$I$(2,1).c$$S$S$S);
});

Clazz_newMeth(C$, 'toURI$',  function () {
try {
var sp=C$.slashify$S$Z(this.getAbsoluteFile$().getPath$(), false);
if (sp.startsWith$S("//")) sp="file:" + sp;
var uri=Clazz_new_($I$(3,1).c$$S$S$S$S,["file", null, sp, null]);
uri.秘bytes=this.秘bytes;
return uri;
} catch (x) {
if (Clazz_exceptionOf(x,"java.net.URISyntaxException")){
throw Clazz_new_($I$(4,1).c$$Throwable,[x]);
} else {
throw x;
}
}
});

Clazz_newMeth(C$, 'canRead$',  function () {
return true;
});

Clazz_newMeth(C$, 'canWrite$',  function () {
return true;
});

Clazz_newMeth(C$, 'exists$',  function () {
return this.path.indexOf$S("!/") < 0 && (C$.fs._exists$java_io_File(this) || C$.fs._isDir$java_io_File(this) ) ;
});

Clazz_newMeth(C$, 'isDirectory$',  function () {
return this.path.indexOf$S("!/") < 0 && C$.fs._isDir$java_io_File(this) ;
});

Clazz_newMeth(C$, 'isFile$',  function () {
return true;
});

Clazz_newMeth(C$, 'isHidden$',  function () {
return false;
});

Clazz_newMeth(C$, 'length$',  function () {
return C$.fs.getLength$java_io_File(this);
});

Clazz_newMeth(C$, 'createNewFile$',  function () {
return true;
});

Clazz_newMeth(C$, 'delete$',  function () {
return C$.fs.delete$java_io_File(this);
});

Clazz_newMeth(C$, 'deleteOnExit$',  function () {
});

Clazz_newMeth(C$, 'list$',  function () {
if (C$.fs == null ) throw Clazz_new_(Clazz_load('java.security.AccessControlException').c$$S,["access denied"]);
return C$.fs.list$java_io_File(this);
});

Clazz_newMeth(C$, 'list$java_io_FilenameFilter',  function (filter) {
var names=this.list$();
if ((names == null ) || (filter == null ) ) {
return names;
}var v=Clazz_new_($I$(5,1));
for (var i=0; i < names.length; i++) {
if (filter.accept$java_io_File$S(this, names[i])) {
v.add$O(names[i]);
}}
return (v.toArray$OA(Clazz_array(String, [v.size$()])));
});

Clazz_newMeth(C$, 'listFiles$',  function () {
var ss=this.list$();
if (ss == null ) return null;
var n=ss.length;
var fs=Clazz_array(C$, [n]);
for (var i=0; i < n; i++) {
fs[i]=Clazz_new_(C$.c$$S$java_io_File,[ss[i], this]);
}
return fs;
});

Clazz_newMeth(C$, 'listFiles$java_io_FilenameFilter',  function (filter) {
var ss=this.list$();
if (ss == null ) return null;
var files=Clazz_new_($I$(5,1));
for (var s, $s = 0, $$s = ss; $s<$$s.length&&((s=($$s[$s])),1);$s++) if ((filter == null ) || filter.accept$java_io_File$S(this, s) ) files.add$O(Clazz_new_(C$.c$$S$java_io_File,[s, this]));

return files.toArray$OA(Clazz_array(C$, [files.size$()]));
});

Clazz_newMeth(C$, 'listFiles$java_io_FileFilter',  function (filter) {
var ss=this.list$();
if (ss == null ) return null;
var files=Clazz_new_($I$(5,1));
for (var s, $s = 0, $$s = ss; $s<$$s.length&&((s=($$s[$s])),1);$s++) {
var f=Clazz_new_(C$.c$$S$java_io_File,[s, this]);
if ((filter == null ) || filter.accept$java_io_File(f) ) files.add$O(f);
}
return files.toArray$OA(Clazz_array(C$, [files.size$()]));
});

Clazz_newMeth(C$, 'mkdir$',  function () {
return true;
});

Clazz_newMeth(C$, 'mkdirs$',  function () {
return true;
});

Clazz_newMeth(C$, 'renameTo$java_io_File',  function (dest) {
this.path=dest.path;
return true;
});

Clazz_newMeth(C$, 'setLastModified$J',  function (time) {
this.lastModified=time;
return true;
});

Clazz_newMeth(C$, 'setReadOnly$',  function () {
return true;
});

Clazz_newMeth(C$, 'setWritable$Z$Z',  function (writable, ownerOnly) {
return true;
});

Clazz_newMeth(C$, 'setWritable$Z',  function (writable) {
return this.setWritable$Z$Z(writable, true);
});

Clazz_newMeth(C$, 'setReadable$Z$Z',  function (readable, ownerOnly) {
return true;
});

Clazz_newMeth(C$, 'setReadable$Z',  function (readable) {
return true;
});

Clazz_newMeth(C$, 'setExecutable$Z$Z',  function (executable, ownerOnly) {
return false;
});

Clazz_newMeth(C$, 'setExecutable$Z',  function (executable) {
return false;
});

Clazz_newMeth(C$, 'canExecute$',  function () {
return false;
});

Clazz_newMeth(C$, 'generateFile$S$S$java_io_File',  function (prefix, suffix, dir) {
var n=Clazz_new_($I$(6,1)).nextInt$();
if (Long.$eq(n,[0,549755813888,-1] )) {
n=0;
} else {
n=Math.abs$J(n);
}var f=Clazz_new_(C$.c$$java_io_File$S,[dir, prefix + Long.toString$J(n) + suffix ]);
f.秘isTempFile=true;
return f;
}, 1);

Clazz_newMeth(C$, 'createTempFile0$S$S$java_io_File$Z',  function (prefix, suffix, directory, restrictive) {
if (prefix == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
if (prefix.length$() < 3) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Prefix string too short"]);
var s=(suffix == null ) ? ".tmp" : suffix;
directory=Clazz_new_(C$.c$$S,[C$.temporaryDirectory + (directory == null  ? "" : directory)]);
return C$.generateFile$S$S$java_io_File(prefix, s, directory);
}, 1);

Clazz_newMeth(C$, 'createTempFile$S$S$java_io_File',  function (prefix, suffix, directory) {
return C$.createTempFile0$S$S$java_io_File$Z(prefix, suffix, directory, false);
}, 1);

Clazz_newMeth(C$, 'createTempFile$S$S',  function (prefix, suffix) {
return C$.createTempFile0$S$S$java_io_File$Z(prefix, suffix, null, false);
}, 1);

Clazz_newMeth(C$, ['compareTo$java_io_File','compareTo$O'],  function (pathname) {
return this.getPath$().compareTo$S(pathname.getPath$());
});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if ((obj != null ) && (Clazz_instanceOf(obj, "java.io.File")) ) {
return this.compareTo$java_io_File(obj) == 0;
}return false;
});

Clazz_newMeth(C$, 'hashCode$',  function () {
try {
return this.getCanonicalPath$().hashCode$() | 1234321;
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
return 0;
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'toString',  function () {
return this.getPath$();
});

Clazz_newMeth(C$, 'toPath$',  function () {
var result=this.filePath;
if (result == null ) {
{
result=this.filePath;
if (result == null ) {
result=$I$(7).getDefault$().getPath$S$SA(this.path, Clazz_array(String, -1, []));
(result).set$BA$java_io_File(this.秘bytes, this);
this.filePath=result;
}}}return result;
});

Clazz_newMeth(C$, 'lastModified$',  function () {
return this.lastModified;
});

C$.$static$=function(){C$.$static$=0;
C$.fs=$I$(1).getFileSystem$();
C$.separatorChar=C$.fs.getSeparator$();
C$.separator="" + C$.separatorChar;
C$.temporaryDirectory=System.getProperty$S("java.io.tmpdir");
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[[0,'java.util.Arrays','java.util.concurrent.atomic.AtomicInteger','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "FileDescriptor");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.len=-1;
this.fd=-1;
this.handle=-1;
},1);

C$.$fields$=[['Z',['isTempFile','closed'],'I',['pos','len','fd'],'J',['handle'],'O',['_file','java.io.File','useCount','java.util.concurrent.atomic.AtomicInteger','parent','java.io.Closeable','otherParents','java.util.List']]
,['O',['$in','java.io.FileDescriptor','+out','+err']]]

Clazz_newMeth(C$, '_getBytes$Z',  function (checkDisk) {
if (this._file.秘bytes == null  && checkDisk ) {
this._file.exists$();
}return this._file.秘bytes;
});

Clazz_newMeth(C$, '_setPosAndLen$I$I',  function (pos, len) {
this.pos=pos;
this.len=len;
if (this._file.秘bytes == null ) this._file.秘bytes=Clazz_array(Byte.TYPE, [len]);
 else if (len > this._file.秘bytes.length) this._file.秘bytes=$I$(1).copyOf$BA$I(this._file.秘bytes, len);
});

Clazz_newMeth(C$, '_getPos$',  function () {
return this.pos;
});

Clazz_newMeth(C$, '_getLen$',  function () {
return this.len;
});

Clazz_newMeth(C$, '_isTempFile$',  function () {
return this.isTempFile;
});

Clazz_newMeth(C$, '_setTempFile$Z',  function (b) {
this.isTempFile=b;
});

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.useCount=Clazz_new_($I$(2,1));
}, 1);

Clazz_newMeth(C$, 'c$$I',  function (fd) {
;C$.$init$.apply(this);
this.fd=fd;
this.useCount=Clazz_new_($I$(2,1));
}, 1);

Clazz_newMeth(C$, 'set$java_io_FileDescriptor$I',  function (obj, fd) {
obj.fd=fd;
});

Clazz_newMeth(C$, 'get$java_io_FileDescriptor',  function (obj) {
return obj.fd;
});

Clazz_newMeth(C$, 'setHandle$java_io_FileDescriptor$J',  function (obj, handle) {
obj.handle=handle;
});

Clazz_newMeth(C$, 'getHandle$java_io_FileDescriptor',  function (obj) {
return obj.handle;
});

Clazz_newMeth(C$, 'valid$',  function () {
return this.fd != -1;
});

Clazz_newMeth(C$, 'sync$',  function () {
});

Clazz_newMeth(C$, 'incrementAndGetUseCount$',  function () {
return this.useCount.incrementAndGet$();
});

Clazz_newMeth(C$, 'decrementAndGetUseCount$',  function () {
return this.useCount.decrementAndGet$();
});

Clazz_newMeth(C$, 'attach$java_io_Closeable',  function (c) {
this._file=(c._file ||null);
this.isTempFile=this._file != null  && this._file.秘isTempFile ;
if (this.parent == null ) {
this.parent=c;
} else if (this.otherParents == null ) {
this.otherParents=Clazz_new_($I$(3,1));
this.otherParents.add$O(this.parent);
this.otherParents.add$O(c);
} else {
this.otherParents.add$O(c);
}});

Clazz_newMeth(C$, 'closeAll$java_io_Closeable',  function (releaser) {
if (!this.closed) {
this.closed=true;
var ioe=null;
try {
var c=releaser;
try {
if (this.otherParents != null ) {
for (var referent, $referent = this.otherParents.iterator$(); $referent.hasNext$()&&((referent=($referent.next$())),1);) {
try {
referent.close$();
} catch (x) {
if (Clazz_exceptionOf(x,"java.io.IOException")){
if (ioe == null ) {
ioe=x;
} else {
}} else {
throw x;
}
}
}
}
}finally{/*res*/c&&c.close$&&c.close$();}
} catch (ex) {
if (Clazz_exceptionOf(ex,"java.io.IOException")){
ioe=ex;
} else {
throw ex;
}
} finally {
if (ioe != null ) throw ioe;
}
}});

C$.$static$=function(){C$.$static$=0;
C$.$in=Clazz_new_(C$.c$$I,[0]);
C$.out=Clazz_new_(C$.c$$I,[1]);
C$.err=Clazz_new_(C$.c$$I,[2]);
};
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={},I$=[[0,'java.io.File','java.io.FileDescriptor','swingjs.JSUtil','java.io.ByteArrayInputStream',['swingjs.JSFileSystem','.JSFileChannel']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "FileInputStream", null, 'java.io.InputStream');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.channel=null;
this.closed=false;
},1);

C$.$fields$=[['Z',['closed'],'S',['path'],'O',['fd','java.io.FileDescriptor','秘is','java.io.ByteArrayInputStream','channel','swingjs.JSFileSystem.JSFileChannel','_file','java.io.File']]]

Clazz_newMeth(C$, 'c$$S',  function (name) {
C$.c$$java_io_File.apply(this, [(name == null  ? null : Clazz_new_($I$(1,1).c$$S,[name]))]);
}, 1);

Clazz_newMeth(C$, 'c$$java_io_File',  function (file) {
Clazz_super_(C$, this);
var name=(file != null  ? file.getPath$() : null);
if (name == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}this.fd=Clazz_new_($I$(2,1));
this._file=file;
this.fd.attach$java_io_Closeable(this);
this.path=name;
p$1.open$java_io_File.apply(this, [file]);
}, 1);

Clazz_newMeth(C$, 'c$$java_io_FileDescriptor',  function (fdObj) {
Clazz_super_(C$, this);
var security=System.getSecurityManager$();
if (fdObj == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}if (security != null ) {
security.checkRead$java_io_FileDescriptor(fdObj);
}this.fd=fdObj;
this.path=null;
this.fd.attach$java_io_Closeable(this);
}, 1);

Clazz_newMeth(C$, 'open$java_io_File',  function (file) {
var bytes=$I$(3).getFileAsBytes$O(file);
if (bytes == null ) throw Clazz_new_(Clazz_load('java.io.FileNotFoundException').c$$S,["Opening file " + file]);
file.秘bytes=bytes;
this.秘is=Clazz_new_($I$(4,1).c$$BA,[bytes]);
}, p$1);

Clazz_newMeth(C$, 'read$',  function () {
return (this.channel == null  ? this.秘is.read$() : this.channel.read$());
});

Clazz_newMeth(C$, 'readBytes$BA$I$I',  function (b, off, len) {
return this.channel == null  ? this.秘is.read$BA$I$I(b, off, len) : this.channel.readBytes$BA$I$I(b, off, len);
}, p$1);

Clazz_newMeth(C$, 'read$BA',  function (b) {
return p$1.readBytes$BA$I$I.apply(this, [b, 0, b.length]);
});

Clazz_newMeth(C$, 'read$BA$I$I',  function (b, off, len) {
return p$1.readBytes$BA$I$I.apply(this, [b, off, len]);
});

Clazz_newMeth(C$, 'skip$J',  function (n) {
return this.channel == null  ? this.秘is.skip$J(n) : this.channel.skip$J(n);
});

Clazz_newMeth(C$, 'available$',  function () {
return this.channel == null  ? this.秘is.available$() : this.channel.available$();
});

Clazz_newMeth(C$, 'close$',  function () {
if (this.closed) {
return;
}this.closed=true;
this.fd.closeAll$java_io_Closeable(((P$.FileInputStream$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "FileInputStream$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.io.Closeable', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'close$',  function () {
if (this.b$['java.io.FileInputStream'].channel == null ) {
this.b$['java.io.FileInputStream'].秘is.close$();
} else {
this.b$['java.io.FileInputStream'].channel.close$();
}});
})()
), Clazz_new_(P$.FileInputStream$1.$init$,[this, null])));
});

Clazz_newMeth(C$, 'getFD$',  function () {
if (this.fd != null ) {
return this.fd;
}throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'getChannel$',  function () {
{
if (this.channel == null ) {
try {
this.fd._setPosAndLen$I$I(this.秘is.pos, this.秘is.pos + this.秘is.available$());
this.channel=$I$(5).open$java_io_FileDescriptor$S$Z$Z$O(this.fd, this.path, true, false, this);
this.秘is=null;
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
}return this.channel;
}});

Clazz_newMeth(C$, 'finalize$',  function () {
if ((this.fd != null ) && (this.fd !== $I$(2).$in ) ) {
this.close$();
}});

Clazz_newMeth(C$, 'transferTo$java_io_OutputStream',  function (out) {
if (this.channel != null ) {
return C$.superclazz.prototype.transferTo$java_io_OutputStream.apply(this, [out]);
}var b=(this.秘is.pos == 0 ? this.秘is.buf : this.秘is.readAllBytes$());
out.write$BA(b);
return b.length;
});

Clazz_newMeth(C$, 'readAllBytes$',  function () {
if (this.channel != null ) C$.superclazz.prototype.readAllBytes$.apply(this, []);
if (this.秘is.pos == 0) return this.秘is.buf;
var b=Clazz_array(Byte.TYPE, [this.available$()]);
this.read$BA$I$I(b, 0, b.length);
return b;
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={},I$=[[0,'swingjs.JSUtil']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "FileSystem");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getFileSystem$',  function () {
return Clazz_new_(C$);
}, 1);

Clazz_newMeth(C$, 'getSeparator$',  function () {
return "/";
});

Clazz_newMeth(C$, 'getPathSeparator$',  function () {
return "/";
});

Clazz_newMeth(C$, 'delete$java_io_File',  function (f) {
f.秘bytes=null;
$I$(1,"removeCachedFileData$S",[f.toPath$().toString()]);
return true;
});

Clazz_newMeth(C$, 'list$java_io_File',  function (f) {
return $I$(1).getCachedFileList$java_io_File(f);
});

Clazz_newMeth(C$, 'getBooleanAttributes$java_io_File',  function (file) {
return (this._isDir$java_io_File(file) ? 4 : 0) | (this._exists$java_io_File(file) ? 1 : 0) | (p$1._regular$java_io_File.apply(this, [file]) ? 2 : 0) | (p$1._hidden$java_io_File.apply(this, [file]) ? 8 : 0) ;
});

Clazz_newMeth(C$, '_hidden$java_io_File',  function (file) {
return false;
}, p$1);

Clazz_newMeth(C$, '_regular$java_io_File',  function (file) {
return p$1._isValid$java_io_File.apply(this, [file]) && !this._isDir$java_io_File(file) ;
}, p$1);

Clazz_newMeth(C$, '_isValid$java_io_File',  function (file) {
return file.toString().indexOf$S(":") < 0;
}, p$1);

Clazz_newMeth(C$, '_exists$java_io_File',  function (file) {
return p$1._isValid$java_io_File.apply(this, [file]) && (file.秘bytes != null  || file.getPrefixLength$() == file.path.length$()  || file.秘isTempFile  ? (file.秘bytes=C$._getTempFileBytes$java_io_File(file)) != null  : (file.秘bytes=$I$(1).getFileAsBytes$O(file)) != null ) ;
});

Clazz_newMeth(C$, '_getTempFileBytes$java_io_File',  function (file) {
return $I$(1).getCachedFileData$S$Z(file.path, true);
}, 1);

Clazz_newMeth(C$, '_isDir$java_io_File',  function (file) {
return (file.秘bytes == null  && p$1._isValid$java_io_File.apply(this, [file])  && file.getPrefixLength$() == file.path.length$() );
});

Clazz_newMeth(C$, 'prefixLength$S',  function (path) {
return path.lastIndexOf$S("/") + 1;
});

Clazz_newMeth(C$, 'resolve$java_io_File',  function (file) {
return file.path;
});

Clazz_newMeth(C$, 'getDefaultParent$',  function () {
return "/";
});

Clazz_newMeth(C$, 'fromURIPath$S',  function (path) {
if (path.startsWith$S("file://")) path=path.substring$I(7);
return path;
});

Clazz_newMeth(C$, 'isAbsolute$java_io_File',  function (f) {
return f.getAbsolutePath$() == f.path;
});

Clazz_newMeth(C$, 'normalize$S',  function (path) {
return path.replaceAll$S$S("\\\\", "/");
});

Clazz_newMeth(C$, 'getLength$java_io_File',  function (file) {
return (this._exists$java_io_File(file) && file.秘bytes != null   ? file.秘bytes.length : 0);
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[[0,'java.io.PushbackInputStream']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "InputStream", null, null, 'java.io.Closeable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['skipBuf','byte[]']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'available$',  function () {
return 0;
});

Clazz_newMeth(C$, 'close$',  function () {
});

Clazz_newMeth(C$, 'mark$I',  function (readlimit) {
});

Clazz_newMeth(C$, 'markSupported$',  function () {
return false;
});

Clazz_newMeth(C$, 'read$BA',  function (b) {
return this.read$BA$I$I(b, 0, b.length);
});

Clazz_newMeth(C$, 'read$BA$I$I',  function (b, offset, length) {
if (offset <= b.length && 0 <= offset  && 0 <= length  && length <= b.length - offset ) {
for (var i=0; i < length; i++) {
var c;
try {
if ((c=this.read$()) == -1) return i == 0 ? -1 : i;
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
if (i != 0) return i;
throw e;
} else {
throw e;
}
}
b[offset + i]=(c|0);
}
return length;
}throw Clazz_new_(Clazz_load('ArrayIndexOutOfBoundsException'));
});

Clazz_newMeth(C$, 'reset$',  function () {
throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'skip$J',  function (n) {
if (Long.$le(n,0 )) return 0;
var skipped=0;
var toRead=Long.$lt(n,4096 ) ? Long.$ival(n) : 4096;
if (C$.skipBuf == null  || C$.skipBuf.length < toRead ) C$.skipBuf=Clazz_array(Byte.TYPE, [toRead]);
while (Long.$lt(skipped,n )){
var read=this.read$BA$I$I(C$.skipBuf, 0, toRead);
if (read == -1) return skipped;
(skipped=Long.$add(skipped,(read)));
if (read < toRead) return skipped;
if (Long.$lt(Long.$sub(n,skipped),toRead )) toRead=Long.$ival((Long.$sub(n,skipped)));
}
return skipped;
});

Clazz_newMeth(C$, 'transferTo$java_io_OutputStream',  function (out) {
var n=this.available$();
out.write$BA(this.readAllBytes$());
return n;
});

Clazz_newMeth(C$, 'readAllBytes$',  function () {
var b=Clazz_array(Byte.TYPE, [this.available$()]);
this.read$BA$I$I(b, 0, b.length);
return b;
});

Clazz_newMeth(C$, '秘getByteStream$java_io_InputStream$I',  function (ins, pt) {
var newIn=ins;
var isRoot=(pt < 0);
var asPushback=(pt == -2);
if (isRoot) pt=0;
switch (ins.__CLASS_NAME__||"") {
case "java.io.ByteArrayInputStream":
var bis=ins;
bis.pos-=pt;
break;
case "java.io.FileInputStream":
newIn=(ins).秘is;
break;
case "java.io.BufferedInputStream":
pt+=(ins).count - (ins).pos;
newIn=(ins).$in;
break;
default:
newIn=null;
}
if (newIn != null  && newIn !== ins  ) newIn=C$.秘getByteStream$java_io_InputStream$I(newIn, pt);
ins=(newIn != null  ? newIn : isRoot ? ins : null);
return (!isRoot ? ins : newIn != null  ? newIn : asPushback ? Clazz_new_($I$(1,1).c$$java_io_InputStream$I,[ins, 1024]) : null);
}, 1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:00 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[];
/*c*/var C$=Clazz_newClass(P$, "OutputStream", null, null, ['java.io.Closeable', 'java.io.Flushable']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'write$BA',  function (b) {
this.write$BA$I$I(b, 0, b.length);
});

Clazz_newMeth(C$, 'write$BA$I$I',  function (b, off, len) {
if (b == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
} else if ((off < 0) || (off > b.length) || (len < 0) || ((off + len) > b.length) || ((off + len) < 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
} else if (len == 0) {
return;
}for (var i=0; i < len; i++) {
this.write$I(b[off + i]);
}
});

Clazz_newMeth(C$, 'flush$',  function () {
});

Clazz_newMeth(C$, 'close$',  function () {
});

Clazz_newMeth(C$, '秘setBytes$BA',  function (b) {
try {
this.write$BA$I$I(b, 0, b.length);
return true;
} catch (e) {
if (Clazz_exceptionOf(e,"java.io.IOException")){
return false;
} else {
throw e;
}
}
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:01 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,I$=[[0,'java.util.Objects']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Reader", null, null, ['Readable', 'java.io.Closeable']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['lock','java.lang.Object']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.lock=this;
}, 1);

Clazz_newMeth(C$, 'c$$O',  function (lock) {
;C$.$init$.apply(this);
if (lock != null ) this.lock="";
 else throw Clazz_new_(Clazz_load('NullPointerException'));
}, 1);

Clazz_newMeth(C$, 'transferTo$java_io_Writer',  function (out) {
$I$(1).requireNonNull$O$S(out, "out");
var transferred=0;
var buffer=Clazz_array(Character.TYPE, [8192]);
var nRead;
while ((nRead=this.read$CA$I$I(buffer, 0, 8192)) >= 0){
out.write$CA$I$I(buffer, 0, nRead);
(transferred=Long.$add(transferred,(nRead)));
}
return transferred;
});

Clazz_newMeth(C$, 'mark$I',  function (readLimit) {
throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'markSupported$',  function () {
return false;
});

Clazz_newMeth(C$, 'read$',  function () {
{
var charArray=Clazz_array(Character.TYPE, [1]);
if (this.read$CA$I$I(charArray, 0, 1) != -1) return charArray[0].$c();
return -1;
}});

Clazz_newMeth(C$, 'read$CA',  function (buf) {
return this.read$CA$I$I(buf, 0, buf.length);
});

Clazz_newMeth(C$, 'ready$',  function () {
return false;
});

Clazz_newMeth(C$, 'reset$',  function () {
throw Clazz_new_(Clazz_load('java.io.IOException'));
});

Clazz_newMeth(C$, 'skip$J',  function (count) {
if (Long.$ge(count,0 )) {
{
var skipped=0;
var toRead=Long.$lt(count,512 ) ? Long.$ival(count) : 512;
var charsSkipped=Clazz_array(Character.TYPE, [toRead]);
while (Long.$lt(skipped,count )){
var read=this.read$CA$I$I(charsSkipped, 0, toRead);
if (read == -1) {
return skipped;
}(skipped=Long.$add(skipped,(read)));
if (read < toRead) {
return skipped;
}if (Long.$lt(Long.$sub(count,skipped),toRead )) {
toRead=Long.$ival((Long.$sub(count,skipped)));
}}
return skipped;
}}throw Clazz_new_(Clazz_load('IllegalArgumentException'));
});

Clazz_newMeth(C$, 'read$java_nio_CharBuffer',  function (target) {
if (null == target ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}var length=target.length$();
var buf=Clazz_array(Character.TYPE, [length]);
length=Math.min(length, this.read$CA(buf));
if (length > 0) {
target.put$CA$I$I(buf, 0, length);
}return length;
});
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:01 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.io,p$1={};
/*c*/var C$=Clazz_newClass(P$, "StringReader", null, 'java.io.Reader');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.next=0;
this.mark=0;
},1);

C$.$fields$=[['I',['length','next','mark'],'S',['str']]]

Clazz_newMeth(C$, 'c$$S',  function (s) {
Clazz_super_(C$, this);
this.str=s;
this.length=s.length$();
}, 1);

Clazz_newMeth(C$, 'ensureOpen',  function () {
if (this.str == null ) throw Clazz_new_(Clazz_load('java.io.IOException').c$$S,["Stream closed"]);
}, p$1);

Clazz_newMeth(C$, 'read$',  function () {
{
p$1.ensureOpen.apply(this, []);
if (this.next >= this.length) return -1;
return this.str.charAt$I(this.next++).$c();
}});

Clazz_newMeth(C$, 'read$CA$I$I',  function (cbuf, off, len) {
{
p$1.ensureOpen.apply(this, []);
if ((off < 0) || (off > cbuf.length) || (len < 0) || ((off + len) > cbuf.length) || ((off + len) < 0)  ) {
throw Clazz_new_(Clazz_load('IndexOutOfBoundsException'));
} else if (len == 0) {
return 0;
}if (this.next >= this.length) return -1;
var n=Math.min(this.length - this.next, len);
this.str.getChars$I$I$CA$I(this.next, this.next + n, cbuf, off);
this.next+=n;
return n;
}});

Clazz_newMeth(C$, 'skip$J',  function (ns) {
{
p$1.ensureOpen.apply(this, []);
if (this.next >= this.length) return 0;
var n=Math.min$J$J(this.length - this.next, ns);
n=Math.max$J$J(-this.next, n);
this.next=Long.$ival(Long.$add(this.next,(n)));
return n;
}});

Clazz_newMeth(C$, 'ready$',  function () {
{
p$1.ensureOpen.apply(this, []);
return true;
}});

Clazz_newMeth(C$, 'markSupported$',  function () {
return true;
});

Clazz_newMeth(C$, 'mark$I',  function (readAheadLimit) {
if (readAheadLimit < 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Read-ahead limit < 0"]);
}{
p$1.ensureOpen.apply(this, []);
this.mark=this.next;
}});

Clazz_newMeth(C$, 'reset$',  function () {
{
p$1.ensureOpen.apply(this, []);
this.next=this.mark;
}});

Clazz_newMeth(C$, 'close$',  function () {
this.str=null;
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:01 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "AutoCloseable");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:02 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.lang,I$=[];
/*i*/var C$=Clazz_newInterface(P$, "Readable");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:03 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.math"),I$=[];
/*e*/var C$=Clazz_newClass(P$, "RoundingMode", null, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['oldMode']]]

Clazz_newMeth(C$, 'c$$I',  function (oldMode) {
;C$.$init$.apply(this);
this.oldMode=oldMode;
}, 1);

Clazz_newMeth(C$, 'valueOf$I',  function (rm) {
switch (rm) {
case 0:
return C$.UP;
case 1:
return C$.DOWN;
case 2:
return C$.CEILING;
case 3:
return C$.FLOOR;
case 4:
return C$.HALF_UP;
case 5:
return C$.HALF_DOWN;
case 6:
return C$.HALF_EVEN;
case 7:
return C$.UNNECESSARY;
default:
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["argument out of range"]);
}
}, 1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$$I, "UP", 0, [0]);
Clazz_newEnumConst($vals, C$.c$$I, "DOWN", 1, [1]);
Clazz_newEnumConst($vals, C$.c$$I, "CEILING", 2, [2]);
Clazz_newEnumConst($vals, C$.c$$I, "FLOOR", 3, [3]);
Clazz_newEnumConst($vals, C$.c$$I, "HALF_UP", 4, [4]);
Clazz_newEnumConst($vals, C$.c$$I, "HALF_DOWN", 5, [5]);
Clazz_newEnumConst($vals, C$.c$$I, "HALF_EVEN", 6, [6]);
Clazz_newEnumConst($vals, C$.c$$I, "UNNECESSARY", 7, [7]);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:05 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*i*/var C$=Clazz_newInterface(P$, "AttributedCharacterIterator", function(){
}, null, 'java.text.CharacterIterator');
C$.$classes$=[['Attribute',9]];

C$.$clinit$=2;
;
(function(){/*c*/var C$=Clazz_newClass(P$.AttributedCharacterIterator, "Attribute", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name']]
,['O',['instanceMap','java.util.Map','LANGUAGE','java.text.AttributedCharacterIterator.Attribute','+READING','+INPUT_METHOD_SEGMENT']]]

Clazz_newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.name=name;
if (this.getClass$() === Clazz_getClass(C$) ) {
C$.instanceMap.put$O$O(name, this);
}}, 1);

Clazz_newMeth(C$, 'equals$O',  function (obj) {
return C$.superclazz.prototype.equals$O.apply(this, [obj]);
});

Clazz_newMeth(C$, 'hashCode$',  function () {
return C$.superclazz.prototype.hashCode$.apply(this, []);
});

Clazz_newMeth(C$, 'toString',  function () {
return this.getClass$().getName$() + "(" + this.name + ")" ;
});

Clazz_newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz_newMeth(C$, 'readResolve$',  function () {
if (this.getClass$() !== Clazz_getClass(C$) ) {
throw Clazz_new_(Clazz_load('java.io.InvalidObjectException').c$$S,["subclass didn\'t correctly implement readResolve"]);
}var instance=C$.instanceMap.get$O(this.getName$());
if (instance != null ) {
return instance;
} else {
throw Clazz_new_(Clazz_load('java.io.InvalidObjectException').c$$S,["unknown attribute name"]);
}});

C$.$static$=function(){C$.$static$=0;
C$.instanceMap=Clazz_new_($I$(1,1).c$$I,[7]);
C$.LANGUAGE=Clazz_new_(C$.c$$S,["language"]);
C$.READING=Clazz_new_(C$.c$$S,["reading"]);
C$.INPUT_METHOD_SEGMENT=Clazz_new_(C$.c$$S,["input_method_segment"]);
};

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:16 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),p$1={},I$=[[0,'java.text.FieldPosition','java.util.Hashtable','java.text.DigitList','java.util.Locale','sun.util.resources.LocaleData','java.text.DecimalFormatSymbols',['java.text.NumberFormat','.Field'],'java.math.BigInteger','java.text.CharacterIteratorFieldDelegate','java.math.BigDecimal','java.text.ParsePosition','InternalError','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "DecimalFormat", null, 'java.text.NumberFormat');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.digitList=Clazz_new_($I$(3,1));
this.positivePrefix="";
this.positiveSuffix="";
this.negativePrefix="-";
this.negativeSuffix="";
this.multiplier=1;
this.groupingSize=($b$[0] = 3, $b$[0]);
this.decimalSeparatorAlwaysShown=false;
this.parseBigDecimal=false;
this.isCurrencyFormat=false;
this.symbols=null;
this.$maximumIntegerDigits=C$.superclazz.prototype.getMaximumIntegerDigits$.apply(this, []);
this.$minimumIntegerDigits=C$.superclazz.prototype.getMinimumIntegerDigits$.apply(this, []);
this.$maximumFractionDigits=C$.superclazz.prototype.getMaximumFractionDigits$.apply(this, []);
this.$minimumFractionDigits=C$.superclazz.prototype.getMinimumFractionDigits$.apply(this, []);
},1);

C$.$fields$=[['Z',['decimalSeparatorAlwaysShown','parseBigDecimal','isCurrencyFormat','useExponentialNotation'],'B',['groupingSize','minExponentDigits'],'I',['multiplier','$maximumIntegerDigits','$minimumIntegerDigits','$maximumFractionDigits','$minimumFractionDigits'],'S',['positivePrefix','positiveSuffix','negativePrefix','negativeSuffix','posPrefixPattern','posSuffixPattern','negPrefixPattern','negSuffixPattern'],'O',['bigIntegerMultiplier','java.math.BigInteger','bigDecimalMultiplier','java.math.BigDecimal','digitList','java.text.DigitList','symbols','java.text.DecimalFormatSymbols','positivePrefixFieldPositions','java.text.FieldPosition[]','+positiveSuffixFieldPositions','+negativePrefixFieldPositions','+negativeSuffixFieldPositions','roundingMode','java.math.RoundingMode']]
,['O',['EmptyFieldPositionArray','java.text.FieldPosition[]','$cachedLocaleData','java.util.Hashtable']]]

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
var def=$I$(4).getDefault$();
var pattern=C$.$cachedLocaleData.get$O(def);
if (pattern == null ) {
var rb=$I$(5).getNumberFormatData$java_util_Locale(def);
var all=rb.getStringArray$S("NumberPatterns");
pattern=all[0];
C$.$cachedLocaleData.put$O$O(def, pattern);
}this.symbols=Clazz_new_($I$(6,1).c$$java_util_Locale,[def]);
p$1.applyPattern$S$Z.apply(this, [pattern, false]);
}, 1);

Clazz_newMeth(C$, 'c$$S',  function (pattern) {
Clazz_super_(C$, this);
this.symbols=Clazz_new_([$I$(4).getDefault$()],$I$(6,1).c$$java_util_Locale);
p$1.applyPattern$S$Z.apply(this, [pattern, false]);
}, 1);

Clazz_newMeth(C$, 'c$$S$java_text_DecimalFormatSymbols',  function (pattern, symbols) {
Clazz_super_(C$, this);
this.symbols=symbols.clone$();
p$1.applyPattern$S$Z.apply(this, [pattern, false]);
}, 1);

Clazz_newMeth(C$, 'format$O$StringBuffer$java_text_FieldPosition',  function (number, toAppendTo, pos) {
if (Clazz_instanceOf(number, "java.lang.Long") || Clazz_instanceOf(number, "java.lang.Integer") || Clazz_instanceOf(number, "java.lang.Short") || Clazz_instanceOf(number, "java.lang.Byte") || Clazz_instanceOf(number, "java.util.concurrent.atomic.AtomicInteger") || Clazz_instanceOf(number, "java.util.concurrent.atomic.AtomicLong") || (Clazz_instanceOf(number, "java.math.BigInteger") && (number).bitLength$() < 64 )  ) {
return this.format$J$StringBuffer$java_text_FieldPosition((number).longValue$(), toAppendTo, pos);
} else if (Clazz_instanceOf(number, "java.math.BigDecimal")) {
return p$1.format$java_math_BigDecimal$StringBuffer$java_text_FieldPosition.apply(this, [number, toAppendTo, pos]);
} else if (Clazz_instanceOf(number, "java.math.BigInteger")) {
return p$1.format$java_math_BigInteger$StringBuffer$java_text_FieldPosition.apply(this, [number, toAppendTo, pos]);
} else if (Clazz_instanceOf(number, "java.lang.Number")) {
return this.format$D$StringBuffer$java_text_FieldPosition((number).doubleValue$(), toAppendTo, pos);
} else {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Cannot format given Object as a Number"]);
}});

Clazz_newMeth(C$, 'format$D$StringBuffer$java_text_FieldPosition',  function (number, result, fieldPosition) {
fieldPosition.setBeginIndex$I(0);
fieldPosition.setEndIndex$I(0);
var isInt=false;

var a = ("" + number);
isInt = (a.indexOf(".") < 0 && a.indexOf("e") < 0);
var ret=this.秘toArray$StringBuffer(result);
if (isInt) ret=p$1.formatLong$J$SA$java_text_Format_FieldDelegate.apply(this, [Clazz_toLong(number), ret, fieldPosition.getFieldDelegate$()]);
 else ret=p$1.formatDouble$D$SA$java_text_Format_FieldDelegate.apply(this, [number, ret, fieldPosition.getFieldDelegate$()]);
return this.秘toSB$SA$StringBuffer(ret, result);
});

Clazz_newMeth(C$, 'formatDouble$D$SA$java_text_Format_FieldDelegate',  function (number, result, delegate) {
if (Double.isNaN$D(number) || (Double.isInfinite$D(number) && this.multiplier == 0 ) ) {
var iFieldStart=result[0].length$();
result[0]+=(this.symbols.getNaN$());
delegate.formatted$I$java_text_Format_Field$O$I$I$SA(0, $I$(7).INTEGER, $I$(7).INTEGER, iFieldStart, result[0].length$(), result);
return result;
}var isNegative=!!(((number < 0.0 ) || (number == 0.0  && 1 / number < 0.0  ) ) ^ (this.multiplier < 0));
if (this.multiplier != 1) {
number*=this.multiplier;
}if (Double.isInfinite$D(number)) {
if (isNegative) {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.negativePrefix, delegate, p$1.getNegativePrefixFieldPositions.apply(this, []), $I$(7).SIGN]);
} else {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.positivePrefix, delegate, p$1.getPositivePrefixFieldPositions.apply(this, []), $I$(7).SIGN]);
}var iFieldStart=result[0].length$();
result[0]+=(this.symbols.getInfinity$());
delegate.formatted$I$java_text_Format_Field$O$I$I$SA(0, $I$(7).INTEGER, $I$(7).INTEGER, iFieldStart, result[0].length$(), result);
if (isNegative) {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.negativeSuffix, delegate, p$1.getNegativeSuffixFieldPositions.apply(this, []), $I$(7).SIGN]);
} else {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.positiveSuffix, delegate, p$1.getPositiveSuffixFieldPositions.apply(this, []), $I$(7).SIGN]);
}return result;
}if (isNegative) {
number=-number;
}Clazz_assert(C$, this, function(){return (number >= 0  && !Double.isInfinite$D(number) )});
{
var maxIntDigits=C$.superclazz.prototype.getMaximumIntegerDigits$.apply(this, []);
var minIntDigits=C$.superclazz.prototype.getMinimumIntegerDigits$.apply(this, []);
var maxFraDigits=C$.superclazz.prototype.getMaximumFractionDigits$.apply(this, []);
var minFraDigits=C$.superclazz.prototype.getMinimumFractionDigits$.apply(this, []);
this.digitList.set$Z$D$I$Z(isNegative, number, this.useExponentialNotation ? maxIntDigits + maxFraDigits : maxFraDigits, !this.useExponentialNotation);
return p$1.subformat$SA$java_text_Format_FieldDelegate$Z$Z$I$I$I$I.apply(this, [result, delegate, isNegative, false, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits]);
}}, p$1);

Clazz_newMeth(C$, 'format$J$StringBuffer$java_text_FieldPosition',  function (number, result, fieldPosition) {
fieldPosition.setBeginIndex$I(0);
fieldPosition.setEndIndex$I(0);
var ret=this.秘toArray$StringBuffer(result);
ret=p$1.formatLong$J$SA$java_text_Format_FieldDelegate.apply(this, [number, ret, fieldPosition.getFieldDelegate$()]);
return this.秘toSB$SA$StringBuffer(ret, result);
});

Clazz_newMeth(C$, 'formatLong$J$SA$java_text_Format_FieldDelegate',  function (number, result, delegate) {
var isNegative=(Long.$lt(number,0 ));
if (isNegative) {
number=(Long.$neg(number));
}var useBigInteger=false;
if (Long.$lt(number,0 )) {
if (this.multiplier != 0) {
useBigInteger=true;
}} else if (this.multiplier != 1 && this.multiplier != 0 ) {
var cutoff=Long.$div([16777215,549755813887,1],this.multiplier);
if (Long.$lt(cutoff,0 )) {
cutoff=(Long.$neg(cutoff));
}useBigInteger=(Long.$gt(number,cutoff ));
}if (useBigInteger) {
if (isNegative) {
number=(Long.$neg(number));
}var bigIntegerValue=$I$(8).valueOf$J(number);
return p$1.format$java_math_BigInteger$SA$java_text_Format_FieldDelegate$Z.apply(this, [bigIntegerValue, result, delegate, true]);
}(number=Long.$mul(number,(this.multiplier)));
if (Long.$eq(number,0 )) {
isNegative=false;
} else {
if (this.multiplier < 0) {
number=(Long.$neg(number));
isNegative=!isNegative;
}}{
var maxIntDigits=C$.superclazz.prototype.getMaximumIntegerDigits$.apply(this, []);
var minIntDigits=C$.superclazz.prototype.getMinimumIntegerDigits$.apply(this, []);
var maxFraDigits=C$.superclazz.prototype.getMaximumFractionDigits$.apply(this, []);
var minFraDigits=C$.superclazz.prototype.getMinimumFractionDigits$.apply(this, []);
this.digitList.setLong$Z$J$I(isNegative, number, this.useExponentialNotation ? maxIntDigits + maxFraDigits : 0);
return p$1.subformat$SA$java_text_Format_FieldDelegate$Z$Z$I$I$I$I.apply(this, [result, delegate, isNegative, true, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits]);
}}, p$1);

Clazz_newMeth(C$, 'format$java_math_BigDecimal$StringBuffer$java_text_FieldPosition',  function (number, result, fieldPosition) {
fieldPosition.setBeginIndex$I(0);
fieldPosition.setEndIndex$I(0);
var ret=this.秘toArray$StringBuffer(result);
ret=p$1.format$java_math_BigDecimal$SA$java_text_Format_FieldDelegate.apply(this, [number, ret, fieldPosition.getFieldDelegate$()]);
return this.秘toSB$SA$StringBuffer(ret, result);
}, p$1);

Clazz_newMeth(C$, 'format$java_math_BigDecimal$SA$java_text_Format_FieldDelegate',  function (number, result, delegate) {
if (this.multiplier != 1) {
number=number.multiply$java_math_BigDecimal(p$1.getBigDecimalMultiplier.apply(this, []));
}var isNegative=number.signum$() == -1;
if (isNegative) {
number=number.negate$();
}{
var maxIntDigits=this.getMaximumIntegerDigits$();
var minIntDigits=this.getMinimumIntegerDigits$();
var maxFraDigits=this.getMaximumFractionDigits$();
var minFraDigits=this.getMinimumFractionDigits$();
var maximumDigits=maxIntDigits + maxFraDigits;
this.digitList.set$Z$java_math_BigDecimal$I$Z(isNegative, number, this.useExponentialNotation ? ((maximumDigits < 0) ? 2147483647 : maximumDigits) : maxFraDigits, !this.useExponentialNotation);
return p$1.subformat$SA$java_text_Format_FieldDelegate$Z$Z$I$I$I$I.apply(this, [result, delegate, isNegative, false, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits]);
}}, p$1);

Clazz_newMeth(C$, 'format$java_math_BigInteger$StringBuffer$java_text_FieldPosition',  function (number, result, fieldPosition) {
fieldPosition.setBeginIndex$I(0);
fieldPosition.setEndIndex$I(0);
var ret=this.秘toArray$StringBuffer(result);
ret=p$1.format$java_math_BigInteger$SA$java_text_Format_FieldDelegate$Z.apply(this, [number, ret, fieldPosition.getFieldDelegate$(), false]);
return this.秘toSB$SA$StringBuffer(ret, result);
}, p$1);

Clazz_newMeth(C$, 'format$java_math_BigInteger$SA$java_text_Format_FieldDelegate$Z',  function (number, result, delegate, formatLong) {
if (this.multiplier != 1) {
number=number.multiply$java_math_BigInteger(p$1.getBigIntegerMultiplier.apply(this, []));
}var isNegative=number.signum$() == -1;
if (isNegative) {
number=number.negate$();
}{
var maxIntDigits;
var minIntDigits;
var maxFraDigits;
var minFraDigits;
var maximumDigits;
if (formatLong) {
maxIntDigits=C$.superclazz.prototype.getMaximumIntegerDigits$.apply(this, []);
minIntDigits=C$.superclazz.prototype.getMinimumIntegerDigits$.apply(this, []);
maxFraDigits=C$.superclazz.prototype.getMaximumFractionDigits$.apply(this, []);
minFraDigits=C$.superclazz.prototype.getMinimumFractionDigits$.apply(this, []);
maximumDigits=maxIntDigits + maxFraDigits;
} else {
maxIntDigits=this.getMaximumIntegerDigits$();
minIntDigits=this.getMinimumIntegerDigits$();
maxFraDigits=this.getMaximumFractionDigits$();
minFraDigits=this.getMinimumFractionDigits$();
maximumDigits=maxIntDigits + maxFraDigits;
if (maximumDigits < 0) {
maximumDigits=2147483647;
}}this.digitList.set$Z$java_math_BigInteger$I(isNegative, number, this.useExponentialNotation ? maximumDigits : 0);
return p$1.subformat$SA$java_text_Format_FieldDelegate$Z$Z$I$I$I$I.apply(this, [result, delegate, isNegative, true, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits]);
}}, p$1);

Clazz_newMeth(C$, 'formatToCharacterIterator$O',  function (obj) {
var delegate=Clazz_new_($I$(9,1));
var sb=this.秘newSA$();
if (Clazz_instanceOf(obj, "java.lang.Double") || Clazz_instanceOf(obj, "java.lang.Float") ) {
p$1.formatDouble$D$SA$java_text_Format_FieldDelegate.apply(this, [(obj).doubleValue$(), sb, delegate]);
} else if (Clazz_instanceOf(obj, "java.lang.Long") || Clazz_instanceOf(obj, "java.lang.Integer") || Clazz_instanceOf(obj, "java.lang.Short") || Clazz_instanceOf(obj, "java.lang.Byte") || Clazz_instanceOf(obj, "java.util.concurrent.atomic.AtomicInteger") || Clazz_instanceOf(obj, "java.util.concurrent.atomic.AtomicLong")  ) {
p$1.formatLong$J$SA$java_text_Format_FieldDelegate.apply(this, [(obj).longValue$(), sb, delegate]);
} else if (Clazz_instanceOf(obj, "java.math.BigDecimal")) {
p$1.format$java_math_BigDecimal$SA$java_text_Format_FieldDelegate.apply(this, [obj, sb, delegate]);
} else if (Clazz_instanceOf(obj, "java.math.BigInteger")) {
p$1.format$java_math_BigInteger$SA$java_text_Format_FieldDelegate$Z.apply(this, [obj, sb, delegate, false]);
} else if (obj == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["formatToCharacterIterator must be passed non-null object"]);
} else {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Cannot format given Object as a Number"]);
}return delegate.getIterator$S(sb[0]);
});

Clazz_newMeth(C$, 'subformat$SA$java_text_Format_FieldDelegate$Z$Z$I$I$I$I',  function (result, delegate, isNegative, isInteger, maxIntDigits, minIntDigits, maxFraDigits, minFraDigits) {
var zero=this.symbols.getZeroDigit$();
var zeroDelta=zero.$c() - 48;
var grouping=this.symbols.getGroupingSeparator$();
var decimal=this.isCurrencyFormat ? this.symbols.getMonetaryDecimalSeparator$() : this.symbols.getDecimalSeparator$();
if (this.digitList.isZero$()) {
this.digitList.decimalAt=0;
}if (isNegative) {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.negativePrefix, delegate, p$1.getNegativePrefixFieldPositions.apply(this, []), $I$(7).SIGN]);
} else {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.positivePrefix, delegate, p$1.getPositivePrefixFieldPositions.apply(this, []), $I$(7).SIGN]);
}if (this.useExponentialNotation) {
var iFieldStart=result[0].length$();
var iFieldEnd=-1;
var fFieldStart=-1;
var exponent=this.digitList.decimalAt;
var repeat=maxIntDigits;
var minimumIntegerDigits=minIntDigits;
if (repeat > 1 && repeat > minIntDigits ) {
if (exponent >= 1) {
exponent=(((exponent - 1)/repeat|0)) * repeat;
} else {
exponent=(((exponent - repeat)/repeat|0)) * repeat;
}minimumIntegerDigits=1;
} else {
exponent-=minimumIntegerDigits;
}var minimumDigits=minIntDigits + minFraDigits;
if (minimumDigits < 0) {
minimumDigits=2147483647;
}var integerDigits=this.digitList.isZero$() ? minimumIntegerDigits : this.digitList.decimalAt - exponent;
if (minimumDigits < integerDigits) {
minimumDigits=integerDigits;
}var totalDigits=this.digitList.count;
if (minimumDigits > totalDigits) {
totalDigits=minimumDigits;
}var addedDecimalSeparator=false;
for (var i=0; i < totalDigits; ++i) {
if (i == integerDigits) {
iFieldEnd=result[0].length$();
result[0]+=(decimal);
addedDecimalSeparator=true;
fFieldStart=result[0].length$();
}result[0]+=((i < this.digitList.count) ? String.fromCharCode(((this.digitList.digits[i]).$c() + zeroDelta)) : zero);
}
if (this.decimalSeparatorAlwaysShown && totalDigits == integerDigits ) {
iFieldEnd=result[0].length$();
result[0]+=(decimal);
addedDecimalSeparator=true;
fFieldStart=result[0].length$();
}if (iFieldEnd == -1) {
iFieldEnd=result[0].length$();
}delegate.formatted$I$java_text_Format_Field$O$I$I$SA(0, $I$(7).INTEGER, $I$(7).INTEGER, iFieldStart, iFieldEnd, result);
if (addedDecimalSeparator) {
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).DECIMAL_SEPARATOR, $I$(7).DECIMAL_SEPARATOR, iFieldEnd, fFieldStart, result);
}if (fFieldStart == -1) {
fFieldStart=result[0].length$();
}delegate.formatted$I$java_text_Format_Field$O$I$I$SA(1, $I$(7).FRACTION, $I$(7).FRACTION, fFieldStart, result[0].length$(), result);
var fieldStart=result[0].length$();
result[0]+=(this.symbols.getExponentSeparator$());
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).EXPONENT_SYMBOL, $I$(7).EXPONENT_SYMBOL, fieldStart, result[0].length$(), result);
if (this.digitList.isZero$()) {
exponent=0;
}var negativeExponent=exponent < 0;
if (negativeExponent) {
exponent=-exponent;
fieldStart=result[0].length$();
result[0]+=(this.symbols.getMinusSign$());
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).EXPONENT_SIGN, $I$(7).EXPONENT_SIGN, fieldStart, result[0].length$(), result);
}this.digitList.setExp$Z$J(negativeExponent, exponent);
var eFieldStart=result[0].length$();
for (var i=this.digitList.decimalAt; i < this.minExponentDigits; ++i) {
result[0]+=(zero);
}
for (var i=0; i < this.digitList.decimalAt; ++i) {
result[0]+=((i < this.digitList.count) ? String.fromCharCode(((this.digitList.digits[i]).$c() + zeroDelta)) : zero);
}
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).EXPONENT, $I$(7).EXPONENT, eFieldStart, result[0].length$(), result);
} else {
var iFieldStart=result[0].length$();
var count=minIntDigits;
var digitIndex=0;
if (this.digitList.decimalAt > 0 && count < this.digitList.decimalAt ) {
count=this.digitList.decimalAt;
}if (count > maxIntDigits) {
count=maxIntDigits;
digitIndex=this.digitList.decimalAt - count;
}var sizeBeforeIntegerPart=result[0].length$();
for (var i=count - 1; i >= 0; --i) {
if (i < this.digitList.decimalAt && digitIndex < this.digitList.count ) {
result[0]+=(String.fromCharCode(((this.digitList.digits[digitIndex++]).$c() + zeroDelta)));
} else {
result[0]+=(zero);
}if (this.isGroupingUsed$() && i > 0  && (this.groupingSize != 0)  && (i % this.groupingSize == 0) ) {
var gStart=result[0].length$();
result[0]+=(grouping);
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).GROUPING_SEPARATOR, $I$(7).GROUPING_SEPARATOR, gStart, result[0].length$(), result);
}}
var fractionPresent=(minFraDigits > 0) || (!isInteger && digitIndex < this.digitList.count ) ;
if (!fractionPresent && result[0].length$() == sizeBeforeIntegerPart ) {
result[0]+=(zero);
}delegate.formatted$I$java_text_Format_Field$O$I$I$SA(0, $I$(7).INTEGER, $I$(7).INTEGER, iFieldStart, result[0].length$(), result);
var sStart=result[0].length$();
if (this.decimalSeparatorAlwaysShown || fractionPresent ) {
result[0]+=(decimal);
}if (sStart != result[0].length$()) {
delegate.formatted$java_text_Format_Field$O$I$I$SA($I$(7).DECIMAL_SEPARATOR, $I$(7).DECIMAL_SEPARATOR, sStart, result[0].length$(), result);
}var fFieldStart=result[0].length$();
for (var i=0; i < maxFraDigits; ++i) {
if (i >= minFraDigits && (isInteger || digitIndex >= this.digitList.count ) ) {
break;
}if (-1 - i > (this.digitList.decimalAt - 1)) {
result[0]+=(zero);
continue;
}if (!isInteger && digitIndex < this.digitList.count ) {
result[0]+=(String.fromCharCode(((this.digitList.digits[digitIndex++]).$c() + zeroDelta)));
} else {
result[0]+=(zero);
}}
delegate.formatted$I$java_text_Format_Field$O$I$I$SA(1, $I$(7).FRACTION, $I$(7).FRACTION, fFieldStart, result[0].length$(), result);
}if (isNegative) {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.negativeSuffix, delegate, p$1.getNegativeSuffixFieldPositions.apply(this, []), $I$(7).SIGN]);
} else {
p$1.append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field.apply(this, [result, this.positiveSuffix, delegate, p$1.getPositiveSuffixFieldPositions.apply(this, []), $I$(7).SIGN]);
}return result;
}, p$1);

Clazz_newMeth(C$, 'append$SA$S$java_text_Format_FieldDelegate$java_text_FieldPositionA$java_text_Format_Field',  function (result, string, delegate, positions, signAttribute) {
var start=result[0].length$();
if (string.length$() > 0) {
result[0]+=(string);
for (var counter=0, max=positions.length; counter < max; counter++) {
var fp=positions[counter];
var attribute=fp.getFieldAttribute$();
if (attribute === $I$(7).SIGN ) {
attribute=signAttribute;
}delegate.formatted$java_text_Format_Field$O$I$I$SA(attribute, attribute, start + fp.getBeginIndex$(), start + fp.getEndIndex$(), result);
}
}}, p$1);

Clazz_newMeth(C$, 'parse$S$java_text_ParsePosition',  function (text, pos) {
if (text.regionMatches$I$S$I$I(pos.index, this.symbols.getNaN$(), 0, this.symbols.getNaN$().length$())) {
pos.index=pos.index + this.symbols.getNaN$().length$();
return  new Double(NaN);
}var status=Clazz_array(Boolean.TYPE, [2]);
if (!p$1.subparse$S$java_text_ParsePosition$S$S$java_text_DigitList$Z$ZA.apply(this, [text, pos, this.positivePrefix, this.negativePrefix, this.digitList, false, status])) {
return null;
}if (status[0]) {
if (status[1] == (this.multiplier >= 0) ) {
return  new Double(Infinity);
} else {
return  new Double(-Infinity);
}}if (this.multiplier == 0) {
if (this.digitList.isZero$()) {
return  new Double(NaN);
} else if (status[1]) {
return  new Double(Infinity);
} else {
return  new Double(-Infinity);
}}if (this.isParseBigDecimal$()) {
var bigDecimalResult=this.digitList.getBigDecimal$();
if (this.multiplier != 1) {
try {
bigDecimalResult=bigDecimalResult.divide$java_math_BigDecimal(p$1.getBigDecimalMultiplier.apply(this, []));
} catch (e) {
if (Clazz_exceptionOf(e,"ArithmeticException")){
bigDecimalResult=bigDecimalResult.divide$java_math_BigDecimal$java_math_RoundingMode(p$1.getBigDecimalMultiplier.apply(this, []), this.roundingMode);
} else {
throw e;
}
}
}if (!status[1]) {
bigDecimalResult=bigDecimalResult.negate$();
}return bigDecimalResult;
} else {
var gotDouble=true;
var gotLongMinimum=false;
var doubleResult=0.0;
var longResult=0;
if (this.digitList.fitsIntoLong$Z$Z(status[1], this.isParseIntegerOnly$())) {
gotDouble=false;
longResult=this.digitList.getLong$();
if (Long.$lt(longResult,0 )) {
gotLongMinimum=true;
}} else {
doubleResult=this.digitList.getDouble$();
}if (this.multiplier != 1) {
if (gotDouble) {
doubleResult/=this.multiplier;
} else {
if (Long.$eq(Long.$mod(longResult,this.multiplier),0 )) {
longResult=Long.$div(longResult,this.multiplier);
} else {
doubleResult=(Long.$dval(longResult)) / this.multiplier;
gotDouble=true;
}}}if (!status[1] && !gotLongMinimum ) {
doubleResult=-doubleResult;
longResult=(Long.$neg(longResult));
}if (this.multiplier != 1 && gotDouble ) {
longResult=Clazz_toLong(doubleResult);
gotDouble=((doubleResult != Long.$dval(longResult) ) || (doubleResult == 0.0  && 1 / doubleResult < 0.0  ) ) && !this.isParseIntegerOnly$() ;
}return gotDouble ?  new Double(doubleResult) :  new Long(longResult);
}});

Clazz_newMeth(C$, 'getBigIntegerMultiplier',  function () {
if (this.bigIntegerMultiplier == null ) {
this.bigIntegerMultiplier=$I$(8).valueOf$J(this.multiplier);
}return this.bigIntegerMultiplier;
}, p$1);

Clazz_newMeth(C$, 'getBigDecimalMultiplier',  function () {
if (this.bigDecimalMultiplier == null ) {
this.bigDecimalMultiplier=Clazz_new_($I$(10,1).c$$I,[this.multiplier]);
}return this.bigDecimalMultiplier;
}, p$1);

Clazz_newMeth(C$, 'subparse$S$java_text_ParsePosition$S$S$java_text_DigitList$Z$ZA',  function (text, parsePosition, positivePrefix, negativePrefix, digits, isExponent, status) {
var position=parsePosition.index;
var oldStart=parsePosition.index;
var backup;
var gotPositive;
var gotNegative;
gotPositive=text.regionMatches$I$S$I$I(position, positivePrefix, 0, positivePrefix.length$());
gotNegative=text.regionMatches$I$S$I$I(position, negativePrefix, 0, negativePrefix.length$());
if (gotPositive && gotNegative ) {
if (positivePrefix.length$() > negativePrefix.length$()) {
gotNegative=false;
} else if (positivePrefix.length$() < negativePrefix.length$()) {
gotPositive=false;
}}if (gotPositive) {
position+=positivePrefix.length$();
} else if (gotNegative) {
position+=negativePrefix.length$();
} else {
parsePosition.errorIndex=position;
return false;
}status[0]=false;
if (!isExponent && text.regionMatches$I$S$I$I(position, this.symbols.getInfinity$(), 0, this.symbols.getInfinity$().length$()) ) {
position+=this.symbols.getInfinity$().length$();
status[0]=true;
} else {
digits.decimalAt=digits.count=0;
var zero=this.symbols.getZeroDigit$();
var decimal=this.isCurrencyFormat ? this.symbols.getMonetaryDecimalSeparator$() : this.symbols.getDecimalSeparator$();
var grouping=this.symbols.getGroupingSeparator$();
var exponentString=this.symbols.getExponentSeparator$();
var sawDecimal=false;
var sawExponent=false;
var sawDigit=false;
var exponent=0;
var digitCount=0;
backup=-1;
for (; position < text.length$(); ++position) {
var ch=text.charAt$I(position);
var digit=ch.$c() - zero.$c();
if (digit < 0 || digit > 9 ) {
digit=Character.digit$C$I(ch, 10);
}if (digit == 0) {
backup=-1;
sawDigit=true;
if (digits.count == 0) {
if (!sawDecimal) {
continue;
}--digits.decimalAt;
} else {
++digitCount;
digits.append$C(String.fromCharCode((digit + 48)));
}} else if (digit > 0 && digit <= 9 ) {
sawDigit=true;
++digitCount;
digits.append$C(String.fromCharCode((digit + 48)));
backup=-1;
} else if (!isExponent && ch == decimal ) {
if (this.isParseIntegerOnly$() || sawDecimal ) {
break;
}digits.decimalAt=digitCount;
sawDecimal=true;
} else if (!isExponent && ch == grouping  && this.isGroupingUsed$() ) {
if (sawDecimal) {
break;
}backup=position;
} else if (!isExponent && text.regionMatches$I$S$I$I(position, exponentString, 0, exponentString.length$()) && !sawExponent  ) {
var pos=Clazz_new_([position + exponentString.length$()],$I$(11,1).c$$I);
var stat=Clazz_array(Boolean.TYPE, [2]);
var exponentDigits=Clazz_new_($I$(3,1));
if (p$1.subparse$S$java_text_ParsePosition$S$S$java_text_DigitList$Z$ZA.apply(this, [text, pos, "", Character.toString$C(this.symbols.getMinusSign$()), exponentDigits, true, stat]) && exponentDigits.fitsIntoLong$Z$Z(stat[1], true) ) {
position=pos.index;
exponent=Long.$ival(exponentDigits.getLong$());
if (!stat[1]) {
exponent=-exponent;
}sawExponent=true;
}break;
} else {
break;
}}
if (backup != -1) {
position=backup;
}if (!sawDecimal) {
digits.decimalAt=digitCount;
}digits.decimalAt+=exponent;
if (!sawDigit && digitCount == 0 ) {
parsePosition.index=oldStart;
parsePosition.errorIndex=oldStart;
return false;
}}if (!isExponent) {
if (gotPositive) {
gotPositive=text.regionMatches$I$S$I$I(position, this.positiveSuffix, 0, this.positiveSuffix.length$());
}if (gotNegative) {
gotNegative=text.regionMatches$I$S$I$I(position, this.negativeSuffix, 0, this.negativeSuffix.length$());
}if (gotPositive && gotNegative ) {
if (this.positiveSuffix.length$() > this.negativeSuffix.length$()) {
gotNegative=false;
} else if (this.positiveSuffix.length$() < this.negativeSuffix.length$()) {
gotPositive=false;
}}if (gotPositive == gotNegative ) {
parsePosition.errorIndex=position;
return false;
}parsePosition.index=position + (gotPositive ? this.positiveSuffix.length$() : this.negativeSuffix.length$());
} else {
parsePosition.index=position;
}status[1]=gotPositive;
if (parsePosition.index == oldStart) {
parsePosition.errorIndex=position;
return false;
}return true;
}, p$1);

Clazz_newMeth(C$, 'getDecimalFormatSymbols$',  function () {
try {
return this.symbols.clone$();
} catch (foo) {
if (Clazz_exceptionOf(foo,"Exception")){
return null;
} else {
throw foo;
}
}
});

Clazz_newMeth(C$, 'setDecimalFormatSymbols$java_text_DecimalFormatSymbols',  function (newSymbols) {
try {
this.symbols=newSymbols.clone$();
p$1.expandAffixes.apply(this, []);
} catch (foo) {
if (Clazz_exceptionOf(foo,"Exception")){
} else {
throw foo;
}
}
});

Clazz_newMeth(C$, 'getPositivePrefix$',  function () {
return this.positivePrefix;
});

Clazz_newMeth(C$, 'setPositivePrefix$S',  function (newValue) {
this.positivePrefix=newValue;
this.posPrefixPattern=null;
this.positivePrefixFieldPositions=null;
});

Clazz_newMeth(C$, 'getPositivePrefixFieldPositions',  function () {
if (this.positivePrefixFieldPositions == null ) {
if (this.posPrefixPattern != null ) {
this.positivePrefixFieldPositions=p$1.expandAffix$S.apply(this, [this.posPrefixPattern]);
} else {
this.positivePrefixFieldPositions=C$.EmptyFieldPositionArray;
}}return this.positivePrefixFieldPositions;
}, p$1);

Clazz_newMeth(C$, 'getNegativePrefix$',  function () {
return this.negativePrefix;
});

Clazz_newMeth(C$, 'setNegativePrefix$S',  function (newValue) {
this.negativePrefix=newValue;
this.negPrefixPattern=null;
});

Clazz_newMeth(C$, 'getNegativePrefixFieldPositions',  function () {
if (this.negativePrefixFieldPositions == null ) {
if (this.negPrefixPattern != null ) {
this.negativePrefixFieldPositions=p$1.expandAffix$S.apply(this, [this.negPrefixPattern]);
} else {
this.negativePrefixFieldPositions=C$.EmptyFieldPositionArray;
}}return this.negativePrefixFieldPositions;
}, p$1);

Clazz_newMeth(C$, 'getPositiveSuffix$',  function () {
return this.positiveSuffix;
});

Clazz_newMeth(C$, 'setPositiveSuffix$S',  function (newValue) {
this.positiveSuffix=newValue;
this.posSuffixPattern=null;
});

Clazz_newMeth(C$, 'getPositiveSuffixFieldPositions',  function () {
if (this.positiveSuffixFieldPositions == null ) {
if (this.posSuffixPattern != null ) {
this.positiveSuffixFieldPositions=p$1.expandAffix$S.apply(this, [this.posSuffixPattern]);
} else {
this.positiveSuffixFieldPositions=C$.EmptyFieldPositionArray;
}}return this.positiveSuffixFieldPositions;
}, p$1);

Clazz_newMeth(C$, 'getNegativeSuffix$',  function () {
return this.negativeSuffix;
});

Clazz_newMeth(C$, 'setNegativeSuffix$S',  function (newValue) {
this.negativeSuffix=newValue;
this.negSuffixPattern=null;
});

Clazz_newMeth(C$, 'getNegativeSuffixFieldPositions',  function () {
if (this.negativeSuffixFieldPositions == null ) {
if (this.negSuffixPattern != null ) {
this.negativeSuffixFieldPositions=p$1.expandAffix$S.apply(this, [this.negSuffixPattern]);
} else {
this.negativeSuffixFieldPositions=C$.EmptyFieldPositionArray;
}}return this.negativeSuffixFieldPositions;
}, p$1);

Clazz_newMeth(C$, 'getMultiplier$',  function () {
return this.multiplier;
});

Clazz_newMeth(C$, 'setMultiplier$I',  function (newValue) {
this.multiplier=newValue;
this.bigDecimalMultiplier=null;
this.bigIntegerMultiplier=null;
});

Clazz_newMeth(C$, 'getGroupingSize$',  function () {
return this.groupingSize;
});

Clazz_newMeth(C$, 'setGroupingSize$I',  function (newValue) {
this.groupingSize=($b$[0] = newValue, $b$[0]);
});

Clazz_newMeth(C$, 'isDecimalSeparatorAlwaysShown$',  function () {
return this.decimalSeparatorAlwaysShown;
});

Clazz_newMeth(C$, 'setDecimalSeparatorAlwaysShown$Z',  function (newValue) {
this.decimalSeparatorAlwaysShown=newValue;
});

Clazz_newMeth(C$, 'isParseBigDecimal$',  function () {
return this.parseBigDecimal;
});

Clazz_newMeth(C$, 'setParseBigDecimal$Z',  function (newValue) {
this.parseBigDecimal=newValue;
});

Clazz_newMeth(C$, 'clone$',  function () {
try {
var other=C$.superclazz.prototype.clone$.apply(this, []);
other.symbols=this.symbols.clone$();
other.digitList=this.digitList.clone$();
return other;
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
throw Clazz_new_($I$(12,1));
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if (obj == null ) return false;
if (!C$.superclazz.prototype.equals$O.apply(this, [obj])) return false;
var other=obj;
return ((this.posPrefixPattern == other.posPrefixPattern && this.positivePrefix.equals$O(other.positivePrefix) ) || (this.posPrefixPattern != null  && this.posPrefixPattern.equals$O(other.posPrefixPattern) ) ) && ((this.posSuffixPattern == other.posSuffixPattern && this.positiveSuffix.equals$O(other.positiveSuffix) ) || (this.posSuffixPattern != null  && this.posSuffixPattern.equals$O(other.posSuffixPattern) ) ) && ((this.negPrefixPattern == other.negPrefixPattern && this.negativePrefix.equals$O(other.negativePrefix) ) || (this.negPrefixPattern != null  && this.negPrefixPattern.equals$O(other.negPrefixPattern) ) ) && ((this.negSuffixPattern == other.negSuffixPattern && this.negativeSuffix.equals$O(other.negativeSuffix) ) || (this.negSuffixPattern != null  && this.negSuffixPattern.equals$O(other.negSuffixPattern) ) ) && this.multiplier == other.multiplier   && this.groupingSize == other.groupingSize  && this.decimalSeparatorAlwaysShown == other.decimalSeparatorAlwaysShown   && this.parseBigDecimal == other.parseBigDecimal   && this.useExponentialNotation == other.useExponentialNotation   && (!this.useExponentialNotation || this.minExponentDigits == other.minExponentDigits )  && this.$maximumIntegerDigits == other.$maximumIntegerDigits  && this.$minimumIntegerDigits == other.$minimumIntegerDigits  && this.$maximumFractionDigits == other.$maximumFractionDigits  && this.$minimumFractionDigits == other.$minimumFractionDigits  && this.roundingMode === other.roundingMode   && this.symbols.equals$O(other.symbols) ;
});

Clazz_newMeth(C$, 'hashCode$',  function () {
return C$.superclazz.prototype.hashCode$.apply(this, []) * 37 + this.positivePrefix.hashCode$();
});

Clazz_newMeth(C$, 'toPattern$',  function () {
return p$1.toPattern$Z.apply(this, [false]);
});

Clazz_newMeth(C$, 'toLocalizedPattern$',  function () {
return p$1.toPattern$Z.apply(this, [true]);
});

Clazz_newMeth(C$, 'expandAffixes',  function () {
var buffer=this.秘newSA$();
if (this.posPrefixPattern != null ) {
this.positivePrefix=p$1.expandAffix$S$SA.apply(this, [this.posPrefixPattern, buffer]);
this.positivePrefixFieldPositions=null;
}if (this.posSuffixPattern != null ) {
this.positiveSuffix=p$1.expandAffix$S$SA.apply(this, [this.posSuffixPattern, buffer]);
this.positiveSuffixFieldPositions=null;
}if (this.negPrefixPattern != null ) {
this.negativePrefix=p$1.expandAffix$S$SA.apply(this, [this.negPrefixPattern, buffer]);
this.negativePrefixFieldPositions=null;
}if (this.negSuffixPattern != null ) {
this.negativeSuffix=p$1.expandAffix$S$SA.apply(this, [this.negSuffixPattern, buffer]);
this.negativeSuffixFieldPositions=null;
}}, p$1);

Clazz_newMeth(C$, 'expandAffix$S$SA',  function (pattern, buffer) {
buffer[0]="";
for (var i=0; i < pattern.length$(); ) {
var c=pattern.charAt$I(i++);
if (c == "\'") {
c=pattern.charAt$I(i++);
switch (c.$c()) {
case 164:
if (i < pattern.length$() && pattern.charAt$I(i) == "\u00a4" ) {
++i;
buffer[0]+=(this.symbols.getInternationalCurrencySymbol$());
} else {
buffer[0]+=(this.symbols.getCurrencySymbol$());
}continue;
case 37:
c=this.symbols.getPercent$();
break;
case 8240:
c=this.symbols.getPerMill$();
break;
case 45:
c=this.symbols.getMinusSign$();
break;
}
}buffer[0]+=(c);
}
return buffer[0];
}, p$1);

Clazz_newMeth(C$, 'expandAffix$S',  function (pattern) {
var positions=null;
var stringIndex=0;
for (var i=0; i < pattern.length$(); ) {
var c=pattern.charAt$I(i++);
if (c == "\'") {
var field=-1;
var fieldID=null;
c=pattern.charAt$I(i++);
switch (c.$c()) {
case 164:
var string;
if (i < pattern.length$() && pattern.charAt$I(i) == "\u00a4" ) {
++i;
string=this.symbols.getInternationalCurrencySymbol$();
} else {
string=this.symbols.getCurrencySymbol$();
}if (string.length$() > 0) {
if (positions == null ) {
positions=Clazz_new_($I$(13,1).c$$I,[2]);
}var fp=Clazz_new_([$I$(7).CURRENCY],$I$(1,1).c$$java_text_Format_Field);
fp.setBeginIndex$I(stringIndex);
fp.setEndIndex$I(stringIndex + string.length$());
positions.add$O(fp);
stringIndex+=string.length$();
}continue;
case 37:
c=this.symbols.getPercent$();
field=-1;
fieldID=$I$(7).PERCENT;
break;
case 8240:
c=this.symbols.getPerMill$();
field=-1;
fieldID=$I$(7).PERMILLE;
break;
case 45:
c=this.symbols.getMinusSign$();
field=-1;
fieldID=$I$(7).SIGN;
break;
}
if (fieldID != null ) {
if (positions == null ) {
positions=Clazz_new_($I$(13,1).c$$I,[2]);
}var fp=Clazz_new_($I$(1,1).c$$java_text_Format_Field$I,[fieldID, field]);
fp.setBeginIndex$I(stringIndex);
fp.setEndIndex$I(stringIndex + 1);
positions.add$O(fp);
}}++stringIndex;
}
if (positions != null ) {
return positions.toArray$OA(C$.EmptyFieldPositionArray);
}return C$.EmptyFieldPositionArray;
}, p$1);

Clazz_newMeth(C$, 'appendAffix$SA$S$S$Z',  function (buffer, affixPattern, expAffix, localized) {
if (affixPattern == null ) {
p$1.appendAffix$SA$S$Z.apply(this, [buffer, expAffix, localized]);
} else {
var i;
for (var pos=0; pos < affixPattern.length$(); pos=i) {
i=affixPattern.indexOf$I$I("\'", pos);
if (i < 0) {
p$1.appendAffix$SA$S$Z.apply(this, [buffer, affixPattern.substring$I(pos), localized]);
break;
}if (i > pos) {
p$1.appendAffix$SA$S$Z.apply(this, [buffer, affixPattern.substring$I$I(pos, i), localized]);
}var c=affixPattern.charAt$I(++i);
++i;
if (c == "\'") {
buffer[0]+=(c);
} else if (c == "\u00a4" && i < affixPattern.length$()  && affixPattern.charAt$I(i) == "\u00a4" ) {
++i;
buffer[0]+=(c);
} else if (localized) {
switch (c.$c()) {
case 37:
c=this.symbols.getPercent$();
break;
case 8240:
c=this.symbols.getPerMill$();
break;
case 45:
c=this.symbols.getMinusSign$();
break;
}
}buffer[0]+=(c);
}
}}, p$1);

Clazz_newMeth(C$, 'appendAffix$SA$S$Z',  function (buffer, affix, localized) {
var needQuote;
if (localized) {
needQuote=affix.indexOf$I(this.symbols.getZeroDigit$()) >= 0 || affix.indexOf$I(this.symbols.getGroupingSeparator$()) >= 0  || affix.indexOf$I(this.symbols.getDecimalSeparator$()) >= 0  || affix.indexOf$I(this.symbols.getPercent$()) >= 0  || affix.indexOf$I(this.symbols.getPerMill$()) >= 0  || affix.indexOf$I(this.symbols.getDigit$()) >= 0  || affix.indexOf$I(this.symbols.getPatternSeparator$()) >= 0  || affix.indexOf$I(this.symbols.getMinusSign$()) >= 0  || affix.indexOf$I("\u00a4") >= 0 ;
} else {
needQuote=affix.indexOf$I("0") >= 0 || affix.indexOf$I(",") >= 0  || affix.indexOf$I(".") >= 0  || affix.indexOf$I("%") >= 0  || affix.indexOf$I("\u2030") >= 0  || affix.indexOf$I("#") >= 0  || affix.indexOf$I(";") >= 0  || affix.indexOf$I("-") >= 0  || affix.indexOf$I("\u00a4") >= 0 ;
}if (needQuote) buffer[0]+=('\'');
if (affix.indexOf$I("\'") < 0) buffer[0]+=(affix);
 else {
for (var j=0; j < affix.length$(); ++j) {
var c=affix.charAt$I(j);
buffer[0]+=(c);
if (c == "\'") buffer[0]+=(c);
}
}if (needQuote) buffer[0]+=('\'');
}, p$1);

Clazz_newMeth(C$, 'toPattern$Z',  function (localized) {
var result=Clazz_array(String, -1, [""]);
for (var j=1; j >= 0; --j) {
if (j == 1) p$1.appendAffix$SA$S$S$Z.apply(this, [result, this.posPrefixPattern, this.positivePrefix, localized]);
 else p$1.appendAffix$SA$S$S$Z.apply(this, [result, this.negPrefixPattern, this.negativePrefix, localized]);
var i;
var digitCount=this.useExponentialNotation ? this.getMaximumIntegerDigits$() : Math.max(this.groupingSize, this.getMinimumIntegerDigits$()) + 1;
for (i=digitCount; i > 0; --i) {
if (i != digitCount && this.isGroupingUsed$()  && this.groupingSize != 0  && i % this.groupingSize == 0 ) {
result[0]+=(localized ? this.symbols.getGroupingSeparator$() : ",");
}result[0]+=(i <= this.getMinimumIntegerDigits$() ? (localized ? this.symbols.getZeroDigit$() : "0") : (localized ? this.symbols.getDigit$() : "#"));
}
if (this.getMaximumFractionDigits$() > 0 || this.decimalSeparatorAlwaysShown ) result[0]+=(localized ? this.symbols.getDecimalSeparator$() : ".");
for (i=0; i < this.getMaximumFractionDigits$(); ++i) {
if (i < this.getMinimumFractionDigits$()) {
result[0]+=(localized ? this.symbols.getZeroDigit$() : "0");
} else {
result[0]+=(localized ? this.symbols.getDigit$() : "#");
}}
if (this.useExponentialNotation) {
result[0]+=(localized ? this.symbols.getExponentSeparator$() : "E");
for (i=0; i < this.minExponentDigits; ++i) result[0]+=(localized ? this.symbols.getZeroDigit$() : "0");

}if (j == 1) {
p$1.appendAffix$SA$S$S$Z.apply(this, [result, this.posSuffixPattern, this.positiveSuffix, localized]);
if ((this.negSuffixPattern == this.posSuffixPattern && this.negativeSuffix.equals$O(this.positiveSuffix) ) || (this.negSuffixPattern != null  && this.negSuffixPattern.equals$O(this.posSuffixPattern) ) ) {
if ((this.negPrefixPattern != null  && this.posPrefixPattern != null   && this.negPrefixPattern.equals$O("'-" + this.posPrefixPattern) ) || (this.negPrefixPattern == this.posPrefixPattern && this.negativePrefix.equals$O(this.symbols.getMinusSign$() + this.positivePrefix) ) ) break;
}result[0]+=(localized ? this.symbols.getPatternSeparator$() : ";");
} else p$1.appendAffix$SA$S$S$Z.apply(this, [result, this.negSuffixPattern, this.negativeSuffix, localized]);
}
return result[0];
}, p$1);

Clazz_newMeth(C$, 'applyPattern$S',  function (pattern) {
p$1.applyPattern$S$Z.apply(this, [pattern, false]);
});

Clazz_newMeth(C$, 'applyLocalizedPattern$S',  function (pattern) {
p$1.applyPattern$S$Z.apply(this, [pattern, true]);
});

Clazz_newMeth(C$, 'applyPattern$S$Z',  function (pattern, localized) {
var zeroDigit="0";
var groupingSeparator=",";
var decimalSeparator=".";
var percent="%";
var perMill="\u2030";
var digit="#";
var separator=";";
var exponent="E";
var minus="-";
if (localized) {
zeroDigit=this.symbols.getZeroDigit$();
groupingSeparator=this.symbols.getGroupingSeparator$();
decimalSeparator=this.symbols.getDecimalSeparator$();
percent=this.symbols.getPercent$();
perMill=this.symbols.getPerMill$();
digit=this.symbols.getDigit$();
separator=this.symbols.getPatternSeparator$();
exponent=this.symbols.getExponentSeparator$();
minus=this.symbols.getMinusSign$();
}var gotNegative=false;
this.decimalSeparatorAlwaysShown=false;
this.isCurrencyFormat=false;
this.useExponentialNotation=false;
var phaseOneLength=0;
var start=0;
for (var j=1; j >= 0 && start < pattern.length$() ; --j) {
var inQuote=false;
var prefix=this.秘newSA$();
var suffix=this.秘newSA$();
var decimalPos=-1;
var multiplier=1;
var digitLeftCount=0;
var zeroDigitCount=0;
var digitRightCount=0;
var groupingCount=($b$[0] = -1, $b$[0]);
var phase=0;
var affix=prefix;
for (var pos=start; pos < pattern.length$(); ++pos) {
var ch=pattern.charAt$I(pos);
switch (phase) {
case 0:
case 2:
if (inQuote) {
if (ch == "\'") {
if ((pos + 1) < pattern.length$() && pattern.charAt$I(pos + 1) == "\'" ) {
++pos;
affix[0]+=("''");
} else {
inQuote=false;
}continue;
}} else {
if (ch == digit || ch == zeroDigit  || ch == groupingSeparator  || ch == decimalSeparator ) {
phase=1;
--pos;
continue;
} else if (ch == "\u00a4") {
var doubled=(pos + 1) < pattern.length$() && pattern.charAt$I(pos + 1) == "\u00a4" ;
if (doubled) {
++pos;
}this.isCurrencyFormat=true;
affix[0]+=(doubled ? "\'\u00a4\u00a4" : "\'\u00a4");
continue;
} else if (ch == "\'") {
if (ch == "\'") {
if ((pos + 1) < pattern.length$() && pattern.charAt$I(pos + 1) == "\'" ) {
++pos;
affix[0]+=("''");
} else {
inQuote=true;
}continue;
}} else if (ch == separator) {
if (phase == 0 || j == 0 ) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Unquoted special character '" + ch + "' in pattern \"" + pattern + '\"' ]);
}start=pos + 1;
pos=pattern.length$();
continue;
} else if (ch == percent) {
if (multiplier != 1) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Too many percent/per mille characters in pattern \"" + pattern + '\"' ]);
}multiplier=100;
affix[0]+=("'%");
continue;
} else if (ch == perMill) {
if (multiplier != 1) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Too many percent/per mille characters in pattern \"" + pattern + '\"' ]);
}multiplier=1000;
affix[0]+=("'\u2030");
continue;
} else if (ch == minus) {
affix[0]+=("'-");
continue;
}}affix[0]+=(ch);
break;
case 1:
if (j == 1) {
++phaseOneLength;
} else {
if (--phaseOneLength == 0) {
phase=2;
affix=suffix;
}continue;
}if (ch == digit) {
if (zeroDigitCount > 0) {
++digitRightCount;
} else {
++digitLeftCount;
}if (groupingCount >= 0 && decimalPos < 0 ) {
(($b$[0]=++groupingCount,groupingCount=$b$[0],$b$[0]));
}} else if (ch == zeroDigit) {
if (digitRightCount > 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Unexpected '0' in pattern \"" + pattern + '\"' ]);
}++zeroDigitCount;
if (groupingCount >= 0 && decimalPos < 0 ) {
(($b$[0]=++groupingCount,groupingCount=$b$[0],$b$[0]));
}} else if (ch == groupingSeparator) {
groupingCount=($b$[0] = 0, $b$[0]);
} else if (ch == decimalSeparator) {
if (decimalPos >= 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Multiple decimal separators in pattern \"" + pattern + '\"' ]);
}decimalPos=digitLeftCount + zeroDigitCount + digitRightCount ;
} else if (pattern.regionMatches$I$S$I$I(pos, exponent, 0, exponent.length$())) {
if (this.useExponentialNotation) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Multiple exponential symbols in pattern \"" + pattern + '\"' ]);
}this.useExponentialNotation=true;
this.minExponentDigits=($b$[0] = 0, $b$[0]);
pos=pos + exponent.length$();
while (pos < pattern.length$() && pattern.charAt$I(pos) == zeroDigit ){
(($b$[0]=++this.minExponentDigits,this.minExponentDigits=$b$[0],$b$[0]));
++phaseOneLength;
++pos;
}
if ((digitLeftCount + zeroDigitCount) < 1 || this.minExponentDigits < 1 ) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Malformed exponential pattern \"" + pattern + '\"' ]);
}phase=2;
affix=suffix;
--pos;
continue;
} else {
phase=2;
affix=suffix;
--pos;
--phaseOneLength;
continue;
}break;
}
}
if (zeroDigitCount == 0 && digitLeftCount > 0  && decimalPos >= 0 ) {
var n=decimalPos;
if (n == 0) {
++n;
}digitRightCount=digitLeftCount - n;
digitLeftCount=n - 1;
zeroDigitCount=1;
}if ((decimalPos < 0 && digitRightCount > 0 ) || (decimalPos >= 0 && (decimalPos < digitLeftCount || decimalPos > (digitLeftCount + zeroDigitCount) ) ) || groupingCount == 0   || inQuote ) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Malformed pattern \"" + pattern + '\"' ]);
}if (j == 1) {
this.posPrefixPattern=prefix[0];
this.posSuffixPattern=suffix[0];
this.negPrefixPattern=this.posPrefixPattern;
this.negSuffixPattern=this.posSuffixPattern;
var digitTotalCount=digitLeftCount + zeroDigitCount + digitRightCount ;
var effectiveDecimalPos=decimalPos >= 0 ? decimalPos : digitTotalCount;
this.setMinimumIntegerDigits$I(effectiveDecimalPos - digitLeftCount);
this.setMaximumIntegerDigits$I(this.useExponentialNotation ? digitLeftCount + this.getMinimumIntegerDigits$() : 2147483647);
this.setMaximumFractionDigits$I(decimalPos >= 0 ? (digitTotalCount - decimalPos) : 0);
this.setMinimumFractionDigits$I(decimalPos >= 0 ? (digitLeftCount + zeroDigitCount - decimalPos) : 0);
this.setGroupingUsed$Z(groupingCount > 0);
this.groupingSize=(groupingCount > 0) ? groupingCount : ($b$[0] = 0, $b$[0]);
this.multiplier=multiplier;
this.setDecimalSeparatorAlwaysShown$Z(decimalPos == 0 || decimalPos == digitTotalCount );
} else {
this.negPrefixPattern=prefix[0];
this.negSuffixPattern=suffix[0];
gotNegative=true;
}}
if (pattern.length$() == 0) {
this.posPrefixPattern=this.posSuffixPattern="";
this.setMinimumIntegerDigits$I(0);
this.setMaximumIntegerDigits$I(2147483647);
this.setMinimumFractionDigits$I(0);
this.setMaximumFractionDigits$I(2147483647);
}if (!gotNegative || (this.negPrefixPattern.equals$O(this.posPrefixPattern) && this.negSuffixPattern.equals$O(this.posSuffixPattern) ) ) {
this.negSuffixPattern=this.posSuffixPattern;
this.negPrefixPattern="'-" + this.posPrefixPattern;
}p$1.expandAffixes.apply(this, []);
}, p$1);

Clazz_newMeth(C$, 'setMaximumIntegerDigits$I',  function (newValue) {
this.$maximumIntegerDigits=Math.min(Math.max(0, newValue), 2147483647);
C$.superclazz.prototype.setMaximumIntegerDigits$I.apply(this, [(this.$maximumIntegerDigits > 309) ? 309 : this.$maximumIntegerDigits]);
if (this.$minimumIntegerDigits > this.$maximumIntegerDigits) {
this.$minimumIntegerDigits=this.$maximumIntegerDigits;
C$.superclazz.prototype.setMinimumIntegerDigits$I.apply(this, [(this.$minimumIntegerDigits > 309) ? 309 : this.$minimumIntegerDigits]);
}});

Clazz_newMeth(C$, 'setMinimumIntegerDigits$I',  function (newValue) {
this.$minimumIntegerDigits=Math.min(Math.max(0, newValue), 2147483647);
C$.superclazz.prototype.setMinimumIntegerDigits$I.apply(this, [(this.$minimumIntegerDigits > 309) ? 309 : this.$minimumIntegerDigits]);
if (this.$minimumIntegerDigits > this.$maximumIntegerDigits) {
this.$maximumIntegerDigits=this.$minimumIntegerDigits;
C$.superclazz.prototype.setMaximumIntegerDigits$I.apply(this, [(this.$maximumIntegerDigits > 309) ? 309 : this.$maximumIntegerDigits]);
}});

Clazz_newMeth(C$, 'setMaximumFractionDigits$I',  function (newValue) {
this.$maximumFractionDigits=Math.min(Math.max(0, newValue), 2147483647);
C$.superclazz.prototype.setMaximumFractionDigits$I.apply(this, [(this.$maximumFractionDigits > 340) ? 340 : this.$maximumFractionDigits]);
if (this.$minimumFractionDigits > this.$maximumFractionDigits) {
this.$minimumFractionDigits=this.$maximumFractionDigits;
C$.superclazz.prototype.setMinimumFractionDigits$I.apply(this, [(this.$minimumFractionDigits > 340) ? 340 : this.$minimumFractionDigits]);
}});

Clazz_newMeth(C$, 'setMinimumFractionDigits$I',  function (newValue) {
this.$minimumFractionDigits=Math.min(Math.max(0, newValue), 2147483647);
C$.superclazz.prototype.setMinimumFractionDigits$I.apply(this, [(this.$minimumFractionDigits > 340) ? 340 : this.$minimumFractionDigits]);
if (this.$minimumFractionDigits > this.$maximumFractionDigits) {
this.$maximumFractionDigits=this.$minimumFractionDigits;
C$.superclazz.prototype.setMaximumFractionDigits$I.apply(this, [(this.$maximumFractionDigits > 340) ? 340 : this.$maximumFractionDigits]);
}});

Clazz_newMeth(C$, 'getMaximumIntegerDigits$',  function () {
return this.$maximumIntegerDigits;
});

Clazz_newMeth(C$, 'getMinimumIntegerDigits$',  function () {
return this.$minimumIntegerDigits;
});

Clazz_newMeth(C$, 'getMaximumFractionDigits$',  function () {
return this.$maximumFractionDigits;
});

Clazz_newMeth(C$, 'getMinimumFractionDigits$',  function () {
return this.$minimumFractionDigits;
});

Clazz_newMeth(C$, 'getCurrency$',  function () {
return this.symbols.getCurrency$();
});

Clazz_newMeth(C$, 'setCurrency$java_util_Currency',  function (currency) {
if (currency !== this.symbols.getCurrency$() ) {
this.symbols.setCurrency$java_util_Currency(currency);
if (this.isCurrencyFormat) {
p$1.expandAffixes.apply(this, []);
}}});

Clazz_newMeth(C$, 'getRoundingMode$',  function () {
return this.roundingMode;
});

Clazz_newMeth(C$, 'setRoundingMode$java_math_RoundingMode',  function (roundingMode) {
if (roundingMode == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}this.roundingMode=roundingMode;
this.digitList.setRoundingMode$java_math_RoundingMode(roundingMode);
});

Clazz_newMeth(C$, 'adjustForCurrencyDefaultFractionDigits$',  function () {
var digits=2;
var oldMinDigits=this.getMinimumFractionDigits$();
if (oldMinDigits == this.getMaximumFractionDigits$()) {
this.setMinimumFractionDigits$I(digits);
this.setMaximumFractionDigits$I(digits);
} else {
this.setMinimumFractionDigits$I(Math.min(digits, oldMinDigits));
this.setMaximumFractionDigits$I(digits);
}});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.EmptyFieldPositionArray=Clazz_array($I$(1), [0]);
C$.$cachedLocaleData=Clazz_new_($I$(2,1).c$$I,[3]);
};
var $b$ = new Int8Array(1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),p$1={},I$=[[0,'java.util.Hashtable','java.util.Locale','java.util.Currency','InternalError','sun.util.resources.LocaleData']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "DecimalFormatSymbols", null, null, 'Cloneable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.serialVersionOnStream=3;
},1);

C$.$fields$=[['C',['zeroDigit','groupingSeparator','decimalSeparator','perMill','percent','digit','patternSeparator','minusSign','monetarySeparator','exponential'],'I',['serialVersionOnStream'],'S',['infinity','NaN','currencySymbol','intlCurrencySymbol','exponentialSeparator'],'O',['currency','java.util.Currency','locale','java.util.Locale']]
,['O',['cachedLocaleData','java.util.Hashtable']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.initialize$java_util_Locale.apply(this, [$I$(2).getDefault$()]);
}, 1);

Clazz_newMeth(C$, 'c$$java_util_Locale',  function (locale) {
;C$.$init$.apply(this);
p$1.initialize$java_util_Locale.apply(this, [locale]);
}, 1);

Clazz_newMeth(C$, 'getInstance$',  function () {
return C$.getInstance$java_util_Locale($I$(2).getDefault$());
}, 1);

Clazz_newMeth(C$, 'getInstance$java_util_Locale',  function (locale) {
return Clazz_new_(C$.c$$java_util_Locale,[locale]);
}, 1);

Clazz_newMeth(C$, 'getZeroDigit$',  function () {
return this.zeroDigit;
});

Clazz_newMeth(C$, 'setZeroDigit$C',  function (zeroDigit) {
this.zeroDigit=zeroDigit;
});

Clazz_newMeth(C$, 'getGroupingSeparator$',  function () {
return this.groupingSeparator;
});

Clazz_newMeth(C$, 'setGroupingSeparator$C',  function (groupingSeparator) {
this.groupingSeparator=groupingSeparator;
});

Clazz_newMeth(C$, 'getDecimalSeparator$',  function () {
return this.decimalSeparator;
});

Clazz_newMeth(C$, 'setDecimalSeparator$C',  function (decimalSeparator) {
this.decimalSeparator=decimalSeparator;
});

Clazz_newMeth(C$, 'getPerMill$',  function () {
return this.perMill;
});

Clazz_newMeth(C$, 'setPerMill$C',  function (perMill) {
this.perMill=perMill;
});

Clazz_newMeth(C$, 'getPercent$',  function () {
return this.percent;
});

Clazz_newMeth(C$, 'setPercent$C',  function (percent) {
this.percent=percent;
});

Clazz_newMeth(C$, 'getDigit$',  function () {
return this.digit;
});

Clazz_newMeth(C$, 'setDigit$C',  function (digit) {
this.digit=digit;
});

Clazz_newMeth(C$, 'getPatternSeparator$',  function () {
return this.patternSeparator;
});

Clazz_newMeth(C$, 'setPatternSeparator$C',  function (patternSeparator) {
this.patternSeparator=patternSeparator;
});

Clazz_newMeth(C$, 'getInfinity$',  function () {
return this.infinity;
});

Clazz_newMeth(C$, 'setInfinity$S',  function (infinity) {
this.infinity=infinity;
});

Clazz_newMeth(C$, 'getNaN$',  function () {
return this.NaN;
});

Clazz_newMeth(C$, 'setNaN$S',  function (NaN) {
this.NaN=NaN;
});

Clazz_newMeth(C$, 'getMinusSign$',  function () {
return this.minusSign;
});

Clazz_newMeth(C$, 'setMinusSign$C',  function (minusSign) {
this.minusSign=minusSign;
});

Clazz_newMeth(C$, 'getCurrencySymbol$',  function () {
return this.currencySymbol;
});

Clazz_newMeth(C$, 'setCurrencySymbol$S',  function (currency) {
this.currencySymbol=currency;
});

Clazz_newMeth(C$, 'getInternationalCurrencySymbol$',  function () {
return this.intlCurrencySymbol;
});

Clazz_newMeth(C$, 'setInternationalCurrencySymbol$S',  function (currencyCode) {
this.intlCurrencySymbol=currencyCode;
this.currency=null;
if (currencyCode != null ) {
try {
this.currency=$I$(3).getInstance$S(currencyCode);
this.currencySymbol=this.currency.getSymbol$();
} catch (e) {
if (Clazz_exceptionOf(e,"IllegalArgumentException")){
} else {
throw e;
}
}
}});

Clazz_newMeth(C$, 'getCurrency$',  function () {
return this.currency;
});

Clazz_newMeth(C$, 'setCurrency$java_util_Currency',  function (currency) {
if (currency == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}this.currency=currency;
this.intlCurrencySymbol=currency.getCurrencyCode$();
this.currencySymbol=currency.getSymbol$java_util_Locale(this.locale);
});

Clazz_newMeth(C$, 'getMonetaryDecimalSeparator$',  function () {
return this.monetarySeparator;
});

Clazz_newMeth(C$, 'setMonetaryDecimalSeparator$C',  function (sep) {
this.monetarySeparator=sep;
});

Clazz_newMeth(C$, 'getExponentialSymbol$',  function () {
return this.exponential;
});

Clazz_newMeth(C$, 'getExponentSeparator$',  function () {
return this.exponentialSeparator;
});

Clazz_newMeth(C$, 'setExponentialSymbol$C',  function (exp) {
this.exponential=exp;
});

Clazz_newMeth(C$, 'setExponentSeparator$S',  function (exp) {
if (exp == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}this.exponentialSeparator=exp;
});

Clazz_newMeth(C$, 'clone$',  function () {
try {
return Clazz_clone(this);
} catch (e) {
if (Clazz_exceptionOf(e,"CloneNotSupportedException")){
throw Clazz_new_($I$(4,1));
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if (obj == null ) return false;
if (this === obj ) return true;
if (this.getClass$() !== obj.getClass$() ) return false;
var other=obj;
return (this.zeroDigit == other.zeroDigit && this.groupingSeparator == other.groupingSeparator  && this.decimalSeparator == other.decimalSeparator  && this.percent == other.percent  && this.perMill == other.perMill  && this.digit == other.digit  && this.minusSign == other.minusSign  && this.patternSeparator == other.patternSeparator  && this.infinity.equals$O(other.infinity)  && this.NaN.equals$O(other.NaN)  && this.currencySymbol.equals$O(other.currencySymbol)  && this.intlCurrencySymbol.equals$O(other.intlCurrencySymbol)  && this.monetarySeparator == other.monetarySeparator  && this.exponentialSeparator.equals$O(other.exponentialSeparator)  && this.locale.equals$O(other.locale) );
});

Clazz_newMeth(C$, 'hashCode$',  function () {
var result=this.zeroDigit.$c();
result=result * 37 + this.groupingSeparator.$c();
result=result * 37 + this.decimalSeparator.$c();
return result;
});

Clazz_newMeth(C$, 'initialize$java_util_Locale',  function (locale) {
this.locale=locale;
var needCacheUpdate=false;
var data=C$.cachedLocaleData.get$O(locale.toString());
if (data == null ) {
data=Clazz_array(java.lang.Object, [3]);
var rb=$I$(5).getNumberFormatData$java_util_Locale(locale);
data[0]=rb.getStringArray$S("NumberElements");
needCacheUpdate=true;
}var numberElements=data[0];
this.decimalSeparator=numberElements[0].charAt$I(0);
this.groupingSeparator=numberElements[1].charAt$I(0);
this.patternSeparator=numberElements[2].charAt$I(0);
this.percent=numberElements[3].charAt$I(0);
this.zeroDigit=numberElements[4].charAt$I(0);
this.digit=numberElements[5].charAt$I(0);
this.minusSign=numberElements[6].charAt$I(0);
this.exponential=numberElements[7].charAt$I(0);
this.exponentialSeparator=numberElements[7];
this.perMill=numberElements[8].charAt$I(0);
this.infinity=numberElements[9];
this.NaN=numberElements[10];
this.intlCurrencySymbol="\u00a4";
this.currencySymbol="$";
this.monetarySeparator=this.decimalSeparator;
if (needCacheUpdate) {
C$.cachedLocaleData.put$O$O(locale.toString(), data);
}}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.cachedLocaleData=Clazz_new_($I$(1,1).c$$I,[3]);
};
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),p$1={},I$=[[0,'java.math.RoundingMode','java.math.BigDecimal','InternalError']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "DigitList", null, null, 'Cloneable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.decimalAt=0;
this.count=0;
this.digits=Clazz_array(Character.TYPE, [19]);
this.roundingMode=$I$(1).HALF_EVEN;
this.isNegative=false;
},1);

C$.$fields$=[['Z',['isNegative'],'I',['decimalAt','count'],'O',['+digits','+data','roundingMode','java.math.RoundingMode']]
,['O',['LONG_MIN_REP','char[]']]]

Clazz_newMeth(C$, 'isZero$',  function () {
for (var i=0; i < this.count; ++i) {
if (this.digits[i] != "0") {
return false;
}}
return true;
});

Clazz_newMeth(C$, 'setRoundingMode$java_math_RoundingMode',  function (r) {
this.roundingMode=r;
});

Clazz_newMeth(C$, 'clear$',  function () {
this.decimalAt=0;
this.count=0;
});

Clazz_newMeth(C$, 'append$C',  function (digit) {
if (this.count == this.digits.length) {
var data=Clazz_array(Character.TYPE, [this.count + 100]);
System.arraycopy$O$I$O$I$I(this.digits, 0, data, 0, this.count);
this.digits=data;
}this.digits[this.count++]=digit;
});

Clazz_newMeth(C$, 'getDouble$',  function () {
if (this.count == 0) {
return 0.0;
}return Double.parseDouble$S("." + p$1.秘join$CA$I$I.apply(this, [this.digits, 0, this.count]) + "E" + this.decimalAt );
});

Clazz_newMeth(C$, 'getLong$',  function () {
if (this.count == 0) {
return 0;
}if (p$1.isLongMIN_VALUE.apply(this, [])) {
return [0,549755813888,-1];
}var temp="";
temp+=p$1.秘join$CA$I$I.apply(this, [this.digits, 0, this.count]);
for (var i=this.count; i < this.decimalAt; ++i) {
temp+="0";
}
return Long.parseLong$S(temp);
});

Clazz_newMeth(C$, '秘join$CA$I$I',  function (digits, i, count) {
return (digits.slice(i, i + count).join("") ||null);
}, p$1);

Clazz_newMeth(C$, 'getBigDecimal$',  function () {
if (this.count == 0) {
if (this.decimalAt == 0) {
return $I$(2).ZERO;
} else {
return Clazz_new_($I$(2,1).c$$S,["0E" + this.decimalAt]);
}}if (this.decimalAt == this.count) {
return Clazz_new_($I$(2,1).c$$CA$I$I,[this.digits, 0, this.count]);
} else {
return Clazz_new_($I$(2,1).c$$CA$I$I,[this.digits, 0, this.count]).scaleByPowerOfTen$I(this.decimalAt - this.count);
}});

Clazz_newMeth(C$, 'fitsIntoLong$Z$Z',  function (isPositive, ignoreNegativeZero) {
while (this.count > 0 && this.digits[this.count - 1] == "0" ){
--this.count;
}
if (this.count == 0) {
return isPositive || ignoreNegativeZero ;
}if (this.decimalAt < this.count || this.decimalAt > 19 ) {
return false;
}if (this.decimalAt < 19) return true;
for (var i=0; i < this.count; ++i) {
var dig=this.digits[i];
var max=C$.LONG_MIN_REP[i];
if (dig > max) return false;
if (dig < max) return true;
}
if (this.count < this.decimalAt) return true;
return !isPositive;
});

Clazz_newMeth(C$, 'setDouble$Z$D$I',  function (isNegative, source, maximumFractionDigits) {
this.set$Z$D$I$Z(isNegative, source, maximumFractionDigits, true);
});

Clazz_newMeth(C$, 'set$Z$D$I$Z',  function (isNegative, source, maximumDigits, fixedPoint) {
this.set$Z$S$I$Z(isNegative, Double.toString$D(source), maximumDigits, fixedPoint);
});

Clazz_newMeth(C$, 'set$Z$S$I$Z',  function (isNegative, s, maximumDigits, fixedPoint) {
this.isNegative=isNegative;
var len=s.length$();
var source=p$1.getDataChars$I.apply(this, [len]);
s.getChars$I$I$CA$I(0, len, source, 0);
this.decimalAt=-1;
this.count=0;
var exponent=0;
var leadingZerosAfterDecimal=0;
var nonZeroDigitSeen=false;
for (var i=0; i < len; ) {
var c=source[i++];
if (c == ".") {
this.decimalAt=this.count;
} else if (c == "e" || c == "E" ) {
exponent=C$.parseInt$CA$I$I(source, i, len);
break;
} else {
if (!nonZeroDigitSeen) {
nonZeroDigitSeen=(c != "0");
if (!nonZeroDigitSeen && this.decimalAt != -1 ) ++leadingZerosAfterDecimal;
}if (nonZeroDigitSeen) {
this.digits[this.count++]=c;
}}}
if (this.decimalAt == -1) {
this.decimalAt=this.count;
}if (nonZeroDigitSeen) {
this.decimalAt+=exponent - leadingZerosAfterDecimal;
}if (fixedPoint) {
if (-this.decimalAt > maximumDigits) {
this.count=0;
return;
} else if (-this.decimalAt == maximumDigits) {
if (p$1.shouldRoundUp$I.apply(this, [0])) {
this.count=1;
++this.decimalAt;
this.digits[0]="1";
} else {
this.count=0;
}return;
}}while (this.count > 1 && this.digits[this.count - 1] == "0" ){
--this.count;
}
p$1.round$I.apply(this, [fixedPoint ? (maximumDigits + this.decimalAt) : maximumDigits]);
});

Clazz_newMeth(C$, 'round$I',  function (maximumDigits) {
if (maximumDigits >= 0 && maximumDigits < this.count ) {
if (p$1.shouldRoundUp$I.apply(this, [maximumDigits])) {
for (; ; ) {
--maximumDigits;
if (maximumDigits < 0) {
this.digits[0]="1";
++this.decimalAt;
maximumDigits=0;
break;
}(this.digits[maximumDigits]=String.fromCharCode(this.digits[maximumDigits].$c()+1));
if (this.digits[maximumDigits] <= "9") break;
}
++maximumDigits;
}this.count=maximumDigits;
while (this.count > 1 && this.digits[this.count - 1] == "0" ){
--this.count;
}
}}, p$1);

Clazz_newMeth(C$, 'shouldRoundUp$I',  function (maximumDigits) {
if (maximumDigits < this.count) {
switch (this.roundingMode) {
case $I$(1).UP:
for (var i=maximumDigits; i < this.count; ++i) {
if (this.digits[i] != "0") {
return true;
}}
break;
case $I$(1).DOWN:
break;
case $I$(1).CEILING:
for (var i=maximumDigits; i < this.count; ++i) {
if (this.digits[i] != "0") {
return !this.isNegative;
}}
break;
case $I$(1).FLOOR:
for (var i=maximumDigits; i < this.count; ++i) {
if (this.digits[i] != "0") {
return this.isNegative;
}}
break;
case $I$(1).HALF_UP:
if (this.digits[maximumDigits] >= "5") {
return true;
}break;
case $I$(1).HALF_DOWN:
if (this.digits[maximumDigits] > "5") {
return true;
} else if (this.digits[maximumDigits] == "5") {
for (var i=maximumDigits + 1; i < this.count; ++i) {
if (this.digits[i] != "0") {
return true;
}}
}break;
case $I$(1).HALF_EVEN:
if (this.digits[maximumDigits] > "5") {
return true;
} else if (this.digits[maximumDigits] == "5") {
for (var i=maximumDigits + 1; i < this.count; ++i) {
if (this.digits[i] != "0") {
return true;
}}
return maximumDigits > 0 && ((this.digits[maximumDigits - 1]).$c() % 2 != 0) ;
}break;
case $I$(1).UNNECESSARY:
for (var i=maximumDigits; i < this.count; ++i) {
if (this.digits[i] != "0") {
throw Clazz_new_(Clazz_load('ArithmeticException').c$$S,["Rounding needed with the rounding mode being set to RoundingMode.UNNECESSARY"]);
}}
break;
default:
Clazz_assert(C$, this, function(){return false});
}
}return false;
}, p$1);

Clazz_newMeth(C$, 'setExp$Z$J',  function (isNegative, source) {
this.setLong$Z$J$I(isNegative, source, 0);
});

Clazz_newMeth(C$, 'setLong$Z$J$I',  function (isNegative, source, maximumDigits) {
this.isNegative=isNegative;
if (Long.$le(source,0 )) {
if (Long.$eq(source,[0,549755813888,-1] )) {
this.decimalAt=this.count=19;
System.arraycopy$O$I$O$I$I(C$.LONG_MIN_REP, 0, this.digits, 0, this.count);
} else {
this.decimalAt=this.count=0;
}} else {
var left=19;
var right;
while (Long.$ge(source,1 )){
this.digits[--left]=String.fromCharCode((Long.$add(48,(Long.$mod(source,10)))));
source=Long.$div(source,10);
}
this.decimalAt=19 - left;
for (right=18; this.digits[right] == "0"; --right) {
}
this.count=right - left + 1;
System.arraycopy$O$I$O$I$I(this.digits, left, this.digits, 0, this.count);
}if (maximumDigits > 0) p$1.round$I.apply(this, [maximumDigits]);
});

Clazz_newMeth(C$, 'set$Z$java_math_BigDecimal$I$Z',  function (isNegative, source, maximumDigits, fixedPoint) {
var s=source.toString();
p$1.extendDigits$I.apply(this, [s.length$()]);
this.set$Z$S$I$Z(isNegative, s, maximumDigits, fixedPoint);
});

Clazz_newMeth(C$, 'set$Z$java_math_BigInteger$I',  function (isNegative, source, maximumDigits) {
this.isNegative=isNegative;
var s=source.toString();
var len=s.length$();
p$1.extendDigits$I.apply(this, [len]);
s.getChars$I$I$CA$I(0, len, this.digits, 0);
this.decimalAt=len;
var right;
for (right=len - 1; right >= 0 && this.digits[right] == "0" ; --right) ;
this.count=right + 1;
if (maximumDigits > 0) {
p$1.round$I.apply(this, [maximumDigits]);
}});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if (this === obj ) return true;
if (!(Clazz_instanceOf(obj, "java.text.DigitList"))) return false;
var other=obj;
if (this.count != other.count || this.decimalAt != other.decimalAt ) return false;
for (var i=0; i < this.count; i++) if (this.digits[i] != other.digits[i]) return false;

return true;
});

Clazz_newMeth(C$, 'hashCode$',  function () {
var hashcode=this.decimalAt;
for (var i=0; i < this.count; i++) {
hashcode=hashcode * 37 + (this.digits[i]).$c();
}
return hashcode;
});

Clazz_newMeth(C$, 'clone$',  function () {
try {
var other=Clazz_clone(this);
var newDigits=Clazz_array(Character.TYPE, [this.digits.length]);
System.arraycopy$O$I$O$I$I(this.digits, 0, newDigits, 0, this.digits.length);
other.digits=newDigits;
return other;
} catch (e) {
if (Clazz_exceptionOf(e,"CloneNotSupportedException")){
throw Clazz_new_($I$(3,1));
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'isLongMIN_VALUE',  function () {
if (this.decimalAt != this.count || this.count != 19 ) {
return false;
}for (var i=0; i < this.count; ++i) {
if (this.digits[i] != C$.LONG_MIN_REP[i]) return false;
}
return true;
}, p$1);

Clazz_newMeth(C$, 'parseInt$CA$I$I',  function (str, offset, strLen) {
var c;
var positive=true;
if ((c=str[offset]) == "-") {
positive=false;
++offset;
} else if (c == "+") {
++offset;
}var value=0;
while (offset < strLen){
c=str[offset++];
if (c >= "0" && c <= "9" ) {
value=value * 10 + (c.$c() - 48);
} else {
break;
}}
return positive ? value : -value;
}, 1);

Clazz_newMeth(C$, 'toString',  function () {
if (this.isZero$()) {
return "0";
}return "0." + p$1.秘join$CA$I$I.apply(this, [this.digits, 0, this.count]) + "x10^" + this.decimalAt ;
});

Clazz_newMeth(C$, 'extendDigits$I',  function (len) {
if (len > this.digits.length) {
this.digits=Clazz_array(Character.TYPE, [len]);
}}, p$1);

Clazz_newMeth(C$, 'getDataChars$I',  function (length) {
if (this.data == null  || this.data.length < length ) {
this.data=Clazz_array(Character.TYPE, [length]);
}return this.data;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.LONG_MIN_REP="9223372036854775808".toCharArray$();
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "DontCareFieldPosition", null, 'java.text.FieldPosition');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.noDelegate=((P$.DontCareFieldPosition$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "DontCareFieldPosition$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, [['java.text.Format','java.text.Format.FieldDelegate']], 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz_newMeth(C$, 'formatted$java_text_Format_Field$O$I$I$StringBuffer',  function (attr, value, start, end, buffer) {
});

Clazz_newMeth(C$, 'formatted$I$java_text_Format_Field$O$I$I$StringBuffer',  function (fieldID, attr, value, start, end, buffer) {
});

Clazz_newMeth(C$, 'formatted$java_text_Format_Field$O$I$I$SA',  function (attr, value, start, end, buffer) {
});

Clazz_newMeth(C$, 'formatted$I$java_text_Format_Field$O$I$I$SA',  function (fieldID, attr, value, start, end, buffer) {
});
})()
), Clazz_new_(P$.DontCareFieldPosition$1.$init$,[this, null]));
},1);

C$.$fields$=[['O',['noDelegate','java.text.Format.FieldDelegate']]
,['O',['INSTANCE','java.text.FieldPosition']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$I.apply(this,[0]);C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'getFieldDelegate$',  function () {
return this.noDelegate;
});

C$.$static$=function(){C$.$static$=0;
C$.INSTANCE=Clazz_new_(C$);
};
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),p$1={},I$=[[0,['java.text.FieldPosition','.Delegate']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "FieldPosition", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Delegate',2]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.field=0;
this.endIndex=0;
this.beginIndex=0;
},1);

C$.$fields$=[['I',['field','endIndex','beginIndex'],'O',['attribute','java.text.Format.Field']]]

Clazz_newMeth(C$, 'c$$I',  function (field) {
;C$.$init$.apply(this);
this.field=field;
}, 1);

Clazz_newMeth(C$, 'c$$java_text_Format_Field',  function (attribute) {
C$.c$$java_text_Format_Field$I.apply(this, [attribute, -1]);
}, 1);

Clazz_newMeth(C$, 'c$$java_text_Format_Field$I',  function (attribute, fieldID) {
;C$.$init$.apply(this);
this.attribute=attribute;
this.field=fieldID;
}, 1);

Clazz_newMeth(C$, 'getFieldAttribute$',  function () {
return this.attribute;
});

Clazz_newMeth(C$, 'getField$',  function () {
return this.field;
});

Clazz_newMeth(C$, 'getBeginIndex$',  function () {
return this.beginIndex;
});

Clazz_newMeth(C$, 'getEndIndex$',  function () {
return this.endIndex;
});

Clazz_newMeth(C$, 'setBeginIndex$I',  function (bi) {
this.beginIndex=bi;
});

Clazz_newMeth(C$, 'setEndIndex$I',  function (ei) {
this.endIndex=ei;
});

Clazz_newMeth(C$, 'getFieldDelegate$',  function () {
return Clazz_new_($I$(1,1),[this, null]);
});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if (obj == null ) return false;
if (!(Clazz_instanceOf(obj, "java.text.FieldPosition"))) return false;
var other=obj;
if (this.attribute == null ) {
if (other.attribute != null ) {
return false;
}} else if (!this.attribute.equals$O(other.attribute)) {
return false;
}return (this.beginIndex == other.beginIndex && this.endIndex == other.endIndex  && this.field == other.field );
});

Clazz_newMeth(C$, 'hashCode$',  function () {
return (this.field << 24) | (this.beginIndex << 16) | this.endIndex ;
});

Clazz_newMeth(C$, 'toString',  function () {
return this.getClass$().getName$() + "[field=" + this.field + ",attribute=" + this.attribute + ",beginIndex=" + this.beginIndex + ",endIndex=" + this.endIndex + ']' ;
});

Clazz_newMeth(C$, 'matchesField$java_text_Format_Field',  function (attribute) {
if (this.attribute != null ) {
return this.attribute.equals$O(attribute);
}return false;
}, p$1);

Clazz_newMeth(C$, 'matchesField$java_text_Format_Field$I',  function (attribute, field) {
if (this.attribute != null ) {
return this.attribute.equals$O(attribute);
}return (field == this.field);
}, p$1);
;
(function(){/*c*/var C$=Clazz_newClass(P$.FieldPosition, "Delegate", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, null, [['java.text.Format','java.text.Format.FieldDelegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['encounteredField']]]

Clazz_newMeth(C$, 'formatted$java_text_Format_Field$O$I$I$StringBuffer',  function (attr, value, start, end, buffer) {
if (!this.encounteredField && p$1.matchesField$java_text_Format_Field.apply(this.b$['java.text.FieldPosition'], [attr]) ) {
this.b$['java.text.FieldPosition'].setBeginIndex$I.apply(this.b$['java.text.FieldPosition'], [start]);
this.b$['java.text.FieldPosition'].setEndIndex$I.apply(this.b$['java.text.FieldPosition'], [end]);
this.encounteredField=(start != end);
}});

Clazz_newMeth(C$, 'formatted$I$java_text_Format_Field$O$I$I$StringBuffer',  function (fieldID, attr, value, start, end, buffer) {
if (!this.encounteredField && p$1.matchesField$java_text_Format_Field$I.apply(this.b$['java.text.FieldPosition'], [attr, fieldID]) ) {
this.b$['java.text.FieldPosition'].setBeginIndex$I.apply(this.b$['java.text.FieldPosition'], [start]);
this.b$['java.text.FieldPosition'].setEndIndex$I.apply(this.b$['java.text.FieldPosition'], [end]);
this.encounteredField=(start != end);
}});

Clazz_newMeth(C$, 'formatted$I$java_text_Format_Field$O$I$I$SA',  function (fieldID, attr, value, start, end, buffer) {
if (!this.encounteredField && p$1.matchesField$java_text_Format_Field$I.apply(this.b$['java.text.FieldPosition'], [attr, fieldID]) ) {
this.b$['java.text.FieldPosition'].setBeginIndex$I.apply(this.b$['java.text.FieldPosition'], [start]);
this.b$['java.text.FieldPosition'].setEndIndex$I.apply(this.b$['java.text.FieldPosition'], [end]);
this.encounteredField=(start != end);
}});

Clazz_newMeth(C$, 'formatted$java_text_Format_Field$O$I$I$SA',  function (attr, value, start, end, buffer) {
if (!this.encounteredField && p$1.matchesField$java_text_Format_Field.apply(this.b$['java.text.FieldPosition'], [attr]) ) {
this.b$['java.text.FieldPosition'].setBeginIndex$I.apply(this.b$['java.text.FieldPosition'], [start]);
this.b$['java.text.FieldPosition'].setEndIndex$I.apply(this.b$['java.text.FieldPosition'], [end]);
this.encounteredField=(start != end);
}});

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),I$=[[0,'StringBuffer','java.text.FieldPosition','java.text.ParsePosition','java.text.AttributedString']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Format", function(){
Clazz_newInstance(this, arguments,0,C$);
}, null, ['java.io.Serializable', 'Cloneable']);
C$.$classes$=[['Field',9],['FieldDelegate',8]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'format$O',  function (obj) {
return this.format$O$StringBuffer$java_text_FieldPosition(obj, Clazz_new_($I$(1,1)), Clazz_new_($I$(2,1).c$$I,[0])).toString();
});

Clazz_newMeth(C$, 'formatToCharacterIterator$O',  function (obj) {
return this.createAttributedCharacterIterator$S(this.format$O(obj));
});

Clazz_newMeth(C$, 'parseObject$S',  function (source) {
var pos=Clazz_new_($I$(3,1).c$$I,[0]);
var result=this.parseObject$S$java_text_ParsePosition(source, pos);
if (pos.index == 0) {
throw Clazz_new_(Clazz_load('java.text.ParseException').c$$S$I,["Format.parseObject(String) failed", pos.errorIndex]);
}return result;
});

Clazz_newMeth(C$, 'clone$',  function () {
try {
return Clazz_clone(this);
} catch (e) {
if (Clazz_exceptionOf(e,"CloneNotSupportedException")){
return null;
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'createAttributedCharacterIterator$S',  function (s) {
var as=Clazz_new_($I$(4,1).c$$S,[s]);
return as.getIterator$();
});

Clazz_newMeth(C$, 'createAttributedCharacterIterator$java_text_AttributedCharacterIteratorA',  function (iterators) {
var as=Clazz_new_($I$(4,1).c$$java_text_AttributedCharacterIteratorA,[iterators]);
return as.getIterator$();
});

Clazz_newMeth(C$, 'createAttributedCharacterIterator$S$java_text_AttributedCharacterIterator_Attribute$O',  function (string, key, value) {
var as=Clazz_new_($I$(4,1).c$$S,[string]);
as.addAttribute$java_text_AttributedCharacterIterator_Attribute$O(key, value);
return as.getIterator$();
});

Clazz_newMeth(C$, 'createAttributedCharacterIterator$java_text_AttributedCharacterIterator$java_text_AttributedCharacterIterator_Attribute$O',  function (iterator, key, value) {
var as=Clazz_new_($I$(4,1).c$$java_text_AttributedCharacterIterator,[iterator]);
as.addAttribute$java_text_AttributedCharacterIterator_Attribute$O(key, value);
return as.getIterator$();
});
;
(function(){/*c*/var C$=Clazz_newClass(P$.Format, "Field", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['java.text.AttributedCharacterIterator','.Attribute']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$$S',  function (name) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$);
})()
;
(function(){/*i*/var C$=Clazz_newInterface(P$.Format, "FieldDelegate", function(){
});
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.text"),I$=[[0,'java.util.HashMap','java.util.Hashtable','java.text.DontCareFieldPosition','java.text.ParsePosition','java.util.Locale','sun.util.resources.LocaleData','java.text.DecimalFormatSymbols','java.text.DecimalFormat','StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "NumberFormat", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'java.text.Format');
C$.$classes$=[['Field',9]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.groupingUsed=true;
this.maxFractionDigits=($b$[0] = 3, $b$[0]);
this.parseIntegerOnly=false;
this.maximumIntegerDigits=40;
this.minimumIntegerDigits=1;
this.maximumFractionDigits=3;
this.minimumFractionDigits=0;
},1);

C$.$fields$=[['Z',['groupingUsed','parseIntegerOnly'],'B',['maxFractionDigits'],'I',['maximumIntegerDigits','minimumIntegerDigits','maximumFractionDigits','minimumFractionDigits']]
,['O',['cachedLocaleData','java.util.Hashtable']]]

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
}, 1);

Clazz_newMeth(C$, 'format$O$StringBuffer$java_text_FieldPosition',  function (number, toAppendTo, pos) {
if (Clazz_instanceOf(number, "java.lang.Long") || Clazz_instanceOf(number, "java.lang.Integer") || Clazz_instanceOf(number, "java.lang.Short") || Clazz_instanceOf(number, "java.lang.Byte")  ) {
return this.format$J$StringBuffer$java_text_FieldPosition((number).longValue$(), toAppendTo, pos);
} else if (Clazz_instanceOf(number, "java.lang.Number")) {
return this.format$D$StringBuffer$java_text_FieldPosition((number).doubleValue$(), toAppendTo, pos);
} else {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Cannot format given Object as a Number"]);
}});

Clazz_newMeth(C$, 'parseObject$S$java_text_ParsePosition',  function (source, pos) {
return this.parse$S$java_text_ParsePosition(source, pos);
});

Clazz_newMeth(C$, 'format$D',  function (number) {
return this.format$D$StringBuffer$java_text_FieldPosition(number, this.秘newStringBuffer$Z(true), $I$(3).INSTANCE).toString();
});

Clazz_newMeth(C$, 'format$J',  function (number) {
return this.format$J$StringBuffer$java_text_FieldPosition(number, this.秘newStringBuffer$Z(false), $I$(3).INSTANCE).toString();
});

Clazz_newMeth(C$, 'parse$S',  function (source) {
var parsePosition=Clazz_new_($I$(4,1).c$$I,[0]);
var result=this.parse$S$java_text_ParsePosition(source, parsePosition);
if (parsePosition.index == 0) {
throw Clazz_new_(Clazz_load('java.text.ParseException').c$$S$I,["Unparseable number: \"" + source + "\"" , parsePosition.errorIndex]);
}return result;
});

Clazz_newMeth(C$, 'isParseIntegerOnly$',  function () {
return this.parseIntegerOnly;
});

Clazz_newMeth(C$, 'setParseIntegerOnly$Z',  function (value) {
this.parseIntegerOnly=value;
});

Clazz_newMeth(C$, 'getInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 0);
}, 1);

Clazz_newMeth(C$, 'getInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 0);
}, 1);

Clazz_newMeth(C$, 'getNumberInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 0);
}, 1);

Clazz_newMeth(C$, 'getNumberInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 0);
}, 1);

Clazz_newMeth(C$, 'getIntegerInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 4);
}, 1);

Clazz_newMeth(C$, 'getIntegerInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 4);
}, 1);

Clazz_newMeth(C$, 'getCurrencyInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 1);
}, 1);

Clazz_newMeth(C$, 'getCurrencyInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 1);
}, 1);

Clazz_newMeth(C$, 'getPercentInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 2);
}, 1);

Clazz_newMeth(C$, 'getPercentInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 2);
}, 1);

Clazz_newMeth(C$, 'getScientificInstance$',  function () {
return C$.getInstance$java_util_Locale$I($I$(5).getDefault$(), 3);
}, 1);

Clazz_newMeth(C$, 'getScientificInstance$java_util_Locale',  function (inLocale) {
return C$.getInstance$java_util_Locale$I(inLocale, 3);
}, 1);

Clazz_newMeth(C$, 'hashCode$',  function () {
return this.maximumIntegerDigits * 37 + this.maxFractionDigits;
});

Clazz_newMeth(C$, 'equals$O',  function (obj) {
if (obj == null ) {
return false;
}if (this === obj ) {
return true;
}if (this.getClass$() !== obj.getClass$() ) {
return false;
}var other=obj;
return (this.maximumIntegerDigits == other.maximumIntegerDigits && this.minimumIntegerDigits == other.minimumIntegerDigits  && this.maximumFractionDigits == other.maximumFractionDigits  && this.minimumFractionDigits == other.minimumFractionDigits  && this.groupingUsed == other.groupingUsed   && this.parseIntegerOnly == other.parseIntegerOnly  );
});

Clazz_newMeth(C$, 'clone$',  function () {
var other=C$.superclazz.prototype.clone$.apply(this, []);
return other;
});

Clazz_newMeth(C$, 'isGroupingUsed$',  function () {
return this.groupingUsed;
});

Clazz_newMeth(C$, 'setGroupingUsed$Z',  function (newValue) {
this.groupingUsed=newValue;
});

Clazz_newMeth(C$, 'getMaximumIntegerDigits$',  function () {
return this.maximumIntegerDigits;
});

Clazz_newMeth(C$, 'setMaximumIntegerDigits$I',  function (newValue) {
this.maximumIntegerDigits=Math.max(0, newValue);
if (this.minimumIntegerDigits > this.maximumIntegerDigits) {
this.minimumIntegerDigits=this.maximumIntegerDigits;
}});

Clazz_newMeth(C$, 'getMinimumIntegerDigits$',  function () {
return this.minimumIntegerDigits;
});

Clazz_newMeth(C$, 'setMinimumIntegerDigits$I',  function (newValue) {
this.minimumIntegerDigits=Math.max(0, newValue);
if (this.minimumIntegerDigits > this.maximumIntegerDigits) {
this.maximumIntegerDigits=this.minimumIntegerDigits;
}});

Clazz_newMeth(C$, 'getMaximumFractionDigits$',  function () {
return this.maximumFractionDigits;
});

Clazz_newMeth(C$, 'setMaximumFractionDigits$I',  function (newValue) {
this.maximumFractionDigits=Math.max(0, newValue);
if (this.maximumFractionDigits < this.minimumFractionDigits) {
this.minimumFractionDigits=this.maximumFractionDigits;
}});

Clazz_newMeth(C$, 'getMinimumFractionDigits$',  function () {
return this.minimumFractionDigits;
});

Clazz_newMeth(C$, 'setMinimumFractionDigits$I',  function (newValue) {
this.minimumFractionDigits=Math.max(0, newValue);
if (this.maximumFractionDigits < this.minimumFractionDigits) {
this.maximumFractionDigits=this.minimumFractionDigits;
}});

Clazz_newMeth(C$, 'getRoundingMode$',  function () {
throw Clazz_new_(Clazz_load('UnsupportedOperationException'));
});

Clazz_newMeth(C$, 'setRoundingMode$java_math_RoundingMode',  function (roundingMode) {
throw Clazz_new_(Clazz_load('UnsupportedOperationException'));
});

Clazz_newMeth(C$, 'getInstance$java_util_Locale$I',  function (desiredLocale, choice) {
var numberPatterns=C$.cachedLocaleData.get$O(desiredLocale);
if (numberPatterns == null ) {
var resource=$I$(6).getNumberFormatData$java_util_Locale(desiredLocale);
numberPatterns=resource.getStringArray$S("NumberPatterns");
C$.cachedLocaleData.put$O$O(desiredLocale, numberPatterns);
}var symbols=$I$(7).getInstance$java_util_Locale(desiredLocale);
var entry=(choice == 4) ? 0 : choice;
var format=Clazz_new_($I$(8,1).c$$S$java_text_DecimalFormatSymbols,[numberPatterns[entry], symbols]);
if (choice == 4) {
format.setMaximumFractionDigits$I(0);
format.setDecimalSeparatorAlwaysShown$Z(false);
format.setParseIntegerOnly$Z(true);
} else if (choice == 1) {
format.adjustForCurrencyDefaultFractionDigits$();
}return format;
}, 1);

Clazz_newMeth(C$, '秘newStringBuffer$Z',  function (isDouble) {

var c = (isDouble ? this.format$D$StringBuffer$java_text_FieldPosition.exClazz.__CLASS_NAME__ : this.format$J$StringBuffer$java_text_FieldPosition.exClazz.__CLASS_NAME__);
if (c && c.indexOf("java.text.") == 0)return [""];
return Clazz_new_($I$(9,1));
});

Clazz_newMeth(C$, '秘toArray$StringBuffer',  function (ret) {
return Array.isArray(ret) ? ret :Clazz_array(String, -1, [ret.toString()]);
});

Clazz_newMeth(C$, '秘newSA$',  function () {
return [""] ||null;
});

Clazz_newMeth(C$, '秘toSB$SA$StringBuffer',  function (ret, result) {

if (Array.isArray(result)) return ret;
result.setLength$I(0);
result.append$S(ret[0]);
return result;
});

C$.$static$=function(){C$.$static$=0;
C$.cachedLocaleData=Clazz_new_($I$(2,1).c$$I,[3]);
};
var $b$ = new Int8Array(1);
;
(function(){/*c*/var C$=Clazz_newClass(P$.NumberFormat, "Field", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['java.text.Format','.Field']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['$instanceMap','java.util.Map','INTEGER','java.text.NumberFormat.Field','+FRACTION','+EXPONENT','+DECIMAL_SEPARATOR','+SIGN','+GROUPING_SEPARATOR','+EXPONENT_SYMBOL','+PERCENT','+PERMILLE','+CURRENCY','+EXPONENT_SIGN']]]

Clazz_newMeth(C$, 'c$$S',  function (name) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
if (this.getClass$() === Clazz_getClass(C$) ) {
C$.$instanceMap.put$O$O(name, this);
}}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$instanceMap=Clazz_new_($I$(1,1).c$$I,[11]);
C$.INTEGER=Clazz_new_(C$.c$$S,["integer"]);
C$.FRACTION=Clazz_new_(C$.c$$S,["fraction"]);
C$.EXPONENT=Clazz_new_(C$.c$$S,["exponent"]);
C$.DECIMAL_SEPARATOR=Clazz_new_(C$.c$$S,["decimal separator"]);
C$.SIGN=Clazz_new_(C$.c$$S,["sign"]);
C$.GROUPING_SEPARATOR=Clazz_new_(C$.c$$S,["grouping separator"]);
C$.EXPONENT_SYMBOL=Clazz_new_(C$.c$$S,["exponent symbol"]);
C$.PERCENT=Clazz_new_(C$.c$$S,["percent"]);
C$.PERMILLE=Clazz_new_(C$.c$$S,["per mille"]);
C$.CURRENCY=Clazz_new_(C$.c$$S,["currency"]);
C$.EXPONENT_SIGN=Clazz_new_(C$.c$$S,["exponent sign"]);
};

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:17 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.util,p$1={};
/*c*/var C$=Clazz_newClass(P$, "ComparableTimSort");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.minGallop=7;
this.stackSize=0;
},1);

C$.$fields$=[['I',['minGallop','tmpBase','tmpLen','stackSize'],'O',['a','Object[]','+tmp','runBase','int[]','+runLen']]]

Clazz_newMeth(C$, 'c$$OA$OA$I$I',  function (a, work, workBase, workLen) {
;C$.$init$.apply(this);
this.a=a;
var len=a.length;
var tlen=(len < 512) ? len >>> 1 : 256;
if (work == null  || workLen < tlen  || workBase + tlen > work.length ) {
this.tmp=Clazz_array(java.lang.Object, [tlen]);
this.tmpBase=0;
this.tmpLen=tlen;
} else {
this.tmp=work;
this.tmpBase=workBase;
this.tmpLen=workLen;
}var stackLen=(len < 120 ? 5 : len < 1542 ? 10 : len < 119151 ? 24 : 49);
this.runBase=Clazz_array(Integer.TYPE, [stackLen]);
this.runLen=Clazz_array(Integer.TYPE, [stackLen]);
}, 1);

Clazz_newMeth(C$, 'sort$OA$I$I$OA$I$I',  function (a, lo, hi, work, workBase, workLen) {
Clazz_assert(C$, this, function(){return a != null  && lo >= 0  && lo <= hi  && hi <= a.length });
var nRemaining=hi - lo;
if (nRemaining < 2) return;
if (nRemaining < 32) {
var initRunLen=C$.countRunAndMakeAscending$OA$I$I(a, lo, hi);
C$.binarySort$OA$I$I$I(a, lo, hi, lo + initRunLen);
return;
}var ts=Clazz_new_(C$.c$$OA$OA$I$I,[a, work, workBase, workLen]);
var minRun=C$.minRunLength$I(nRemaining);
do {
var runLen=C$.countRunAndMakeAscending$OA$I$I(a, lo, hi);
if (runLen < minRun) {
var force=nRemaining <= minRun ? nRemaining : minRun;
C$.binarySort$OA$I$I$I(a, lo, lo + force, lo + runLen);
runLen=force;
}p$1.pushRun$I$I.apply(ts, [lo, runLen]);
p$1.mergeCollapse.apply(ts, []);
lo+=runLen;
nRemaining-=runLen;
} while (nRemaining != 0);
Clazz_assert(C$, this, function(){return lo == hi});
p$1.mergeForceCollapse.apply(ts, []);
Clazz_assert(C$, this, function(){return ts.stackSize == 1});
}, 1);

Clazz_newMeth(C$, 'binarySort$OA$I$I$I',  function (a, lo, hi, start) {
Clazz_assert(C$, this, function(){return lo <= start && start <= hi });
if (start == lo) ++start;
for (; start < hi; start++) {
var pivot=a[start];
var left=lo;
var right=start;
Clazz_assert(C$, this, function(){return left <= right});
while (left < right){
var mid=(left + right) >>> 1;
if (pivot.compareTo$O(a[mid]) < 0) right=mid;
 else left=mid + 1;
}
Clazz_assert(C$, this, function(){return left == right});
var n=start - left;
switch (n) {
case 2:
a[left + 2]=a[left + 1];
case 1:
a[left + 1]=a[left];
break;
default:
System.arraycopy$O$I$O$I$I(a, left, a, left + 1, n);
}
a[left]=pivot;
}
}, 1);

Clazz_newMeth(C$, 'countRunAndMakeAscending$OA$I$I',  function (a, lo, hi) {
Clazz_assert(C$, this, function(){return lo < hi});
var runHi=lo + 1;
if (runHi == hi) return 1;
if ((a[runHi++]).compareTo$O(a[lo]) < 0) {
while (runHi < hi && (a[runHi]).compareTo$O(a[runHi - 1]) < 0 )++runHi;

C$.reverseRange$OA$I$I(a, lo, runHi);
} else {
while (runHi < hi && (a[runHi]).compareTo$O(a[runHi - 1]) >= 0 )++runHi;

}return runHi - lo;
}, 1);

Clazz_newMeth(C$, 'reverseRange$OA$I$I',  function (a, lo, hi) {
--hi;
while (lo < hi){
var t=a[lo];
a[lo++]=a[hi];
a[hi--]=t;
}
}, 1);

Clazz_newMeth(C$, 'minRunLength$I',  function (n) {
Clazz_assert(C$, this, function(){return n >= 0});
var r=0;
while (n >= 32){
r|=(n & 1);
n>>=1;
}
return n + r;
}, 1);

Clazz_newMeth(C$, 'pushRun$I$I',  function (runBase, runLen) {
this.runBase[this.stackSize]=runBase;
this.runLen[this.stackSize]=runLen;
++this.stackSize;
}, p$1);

Clazz_newMeth(C$, 'mergeCollapse',  function () {
while (this.stackSize > 1){
var n=this.stackSize - 2;
if (n > 0 && this.runLen[n - 1] <= this.runLen[n] + this.runLen[n + 1] ) {
if (this.runLen[n - 1] < this.runLen[n + 1]) --n;
p$1.mergeAt$I.apply(this, [n]);
} else if (this.runLen[n] <= this.runLen[n + 1]) {
p$1.mergeAt$I.apply(this, [n]);
} else {
break;
}}
}, p$1);

Clazz_newMeth(C$, 'mergeForceCollapse',  function () {
while (this.stackSize > 1){
var n=this.stackSize - 2;
if (n > 0 && this.runLen[n - 1] < this.runLen[n + 1] ) --n;
p$1.mergeAt$I.apply(this, [n]);
}
}, p$1);

Clazz_newMeth(C$, 'mergeAt$I',  function (i) {
Clazz_assert(C$, this, function(){return this.stackSize >= 2});
Clazz_assert(C$, this, function(){return i >= 0});
Clazz_assert(C$, this, function(){return i == this.stackSize - 2 || i == this.stackSize - 3 });
var base1=this.runBase[i];
var len1=this.runLen[i];
var base2=this.runBase[i + 1];
var len2=this.runLen[i + 1];
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0 });
Clazz_assert(C$, this, function(){return base1 + len1 == base2});
this.runLen[i]=len1 + len2;
if (i == this.stackSize - 3) {
this.runBase[i + 1]=this.runBase[i + 2];
this.runLen[i + 1]=this.runLen[i + 2];
}--this.stackSize;
var k=C$.gallopRight$Comparable$OA$I$I$I(this.a[base2], this.a, base1, len1, 0);
Clazz_assert(C$, this, function(){return k >= 0});
base1+=k;
len1-=k;
if (len1 == 0) return;
len2=C$.gallopLeft$Comparable$OA$I$I$I(this.a[base1 + len1 - 1], this.a, base2, len2, len2 - 1);
Clazz_assert(C$, this, function(){return len2 >= 0});
if (len2 == 0) return;
if (len1 <= len2) p$1.mergeLo$I$I$I$I.apply(this, [base1, len1, base2, len2]);
 else p$1.mergeHi$I$I$I$I.apply(this, [base1, len1, base2, len2]);
}, p$1);

Clazz_newMeth(C$, 'gallopLeft$Comparable$OA$I$I$I',  function (key, a, base, len, hint) {
Clazz_assert(C$, this, function(){return len > 0 && hint >= 0  && hint < len });
var lastOfs=0;
var ofs=1;
if (key.compareTo$O(a[base + hint]) > 0) {
var maxOfs=len - hint;
while (ofs < maxOfs && key.compareTo$O(a[base + hint + ofs ]) > 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
lastOfs+=hint;
ofs+=hint;
} else {
var maxOfs=hint + 1;
while (ofs < maxOfs && key.compareTo$O(a[base + hint - ofs]) <= 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
var tmp=lastOfs;
lastOfs=hint - ofs;
ofs=hint - tmp;
}Clazz_assert(C$, this, function(){return -1 <= lastOfs && lastOfs < ofs  && ofs <= len });
++lastOfs;
while (lastOfs < ofs){
var m=lastOfs + ((ofs - lastOfs) >>> 1);
if (key.compareTo$O(a[base + m]) > 0) lastOfs=m + 1;
 else ofs=m;
}
Clazz_assert(C$, this, function(){return lastOfs == ofs});
return ofs;
}, 1);

Clazz_newMeth(C$, 'gallopRight$Comparable$OA$I$I$I',  function (key, a, base, len, hint) {
Clazz_assert(C$, this, function(){return len > 0 && hint >= 0  && hint < len });
var ofs=1;
var lastOfs=0;
if (key.compareTo$O(a[base + hint]) < 0) {
var maxOfs=hint + 1;
while (ofs < maxOfs && key.compareTo$O(a[base + hint - ofs]) < 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
var tmp=lastOfs;
lastOfs=hint - ofs;
ofs=hint - tmp;
} else {
var maxOfs=len - hint;
while (ofs < maxOfs && key.compareTo$O(a[base + hint + ofs ]) >= 0 ){
lastOfs=ofs;
ofs=(ofs << 1) + 1;
if (ofs <= 0) ofs=maxOfs;
}
if (ofs > maxOfs) ofs=maxOfs;
lastOfs+=hint;
ofs+=hint;
}Clazz_assert(C$, this, function(){return -1 <= lastOfs && lastOfs < ofs  && ofs <= len });
++lastOfs;
while (lastOfs < ofs){
var m=lastOfs + ((ofs - lastOfs) >>> 1);
if (key.compareTo$O(a[base + m]) < 0) ofs=m;
 else lastOfs=m + 1;
}
Clazz_assert(C$, this, function(){return lastOfs == ofs});
return ofs;
}, 1);

Clazz_newMeth(C$, 'mergeLo$I$I$I$I',  function (base1, len1, base2, len2) {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0  && base1 + len1 == base2 });
var a=this.a;
var tmp=p$1.ensureCapacity$I.apply(this, [len1]);
var cursor1=this.tmpBase;
var cursor2=base2;
var dest=base1;
System.arraycopy$O$I$O$I$I(a, base1, tmp, cursor1, len1);
a[dest++]=a[cursor2++];
if (--len2 == 0) {
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, len1);
return;
}if (len1 == 1) {
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, len2);
a[dest + len2]=tmp[cursor1];
return;
}var minGallop=this.minGallop;
 outer : while (true){
var count1=0;
var count2=0;
do {
Clazz_assert(C$, this, function(){return len1 > 1 && len2 > 0 });
if ((a[cursor2]).compareTo$O(tmp[cursor1]) < 0) {
a[dest++]=a[cursor2++];
++count2;
count1=0;
if (--len2 == 0) break outer;
} else {
a[dest++]=tmp[cursor1++];
++count1;
count2=0;
if (--len1 == 1) break outer;
}} while ((count1 | count2) < minGallop);
do {
Clazz_assert(C$, this, function(){return len1 > 1 && len2 > 0 });
count1=C$.gallopRight$Comparable$OA$I$I$I(a[cursor2], tmp, cursor1, len1, 0);
if (count1 != 0) {
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, count1);
dest+=count1;
cursor1+=count1;
len1-=count1;
if (len1 <= 1) break outer;
}a[dest++]=a[cursor2++];
if (--len2 == 0) break outer;
count2=C$.gallopLeft$Comparable$OA$I$I$I(tmp[cursor1], a, cursor2, len2, 0);
if (count2 != 0) {
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, count2);
dest+=count2;
cursor2+=count2;
len2-=count2;
if (len2 == 0) break outer;
}a[dest++]=tmp[cursor1++];
if (--len1 == 1) break outer;
--minGallop;
} while (!!(count1 >= 7 | count2 >= 7));
if (minGallop < 0) minGallop=0;
minGallop+=2;
}
this.minGallop=minGallop < 1 ? 1 : minGallop;
if (len1 == 1) {
Clazz_assert(C$, this, function(){return len2 > 0});
System.arraycopy$O$I$O$I$I(a, cursor2, a, dest, len2);
a[dest + len2]=tmp[cursor1];
} else if (len1 == 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Comparison method violates its general contract!"]);
} else {
Clazz_assert(C$, this, function(){return len2 == 0});
Clazz_assert(C$, this, function(){return len1 > 1});
System.arraycopy$O$I$O$I$I(tmp, cursor1, a, dest, len1);
}}, p$1);

Clazz_newMeth(C$, 'mergeHi$I$I$I$I',  function (base1, len1, base2, len2) {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 0  && base1 + len1 == base2 });
var a=this.a;
var tmp=p$1.ensureCapacity$I.apply(this, [len2]);
var tmpBase=this.tmpBase;
System.arraycopy$O$I$O$I$I(a, base2, tmp, tmpBase, len2);
var cursor1=base1 + len1 - 1;
var cursor2=tmpBase + len2 - 1;
var dest=base2 + len2 - 1;
a[dest--]=a[cursor1--];
if (--len1 == 0) {
System.arraycopy$O$I$O$I$I(tmp, tmpBase, a, dest - (len2 - 1), len2);
return;
}if (len2 == 1) {
dest-=len1;
cursor1-=len1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, len1);
a[dest]=tmp[cursor2];
return;
}var minGallop=this.minGallop;
 outer : while (true){
var count1=0;
var count2=0;
do {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 1 });
if ((tmp[cursor2]).compareTo$O(a[cursor1]) < 0) {
a[dest--]=a[cursor1--];
++count1;
count2=0;
if (--len1 == 0) break outer;
} else {
a[dest--]=tmp[cursor2--];
++count2;
count1=0;
if (--len2 == 1) break outer;
}} while ((count1 | count2) < minGallop);
do {
Clazz_assert(C$, this, function(){return len1 > 0 && len2 > 1 });
count1=len1 - C$.gallopRight$Comparable$OA$I$I$I(tmp[cursor2], a, base1, len1, len1 - 1);
if (count1 != 0) {
dest-=count1;
cursor1-=count1;
len1-=count1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, count1);
if (len1 == 0) break outer;
}a[dest--]=tmp[cursor2--];
if (--len2 == 1) break outer;
count2=len2 - C$.gallopLeft$Comparable$OA$I$I$I(a[cursor1], tmp, tmpBase, len2, len2 - 1);
if (count2 != 0) {
dest-=count2;
cursor2-=count2;
len2-=count2;
System.arraycopy$O$I$O$I$I(tmp, cursor2 + 1, a, dest + 1, count2);
if (len2 <= 1) break outer;
}a[dest--]=a[cursor1--];
if (--len1 == 0) break outer;
--minGallop;
} while (!!(count1 >= 7 | count2 >= 7));
if (minGallop < 0) minGallop=0;
minGallop+=2;
}
this.minGallop=minGallop < 1 ? 1 : minGallop;
if (len2 == 1) {
Clazz_assert(C$, this, function(){return len1 > 0});
dest-=len1;
cursor1-=len1;
System.arraycopy$O$I$O$I$I(a, cursor1 + 1, a, dest + 1, len1);
a[dest]=tmp[cursor2];
} else if (len2 == 0) {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Comparison method violates its general contract!"]);
} else {
Clazz_assert(C$, this, function(){return len1 == 0});
Clazz_assert(C$, this, function(){return len2 > 0});
System.arraycopy$O$I$O$I$I(tmp, tmpBase, a, dest - (len2 - 1), len2);
}}, p$1);

Clazz_newMeth(C$, 'ensureCapacity$I',  function (minCapacity) {
if (this.tmpLen < minCapacity) {
var newSize=minCapacity;
newSize|=newSize >> 1;
newSize|=newSize >> 2;
newSize|=newSize >> 4;
newSize|=newSize >> 8;
newSize|=newSize >> 16;
++newSize;
if (newSize < 0) newSize=minCapacity;
 else newSize=Math.min(newSize, this.a.length >>> 1);
var newArray=Clazz_array(java.lang.Object, [newSize]);
this.tmp=newArray;
this.tmpLen=newSize;
this.tmpBase=0;
}return this.tmp;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:19 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.concurrent.atomic"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "AtomicInteger", null, 'Number', 'java.io.Serializable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['value']]]

Clazz_newMeth(C$, 'c$$I',  function (initialValue) {
Clazz_super_(C$, this);
this.value=initialValue;
}, 1);

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
}, 1);

Clazz_newMeth(C$, 'get$',  function () {
return this.value;
});

Clazz_newMeth(C$, 'set$I',  function (newValue) {
this.value=newValue;
});

Clazz_newMeth(C$, 'lazySet$I',  function (newValue) {
this.value=newValue;
});

Clazz_newMeth(C$, 'getAndSet$I',  function (newValue) {
for (; ; ) {
var current=this.get$();
if (this.compareAndSet$I$I(current, newValue)) return current;
}
});

Clazz_newMeth(C$, 'compareAndSet$I$I',  function (expect, update) {
if (this.value != expect) return false;
this.value=update;
return true;
});

Clazz_newMeth(C$, 'weakCompareAndSet$I$I',  function (expect, update) {
return this.compareAndSet$I$I(expect, update);
});

Clazz_newMeth(C$, 'getAndIncrement$',  function () {
for (; ; ) {
var current=this.get$();
var next=current + 1;
if (this.compareAndSet$I$I(current, next)) return current;
}
});

Clazz_newMeth(C$, 'getAndDecrement$',  function () {
for (; ; ) {
var current=this.get$();
var next=current - 1;
if (this.compareAndSet$I$I(current, next)) return current;
}
});

Clazz_newMeth(C$, 'getAndAdd$I',  function (delta) {
for (; ; ) {
var current=this.get$();
var next=current + delta;
if (this.compareAndSet$I$I(current, next)) return current;
}
});

Clazz_newMeth(C$, 'incrementAndGet$',  function () {
for (; ; ) {
var current=this.get$();
var next=current + 1;
if (this.compareAndSet$I$I(current, next)) return next;
}
});

Clazz_newMeth(C$, 'decrementAndGet$',  function () {
for (; ; ) {
var current=this.get$();
var next=current - 1;
if (this.compareAndSet$I$I(current, next)) return next;
}
});

Clazz_newMeth(C$, 'addAndGet$I',  function (delta) {
for (; ; ) {
var current=this.get$();
var next=current + delta;
if (this.compareAndSet$I$I(current, next)) return next;
}
});

Clazz_newMeth(C$, 'toString',  function () {
return Integer.toString$I(this.get$());
});

Clazz_newMeth(C$, 'intValue$',  function () {
return this.get$();
});

Clazz_newMeth(C$, 'longValue$',  function () {
return this.get$();
});

Clazz_newMeth(C$, 'floatValue$',  function () {
return this.get$();
});

Clazz_newMeth(C$, 'doubleValue$',  function () {
return this.get$();
});
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:26 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.concurrent"),p$1={},I$=[[0,['java.util.concurrent.ConcurrentHashMap','.HashEntry'],['java.util.concurrent.ConcurrentHashMap','.WriteThroughEntry'],['java.util.concurrent.ConcurrentHashMap','.KeyIterator'],['java.util.concurrent.ConcurrentHashMap','.ValueIterator'],['java.util.concurrent.ConcurrentHashMap','.EntryIterator'],['java.util.concurrent.ConcurrentHashMap','.Segment'],['java.util.concurrent.ConcurrentHashMap','.KeySet'],['java.util.concurrent.ConcurrentHashMap','.Values'],['java.util.concurrent.ConcurrentHashMap','.EntrySet']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ConcurrentHashMap", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'java.util.AbstractMap', ['java.util.concurrent.ConcurrentMap', 'java.io.Serializable']);
C$.$classes$=[['HashEntry',24],['Segment',24],['HashIterator',1024],['KeyIterator',16],['ValueIterator',16],['WriteThroughEntry',16],['EntryIterator',16],['KeySet',16],['Values',16],['EntrySet',16]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['segmentMask','segmentShift'],'O',['segments','java.util.concurrent.ConcurrentHashMap.Segment[]','$keySet','java.util.Set','+entrySet','$values','java.util.Collection']]]

Clazz_newMeth(C$, 'hash$I',  function (h) {
h+=(h << 15) ^ -12931;
h^=(h >>> 10);
h+=(h << 3);
h^=(h >>> 6);
h+=(h << 2) + (h << 14);
return h ^ (h >>> 16);
}, 1);

Clazz_newMeth(C$, 'segmentFor$I',  function (hash) {
return this.segments[(hash >>> this.segmentShift) & this.segmentMask];
});

Clazz_newMeth(C$, 'c$$I$F$I',  function (initialCapacity, loadFactor, concurrencyLevel) {
Clazz_super_(C$, this);
if (!(loadFactor > 0 ) || initialCapacity < 0  || concurrencyLevel <= 0 ) throw Clazz_new_(Clazz_load('IllegalArgumentException'));
if (concurrencyLevel > 65536) concurrencyLevel=65536;
var sshift=0;
var ssize=1;
while (ssize < concurrencyLevel){
++sshift;
ssize<<=1;
}
this.segmentShift=32 - sshift;
this.segmentMask=ssize - 1;
this.segments=$I$(6).newArray$I(ssize);
if (initialCapacity > 1073741824) initialCapacity=1073741824;
var c=(initialCapacity/ssize|0);
if (c * ssize < initialCapacity) ++c;
var cap=1;
while (cap < c)cap<<=1;

for (var i=0; i < this.segments.length; ++i) this.segments[i]=Clazz_new_($I$(6,1).c$$I$F,[cap, loadFactor]);

}, 1);

Clazz_newMeth(C$, 'c$$I$F',  function (initialCapacity, loadFactor) {
C$.c$$I$F$I.apply(this, [initialCapacity, loadFactor, 16]);
}, 1);

Clazz_newMeth(C$, 'c$$I',  function (initialCapacity) {
C$.c$$I$F$I.apply(this, [initialCapacity, 0.75, 16]);
}, 1);

Clazz_newMeth(C$, 'c$',  function () {
C$.c$$I$F$I.apply(this, [16, 0.75, 16]);
}, 1);

Clazz_newMeth(C$, 'c$$java_util_Map',  function (m) {
C$.c$$I$F$I.apply(this, [Math.max(((m.size$() / 0.75)|0) + 1, 16), 0.75, 16]);
this.putAll$java_util_Map(m);
}, 1);

Clazz_newMeth(C$, 'isEmpty$',  function () {
var segments=this.segments;
var mc=Clazz_array(Integer.TYPE, [segments.length]);
var mcsum=0;
for (var i=0; i < segments.length; ++i) {
if (segments[i].count != 0) return false;
 else mcsum+=mc[i]=segments[i].modCount;
}
if (mcsum != 0) {
for (var i=0; i < segments.length; ++i) {
if (segments[i].count != 0 || mc[i] != segments[i].modCount ) return false;
}
}return true;
});

Clazz_newMeth(C$, 'size$',  function () {
var segments=this.segments;
var sum=0;
var check=0;
var mc=Clazz_array(Integer.TYPE, [segments.length]);
for (var k=0; k < 2; ++k) {
check=0;
sum=0;
var mcsum=0;
for (var i=0; i < segments.length; ++i) {
(sum=Long.$add(sum,(segments[i].count)));
mcsum+=mc[i]=segments[i].modCount;
}
if (mcsum != 0) {
for (var i=0; i < segments.length; ++i) {
(check=Long.$add(check,(segments[i].count)));
if (mc[i] != segments[i].modCount) {
check=-1;
break;
}}
}if (Long.$eq(check,sum )) break;
}
if (Long.$ne(check,sum )) {
sum=0;
for (var i=0; i < segments.length; ++i) segments[i].lock$();

for (var i=0; i < segments.length; ++i) (sum=Long.$add(sum,(segments[i].count)));

for (var i=0; i < segments.length; ++i) segments[i].unlock$();

}if (Long.$gt(sum,2147483647 )) return 2147483647;
 else return Long.$ival(sum);
});

Clazz_newMeth(C$, 'get$O',  function (key) {
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).get$O$I(key, hash);
});

Clazz_newMeth(C$, 'containsKey$O',  function (key) {
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).containsKey$O$I(key, hash);
});

Clazz_newMeth(C$, 'containsValue$O',  function (value) {
if (value == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
var segments=this.segments;
var mc=Clazz_array(Integer.TYPE, [segments.length]);
for (var k=0; k < 2; ++k) {
var mcsum=0;
for (var i=0; i < segments.length; ++i) {
mcsum+=mc[i]=segments[i].modCount;
if (segments[i].containsValue$O(value)) return true;
}
var cleanSweep=true;
if (mcsum != 0) {
for (var i=0; i < segments.length; ++i) {
if (mc[i] != segments[i].modCount) {
cleanSweep=false;
break;
}}
}if (cleanSweep) return false;
}
for (var i=0; i < segments.length; ++i) segments[i].lock$();

var found=false;
try {
for (var i=0; i < segments.length; ++i) {
if (segments[i].containsValue$O(value)) {
found=true;
break;
}}
} finally {
for (var i=0; i < segments.length; ++i) segments[i].unlock$();

}
return found;
});

Clazz_newMeth(C$, 'contains$O',  function (value) {
return this.containsValue$O(value);
});

Clazz_newMeth(C$, 'put$O$O',  function (key, value) {
if (value == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).put$O$I$O$Z(key, hash, value, false);
});

Clazz_newMeth(C$, 'putIfAbsent$O$O',  function (key, value) {
if (value == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).put$O$I$O$Z(key, hash, value, true);
});

Clazz_newMeth(C$, 'putAll$java_util_Map',  function (m) {
for (var e, $e = m.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) this.put$O$O(e.getKey$(), e.getValue$());

});

Clazz_newMeth(C$, 'remove$O',  function (key) {
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).remove$O$I$O(key, hash, null);
});

Clazz_newMeth(C$, 'remove$O$O',  function (key, value) {
var hash=C$.hash$I(key.hashCode$());
if (value == null ) return false;
return this.segmentFor$I(hash).remove$O$I$O(key, hash, value) != null ;
});

Clazz_newMeth(C$, 'replace$O$O$O',  function (key, oldValue, newValue) {
if (oldValue == null  || newValue == null  ) throw Clazz_new_(Clazz_load('NullPointerException'));
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).replace$O$I$O$O(key, hash, oldValue, newValue);
});

Clazz_newMeth(C$, 'replace$O$O',  function (key, value) {
if (value == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
var hash=C$.hash$I(key.hashCode$());
return this.segmentFor$I(hash).replace$O$I$O(key, hash, value);
});

Clazz_newMeth(C$, 'clear$',  function () {
for (var i=0; i < this.segments.length; ++i) this.segments[i].clear$();

});

Clazz_newMeth(C$, 'keySet$',  function () {
var ks=this.$keySet;
return (ks != null ) ? ks : (this.$keySet=Clazz_new_($I$(7,1),[this, null]));
});

Clazz_newMeth(C$, 'values$',  function () {
var vs=this.$values;
return (vs != null ) ? vs : (this.$values=Clazz_new_($I$(8,1),[this, null]));
});

Clazz_newMeth(C$, 'entrySet$',  function () {
var es=this.entrySet;
return (es != null ) ? es : (this.entrySet=Clazz_new_($I$(9,1),[this, null]));
});

Clazz_newMeth(C$, 'keys$',  function () {
return Clazz_new_($I$(3,1),[this, null]);
});

Clazz_newMeth(C$, 'elements$',  function () {
return Clazz_new_($I$(4,1),[this, null]);
});

Clazz_newMeth(C$, 'writeObject$java_io_ObjectOutputStream',  function (s) {
s.defaultWriteObject$();
for (var k=0; k < this.segments.length; ++k) {
var seg=this.segments[k];
seg.lock$();
try {
var tab=seg.table;
for (var i=0; i < tab.length; ++i) {
for (var e=tab[i]; e != null ; e=e.nextEntry) {
s.writeObject$O(e.key);
s.writeObject$O(e.value);
}
}
} finally {
seg.unlock$();
}
}
s.writeObject$O(null);
s.writeObject$O(null);
}, p$1);

Clazz_newMeth(C$, 'readObject$java_io_ObjectInputStream',  function (s) {
s.defaultReadObject$();
for (var i=0; i < this.segments.length; ++i) {
this.segments[i].setTable$java_util_concurrent_ConcurrentHashMap_HashEntryA(Clazz_array($I$(1), [1]));
}
for (; ; ) {
var key=s.readObject$();
var value=s.readObject$();
if (key == null ) break;
this.put$O$O(key, value);
}
}, p$1);
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "HashEntry", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['hash'],'O',['key','<K>','value','<V>','nextEntry','java.util.concurrent.ConcurrentHashMap.HashEntry']]]

Clazz_newMeth(C$, 'c$$O$I$java_util_concurrent_ConcurrentHashMap_HashEntry$O',  function (key, hash, next, value) {
;C$.$init$.apply(this);
this.key=key;
this.hash=hash;
this.nextEntry=next;
this.value=value;
}, 1);

Clazz_newMeth(C$, 'newArray$I',  function (i) {
return Clazz_array(C$, [i]);
}, 1);

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "Segment", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['loadFactor'],'I',['count','modCount','threshold'],'O',['table','java.util.concurrent.ConcurrentHashMap.HashEntry[]']]]

Clazz_newMeth(C$, 'c$$I$F',  function (initialCapacity, lf) {
;C$.$init$.apply(this);
this.loadFactor=lf;
this.setTable$java_util_concurrent_ConcurrentHashMap_HashEntryA($I$(1).newArray$I(initialCapacity));
}, 1);

Clazz_newMeth(C$, 'newArray$I',  function (i) {
return Clazz_array(C$, [i]);
}, 1);

Clazz_newMeth(C$, 'setTable$java_util_concurrent_ConcurrentHashMap_HashEntryA',  function (newTable) {
this.threshold=((newTable.length * this.loadFactor)|0);
this.table=newTable;
});

Clazz_newMeth(C$, 'getFirst$I',  function (hash) {
var tab=this.table;
return tab[hash & (tab.length - 1)];
});

Clazz_newMeth(C$, 'readValueUnderLock$java_util_concurrent_ConcurrentHashMap_HashEntry',  function (e) {
this.lock$();
try {
return e.value;
} finally {
this.unlock$();
}
});

Clazz_newMeth(C$, 'unlock$',  function () {
});

Clazz_newMeth(C$, 'lock$',  function () {
});

Clazz_newMeth(C$, 'get$O$I',  function (key, hash) {
if (this.count != 0) {
var e=this.getFirst$I(hash);
while (e != null ){
if (e.hash == hash && key.equals$O(e.key) ) {
var v=e.value;
if (v != null ) return v;
return this.readValueUnderLock$java_util_concurrent_ConcurrentHashMap_HashEntry(e);
}e=e.nextEntry;
}
}return null;
});

Clazz_newMeth(C$, 'containsKey$O$I',  function (key, hash) {
if (this.count != 0) {
var e=this.getFirst$I(hash);
while (e != null ){
if (e.hash == hash && key.equals$O(e.key) ) return true;
e=e.nextEntry;
}
}return false;
});

Clazz_newMeth(C$, 'containsValue$O',  function (value) {
if (this.count != 0) {
var tab=this.table;
var len=tab.length;
for (var i=0; i < len; i++) {
for (var e=tab[i]; e != null ; e=e.nextEntry) {
var v=e.value;
if (v == null ) v=this.readValueUnderLock$java_util_concurrent_ConcurrentHashMap_HashEntry(e);
if (value.equals$O(v)) return true;
}
}
}return false;
});

Clazz_newMeth(C$, 'replace$O$I$O$O',  function (key, hash, oldValue, newValue) {
this.lock$();
try {
var e=this.getFirst$I(hash);
while (e != null  && (e.hash != hash || !key.equals$O(e.key) ) )e=e.nextEntry;

var replaced=false;
if (e != null  && oldValue.equals$O(e.value) ) {
replaced=true;
e.value=newValue;
}return replaced;
} finally {
this.unlock$();
}
});

Clazz_newMeth(C$, 'replace$O$I$O',  function (key, hash, newValue) {
this.lock$();
try {
var e=this.getFirst$I(hash);
while (e != null  && (e.hash != hash || !key.equals$O(e.key) ) )e=e.nextEntry;

var oldValue=null;
if (e != null ) {
oldValue=e.value;
e.value=newValue;
}return oldValue;
} finally {
this.unlock$();
}
});

Clazz_newMeth(C$, 'put$O$I$O$Z',  function (key, hash, value, onlyIfAbsent) {
this.lock$();
try {
var c=this.count;
if (c++ > this.threshold) this.rehash$();
var tab=this.table;
var index=hash & (tab.length - 1);
var first=tab[index];
var e=first;
while (e != null  && (e.hash != hash || !key.equals$O(e.key) ) )e=e.nextEntry;

var oldValue;
if (e != null ) {
oldValue=e.value;
if (!onlyIfAbsent) e.value=value;
} else {
oldValue=null;
++this.modCount;
tab[index]=Clazz_new_($I$(1,1).c$$O$I$java_util_concurrent_ConcurrentHashMap_HashEntry$O,[key, hash, first, value]);
this.count=c;
}return oldValue;
} finally {
this.unlock$();
}
});

Clazz_newMeth(C$, 'rehash$',  function () {
var oldTable=this.table;
var oldCapacity=oldTable.length;
if (oldCapacity >= 1073741824) return;
var newTable=$I$(1).newArray$I(oldCapacity << 1);
this.threshold=((newTable.length * this.loadFactor)|0);
var sizeMask=newTable.length - 1;
for (var i=0; i < oldCapacity; i++) {
var e=oldTable[i];
if (e != null ) {
var next=e.nextEntry;
var idx=e.hash & sizeMask;
if (next == null ) newTable[idx]=e;
 else {
var lastRun=e;
var lastIdx=idx;
for (var last=next; last != null ; last=last.nextEntry) {
var k=last.hash & sizeMask;
if (k != lastIdx) {
lastIdx=k;
lastRun=last;
}}
newTable[lastIdx]=lastRun;
for (var p=e; p !== lastRun ; p=p.nextEntry) {
var k=p.hash & sizeMask;
var n=newTable[k];
newTable[k]=Clazz_new_($I$(1,1).c$$O$I$java_util_concurrent_ConcurrentHashMap_HashEntry$O,[p.key, p.hash, n, p.value]);
}
}}}
this.table=newTable;
});

Clazz_newMeth(C$, 'remove$O$I$O',  function (key, hash, value) {
this.lock$();
try {
var c=this.count - 1;
var tab=this.table;
var index=hash & (tab.length - 1);
var first=tab[index];
var e=first;
while (e != null  && (e.hash != hash || !key.equals$O(e.key) ) )e=e.nextEntry;

var oldValue=null;
if (e != null ) {
var v=e.value;
if (value == null  || value.equals$O(v) ) {
oldValue=v;
++this.modCount;
var newFirst=e.nextEntry;
for (var p=first; p !== e ; p=p.nextEntry) newFirst=Clazz_new_($I$(1,1).c$$O$I$java_util_concurrent_ConcurrentHashMap_HashEntry$O,[p.key, p.hash, newFirst, p.value]);

tab[index]=newFirst;
this.count=c;
}}return oldValue;
} finally {
this.unlock$();
}
});

Clazz_newMeth(C$, 'clear$',  function () {
if (this.count != 0) {
this.lock$();
try {
var tab=this.table;
for (var i=0; i < tab.length; i++) tab[i]=null;

++this.modCount;
this.count=0;
} finally {
this.unlock$();
}
}});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "HashIterator", function(){
Clazz_newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['nextSegmentIndex','nextTableIndex'],'O',['currentTable','java.util.concurrent.ConcurrentHashMap.HashEntry[]','nextEntry','java.util.concurrent.ConcurrentHashMap.HashEntry','+lastReturned']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.nextSegmentIndex=this.b$['java.util.concurrent.ConcurrentHashMap'].segments.length - 1;
this.nextTableIndex=-1;
this.advance$();
}, 1);

Clazz_newMeth(C$, 'hasMoreElements$',  function () {
return this.hasNext$();
});

Clazz_newMeth(C$, 'advance$',  function () {
if (this.nextEntry != null  && (this.nextEntry=this.nextEntry.nextEntry) != null  ) return;
while (this.nextTableIndex >= 0){
if ((this.nextEntry=this.currentTable[this.nextTableIndex--]) != null ) return;
}
while (this.nextSegmentIndex >= 0){
var seg=this.b$['java.util.concurrent.ConcurrentHashMap'].segments[this.nextSegmentIndex--];
if (seg.count != 0) {
this.currentTable=seg.table;
for (var j=this.currentTable.length - 1; j >= 0; --j) {
if ((this.nextEntry=this.currentTable[j]) != null ) {
this.nextTableIndex=j - 1;
return;
}}
}}
});

Clazz_newMeth(C$, 'hasNext$',  function () {
return this.nextEntry != null ;
});

Clazz_newMeth(C$, 'nextEntry$',  function () {
if (this.nextEntry == null ) throw Clazz_new_(Clazz_load('java.util.NoSuchElementException'));
this.lastReturned=this.nextEntry;
this.advance$();
return this.lastReturned;
});

Clazz_newMeth(C$, 'remove$',  function () {
if (this.lastReturned == null ) throw Clazz_new_(Clazz_load('IllegalStateException'));
this.b$['java.util.concurrent.ConcurrentHashMap'].remove$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [this.lastReturned.key]);
this.lastReturned=null;
});
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "KeyIterator", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, ['java.util.concurrent.ConcurrentHashMap','.HashIterator'], ['java.util.Iterator', 'java.util.Enumeration']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'next$',  function () {
return C$.superclazz.prototype.nextEntry$.apply(this, []).key;
});

Clazz_newMeth(C$, 'nextElement$',  function () {
return C$.superclazz.prototype.nextEntry$.apply(this, []).key;
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "ValueIterator", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, ['java.util.concurrent.ConcurrentHashMap','.HashIterator'], ['java.util.Iterator', 'java.util.Enumeration']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'next$',  function () {
return C$.superclazz.prototype.nextEntry$.apply(this, []).value;
});

Clazz_newMeth(C$, 'nextElement$',  function () {
return C$.superclazz.prototype.nextEntry$.apply(this, []).value;
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "WriteThroughEntry", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, ['java.util.AbstractMap','.SimpleEntry']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$$O$O',  function (k, v) {
;C$.superclazz.c$$O$O.apply(this,[k, v]);C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'setValue$O',  function (value) {
if (value == null ) throw Clazz_new_(Clazz_load('NullPointerException'));
var v=C$.superclazz.prototype.setValue$O.apply(this, [value]);
this.b$['java.util.concurrent.ConcurrentHashMap'].put$O$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [this.getKey$(), value]);
return v;
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "EntryIterator", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, ['java.util.concurrent.ConcurrentHashMap','.HashIterator'], 'java.util.Iterator');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'next$',  function () {
var e=C$.superclazz.prototype.nextEntry$.apply(this, []);
return Clazz_new_($I$(2,1).c$$O$O,[this, null, e.key, e.value]);
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "KeySet", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, 'java.util.AbstractSet');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'iterator$',  function () {
return Clazz_new_($I$(3,1),[this, null]);
});

Clazz_newMeth(C$, 'size$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].size$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'isEmpty$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].isEmpty$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'contains$O',  function (o) {
return this.b$['java.util.concurrent.ConcurrentHashMap'].containsKey$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [o]);
});

Clazz_newMeth(C$, 'remove$O',  function (o) {
return this.b$['java.util.concurrent.ConcurrentHashMap'].remove$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [o]) != null ;
});

Clazz_newMeth(C$, 'clear$',  function () {
this.b$['java.util.concurrent.ConcurrentHashMap'].clear$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "Values", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, 'java.util.AbstractCollection');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'iterator$',  function () {
return Clazz_new_($I$(4,1),[this, null]);
});

Clazz_newMeth(C$, 'size$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].size$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'isEmpty$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].isEmpty$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'contains$O',  function (o) {
return this.b$['java.util.concurrent.ConcurrentHashMap'].containsValue$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [o]);
});

Clazz_newMeth(C$, 'clear$',  function () {
this.b$['java.util.concurrent.ConcurrentHashMap'].clear$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ConcurrentHashMap, "EntrySet", function(){
Clazz_newInstance(this, arguments[0],true,C$);
}, 'java.util.AbstractSet');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'iterator$',  function () {
return Clazz_new_($I$(5,1),[this, null]);
});

Clazz_newMeth(C$, 'contains$O',  function (o) {
if (!(Clazz_instanceOf(o, "java.util.Map.Entry"))) return false;
var e=o;
var v=this.b$['java.util.concurrent.ConcurrentHashMap'].get$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [e.getKey$()]);
return v != null  && v.equals$O(e.getValue$()) ;
});

Clazz_newMeth(C$, 'remove$O',  function (o) {
if (!(Clazz_instanceOf(o, "java.util.Map.Entry"))) return false;
var e=o;
return this.b$['java.util.concurrent.ConcurrentHashMap'].remove$O$O.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], [e.getKey$(), e.getValue$()]);
});

Clazz_newMeth(C$, 'size$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].size$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'isEmpty$',  function () {
return this.b$['java.util.concurrent.ConcurrentHashMap'].isEmpty$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$, 'clear$',  function () {
this.b$['java.util.concurrent.ConcurrentHashMap'].clear$.apply(this.b$['java.util.concurrent.ConcurrentHashMap'], []);
});

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:24 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.concurrent"),I$=[[0,'java.util.Objects']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*i*/var C$=Clazz_newInterface(P$, "ConcurrentMap", null, null, 'java.util.Map');

C$.$clinit$=2;
C$.$defaults$ = function(C$){

Clazz_newMeth(C$, 'getOrDefault$O$O',  function (key, defaultValue) {
var v;
return ((v=this.get$O(key)) != null ) ? v : defaultValue;
});

Clazz_newMeth(C$, 'forEach$java_util_function_BiConsumer',  function (action) {
$I$(1).requireNonNull$O(action);
for (var entry, $entry = this.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var k;
var v;
try {
k=entry.getKey$();
v=entry.getValue$();
} catch (ise) {
if (Clazz_exceptionOf(ise,"IllegalStateException")){
continue;
} else {
throw ise;
}
}
action.accept$O$O(k, v);
}
});

Clazz_newMeth(C$, 'replaceAll$java_util_function_BiFunction',  function ($function) {
$I$(1).requireNonNull$O($function);
this.forEach$java_util_function_BiConsumer(((P$.ConcurrentMap$lambda1||
(function(){/*m*/var C$=Clazz_newClass(P$, "ConcurrentMap$lambda1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz_newMeth(C$, 'accept$O$O',  function (k, v) {
while (!this.b$['java.util.concurrent.ConcurrentMap'].replace$O$O$O.apply(this.b$['java.util.concurrent.ConcurrentMap'], [k, v, this.$finals$.$function.apply$O$O.apply(this.$finals$.$function, [k, v])])){
if ((v=this.b$['java.util.Map'].get$O.apply(this.b$['java.util.Map'], [k])) == null ) {
break;
}}
});
})()
), Clazz_new_(P$.ConcurrentMap$lambda1.$init$,[this, {$function:$function}])));
});

Clazz_newMeth(C$, 'computeIfAbsent$O$java_util_function_Function',  function (key, mappingFunction) {
$I$(1).requireNonNull$O(mappingFunction);
var v;
var newValue;
return ((v=this.get$O(key)) == null  && (newValue=mappingFunction.apply$O(key)) != null   && (v=this.putIfAbsent$O$O(key, newValue)) == null  ) ? newValue : v;
});

Clazz_newMeth(C$, 'computeIfPresent$O$java_util_function_BiFunction',  function (key, remappingFunction) {
$I$(1).requireNonNull$O(remappingFunction);
var oldValue;
while ((oldValue=this.get$O(key)) != null ){
var newValue=remappingFunction.apply$O$O(key, oldValue);
if (newValue != null ) {
if (this.replace$O$O$O(key, oldValue, newValue)) return newValue;
} else if (this.remove$O$O(key, oldValue)) return null;
}
return oldValue;
});

Clazz_newMeth(C$, 'compute$O$java_util_function_BiFunction',  function (key, remappingFunction) {
$I$(1).requireNonNull$O(remappingFunction);
var oldValue=this.get$O(key);
for (; ; ) {
var newValue=remappingFunction.apply$O$O(key, oldValue);
if (newValue == null ) {
if (oldValue != null  || this.containsKey$O(key) ) {
if (this.remove$O$O(key, oldValue)) {
return null;
}oldValue=this.get$O(key);
} else {
return null;
}} else {
if (oldValue != null ) {
if (this.replace$O$O$O(key, oldValue, newValue)) {
return newValue;
}oldValue=this.get$O(key);
} else {
if ((oldValue=this.putIfAbsent$O$O(key, newValue)) == null ) {
return newValue;
}}}}
});

Clazz_newMeth(C$, 'merge$O$O$java_util_function_BiFunction',  function (key, value, remappingFunction) {
$I$(1).requireNonNull$O(remappingFunction);
$I$(1).requireNonNull$O(value);
var oldValue=this.get$O(key);
for (; ; ) {
if (oldValue != null ) {
var newValue=remappingFunction.apply$O$O(oldValue, value);
if (newValue != null ) {
if (this.replace$O$O$O(key, oldValue, newValue)) return newValue;
} else if (this.remove$O$O(key, oldValue)) {
return null;
}oldValue=this.get$O(key);
} else {
if ((oldValue=this.putIfAbsent$O$O(key, value)) == null ) {
return value;
}}}
});
};})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:24 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.util,I$=[];
/*c*/var C$=Clazz_newClass(P$, "DualPivotQuicksort");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'sort$IA$I$I$IA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$IA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Integer.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$IA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$IA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$IA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$IA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$IA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$IA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$JA$I$I$JA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (Long.$lt(a[k],a[k + 1] )) {
while (++k <= right && Long.$le(a[k - 1],a[k] ) );
} else if (Long.$gt(a[k],a[k + 1] )) {
while (++k <= right && Long.$ge(a[k - 1],a[k] ) );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && Long.$eq(a[k - 1],a[k] ) ; ) {
if (--m == 0) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$JA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Long.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && Long.$le(a[p + ao],a[q + ao] )  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$JA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (Long.$lt(ai,a[j] )){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (Long.$ge(a[++left],a[left - 1] ));
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (Long.$lt(a1,a2 )) {
a2=a1;
a1=a[left];
}while (Long.$lt(a1,a[--k] )){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (Long.$lt(a2,a[--k] )){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (Long.$lt(last,a[--right] )){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (Long.$lt(a[e2],a[e1] )) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (Long.$lt(a[e3],a[e2] )) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}if (Long.$lt(a[e4],a[e3] )) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (Long.$lt(t,a[e2] )) {
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}}if (Long.$lt(a[e5],a[e4] )) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (Long.$lt(t,a[e3] )) {
a[e4]=a[e3];
a[e3]=t;
if (Long.$lt(t,a[e2] )) {
a[e3]=a[e2];
a[e2]=t;
if (Long.$lt(t,a[e1] )) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (Long.$ne(a[e1],a[e2] ) && Long.$ne(a[e2],a[e3] )  && Long.$ne(a[e3],a[e4] )  && Long.$ne(a[e4],a[e5] ) ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (Long.$lt(a[++less],pivot1 ));
while (Long.$gt(a[--great],pivot2 ));
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (Long.$lt(ak,pivot1 )) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (Long.$gt(ak,pivot2 )) {
while (Long.$gt(a[great],pivot2 )){
if (great-- == k) {
break outer;
}}
if (Long.$lt(a[great],pivot1 )) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$JA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$JA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (Long.$eq(a[less],pivot1 )){
++less;
}
while (Long.$eq(a[great],pivot2 )){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (Long.$eq(ak,pivot1 )) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (Long.$eq(ak,pivot2 )) {
while (Long.$eq(a[great],pivot2 )){
if (great-- == k) {
break outer;
}}
if (Long.$eq(a[great],pivot1 )) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$JA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (Long.$eq(a[k],pivot )) {
continue;
}var ak=a[k];
if (Long.$lt(ak,pivot )) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (Long.$gt(a[great],pivot )){
--great;
}
if (Long.$lt(a[great],pivot )) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$JA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$JA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$HA$I$I$HA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left > 3200) {
var count=Clazz_array(Integer.TYPE, [65536]);
for (var i=left - 1; ++i <= right; count[a[i] - -32768]++) ;
for (var i=65536, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=($s$[0] = (i + -32768), $s$[0]);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
C$.doSort$HA$I$I$HA$I$I(a, left, right, work, workBase, workLen);
}}, 1);

Clazz_newMeth(C$, 'doSort$HA$I$I$HA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$HA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Short.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$HA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$HA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$HA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$HA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$HA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$HA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$CA$I$I$CA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left > 3200) {
var count=Clazz_array(Integer.TYPE, [65536]);
for (var i=left - 1; ++i <= right; count[(a[i]).$c()]++) ;
for (var i=65536, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=String.fromCharCode(i);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
C$.doSort$CA$I$I$CA$I$I(a, left, right, work, workBase, workLen);
}}, 1);

Clazz_newMeth(C$, 'doSort$CA$I$I$CA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1]) {
while (++k <= right && a[k - 1] <= a[k] );
} else if (a[k] > a[k + 1]) {
while (++k <= right && a[k - 1] >= a[k] );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k] ; ) {
if (--m == 0) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$CA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Character.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]  ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$CA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1]);
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2) {
a2=a1;
a1=a[left];
}while (a1 < a[--k]){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k]){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right]){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1]) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2]) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3]) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4]) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3]) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2]) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1]) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2] && a[e2] != a[e3]  && a[e3] != a[e4]  && a[e4] != a[e5] ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1);
while (a[--great] > pivot2);
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2) {
while (a[great] > pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$CA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$CA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1){
++less;
}
while (a[great] == pivot2){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2) {
while (a[great] == pivot2){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1) {
a[k]=a[less];
a[less]=pivot1;
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$CA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot) {
continue;
}var ak=a[k];
if (ak < pivot) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot){
--great;
}
if (a[great] < pivot) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=pivot;
}a[great]=ak;
--great;
}}
C$.sort$CA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$CA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$BA$I$I',  function (a, left, right) {
if (right - left > 29) {
var count=Clazz_array(Integer.TYPE, [256]);
for (var i=left - 1; ++i <= right; count[a[i] - -128]++) ;
for (var i=256, k=right + 1; k > left; ) {
while (count[--i] == 0);
var value=($b$[0] = (i + -128), $b$[0]);
var s=count[i];
do {
a[--k]=value;
} while (--s > 0);
}
} else {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j]){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
}}, 1);

Clazz_newMeth(C$, 'sort$FA$I$I$FA$I$I',  function (a, left, right, work, workBase, workLen) {
while (left <= right && Float.isNaN$F(a[right]) ){
--right;
}
for (var k=right; --k >= left; ) {
var ak=a[k];
if (ak != ak ) {
a[k]=a[right];
a[right]=ak;
--right;
}}
C$.doSort$FA$I$I$FA$I$I(a, left, right, work, workBase, workLen);
var hi=right;
while (left < hi){
var middle=(left + hi) >>> 1;
var middleValue=a[middle];
if (middleValue < 0.0 ) {
left=middle + 1;
} else {
hi=middle;
}}
while (left <= right && Float.floatToRawIntBits$F(a[left]) < 0 ){
++left;
}
for (var k=left, p=left - 1; ++k <= right; ) {
var ak=a[k];
if (ak != 0.0 ) {
break;
}if (Float.floatToRawIntBits$F(ak) < 0) {
a[k]=0.0;
a[++p]=-0.0;
}}
}, 1);

Clazz_newMeth(C$, 'doSort$FA$I$I$FA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1] ) {
while (++k <= right && a[k - 1] <= a[k]  );
} else if (a[k] > a[k + 1] ) {
while (++k <= right && a[k - 1] >= a[k]  );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k]  ; ) {
if (--m == 0) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$FA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Float.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]   ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$FA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j] ){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1] );
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2 ) {
a2=a1;
a1=a[left];
}while (a1 < a[--k] ){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k] ){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right] ){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1] ) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2] ) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3] ) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4] ) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3] ) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2]  && a[e2] != a[e3]   && a[e3] != a[e4]   && a[e4] != a[e5]  ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1 );
while (a[--great] > pivot2 );
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2 ) {
while (a[great] > pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$FA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$FA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1 ){
++less;
}
while (a[great] == pivot2 ){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2 ) {
while (a[great] == pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$FA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot ) {
continue;
}var ak=a[k];
if (ak < pivot ) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot ){
--great;
}
if (a[great] < pivot ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
C$.sort$FA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$FA$I$I$Z(a, great + 1, right, false);
}}, 1);

Clazz_newMeth(C$, 'sort$DA$I$I$DA$I$I',  function (a, left, right, work, workBase, workLen) {
while (left <= right && Double.isNaN$D(a[right]) ){
--right;
}
for (var k=right; --k >= left; ) {
var ak=a[k];
if (ak != ak ) {
a[k]=a[right];
a[right]=ak;
--right;
}}
C$.doSort$DA$I$I$DA$I$I(a, left, right, work, workBase, workLen);
var hi=right;
while (left < hi){
var middle=(left + hi) >>> 1;
var middleValue=a[middle];
if (middleValue < 0.0 ) {
left=middle + 1;
} else {
hi=middle;
}}
while (left <= right && Long.$lt(Double.doubleToRawLongBits$D(a[left]),0 ) ){
++left;
}
for (var k=left, p=left - 1; ++k <= right; ) {
var ak=a[k];
if (ak != 0.0 ) {
break;
}if (Long.$lt(Double.doubleToRawLongBits$D(ak),0 )) {
a[k]=0.0;
a[++p]=-0.0;
}}
}, 1);

Clazz_newMeth(C$, 'doSort$DA$I$I$DA$I$I',  function (a, left, right, work, workBase, workLen) {
if (right - left < 286) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}var run=Clazz_array(Integer.TYPE, [68]);
var count=0;
run[0]=left;
for (var k=left; k < right; run[count]=k) {
if (a[k] < a[k + 1] ) {
while (++k <= right && a[k - 1] <= a[k]  );
} else if (a[k] > a[k + 1] ) {
while (++k <= right && a[k - 1] >= a[k]  );
for (var lo=run[count] - 1, hi=k; ++lo < --hi; ) {
var t=a[lo];
a[lo]=a[hi];
a[hi]=t;
}
} else {
for (var m=33; ++k <= right && a[k - 1] == a[k]  ; ) {
if (--m == 0) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}}
}if (++count == 67) {
C$.sort$DA$I$I$Z(a, left, right, true);
return;
}}
if (run[count] == right++) {
run[++count]=right;
} else if (count == 1) {
return;
}var odd=($b$[0] = 0, $b$[0]);
for (var n=1; (n<<=1) < count; odd=($b$[0] = odd^(1), $b$[0])) ;
var b;
var ao;
var bo;
var blen=right - left;
if (work == null  || workLen < blen  || workBase + blen > work.length ) {
work=Clazz_array(Double.TYPE, [blen]);
workBase=0;
}if (odd == 0) {
System.arraycopy$O$I$O$I$I(a, left, work, workBase, blen);
b=a;
bo=0;
a=work;
ao=workBase - left;
} else {
b=work;
ao=0;
bo=workBase - left;
}for (var last; count > 1; count=last) {
for (var k=(last=0) + 2; k <= count; k+=2) {
var hi=run[k];
var mi=run[k - 1];
for (var i=run[k - 2], p=i, q=mi; i < hi; ++i) {
if (q >= hi || p < mi && a[p + ao] <= a[q + ao]   ) {
b[i + bo]=a[p++ + ao];
} else {
b[i + bo]=a[q++ + ao];
}}
run[++last]=hi;
}
if ((count & 1) != 0) {
for (var i=right, lo=run[count - 1]; --i >= lo; b[i + bo]=a[i + ao]) ;
run[++last]=right;
}var t=a;
a=b;
b=t;
var o=ao;
ao=bo;
bo=o;
}
}, 1);

Clazz_newMeth(C$, 'sort$DA$I$I$Z',  function (a, left, right, leftmost) {
var length=right - left + 1;
if (length < 47) {
if (leftmost) {
for (var i=left, j=i; i < right; j=++i) {
var ai=a[i + 1];
while (ai < a[j] ){
a[j + 1]=a[j];
if (j-- == left) {
break;
}}
a[j + 1]=ai;
}
} else {
do {
if (left >= right) {
return;
}} while (a[++left] >= a[left - 1] );
for (var k=left; ++left <= right; k=++left) {
var a1=a[k];
var a2=a[left];
if (a1 < a2 ) {
a2=a1;
a1=a[left];
}while (a1 < a[--k] ){
a[k + 2]=a[k];
}
a[++k + 1]=a1;
while (a2 < a[--k] ){
a[k + 1]=a[k];
}
a[k + 1]=a2;
}
var last=a[right];
while (last < a[--right] ){
a[right + 1]=a[right];
}
a[right + 1]=last;
}return;
}var seventh=(length >> 3) + (length >> 6) + 1 ;
var e3=(left + right) >>> 1;
var e2=e3 - seventh;
var e1=e2 - seventh;
var e4=e3 + seventh;
var e5=e4 + seventh;
if (a[e2] < a[e1] ) {
var t=a[e2];
a[e2]=a[e1];
a[e1]=t;
}if (a[e3] < a[e2] ) {
var t=a[e3];
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}if (a[e4] < a[e3] ) {
var t=a[e4];
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}if (a[e5] < a[e4] ) {
var t=a[e5];
a[e5]=a[e4];
a[e4]=t;
if (t < a[e3] ) {
a[e4]=a[e3];
a[e3]=t;
if (t < a[e2] ) {
a[e3]=a[e2];
a[e2]=t;
if (t < a[e1] ) {
a[e2]=a[e1];
a[e1]=t;
}}}}var less=left;
var great=right;
if (a[e1] != a[e2]  && a[e2] != a[e3]   && a[e3] != a[e4]   && a[e4] != a[e5]  ) {
var pivot1=a[e2];
var pivot2=a[e4];
a[e2]=a[left];
a[e4]=a[right];
while (a[++less] < pivot1 );
while (a[--great] > pivot2 );
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak < pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak > pivot2 ) {
while (a[great] > pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] < pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
a[left]=a[less - 1];
a[less - 1]=pivot1;
a[right]=a[great + 1];
a[great + 1]=pivot2;
C$.sort$DA$I$I$Z(a, left, less - 2, leftmost);
C$.sort$DA$I$I$Z(a, great + 2, right, false);
if (less < e1 && e5 < great ) {
while (a[less] == pivot1 ){
++less;
}
while (a[great] == pivot2 ){
--great;
}
 outer : for (var k=less - 1; ++k <= great; ) {
var ak=a[k];
if (ak == pivot1 ) {
a[k]=a[less];
a[less]=ak;
++less;
} else if (ak == pivot2 ) {
while (a[great] == pivot2 ){
if (great-- == k) {
break outer;
}}
if (a[great] == pivot1 ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
}C$.sort$DA$I$I$Z(a, less, great, false);
} else {
var pivot=a[e3];
for (var k=less; k <= great; ++k) {
if (a[k] == pivot ) {
continue;
}var ak=a[k];
if (ak < pivot ) {
a[k]=a[less];
a[less]=ak;
++less;
} else {
while (a[great] > pivot ){
--great;
}
if (a[great] < pivot ) {
a[k]=a[less];
a[less]=a[great];
++less;
} else {
a[k]=a[great];
}a[great]=ak;
--great;
}}
C$.sort$DA$I$I$Z(a, left, less - 1, leftmost);
C$.sort$DA$I$I$Z(a, great + 1, right, false);
}}, 1);
var $b$ = new Int8Array(1);
var $s$ = new Int16Array(1);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:19 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.regex"),p$1={},I$=[[0,['java.util.regex.Matcher','.RegExp'],'StringBuilder','java.util.regex.ASCII',['java.util.regex.Matcher','.Value'],'StringBuffer','java.util.Objects']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Matcher", function(){
Clazz_newInstance(this, arguments,0,C$);
}, null, 'java.util.regex.MatchResult');
C$.$classes$=[['Value',0],['RegExp',1032]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.acceptMode=-1;
this.first=-1;
this.last=0;
this.oldLast=-1;
this.appendPos=0;
this.transparentBounds=false;
this.anchoringBounds=true;
},1);

C$.$fields$=[['Z',['hitEnd','requireEnd','transparentBounds','anchoringBounds','秘haveGroups'],'I',['leftBound','rightBound','lookbehindTo','acceptMode','first','last','oldLast','appendPos','groupCount','秘groupCount'],'S',['processedRepl','replacement','strString'],'O',['pat','java.util.regex.Pattern','groups','int[]','cs','CharSequence','replacementParts','Object[]','秘results','String[]','+results']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$java_util_regex_Pattern$CharSequence',  function (parent, text) {
;C$.$init$.apply(this);
this.pat=parent;
this.cs=text;
this.reset$();
}, 1);

Clazz_newMeth(C$, 'toMatchResult$',  function () {
var result=Clazz_new_(C$.c$$java_util_regex_Pattern$CharSequence,[this.pat, this.cs.toString()]);
result.first=this.first;
result.last=this.last;
result.秘groupCount=this.秘groupCount;
result.秘results=this.秘results.clone$();
return result;
});

Clazz_newMeth(C$, 'usePattern$java_util_regex_Pattern',  function (newPattern) {
if (newPattern == null ) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Pattern cannot be null"]);
this.pat=newPattern;
p$1.clearGroups.apply(this, []);
return this;
});

Clazz_newMeth(C$, 'reset$',  function () {
this.first=-1;
this.last=0;
this.秘groupCount=0;
this.oldLast=-1;
p$1.clearGroups.apply(this, []);
this.appendPos=0;
this.leftBound=0;
this.rightBound=this.getTextLength$();
this.strString=null;
this.pat.regexp=$I$(1).clone$java_util_regex_Matcher_RegExp(this.pat.regexp);
return this;
});

Clazz_newMeth(C$, 'reset$CharSequence',  function (input) {
this.cs=input;
return this.reset$();
});

Clazz_newMeth(C$, 'find$',  function () {
var nextSearchIndex=this.last;
if (nextSearchIndex == this.first) ++nextSearchIndex;
if (nextSearchIndex < this.leftBound) nextSearchIndex=this.leftBound;
if (nextSearchIndex > this.rightBound) {
p$1.clearGroups.apply(this, []);
return false;
}return this.search$I$I(nextSearchIndex, -1);
});

Clazz_newMeth(C$, 'search$I$I',  function (from, anchor) {
if (this.strString == null ) this.strString=this.cs.toString();
this.hitEnd=false;
this.requireEnd=this.pat.pattern$().endsWith$S("$");
from=(from < 0 ? 0 : from);
this.first=from;
this.oldLast=(this.oldLast < 0 ? from : this.oldLast);
p$1.clearGroups.apply(this, []);
var s=(this.rightBound == this.strString.length$() ? this.strString : this.strString.substring$I$I(0, this.rightBound));
var rg=this.pat.regexp;
rg.lastIndex=from;
this.acceptMode=(anchor == -1 ? 0 : anchor);
this.秘results=p$1.execRE$java_util_regex_Matcher_RegExp$S.apply(this, [rg, s]);
var result=p$1.checkRE$SA$S.apply(this, [this.秘results, s]);
this.oldLast=this.last;
return result;
});

Clazz_newMeth(C$, 'clearGroups',  function () {
this.秘haveGroups=false;
this.groups=null;
}, p$1);

Clazz_newMeth(C$, 'find$I',  function (start) {
var limit=this.getTextLength$();
if ((start < 0) || (start > limit) ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["Illegal start index"]);
this.reset$();
return this.search$I$I(start, -1);
});

Clazz_newMeth(C$, 'lookingAt$',  function () {
return this.match$I$I(this.leftBound, 2);
});

Clazz_newMeth(C$, 'appendReplacement$StringBuffer$S',  function (sb, replacement) {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match available"]);
this.processedRepl=p$1.processRepl$S.apply(this, [replacement]);
sb.append$CharSequence$I$I(this.cs, this.appendPos, this.first);
sb.append$S(this.processedRepl);
this.appendPos=this.last;
return this;
});

Clazz_newMeth(C$, 'processRepl$S',  function (replacement) {
if (this.replacement != null  && this.replacement.equals$O(replacement) ) {
return (this.replacementParts == null  ? this.processedRepl : 1 ? this.replacementParts.join("") :null);
}this.replacement=replacement;
if (replacement != null  && replacement.indexOf$S("$") >= 0 ) p$1.秘updateGroups.apply(this, []);
var index=0;
var replacementPos=0;
var res=Clazz_new_($I$(2,1));
var len=replacement.length$();
while (index < len){
var nextChar=replacement.charAt$I(index);
switch (nextChar.$c()) {
case 92:
++index;
if (index == replacement.length$()) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["character to be escaped is missing"]);
nextChar=replacement.charAt$I(index);
res.append$C(nextChar);
++index;
break;
case 36:
++index;
if (index == len) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Illegal group reference: group index is missing"]);
nextChar=replacement.charAt$I(index);
var gr=-1;
if (nextChar == "{") {
++index;
var gsb=Clazz_new_($I$(2,1));
while (index < replacement.length$()){
nextChar=replacement.charAt$I(index);
if ($I$(3,"isLower$I",[nextChar.$c()]) || $I$(3,"isUpper$I",[nextChar.$c()]) || $I$(3,"isDigit$I",[nextChar.$c()])  ) {
gsb.append$C(nextChar);
++index;
} else {
break;
}}
if (gsb.length$() == 0) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["named capturing group has 0 length name"]);
if (nextChar != "}") throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["named capturing group is missing trailing \'}\'"]);
var gname=gsb.toString();
if ($I$(3,"isDigit$I",[gname.charAt$I(0).$c()])) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["capturing group name {" + gname + "} starts with digit character" ]);
if (this.pat.namedGroups == null  || !this.pat.namedGroups$().containsKey$O(gname) ) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["No group with name {" + gname + "}" ]);
gr=(this.pat.namedGroups$().get$O(gname)).$c();
++index;
} else {
if (this.replacementParts == null ) this.replacementParts=Clazz_array(String, [0]);
gr=nextChar.$c() - 48;
if ((gr < 0) || (gr > 9) ) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["Illegal group reference"]);
++index;
var done=false;
while (!done){
if (index >= replacement.length$()) {
break;
}var nextDigit=(replacement.charCodeAt$I(index)) - 48;
if ((nextDigit < 0) || (nextDigit > 9) ) {
break;
}var newRefNum=(gr * 10) + nextDigit;
if (this.groupCount$() < newRefNum) {
done=true;
} else {
gr=newRefNum;
++index;
}}
}var n=res.length$();
if (replacementPos != n) {
this.replacementParts[this.replacementParts.length]=res.substring$I$I(replacementPos, n);
replacementPos=n;
}var g=(this.replacementParts[this.replacementParts.length]=Clazz_new_($I$(4,1).c$$I,[this, null, gr])).toString();
res.append$S(g);
replacementPos=res.length$();
break;
default:
res.append$C(nextChar);
++index;
break;
}
}
if (this.replacementParts != null  && replacementPos != res.length$() ) {
this.replacementParts[this.replacementParts.length]=res.substring$I$I(replacementPos, res.length$());
}return res.toString();
}, p$1);

Clazz_newMeth(C$, 'region$I$I',  function (start, end) {
if ((start < 0) || (start > this.getTextLength$()) ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["start"]);
if ((end < 0) || (end > this.getTextLength$()) ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["end"]);
if (start > end) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["start > end"]);
this.reset$();
this.leftBound=start;
this.rightBound=end;
return this;
});

Clazz_newMeth(C$, 'appendTail$StringBuffer',  function (sb) {
return sb.append$CharSequence$I$I(this.cs, this.appendPos, this.getTextLength$());
});

Clazz_newMeth(C$, 'replaceFirst$S',  function (replacement) {
if (replacement == null ) throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["replacement"]);
this.reset$();
if (!this.find$()) return this.cs.toString();
var sb=Clazz_new_($I$(5,1));
this.appendReplacement$StringBuffer$S(sb, replacement);
return this.appendTail$StringBuffer(sb).toString();
});

Clazz_newMeth(C$, 'replaceAll$S',  function (replacement) {
this.reset$();
var result=this.find$();
if (!result) {
return this.cs.toString();
}var sb=Clazz_new_($I$(5,1));
do {
this.appendReplacement$StringBuffer$S(sb, replacement);
result=this.find$();
} while (result);
return this.appendTail$StringBuffer(sb).toString();
});

Clazz_newMeth(C$, 'pattern$',  function () {
return this.pat;
});

Clazz_newMeth(C$, 'group$',  function () {
return this.group$I(0);
});

Clazz_newMeth(C$, 'group$I',  function (group) {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match found"]);
if (group < 0 || group > this.groupCount$() ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["No group " + group]);
return this.results[group] == null  ? null : this.results[group];
});

Clazz_newMeth(C$, 'group$S',  function (name) {
var group=this.getMatchedGroupIndex$S(name);
return group < 0 || group >= this.results.length  ? null : this.group$I(group);
});

Clazz_newMeth(C$, 'groupCount$',  function () {
p$1.秘updateGroups.apply(this, []);
return this.groupCount;
});

Clazz_newMeth(C$, '秘updateGroups',  function () {
if (this.秘haveGroups || this.秘groupCount <= 0  || this.秘results == null  ) return;
this.秘haveGroups=true;
this.pat.秘setNameGroups$();
var names=this.pat.秘groupNames;
var pt=this.start$();
this.groupCount=-1;
this.groups=Clazz_array(Integer.TYPE, [names.size$() * 2]);
this.results=Clazz_array(String, [this.秘results.length]);
for (var i=0, gpt=0, n=names.size$(); i < n; i++) {
var name=names.get$I(i);
var r=this.秘results[i];
var len=(r == null  ? 0 : r.length$());
if (name == null  || !name.startsWith$S("\u79d8") ) {
this.groups[gpt++]=pt;
this.groups[gpt++]=pt + len;
this.pat.namedGroups$().put$O$O(name, Integer.valueOf$I(this.groupCount));
this.results[++this.groupCount]=r;
} else {
pt+=len;
}}
}, p$1);

Clazz_newMeth(C$, 'matches$',  function () {
return this.match$I$I(this.leftBound, 1);
});

Clazz_newMeth(C$, 'match$I$I',  function (from, anchor) {
this.hitEnd=false;
from=Math.max(0, from);
this.first=from;
this.oldLast=(this.oldLast < 0 ? from : this.oldLast);
p$1.clearGroups.apply(this, []);
var result=this.search$I$I(from, anchor);
this.oldLast=from;
this.pat.regexp.lastIndex=from;
return result;
});

Clazz_newMeth(C$, 'indexRE$SA',  function (r) {
return r.index ||0;
}, p$1);

Clazz_newMeth(C$, 'execRE$java_util_regex_Matcher_RegExp$S',  function (rg, s) {
return 1 ? rg.exec(s) :null;
}, p$1);

Clazz_newMeth(C$, 'checkRE$SA$S',  function (r, s) {
this.hitEnd=(r == null );
if (this.hitEnd) {
this.requireEnd=false;
this.first=-1;
return false;
}this.秘groupCount=r.length - 1;
var f0=this.first;
this.first=p$1.indexRE$SA.apply(this, [r]);
this.last=this.first + r[0].length$();
this.hitEnd=(this.last == s.length$());
if (this.hitEnd && this.requireEnd$() && this.last != this.strString.length$()  ) {
return false;
}if (this.秘groupCount < 0) return false;
switch (this.acceptMode) {
case 2:
return this.first == f0;
case 1:
return this.first == f0 && this.last == r.input.length ||0 ;
default:
return true;
}
}, p$1);

Clazz_newMeth(C$, 'quoteReplacement$S',  function (s) {
if ((s.indexOf$I("\\") == -1) && (s.indexOf$I("$") == -1) ) return s;
var sb="";
for (var i=0; i < s.length$(); i++) {
var c=s.charAt$I(i);
if (c == "\\" || c == "$" ) {
sb+="\\";
}sb+=c;
}
return sb;
}, 1);

Clazz_newMeth(C$, 'regionStart$',  function () {
return this.leftBound;
});

Clazz_newMeth(C$, 'regionEnd$',  function () {
return this.rightBound;
});

Clazz_newMeth(C$, 'hasTransparentBounds$',  function () {
return this.transparentBounds;
});

Clazz_newMeth(C$, 'useTransparentBounds$Z',  function (b) {
this.transparentBounds=b;
return this;
});

Clazz_newMeth(C$, 'hasAnchoringBounds$',  function () {
return this.anchoringBounds;
});

Clazz_newMeth(C$, 'useAnchoringBounds$Z',  function (b) {
this.anchoringBounds=b;
return this;
});

Clazz_newMeth(C$, 'toString',  function () {
var sb=Clazz_new_($I$(2,1));
sb.append$S("java.util.regex.Matcher");
sb.append$S("[pattern=" + this.pattern$());
sb.append$S(" region=");
sb.append$S(this.regionStart$() + "," + this.regionEnd$() );
sb.append$S(" lastmatch=");
if ((this.first >= 0) && (this.group$() != null ) ) {
sb.append$S(this.group$());
}sb.append$S("]");
return sb.toString();
});

Clazz_newMeth(C$, 'hitEnd$',  function () {
return this.hitEnd;
});

Clazz_newMeth(C$, 'requireEnd$',  function () {
return this.requireEnd;
});

Clazz_newMeth(C$, 'getTextLength$',  function () {
return this.cs.length$();
});

Clazz_newMeth(C$, 'getSubSequence$I$I',  function (beginIndex, endIndex) {
return this.cs.subSequence$I$I(beginIndex, endIndex);
});

Clazz_newMeth(C$, 'charAt$I',  function (i) {
return this.cs.charAt$I(i);
});

Clazz_newMeth(C$, 'getMatchedGroupIndex$S',  function (name) {
$I$(6).requireNonNull$O$S(name, "Group name");
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match found"]);
p$1.秘updateGroups.apply(this, []);
if (this.pat.namedGroups == null  || !this.pat.namedGroups$().containsKey$O(name) ) throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["No group with name <" + name + ">" ]);
return this.pat.namedGroups$().get$O(name).intValue$() + 1;
});

Clazz_newMeth(C$, 'start$',  function () {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match available"]);
return this.first;
});

Clazz_newMeth(C$, 'start$I',  function (group) {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match available"]);
if (group < 0 || group > this.groupCount$() ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["No group " + group]);
if (group == 0) return this.start$();
return this.groups[group * 2];
});

Clazz_newMeth(C$, 'start$S',  function (name) {
var g=this.getMatchedGroupIndex$S(name);
return this.groups[g * 2];
});

Clazz_newMeth(C$, 'end$',  function () {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match available"]);
return this.last;
});

Clazz_newMeth(C$, 'end$I',  function (group) {
if (this.first < 0) throw Clazz_new_(Clazz_load('IllegalStateException').c$$S,["No match available"]);
if (group < 0 || group > this.groupCount$() ) throw Clazz_new_(Clazz_load('IndexOutOfBoundsException').c$$S,["No group " + group]);
if (group == 0) return this.end$();
return this.groups[group * 2 + 1];
});

Clazz_newMeth(C$, 'end$S',  function (name) {
var g=this.getMatchedGroupIndex$S(name);
return this.groups[g * 2 + 1];
});
;
(function(){/*c*/var C$=Clazz_newClass(P$.Matcher, "Value", function(){
Clazz_newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['grN']]]

Clazz_newMeth(C$, 'c$$I',  function (grN) {
;C$.$init$.apply(this);
this.grN=grN;
}, 1);

Clazz_newMeth(C$, 'toString',  function () {
return this.b$['java.util.regex.Matcher'].group$I.apply(this.b$['java.util.regex.Matcher'], [this.grN]).toString();
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.Matcher, "RegExp", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['lastIndex']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'clone$java_util_regex_Matcher_RegExp',  function (rg) {
return 1?new RegExp(rg.source, rg.flags):null;
}, 1);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:29 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.regex"),I$=[];
/*i*/var C$=Clazz_newInterface(P$, "MatchResult");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:29 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=java.util,p$1={},p$2={},I$=[[0,'InternalError','java.util.Collections','java.util.Arrays',['java.util.ResourceBundle','.SingleFormatControl'],['java.util.ResourceBundle','.NoFallbackControl'],'java.util.ArrayList','java.util.Locale','swingjs.api.Interface','swingjs.JSUtil','java.util.ResourceBundle','StringBuilder',['java.util.ResourceBundle','.Control'],'java.util.HashMap',['java.util.ResourceBundle','.CacheKey'],'Thread','java.util.HashSet']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ResourceBundle", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['CacheKey',26],['Control',9],['SingleFormatControl',10],['NoFallbackControl',26]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.parent=null;
this.locale=null;
},1);

C$.$fields$=[['Z',['expired'],'S',['name'],'O',['parent','java.util.ResourceBundle','locale','java.util.Locale','keySet','java.util.Set']]
,['O',['NONEXISTENT_BUNDLE','java.util.ResourceBundle','cacheList','java.util.HashMap']]]

Clazz_newMeth(C$, 'getBaseBundleName$',  function () {
return this.name;
});

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'getString$S',  function (key) {
return this.getObject$S(key);
});

Clazz_newMeth(C$, 'getStringArray$S',  function (key) {
return this.getObject$S(key);
});

Clazz_newMeth(C$, 'getObject$S',  function (key) {
var obj=this.handleGetObject$S(key);
if (obj == null ) {
if (this.parent != null ) {
obj=this.parent.getObject$S(key);
}if (obj == null ) throw Clazz_new_(Clazz_load('java.util.MissingResourceException').c$$S$S$S,["Can't find resource for bundle " + this.getClass$().getName$() + ", key " + key , this.getClass$().getName$(), key]);
}return obj;
});

Clazz_newMeth(C$, 'getLocale$',  function () {
return this.locale;
});

Clazz_newMeth(C$, 'setParent$java_util_ResourceBundle',  function (parent) {
Clazz_assert(C$, this, function(){return parent !== C$.NONEXISTENT_BUNDLE });
this.parent=parent;
});

Clazz_newMeth(C$, 'getBundle$S',  function (baseName) {
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, $I$(7).getDefault$(), null, $I$(12).INSTANCE);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$java_util_ResourceBundle_Control',  function (baseName, control) {
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, $I$(7).getDefault$(), null, control);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$java_util_Locale',  function (baseName, locale) {
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, locale, null, $I$(12).INSTANCE);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$java_util_Locale$java_util_ResourceBundle_Control',  function (baseName, targetLocale, control) {
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, targetLocale, null, control);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$java_util_Locale$O',  function (baseName, locale, loader) {
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, locale, null, $I$(12).INSTANCE);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$O$O$java_util_ResourceBundle_Control',  function (baseName, targetLocale, loader, control) {
if (targetLocale == null ) targetLocale=$I$(7).getDefault$();
if (control == null ) control=$I$(12,"getControl$java_util_List",[$I$(12).FORMAT_PROPERTIES]);
return C$.getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control(baseName, targetLocale, loader, control);
}, 1);

Clazz_newMeth(C$, 'getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control',  function (baseName, locale, loader, control) {
if (control == null ) {
throw Clazz_new_(Clazz_load('NullPointerException').c$$S,["ResourceBundle locale or control is null"]);
}var cacheKey=Clazz_new_($I$(14,1).c$$S$java_util_Locale$O,[baseName, locale, loader]);
var bundle=null;
var bundleRef=C$.cacheList.get$O(cacheKey);
if (bundleRef != null ) {
bundle=bundleRef;
bundleRef=null;
}if (C$.isValidBundle$java_util_ResourceBundle(bundle)) {
return bundle;
}var formats=control.getFormats$S(baseName);
var baseBundle=null;
for (var targetLocale=locale; targetLocale != null ; targetLocale=control.getFallbackLocale$S$java_util_Locale(baseName, targetLocale)) {
var candidateLocales=control.getCandidateLocales$S$java_util_Locale(baseName, targetLocale);
bundle=C$.findBundle$java_util_ResourceBundle_CacheKey$java_util_List$java_util_List$I$java_util_ResourceBundle_Control$java_util_ResourceBundle(cacheKey, candidateLocales, formats, 0, control, baseBundle);
if (C$.isValidBundle$java_util_ResourceBundle(bundle)) {
var isBaseBundle=$I$(7).ROOT.equals$O(bundle.locale);
if (!isBaseBundle || bundle.locale.equals$O(locale) || (candidateLocales.size$() == 1 && bundle.locale.equals$O(candidateLocales.get$I(0)) )  ) {
break;
}if (isBaseBundle && baseBundle == null  ) {
baseBundle=bundle;
}}}
if (bundle == null ) {
if (baseBundle == null ) {
C$.throwMissingResourceException$S$java_util_Locale$Throwable(baseName, locale, p$1.getCause.apply(cacheKey, []));
}bundle=baseBundle;
}return bundle;
}, 1);

Clazz_newMeth(C$, 'findBundle$java_util_ResourceBundle_CacheKey$java_util_List$java_util_List$I$java_util_ResourceBundle_Control$java_util_ResourceBundle',  function (cacheKey, candidateLocales, formats, index, control, baseBundle) {
var targetLocale=candidateLocales.get$I(index);
var parent=null;
if (index != candidateLocales.size$() - 1) {
parent=C$.findBundle$java_util_ResourceBundle_CacheKey$java_util_List$java_util_List$I$java_util_ResourceBundle_Control$java_util_ResourceBundle(cacheKey, candidateLocales, formats, index + 1, control, baseBundle);
} else if (baseBundle != null  && $I$(7).ROOT.equals$O(targetLocale) ) {
return baseBundle;
}var expiredBundle=false;
cacheKey.setLocale$java_util_Locale(targetLocale);
var bundle=C$.findBundleInCache$java_util_ResourceBundle_CacheKey$java_util_ResourceBundle_Control(cacheKey, control);
if (C$.isValidBundle$java_util_ResourceBundle(bundle)) {
expiredBundle=bundle.expired;
if (!expiredBundle) {
if (bundle.parent === parent ) {
return bundle;
}var bundleRef=C$.cacheList.get$O(cacheKey);
if (bundleRef != null  && bundleRef === bundle  ) {
C$.cacheList.remove$O(cacheKey);
}}}if (bundle !== C$.NONEXISTENT_BUNDLE ) {
var constKey=cacheKey.clone$();
try {
try {
bundle=C$.loadBundle$java_util_ResourceBundle_CacheKey$java_util_List$java_util_ResourceBundle_Control$Z(cacheKey, formats, control, expiredBundle);
if (bundle != null ) {
if (bundle.parent == null ) {
bundle.setParent$java_util_ResourceBundle(parent);
}bundle.locale=targetLocale;
bundle=C$.putBundleInCache$java_util_ResourceBundle_CacheKey$java_util_ResourceBundle$java_util_ResourceBundle_Control(cacheKey, bundle, control);
return bundle;
}C$.putBundleInCache$java_util_ResourceBundle_CacheKey$java_util_ResourceBundle$java_util_ResourceBundle_Control(cacheKey, C$.NONEXISTENT_BUNDLE, control);
} finally {
}
} finally {
if (Clazz_instanceOf(p$1.getCause.apply(constKey, []), "java.lang.InterruptedException")) {
$I$(15).currentThread$().interrupt$();
}}
}return parent;
}, 1);

Clazz_newMeth(C$, 'loadBundle$java_util_ResourceBundle_CacheKey$java_util_List$java_util_ResourceBundle_Control$Z',  function (cacheKey, formats, control, reload) {
var targetLocale=cacheKey.getLocale$();
var bundle=null;
var size=formats.size$();
for (var i=0; i < size; i++) {
var format=formats.get$I(i);
try {
bundle=control.newBundle$S$java_util_Locale$S$O$Z(cacheKey.getName$(), targetLocale, format, null, reload);
} catch (e$$) {
if (Clazz_exceptionOf(e$$,"LinkageError")){
var error = e$$;
{
p$1.setCause$Throwable.apply(cacheKey, [error]);
}
} else if (Clazz_exceptionOf(e$$,"Exception")){
var cause = e$$;
{
p$1.setCause$Throwable.apply(cacheKey, [cause]);
}
} else {
throw e$$;
}
}
if (bundle != null ) {
cacheKey.setFormat$S(format);
bundle.name=cacheKey.getName$();
bundle.locale=targetLocale;
bundle.expired=false;
break;
}}
return bundle;
}, 1);

Clazz_newMeth(C$, 'isValidBundle$java_util_ResourceBundle',  function (bundle) {
return bundle != null  && bundle !== C$.NONEXISTENT_BUNDLE  ;
}, 1);

Clazz_newMeth(C$, 'throwMissingResourceException$S$java_util_Locale$Throwable',  function (baseName, locale, cause) {
if (Clazz_instanceOf(cause, "java.util.MissingResourceException")) {
cause=null;
}throw Clazz_new_(Clazz_load('java.util.MissingResourceException').c$$S$S$S$Throwable,["Can't find bundle for base name " + baseName + ", locale " + locale , baseName + "_" + locale , "", cause]);
}, 1);

Clazz_newMeth(C$, 'findBundleInCache$java_util_ResourceBundle_CacheKey$java_util_ResourceBundle_Control',  function (cacheKey, control) {
var bundleRef=C$.cacheList.get$O(cacheKey.toString());
if (bundleRef == null ) {
return null;
}var bundle=bundleRef;
return bundle;
}, 1);

Clazz_newMeth(C$, 'putBundleInCache$java_util_ResourceBundle_CacheKey$java_util_ResourceBundle$java_util_ResourceBundle_Control',  function (cacheKey, bundle, control) {
var key=cacheKey.clone$();
C$.cacheList.put$O$O(key.toString(), bundle);
return bundle;
}, 1);

Clazz_newMeth(C$, 'clearCache$',  function () {
C$.cacheList.clear$();
}, 1);

Clazz_newMeth(C$, 'containsKey$S',  function (key) {
if (key == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}for (var rb=this; rb != null ; rb=rb.parent) {
if (rb.handleKeySet$().contains$O(key)) {
return true;
}}
return false;
});

Clazz_newMeth(C$, 'keySet$',  function () {
var keys=Clazz_new_($I$(16,1));
for (var rb=this; rb != null ; rb=rb.parent) {
keys.addAll$java_util_Collection(rb.handleKeySet$());
}
return keys;
});

Clazz_newMeth(C$, 'handleKeySet$',  function () {
if (this.keySet == null ) {
{
if (this.keySet == null ) {
var keys=Clazz_new_($I$(16,1));
var enumKeys=this.getKeys$();
while (enumKeys.hasMoreElements$()){
var key=enumKeys.nextElement$();
if (this.handleGetObject$S(key) != null ) {
keys.add$O(key);
}}
this.keySet=keys;
}}}return this.keySet;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.NONEXISTENT_BUNDLE=((P$.ResourceBundle$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "ResourceBundle$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, Clazz_load('java.util.ResourceBundle'), null, 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getKeys$',  function () {
return null;
});

Clazz_newMeth(C$, 'handleGetObject$S',  function (key) {
return null;
});

Clazz_newMeth(C$, 'toString',  function () {
return "NONEXISTENT_BUNDLE";
});
})()
), Clazz_new_(C$,[this, null],P$.ResourceBundle$1));
C$.cacheList=Clazz_new_($I$(13,1).c$$I,[32]);
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.ResourceBundle, "CacheKey", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, null, 'Cloneable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['hashCodeCache'],'S',['name','format'],'O',['locale','java.util.Locale','cause','Throwable']]]

Clazz_newMeth(C$, 'c$$S$java_util_Locale$O',  function (baseName, locale, loader) {
;C$.$init$.apply(this);
this.name=baseName;
this.locale=locale;
if (this.name != null ) p$1.calculateHashCode.apply(this, []);
}, 1);

Clazz_newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz_newMeth(C$, 'getLocale$',  function () {
return this.locale;
});

Clazz_newMeth(C$, 'setLocale$java_util_Locale',  function (locale) {
if (!this.locale.equals$O(locale)) {
this.locale=locale;
p$1.calculateHashCode.apply(this, []);
}return this;
});

Clazz_newMeth(C$, 'equals$O',  function (other) {
if (this === other ) {
return true;
}try {
var otherEntry=other;
if (this.hashCodeCache != otherEntry.hashCodeCache) {
return false;
}if (!this.name.equals$O(otherEntry.name)) {
return false;
}if (!this.locale.equals$O(otherEntry.locale)) {
return false;
}return true;
} catch (e$$) {
if (Clazz_exceptionOf(e$$,"NullPointerException")){
var e = e$$;
{
}
} else if (Clazz_exceptionOf(e$$,"ClassCastException")){
var e = e$$;
{
}
} else {
throw e$$;
}
}
return false;
});

Clazz_newMeth(C$, 'hashCode$',  function () {
return this.hashCodeCache;
});

Clazz_newMeth(C$, 'calculateHashCode',  function () {
this.hashCodeCache=this.name.hashCode$() << 3;
this.hashCodeCache^=this.locale.hashCode$();
}, p$1);

Clazz_newMeth(C$, 'clone$',  function () {
try {
var clone=Clazz_clone(this);
clone.cause=null;
return clone;
} catch (e) {
if (Clazz_exceptionOf(e,"CloneNotSupportedException")){
throw Clazz_new_($I$(1,1));
} else {
throw e;
}
}
});

Clazz_newMeth(C$, 'setFormat$S',  function (format) {
this.format=format;
});

Clazz_newMeth(C$, 'setCause$Throwable',  function (cause) {
if (this.cause == null ) {
this.cause=cause;
} else {
if (Clazz_instanceOf(this.cause, "java.lang.ClassNotFoundException")) {
this.cause=cause;
}}}, p$1);

Clazz_newMeth(C$, 'getCause',  function () {
return this.cause;
}, p$1);

Clazz_newMeth(C$, 'toString',  function () {
var l=this.locale.toString();
if (l.length$() == 0) {
if (this.locale.getVariant$().length$() != 0) {
l="__" + this.locale.getVariant$();
} else {
l="\"\"";
}}return "CacheKey[" + this.name + ", lc=" + l + "(format=" + this.format + ")]" ;
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ResourceBundle, "Control", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['FORMAT_DEFAULT','java.util.List','+FORMAT_CLASS','+FORMAT_PROPERTIES','INSTANCE','java.util.ResourceBundle.Control']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'getControl$java_util_List',  function (formats) {
if (formats.equals$O(C$.FORMAT_PROPERTIES)) {
return $I$(4).PROPERTIES_ONLY;
}if (formats.equals$O(C$.FORMAT_CLASS)) {
return $I$(4).CLASS_ONLY;
}if (formats.equals$O(C$.FORMAT_DEFAULT)) {
return C$.INSTANCE;
}throw Clazz_new_(Clazz_load('IllegalArgumentException'));
}, 1);

Clazz_newMeth(C$, 'getNoFallbackControl$java_util_List',  function (formats) {
if (formats.equals$O(C$.FORMAT_DEFAULT)) {
return $I$(5).NO_FALLBACK;
}if (formats.equals$O(C$.FORMAT_PROPERTIES)) {
return $I$(5).PROPERTIES_ONLY_NO_FALLBACK;
}if (formats.equals$O(C$.FORMAT_CLASS)) {
return $I$(5).CLASS_ONLY_NO_FALLBACK;
}throw Clazz_new_(Clazz_load('IllegalArgumentException'));
}, 1);

Clazz_newMeth(C$, 'getFormats$S',  function (baseName) {
if (baseName == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}return C$.FORMAT_DEFAULT;
});

Clazz_newMeth(C$, 'getCandidateLocales$S$java_util_Locale',  function (baseName, locale) {
if (baseName == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}var language=locale.getLanguage$();
var country=locale.getCountry$();
var variant=locale.getVariant$();
var locales=Clazz_new_($I$(6,1).c$$I,[4]);
if (variant.length$() > 0) {
locales.add$O(locale);
}if (country.length$() > 0) {
locales.add$O((locales.size$() == 0) ? locale : $I$(7).getInstance$S$S$S(language, country, ""));
}if (language.length$() > 0) {
locales.add$O((locales.size$() == 0) ? locale : $I$(7).getInstance$S$S$S(language, "", ""));
}locales.add$O($I$(7).ROOT);
return locales;
});

Clazz_newMeth(C$, 'getFallbackLocale$S$java_util_Locale',  function (baseName, locale) {
if (baseName == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}var defaultLocale=$I$(7).getDefault$();
return locale.equals$O(defaultLocale) ? null : defaultLocale;
});

Clazz_newMeth(C$, 'newBundle$S$java_util_Locale$S$O$Z',  function (baseName, locale, format, loader, reload) {
var bundleName=this.toBundleName$S$java_util_Locale(baseName, locale);
var bundle=null;
if (format.equals$O("java.class")) {
bundle=$I$(8).getInstance$S$Z(bundleName, true);
} else if (format.equals$O("java.properties")) {
var resourceName=p$2.toResourceName0$S$S.apply(this, [bundleName, "properties"]);
var stream;
if (resourceName == null  || (stream=$I$(9).getCachedResourceAsStream$S(resourceName)) == null  ) return null;
try {
bundle=p$2.newPropertyBundle$java_io_InputStream.apply(this, [stream]);
} finally {
stream.close$();
}
} else {
throw Clazz_new_(Clazz_load('IllegalArgumentException').c$$S,["unknown format: " + format]);
}return bundle;
});

Clazz_newMeth(C$, 'getBundle$S',  function (baseName) {
return $I$(10,"getBundleImpl$S$java_util_Locale$O$java_util_ResourceBundle_Control",[baseName, $I$(7).getDefault$(), null, C$.INSTANCE]);
}, 1);

Clazz_newMeth(C$, 'newPropertyBundle$java_io_InputStream',  function (stream) {
return ($I$(8).getInstance$S$Z("java.util.PropertyResourceBundle", false)).setStream$java_io_InputStream(stream);
}, p$2);

Clazz_newMeth(C$, 'getTimeToLive$S$java_util_Locale',  function (baseName, locale) {
if (baseName == null  || locale == null  ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}return -2;
});

Clazz_newMeth(C$, 'toBundleName$S$java_util_Locale',  function (baseName, locale) {
if (locale === $I$(7).ROOT ) {
return baseName;
}var language=locale.getLanguage$();
var country=locale.getCountry$();
var variant=locale.getVariant$();
if (language === ""  && country === ""   && variant === ""  ) {
return baseName;
}var sb=Clazz_new_($I$(11,1).c$$S,[baseName]);
sb.append$C("_");
if (variant !== "" ) {
sb.append$S(language).append$C("_").append$S(country).append$C("_").append$S(variant);
} else if (country !== "" ) {
sb.append$S(language).append$C("_").append$S(country);
} else {
sb.append$S(language);
}return sb.toString();
});

Clazz_newMeth(C$, 'toResourceName$S$S',  function (bundleName, suffix) {
var sb=Clazz_new_([bundleName.length$() + 1 + suffix.length$() ],$I$(11,1).c$$I);
sb.append$S(bundleName.replace$C$C(".", "/")).append$C(".").append$S(suffix);
return sb.toString();
});

Clazz_newMeth(C$, 'toResourceName0$S$S',  function (bundleName, suffix) {
if (bundleName.contains$CharSequence("://")) {
return null;
} else {
return this.toResourceName$S$S(bundleName, suffix);
}}, p$2);

C$.$static$=function(){C$.$static$=0;
C$.FORMAT_DEFAULT=$I$(2,"unmodifiableList$java_util_List",[$I$(3,"asList$OA",[Clazz_array(String, -1, ["java.class", "java.properties"])])]);
C$.FORMAT_CLASS=$I$(2,"unmodifiableList$java_util_List",[$I$(3,"asList$OA",[Clazz_array(String, -1, ["java.class"])])]);
C$.FORMAT_PROPERTIES=$I$(2,"unmodifiableList$java_util_List",[$I$(3,"asList$OA",[Clazz_array(String, -1, ["java.properties"])])]);
C$.INSTANCE=Clazz_new_(C$);
};
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ResourceBundle, "SingleFormatControl", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['java.util.ResourceBundle','.Control']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['formats','java.util.List']]
,['O',['PROPERTIES_ONLY','java.util.ResourceBundle.Control','+CLASS_ONLY']]]

Clazz_newMeth(C$, 'c$$java_util_List',  function (formats) {
Clazz_super_(C$, this);
this.formats=formats;
}, 1);

Clazz_newMeth(C$, 'getFormats$S',  function (baseName) {
if (baseName == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}return this.formats;
});

C$.$static$=function(){C$.$static$=0;
C$.PROPERTIES_ONLY=Clazz_new_(C$.c$$java_util_List,[$I$(12).FORMAT_PROPERTIES]);
C$.CLASS_ONLY=Clazz_new_(C$.c$$java_util_List,[$I$(12).FORMAT_CLASS]);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.ResourceBundle, "NoFallbackControl", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['java.util.ResourceBundle','.SingleFormatControl']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['NO_FALLBACK','java.util.ResourceBundle.Control','+PROPERTIES_ONLY_NO_FALLBACK','+CLASS_ONLY_NO_FALLBACK']]]

Clazz_newMeth(C$, 'c$$java_util_List',  function (formats) {
;C$.superclazz.c$$java_util_List.apply(this,[formats]);C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'getFallbackLocale$S$java_util_Locale',  function (baseName, locale) {
if (baseName == null  || locale == null  ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}return null;
});

C$.$static$=function(){C$.$static$=0;
C$.NO_FALLBACK=Clazz_new_(C$.c$$java_util_List,[$I$(12).FORMAT_DEFAULT]);
C$.PROPERTIES_ONLY_NO_FALLBACK=Clazz_new_(C$.c$$java_util_List,[$I$(12).FORMAT_PROPERTIES]);
C$.CLASS_ONLY_NO_FALLBACK=Clazz_new_(C$.c$$java_util_List,[$I$(12).FORMAT_CLASS]);
};

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:22 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("java.util.spi"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "LocaleServiceProvider");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
locale=locale.stripExtensions$();
for (var available, $available = 0, $$available = this.getAvailableLocales$(); $available<$$available.length&&((available=($$available[$available])),1);$available++) {
if (locale.equals$O(available.stripExtensions$())) {
return true;
}}
return false;
});
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:04:29 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("javajs.util"),I$=[[0,'java.lang.reflect.Array','javajs.util.T3','java.util.Arrays','javajs.util.Lst','java.util.Hashtable','javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "AU");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'ensureLength$O$I',  function (array, minimumLength) {
return (array != null  && C$.getLength$O(array) >= minimumLength  ? array : C$.arrayCopyObject$O$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthS$SA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyS$SA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthA$FA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyF$FA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthD$DA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyD$DA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthI$IA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyI$IA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthShort$HA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyShort$HA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'ensureLengthByte$BA$I',  function (array, minimumLength) {
return (array != null  && array.length >= minimumLength  ? array : C$.arrayCopyByte$BA$I(array, minimumLength));
}, 1);

Clazz_newMeth(C$, 'doubleLength$O',  function (array) {
return C$.arrayCopyObject$O$I(array, (array == null  ? 16 : 2 * C$.getLength$O(array)));
}, 1);

Clazz_newMeth(C$, 'doubleLengthS$SA',  function (array) {
return C$.arrayCopyS$SA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthD$DA',  function (array) {
return C$.arrayCopyD$DA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthF$FA',  function (array) {
return C$.arrayCopyF$FA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthI$IA',  function (array) {
return C$.arrayCopyI$IA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthShort$HA',  function (array) {
return C$.arrayCopyShort$HA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthByte$BA',  function (array) {
return C$.arrayCopyByte$BA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'doubleLengthBool$ZA',  function (array) {
return C$.arrayCopyBool$ZA$I(array, (array == null  ? 16 : 2 * array.length));
}, 1);

Clazz_newMeth(C$, 'deleteElements$O$I$I',  function (array, firstElement, nElements) {
if (nElements == 0 || array == null  ) return array;
var oldLength=C$.getLength$O(array);
if (firstElement >= oldLength) return array;
var n=oldLength - (firstElement + nElements);
if (n < 0) n=0;
var t=C$.newInstanceO$O$I(array, firstElement + n);
if (firstElement > 0) System.arraycopy$O$I$O$I$I(array, 0, t, 0, firstElement);
if (n > 0) System.arraycopy$O$I$O$I$I(array, firstElement + nElements, t, firstElement, n);
return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyObject$O$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : C$.getLength$O(array));
if (newLength < 0) newLength=oldLength;
if (newLength == oldLength) return array;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=C$.newInstanceO$O$I(array, newLength);
if (oldLength > 0) System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
return t;
}, 1);

Clazz_newMeth(C$, 'newInstanceO$O$I',  function (array, n) {
return Clazz_array(array.getClass$().getComponentType$(), n);
}, 1);

Clazz_newMeth(C$, 'getLength$O',  function (array) {
{
return array.length
}
}, 1);

Clazz_newMeth(C$, 'arrayCopyS$SA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(String, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyII$IAA$I',  function (array, newLength) {
var t=C$.newInt2$I(newLength);
if (array != null ) {
var oldLength=array.length;
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyPt$javajs_util_T3A$I',  function (array, newLength) {
if (newLength < 0) newLength=array.length;
var t=Clazz_array($I$(2), [newLength]);
if (array != null ) {
var oldLength=array.length;
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyF$FA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Float.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyD$DA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Double.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyI$IA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Integer.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyRangeI$IA$I$I',  function (array, i0, n) {
if (array == null ) return null;
var oldLength=array.length;
if (n == -1) n=oldLength;
if (n == -2) n=(oldLength/2|0);
{
return Clazz_array(-1, array, i0, n);
}
}, 1);

Clazz_newMeth(C$, 'arrayCopyRangeRevI$IA$I$I',  function (array, i0, n) {
if (array == null ) return null;
{
return Clazz_array(-1, array, i0, n).reverse();
}
}, 1);

Clazz_newMeth(C$, 'arrayCopyShort$HA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Short.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyByte$BA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Byte.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'arrayCopyBool$ZA$I',  function (array, newLength) {
var oldLength=(array == null  ? -1 : array.length);
if (newLength < 0) newLength=oldLength;
{
if (newLength < oldLength) return Clazz_array(-1, array, 0, newLength);
}
var t=Clazz_array(Boolean.TYPE, [newLength]);
if (array != null ) {
System.arraycopy$O$I$O$I$I(array, 0, t, 0, oldLength < newLength ? oldLength : newLength);
}return t;
}, 1);

Clazz_newMeth(C$, 'swapInt$IA$I$I',  function (array, indexA, indexB) {
var t=array[indexA];
array[indexA]=array[indexB];
array[indexB]=t;
}, 1);

Clazz_newMeth(C$, 'dumpArray$S$FAA$I$I$I$I',  function (msg, A, x1, x2, y1, y2) {
var s="dumpArray: " + msg + "\n" ;
for (var x=x1; x <= x2; x++) s+="\t*" + x + "*" ;

for (var y=y2; y >= y1; y--) {
s+="\n*" + y + "*" ;
for (var x=x1; x <= x2; x++) s+="\t" + (new Float(x < A.length && y < A[x].length  ? A[x][y] : NaN).toString());

}
return s;
}, 1);

Clazz_newMeth(C$, 'dumpIntArray$IA$I',  function (A, n) {
var str="";
for (var i=0; i < n; i++) str+=" " + A[i];

return str;
}, 1);

Clazz_newMeth(C$, 'sortedItem$javajs_util_Lst$I',  function (v, n) {
if (v.size$() == 0) return null;
if (v.size$() == 1) return v.get$I(0);
var keys=v.toArray$OA(Clazz_array(String, [v.size$()]));
$I$(3).sort$OA(keys);
return keys[n % keys.length];
}, 1);

Clazz_newMeth(C$, 'createArrayOfArrayList$I',  function (size) {
return Clazz_array($I$(4), [size]);
}, 1);

Clazz_newMeth(C$, 'createArrayOfHashtable$I',  function (size) {
return Clazz_array($I$(5), [size]);
}, 1);

Clazz_newMeth(C$, 'swap$OA$I$I',  function (o, i, j) {
var oi=o[i];
o[i]=o[j];
o[j]=oi;
}, 1);

Clazz_newMeth(C$, 'newFloat2$I',  function (n) {
return Clazz_array(Float.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'newBool2$I',  function (n) {
return Clazz_array(Boolean.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'newInt2$I',  function (n) {
return Clazz_array(Integer.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'newInt3$I$I',  function (nx, ny) {
return (ny < 0 ? Clazz_array(Integer.TYPE, [nx, null, null]) : Clazz_array(Integer.TYPE, [nx, ny, null]));
}, 1);

Clazz_newMeth(C$, 'newFloat3$I$I',  function (nx, ny) {
return (ny < 0 ? Clazz_array(Float.TYPE, [nx, null, null]) : Clazz_array(Float.TYPE, [nx, ny, null]));
}, 1);

Clazz_newMeth(C$, 'newInt4$I',  function (n) {
return Clazz_array(Integer.TYPE, [n, null, null, null]);
}, 1);

Clazz_newMeth(C$, 'newShort2$I',  function (n) {
return Clazz_array(Short.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'newByte2$I',  function (n) {
return Clazz_array(Byte.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'newDouble2$I',  function (n) {
return Clazz_array(Double.TYPE, [n, null]);
}, 1);

Clazz_newMeth(C$, 'removeMapKeys$java_util_Map$S',  function (map, root) {
var list=Clazz_new_($I$(4,1));
for (var key, $key = map.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) if (key.startsWith$S(root)) list.addLast$O(key);

for (var i=list.size$(); --i >= 0; ) map.remove$O(list.get$I(i));

return list.size$();
}, 1);

Clazz_newMeth(C$, 'isAS$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(String, -1));
}, 1);

Clazz_newMeth(C$, 'isASS$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(String, -2));
}, 1);

Clazz_newMeth(C$, 'isAP$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array($I$(2), -1));
}, 1);

Clazz_newMeth(C$, 'isAF$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Float.TYPE, -1));
}, 1);

Clazz_newMeth(C$, 'isAFloat$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Float, -1));
}, 1);

Clazz_newMeth(C$, 'isADouble$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Double, -1));
}, 1);

Clazz_newMeth(C$, 'isAD$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Double.TYPE, -1));
}, 1);

Clazz_newMeth(C$, 'isADD$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Double.TYPE, -2));
}, 1);

Clazz_newMeth(C$, 'isAB$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Byte.TYPE, -1));
}, 1);

Clazz_newMeth(C$, 'isAI$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Integer.TYPE, -1));
}, 1);

Clazz_newMeth(C$, 'isAII$O',  function (x) {
return (Clazz_instanceOf(x, Clazz_array(Integer.TYPE, -2)));
}, 1);

Clazz_newMeth(C$, 'isAFF$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Float.TYPE, -2));
}, 1);

Clazz_newMeth(C$, 'isAFFF$O',  function (x) {
return Clazz_instanceOf(x, Clazz_array(Float.TYPE, -3));
}, 1);

Clazz_newMeth(C$, 'ensureSignedBytes$BA',  function (b) {
if (b != null ) {
{
for (var i = b.length; --i >= 0;) { var j = b[i] & 0xFF; if (j >= 0x80) j -= 0x100; b[i] = j; }
}
}return b;
}, 1);

Clazz_newMeth(C$, 'asFloatA$DA',  function (a) {
{
a.__ARRAYTYPE = "FA"; return a;
}
}, 1);

Clazz_newMeth(C$, 'toFloatA$DA',  function (a) {
var f=Clazz_array(Float.TYPE, [a.length]);
for (var i=f.length; --i >= 0; ) f[i]=a[i];

return f;
}, 1);

Clazz_newMeth(C$, 'asDoubleA$FA',  function (a) {
{
a.__ARRAYTYPE = "DA"; return a;
}
}, 1);

Clazz_newMeth(C$, 'toDoubleA$FA',  function (a) {
var f=Clazz_array(Double.TYPE, [a.length]);
for (var i=f.length; --i >= 0; ) f[i]=$I$(6).toDouble$F(a[i]);

return f;
}, 1);

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-31 20:16:38 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.canvas"),I$=[[0,'java.util.ArrayList','jme.canvas.Graphical2DObject','java.util.Collections','jme.util.Box']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Graphical2DObjectGroup", null, null, 'jme.canvas.Graphical2DObject');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['group','java.util.ArrayList']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.group=Clazz_new_($I$(1,1));
}, 1);

Clazz_newMeth(C$, 'c$$java_util_ArrayList',  function (initGroup) {
;C$.$init$.apply(this);
this.group=Clazz_new_($I$(1,1).c$$java_util_Collection,[initGroup]);
}, 1);

Clazz_newMeth(C$, 'draw$jme_canvas_PreciseGraphicsAWT',  function (og) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
go.draw$jme_canvas_PreciseGraphicsAWT(og);
}
});

Clazz_newMeth(C$, 'moveXY$D$D',  function (movex, movey) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
go.moveXY$D$D(movex, movey);
}
});

Clazz_newMeth(C$, 'computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double',  function (union) {
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
union=go.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(union);
}
return union;
});

Clazz_newMeth(C$, 'centerX$',  function () {
var center=0;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
center+=go.centerX$();
}
if (this.group.size$() > 0) {
center/=this.group.size$();
}return center;
});

Clazz_newMeth(C$, 'centerY$',  function () {
var center=0;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
center+=go.centerY$();
}
if (this.group.size$() > 0) {
center/=this.group.size$();
}return center;
});

Clazz_newMeth(C$, 'alignCenter$jme_util_Box_Axis',  function (xOrY) {
var groupCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(this, xOrY);
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
var delta=groupCenter - $I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(go, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(go, xOrY, delta);
}
});

Clazz_newMeth(C$, 'closestDistance$D$D',  function (x, y) {
var min=1.7976931348623157E308;
for (var go, $go = this.group.iterator$(); $go.hasNext$()&&((go=($go.next$())),1);) {
min=Math.min(min, go.closestDistance$D$D(x, y));
}
return min;
});

Clazz_newMeth(C$, 'add$jme_canvas_Graphical2DObject',  function (element) {
this.group.add$O(element);
});

Clazz_newMeth(C$, 'add$I$jme_canvas_Graphical2DObject',  function (pos, element) {
this.group.add$I$O(pos, element);
});

Clazz_newMeth(C$, 'size$',  function () {
return this.group.size$();
});

Clazz_newMeth(C$, 'isEmpty$',  function () {
return this.size$() == 0;
});

Clazz_newMeth(C$, 'distributePositions$jme_util_Box_Axis$D',  function (xOrY, margin) {
this.distributePositions$jme_util_Box_Axis$D$Z(xOrY, margin, true);
});

Clazz_newMeth(C$, 'distributePositions$jme_util_Box_Axis$D$Z',  function (xOrY, margin, keepXorYorder) {
if (this.size$() <= 1) {
return;
}var sorted=Clazz_new_(C$);
sorted.addAll$jme_canvas_Graphical2DObjectGroup(this);
sorted.removeNoSizeObjects$();
if (sorted.size$() <= 1) {
return;
}var beforeAlignCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY);
if (keepXorYorder) {
$I$(3,"sort$java_util_List$java_util_Comparator",[sorted.group, ((P$.Graphical2DObjectGroup$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "Graphical2DObjectGroup$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, ['compare$jme_canvas_Graphical2DObject$jme_canvas_Graphical2DObject','compare$O$O'],  function (m1, m2) {
var x2=$I$(4,"get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis",[m1.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null), this.$finals$.xOrY]);
var x1=$I$(4,"get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis",[m2.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null), this.$finals$.xOrY]);
return x1 > x2  ? -1 : (x2 < x1 ) ? 1 : 0;
});
})()
), Clazz_new_(P$.Graphical2DObjectGroup$1.$init$,[this, {xOrY:xOrY}]))]);
}var sumMove=0;
for (var mol, $mol = sorted.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var moleculeBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
var move=sumMove - $I$(4).get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis(moleculeBox, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(mol, xOrY, move);
sumMove+=$I$(4).getDim$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis(moleculeBox, xOrY) + margin;
}
var afterAlignCenter=$I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY);
$I$(2).move$jme_canvas_Graphical2DObject$jme_util_Box_Axis$D(sorted, xOrY, beforeAlignCenter - afterAlignCenter);
Clazz_assert(C$, this, function(){return (Math.abs(beforeAlignCenter - $I$(2).center$jme_canvas_Graphical2DObject$jme_util_Box_Axis(sorted, xOrY)) < 0.001 )});
});

Clazz_newMeth(C$, 'removeNoSizeObjects$',  function () {
var emptyList=Clazz_new_(C$);
for (var mol, $mol = this.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
var moleculeBox=mol.computeBoundingBoxWithAtomLabels$java_awt_geom_Rectangle2D_Double(null);
if (moleculeBox == null  || moleculeBox.isEmpty$() ) {
emptyList.add$jme_canvas_Graphical2DObject(mol);
}}
for (var mol, $mol = emptyList.group.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
this.group.remove$O(mol);
}
return emptyList.size$() > 0;
});

Clazz_newMeth(C$, 'addAll$jme_canvas_Graphical2DObjectGroup',  function (graphical2dObjectGroup) {
this.addAll$java_util_ArrayList(graphical2dObjectGroup.group);
});

Clazz_newMeth(C$, 'addAll$java_util_ArrayList',  function (graphical2dObjectList) {
this.group.addAll$java_util_Collection(graphical2dObjectList);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-17 22:48:13 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.io"),I$=[[0,'jme.util.JMEUtil']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ChemicalMimeType");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['S',['typeName','url','molfile']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'molfile$S',  function (separator) {
return C$.typeName + separator + C$.molfile ;
}, 1);

Clazz_newMeth(C$, 'chemicalMimeTag$',  function () {
return C$.molfile$S(":");
}, 1);

Clazz_newMeth(C$, 'extractEmbeddedChemicalString$S',  function (svg) {
var result=null;
var tag=C$.chemicalMimeTag$();
var tagStart=svg.indexOf$S(tag);
if (tagStart > 0) {
var molStart=svg.indexOf$S$I(">", tagStart) + 1;
var molEnd=svg.indexOf$S$I("</" + tag, molStart);
if (molEnd - molStart > 20) {
result=svg.substring$I$I(molStart, molEnd);
}}if (result == null ) return null;
if (result.indexOf$I("\n") < 0) result=result.replaceAll$S$S("\\\n", "\n");
return $I$(1).unwrapCData$S(result);
}, 1);

Clazz_newMeth(C$, 'additionalNameSpaces$S',  function (post) {
return "xmlns:" + C$.typeName + "=\"" + C$.url + "\"" + post ;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.typeName="chemical";
C$.url="http://www.ch.ic.ac.uk/chemime/";
C$.molfile="x-mdl-molfile";
};
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-25 03:18:17 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.io"),p$1={},I$=[[0,'java.util.regex.Pattern',['jme.io.JMEReader','.MajorChemicalFormat'],['jme.io.JMEReader','.Author'],'jme.io.ChemicalMimeType','java.util.StringTokenizer',['jme.io.JMEReader','.OclCheck'],['jme.io.JMEReader','.MinorChemicalFormat'],'jme.JMEmolList','jme.JMEmol',['jme.io.JMEReader','.SupportedInputFileFormat'],'jme.JME',['jme.JMEmol','.ReactionRole'],'java.util.ArrayList','jme.util.JMEUtil','jme.util.Isotopes','javax.swing.SwingUtilities']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "JMEReader", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['OclCheck',8],['MajorChemicalFormat',25],['MinorChemicalFormat',25],['Author',25],['SupportedInputFileFormat',25]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.numberOfLines=0;
this.isInputEmpty=false;
},1);

C$.$fields$=[['Z',['isReaction','isInputEmpty','hasSpace'],'I',['numberOfLines'],'S',['chemicalString','error'],'O',['majorChemicalFormat','jme.io.JMEReader.MajorChemicalFormat','minorChemicalFormat','jme.io.JMEReader.MinorChemicalFormat','author','jme.io.JMEReader.Author','embeddedChemicalFormat','jme.io.JMEReader','fileTypeRead','jme.io.JMEReader.SupportedInputFileFormat','jme','jme.JME']]
,['O',['InchiKeyPattern','java.util.regex.Pattern','+Smiles6Pattern','+SmilesOrSmirksPattern','+NonSmilesPattern','+SpacePattern','+Smartspattern','+ExtendedSmartsExtraPattern','+SmartsExtraPattern','+CSRMlpattern','+URLpattern']]]

Clazz_newMeth(C$, 'c$$jme_JME$S',  function (jme, chemicalString) {
;C$.$init$.apply(this);
this.jme=jme;
this.detectFormat$S(chemicalString);
}, 1);

Clazz_newMeth(C$, 'reset$',  function () {
this.init$jme_io_JMEReader(null);
});

Clazz_newMeth(C$, 'detectFormat$S',  function (chemicalString) {
this.reset$();
var success=false;
if (chemicalString == null  || C$.URLpattern.matcher$CharSequence(chemicalString).find$() ) {
return false;
}this.numberOfLines=C$.countLines$S$I(chemicalString, 5);
if (this.numberOfLines == 1) {
chemicalString=chemicalString.trim$();
}this.chemicalString=chemicalString;
if (chemicalString.length$() == 0) {
this.isInputEmpty=true;
return false;
}this.hasSpace=C$.SpacePattern.matcher$CharSequence(chemicalString).find$();
do {
if (C$.CSRMlpattern.matcher$CharSequence(chemicalString).find$()) {
this.majorChemicalFormat=$I$(2).CSRML;
this.author=$I$(3).MolecularNetworks;
break;
}if (this.numberOfLines > 4) {
if (chemicalString.startsWith$S("<")) {
if (chemicalString.toLowerCase$().startsWith$S("<svg")) {
var mol=$I$(4).extractEmbeddedChemicalString$S(chemicalString);
if (mol != null ) {
this.embeddedChemicalFormat=Clazz_new_(C$.c$$jme_JME$S,[this.jme, mol]);
if (this.embeddedChemicalFormat.majorChemicalFormat != null ) {
this.majorChemicalFormat=$I$(2).SVG;
}}}break;
}if (this.detectMDLformat$()) {
break;
}}if (this.numberOfLines == 1) {
if (chemicalString.startsWith$S("InChI=") || chemicalString.startsWith$S("AuxInfo=") ) {
this.majorChemicalFormat=$I$(2).InChI;
break;
}if (chemicalString.length$() == 27) {
var m=C$.InchiKeyPattern.matcher$CharSequence(chemicalString);
if (m.find$()) {
this.majorChemicalFormat=$I$(2).InChIkey;
break;
}}if (chemicalString.length$() >= 1) {
if (this.hasSpace) {
var st=Clazz_new_($I$(5,1).c$$S$S,[chemicalString, " |"]);
try {
var next;
next=st.nextToken$();
while (next.equals$O("|")){
next=st.nextToken$();
}
var natomsx=Integer.valueOf$S(next).intValue$();
var nbondsx=Integer.valueOf$S(st.nextToken$()).intValue$();
for (var i=0; i < 3 * (natomsx + nbondsx); i++) {
st.nextToken$();
}
this.isReaction=chemicalString.indexOf$S(">") > 0;
this.majorChemicalFormat=$I$(2).JME;
this.author=$I$(3).P_ERTL;
break;
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
} else {
throw e;
}
}
} else if ($I$(6).isOclIdCode$S(chemicalString)) {
this.initAsOClcode$();
break;
} else if (!C$.NonSmilesPattern.matcher$CharSequence(chemicalString).find$()) {
var isReaction=chemicalString.indexOf$S(">") > 0;
var isSmarts=C$.Smartspattern.matcher$CharSequence(chemicalString).find$();
var canBeExtendedSmarts=C$.ExtendedSmartsExtraPattern.matcher$CharSequence(chemicalString).find$();
var isSmiles=C$.SmilesOrSmirksPattern.matcher$CharSequence(chemicalString).find$() && !C$.SmartsExtraPattern.matcher$CharSequence(chemicalString).find$() && !canBeExtendedSmarts  ;
if (isSmiles) {
this.majorChemicalFormat=$I$(2).SMILES;
if (isReaction) {
this.majorChemicalFormat=$I$(2).SMIRKS;
this.isReaction=isReaction;
}} else if (isSmarts || canBeExtendedSmarts ) {
this.majorChemicalFormat=$I$(2).SMARTS;
if (canBeExtendedSmarts) {
this.minorChemicalFormat=$I$(7).extended;
}}break;
}}}} while (false);
success=this.majorChemicalFormat != null ;
if (this.majorChemicalFormat === $I$(2).InChIkey  || this.majorChemicalFormat === $I$(2).InChI  ) {
this.author=$I$(3).IUPAC;
} else if (this.majorChemicalFormat === $I$(2).SMILES  || this.majorChemicalFormat === $I$(2).SMARTS   || this.majorChemicalFormat === $I$(2).SMIRKS  ) {
this.author=$I$(3).DAYLIGHT;
}return success;
});

Clazz_newMeth(C$, 'detectMDLformat$',  function () {
if (this.chemicalString.contains$CharSequence("M  END") || (this.chemicalString.contains$CharSequence("M END") && (this.chemicalString.contains$CharSequence("V2000") || this.chemicalString.contains$CharSequence("V3000") ) ) ) {
this.author=$I$(3).MDL;
this.majorChemicalFormat=$I$(2).MOL;
if (this.chemicalString.contains$CharSequence("V2000")) {
this.minorChemicalFormat=$I$(7).V2000;
}if (this.chemicalString.contains$CharSequence("V3000")) {
this.minorChemicalFormat=$I$(7).V3000;
}if (this.chemicalString.startsWith$S("$RXN")) {
this.majorChemicalFormat=$I$(2).RXN;
} else if (this.chemicalString.contains$CharSequence("$$$$")) {
this.majorChemicalFormat=$I$(2).SDF;
}return true;
}return false;
});

Clazz_newMeth(C$, 'isReaction$',  function () {
return this.isReaction || this.majorChemicalFormat === $I$(2).RXN   || this.majorChemicalFormat === $I$(2).SMIRKS  ;
});

Clazz_newMeth(C$, 'countLines$S',  function (str) {
return C$.countLines$S$I(str, -1);
}, 1);

Clazz_newMeth(C$, 'countLines$S$I',  function (str, stop) {
if (str == null  || str.length$() == 0 ) return 0;
var lines=1;
var len=str.length$();
for (var pos=0; pos < len; pos++) {
if (stop > 0 && lines > stop ) return lines;
var c=str.charAt$I(pos);
if (c == "\r") {
++lines;
if (pos + 1 < len && str.charAt$I(pos + 1) == "\n" ) ++pos;
} else if (c == "\n") {
++lines;
}}
return lines;
}, 1);

Clazz_newMeth(C$, 'init$jme_io_JMEReader',  function (other) {
if (other == null ) {
this.author=null;
this.majorChemicalFormat=null;
this.minorChemicalFormat=null;
this.isReaction=false;
return;
}this.author=other.author;
this.majorChemicalFormat=other.majorChemicalFormat;
this.minorChemicalFormat=other.minorChemicalFormat;
this.isReaction=other.isReaction;
this.embeddedChemicalFormat=other.embeddedChemicalFormat;
this.chemicalString=other.chemicalString;
});

Clazz_newMeth(C$, 'checkAndInitAsMDL$',  function () {
return this.detectMDLformat$();
});

Clazz_newMeth(C$, 'initAsV2000MOL$',  function () {
this.reset$();
this.author=$I$(3).MDL;
this.majorChemicalFormat=$I$(2).MOL;
this.minorChemicalFormat=$I$(7).V2000;
this.isReaction=false;
this.embeddedChemicalFormat=null;
return this;
});

Clazz_newMeth(C$, 'initAsV3000MOL$',  function () {
this.initAsV2000MOL$();
this.minorChemicalFormat=$I$(7).V3000;
return this;
});

Clazz_newMeth(C$, 'initAsOClcode$',  function () {
this.reset$();
this.author=$I$(3).OPENCHEMLIB;
this.majorChemicalFormat=$I$(2).OCLCODE;
return this;
});

Clazz_newMeth(C$, 'readMDLstringInput$S$jme_core_JMECore_Parameters',  function (s, pars) {
var molList=Clazz_new_($I$(8,1));
try {
molList.isReaction=s.startsWith$S("$RXN");
if (molList.isReaction) {
molList.addAll$java_util_Collection(C$.readReactionMols$S$jme_core_JMECore_Parameters(s, pars));
} else {
molList.add$O(C$.readSingleMOL$S$jme_core_JMECore_Parameters(s, pars));
}} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
molList.error=e;
return null;
} else {
throw e;
}
}
return molList;
}, 1);

Clazz_newMeth(C$, 'readJMEstringInput$S$jme_core_JMECore_Parameters',  function (molecule, pars) {
var molList=Clazz_new_($I$(8,1));
var st=Clazz_new_($I$(5,1).c$$S$S$Z,[molecule, "|>", true]);
molList.isReaction=(molecule.indexOf$S(">") > -1);
var nt=st.countTokens$();
var roleIndex=0;
for (var i=1; i <= nt; i++) {
var s=st.nextToken$();
s.trim$();
if (s.equals$O("|")) continue;
if (s.equals$O(">")) {
++roleIndex;
continue;
}if (roleIndex > 3) {
return molList.setErrorMsg$S("too many \">\"");
}var mol=null;
try {
mol=Clazz_new_([null, s, $I$(10).JME, pars],$I$(9,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
if (mol.natoms == 0) {
return molList.setErrorMsg$S("0 atoms found in \"" + s + "\"" );
}} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
return molList.setErrorMsg$S($I$(11).makeErrorMessage$Exception(e) + ": " + s );
} else {
throw e;
}
}
molList.add$O(mol);
if (molList.isReaction) {
mol.setReactionRole$I($I$(12).all[roleIndex]);
}}
return molList;
}, 1);

Clazz_newMeth(C$, 'readReactionMols$S$jme_core_JMECore_Parameters',  function (s, pars) {
var mols=Clazz_new_($I$(13,1));
var separator=$I$(14).findLineSeparator$S(s);
var st=Clazz_new_($I$(5,1).c$$S$S$Z,[s, separator, true]);
var line="";
for (var i=1; i <= 5; i++) {
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
}
var nr=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
var np=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var na=0;
if (line.length$() >= 9) {
na=Integer.valueOf$S(line.substring$I$I(6, 9).trim$()).intValue$();
}$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
for (var p=1; p <= nr + np + na ; p++) {
var m="";
while (true){
var ns=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
if (ns == null  || ns.equals$O("$MOL") ) break;
 else m+=ns + separator;
}
var mol=C$.readSingleMOL$S$jme_core_JMECore_Parameters(m, pars);
mols.add$O(mol);
if (p <= nr) {
mol.setReactionRole$I(1);
} else if (p > nr && p <= nr + np ) {
mol.setReactionRole$I(3);
} else {
mol.setReactionRole$I(2);
}}
return mols;
}, 1);

Clazz_newMeth(C$, 'readSingleMOL$S$jme_core_JMECore_Parameters',  function (s, pars) {
return Clazz_new_([null, s, $I$(10).MOL, pars],$I$(9,1).c$$jme_JME$O$jme_io_JMEReader_SupportedInputFileFormat$jme_core_JMECore_Parameters);
}, 1);

Clazz_newMeth(C$, 'equals$O$O',  function (a, b) {
return (a === b ) || (a != null  && a.equals$O(b) ) ;
}, 1);

Clazz_newMeth(C$, 'createMolFromString$jme_core_JMECore$S',  function (mol, jmeString) {
if (jmeString.startsWith$S("\"")) jmeString=jmeString.substring$I$I(1, jmeString.length$());
if (jmeString.endsWith$S("\"")) jmeString=jmeString.substring$I$I(0, jmeString.length$() - 1);
if (jmeString.length$() < 1) {
mol.natoms=0;
return;
}try {
var st=Clazz_new_($I$(5,1).c$$S,[jmeString]);
var natomsx=Integer.valueOf$S(st.nextToken$()).intValue$();
var nbondsx=Integer.valueOf$S(st.nextToken$()).intValue$();
for (var i=1; i <= natomsx; i++) {
var symbol=st.nextToken$();
var atom=mol.createAtom$S(symbol);
atom.x=Double.valueOf$S(st.nextToken$()).doubleValue$();
atom.y=-Double.valueOf$S(st.nextToken$()).doubleValue$();
}
for (var i=1; i <= nbondsx; i++) {
var bond=mol.createAndAddBondFromOther$jme_core_Bond(null);
bond.va=Integer.valueOf$S(st.nextToken$()).intValue$();
bond.vb=Integer.valueOf$S(st.nextToken$()).intValue$();
var bondType=Integer.valueOf$S(st.nextToken$()).intValue$();
var stereob=0;
if (bondType == -1) {
bondType=1;
stereob=1;
} else if (bondType == -2) {
bondType=1;
stereob=2;
} else if (bondType == -5) {
bondType=2;
stereob=10;
} else if (bondType == 11 || bondType == 12  || bondType == 13  || bondType == 14 ) {
stereob=bondType;
bondType=9;
}bond.bondType=bondType;
bond.stereo=stereob;
}
mol.finalizeMolecule$();
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
System.err.println$S("read JSME string exception - " + e.getMessage$());
mol.natoms=0;
throw (e);
} else {
throw e;
}
}
}, 1);

Clazz_newMeth(C$, 'createMolFromMolData$jme_core_JMECore$S',  function (mol, molData) {
var line="";
var separator=$I$(14).findLineSeparator$S(molData);
if (separator == null ) {
return;
}var st=Clazz_new_($I$(5,1).c$$S$S$Z,[molData, separator, true]);
for (var i=1; i <= 4; i++) {
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
}
var natomsx=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
var nbondsx=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var chiral=0;
try {
chiral=Integer.valueOf$S(line.substring$I$I(14, 15).trim$()).intValue$();
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
} else {
throw e;
}
}
mol.setChiralFlag$Boolean(Boolean.valueOf$Z(chiral == 1));
var valences=Clazz_array(Integer.TYPE, [natomsx + 1]);
for (var i=1; i <= natomsx; i++) {
var atom=mol.createAtom$();
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
atom.x=Double.valueOf$S(line.substring$I$I(0, 10).trim$()).doubleValue$();
atom.y=-Double.valueOf$S(line.substring$I$I(10, 20).trim$()).doubleValue$();
atom.z=Double.valueOf$S(line.substring$I$I(20, 30).trim$()).doubleValue$();
var endsymbol=34;
if (line.length$() < 34) endsymbol=line.length$();
var symbol=line.substring$I$I(31, endsymbol).trim$();
mol.setAtom$I$S(i, symbol);
if (line.length$() >= 62) {
var s=line.substring$I$I(60, 63).trim$();
if (s.length$() > 0) {
var mark=Integer.valueOf$S(s).intValue$();
if (mark > 0) {
mol.setAtomMapFromInput$I$I(i, mark);
}}}if (line.length$() >= 36) {
var s=line.substring$I$I(34, 36).trim$();
if (s.length$() > 0) {
var delta=Integer.valueOf$S(s).intValue$();
if (delta != 0 && delta >= -3  && delta <= 4 ) {
var iso=$I$(15).getIsotopicMassOfElementDelta$S$I(symbol, delta);
if (iso < 0) iso=0;
mol.atoms[i].iso=iso;
}}}if (line.length$() >= 39) {
var s=line.substring$I$I(37, 39).trim$();
if (s.length$() > 0) {
var delta=Integer.valueOf$S(s).intValue$();
if (delta > 0 && delta <= 7 ) {
var charge=0;
switch (delta) {
case 1:
charge=3;
break;
case 2:
charge=2;
break;
case 3:
charge=1;
break;
case 4:
charge=0;
break;
case 5:
charge=-1;
break;
case 6:
charge=-2;
break;
case 7:
charge=-3;
break;
}
mol.Q$I$I(i, charge);
}}}if (line.length$() >= 45) {
var s=line.substring$I$I(43, 45).trim$();
if (s.length$() > 0) valences[i]=Integer.valueOf$S(s).intValue$();
}}
for (var i=1; i <= nbondsx; i++) {
var bond=mol.createAndAddBondFromOther$jme_core_Bond(null);
line=$I$(14).nextData$java_util_StringTokenizer$S(st, separator);
bond.va=Integer.valueOf$S(line.substring$I$I(0, 3).trim$()).intValue$();
bond.vb=Integer.valueOf$S(line.substring$I$I(3, 6).trim$()).intValue$();
var nasvx=Integer.valueOf$S(line.substring$I$I(6, 9).trim$()).intValue$();
var bondType;
if (nasvx == 1) bondType=1;
 else if (nasvx == 2) bondType=2;
 else if (nasvx == 3) bondType=3;
 else if (nasvx == 8) bondType=0;
 else bondType=9;
var stereoVal=0;
if (line.length$() > 11) stereoVal=Integer.valueOf$S(line.substring$I$I(9, 12).trim$()).intValue$();
if (bondType == 1 || bondType == 0 ) {
if (stereoVal == 1) {
bond.stereo=1;
} else if (stereoVal == 6) {
bond.stereo=2;
} else if (stereoVal == 4) {
bond.stereo=5;
}}if (nasvx == 2 && stereoVal == 3 ) {
bondType=2;
bond.stereo=10;
}bond.bondType=bondType;
}
while (st.hasMoreTokens$()){
if ((line=st.nextToken$()) == null ) break;
if (line.startsWith$S("M  END")) break;
if (line.startsWith$S("M  CHG")) {
var stq=Clazz_new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.atoms[a].q=Integer.valueOf$S(stq.nextToken$()).intValue$();
}
}if (line.startsWith$S("M  ISO")) {
var stq=Clazz_new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.atoms[a].iso=Integer.valueOf$S(stq.nextToken$()).intValue$();
}
}if (line.startsWith$S("M  APO")) {
var stq=Clazz_new_($I$(5,1).c$$S,[line]);
stq.nextToken$();
stq.nextToken$();
var ndata=Integer.valueOf$S(stq.nextToken$()).intValue$();
for (var i=1; i <= ndata; i++) {
var a=Integer.valueOf$S(stq.nextToken$()).intValue$();
var nr=Integer.valueOf$S(stq.nextToken$()).intValue$();
mol.addBondToAtom$I$I$I$Z$D(1, a, 0, false, 0);
mol.setAtom$I$S(mol.natoms, "R" + nr);
}
}}
for (var i=1; i <= natomsx; i++) {
if (valences[i] > 0) {
var nv=mol.atoms[i].nv;
if (valences[i] != 15) {
var nh=valences[i] - nv;
if (nh > 0) mol.atoms[i].nh=nh;
} else {
mol.atoms[i].nh=0;
}}}
mol.finalizeMolecule$();
}, 1);

Clazz_newMeth(C$, 'readGenericString$Z$jme_js_AsyncCallback$Z$Z',  function (runAsync, callback, recordEvent, repaint) {
do {
if (this.majorChemicalFormat === $I$(2).SVG  && this.embeddedChemicalFormat != null  ) {
this.init$jme_io_JMEReader(this.embeddedChemicalFormat);
}if (this.author === $I$(3).MDL  && this.minorChemicalFormat !== $I$(7).V3000  ) {
if (this.jme.handleReadMolFileRXN$S$Z(this.chemicalString, false)) this.fileTypeRead=this.isReaction$() ? $I$(10).RXN : $I$(10).MOL;
 else {
this.error="Invalid V2000 molfile";
}break;
}if (this.author === $I$(3).P_ERTL ) {
if (this.jme.readMolecule$S$Z(this.chemicalString, false)) {
this.fileTypeRead=$I$(10).JME;
} else {
this.error="Invalid JME string";
}break;
}if (this.author === $I$(3).IUPAC  || this.majorChemicalFormat === $I$(2).CSRML  ) {
this.error="Reading " + this.majorChemicalFormat + " is not supported" ;
break;
}var r=((P$.JMEReader$lambda1||
(function(){/*m*/var C$=Clazz_newClass(P$, "JMEReader$lambda1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz_newMeth(C$, 'run$',  function () {
this.b$['jme.io.JMEReader'].oclSuccess$jme_js_AsyncCallback$Z$Z.apply(this.b$['jme.io.JMEReader'], [this.$finals$.callback, this.$finals$.recordEvent, this.$finals$.repaint]);
});
})()
), Clazz_new_(P$.JMEReader$lambda1.$init$,[this, {repaint:repaint,recordEvent:recordEvent,callback:callback}]));
if (runAsync) {
$I$(16).invokeLater$Runnable(r);
} else {
r.run$();
}} while (false);
});

Clazz_newMeth(C$, 'v3000toV2000MOL$S',  function (v3000Mol) {
return $I$(11).getOclAdapter$().v3000toV2000MOL$S(v3000Mol);
}, 1);

Clazz_newMeth(C$, 'oclSuccess$jme_js_AsyncCallback$Z$Z',  function (callback, recordEvent, repaint) {
var error=null;
var convertedmolFile=null;
var fileTypeRead=null;
if (this.author === $I$(3).MDL  && this.minorChemicalFormat === $I$(7).V3000  ) {
try {
convertedmolFile=C$.v3000toV2000MOL$S(this.chemicalString);
if (convertedmolFile == null ) {
throw Clazz_new_(Clazz_load('Exception').c$$S,["V3000 read failed."]);
}fileTypeRead=$I$(10).MOL_V3000;
this.jme.sdfPastedMessage.innerString="V3000 conversion provided by OpenChemLib";
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
error=e.getMessage$();
} else {
throw e;
}
}
} else if (this.author === $I$(3).DAYLIGHT ) {
try {
convertedmolFile=this.jme.SMILESorSMIRKStoMolOrRXN$S(this.chemicalString);
switch (this.majorChemicalFormat) {
case $I$(2).SMIRKS:
fileTypeRead=$I$(10).SMIRKS;
break;
case $I$(2).SMILES:
fileTypeRead=$I$(10).SMILES;
break;
case $I$(2).SMARTS:
break;
default:
break;
}
this.jme.sdfPastedMessage.innerString="SMILES conversion provided by OpenChemLib";
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
error="SMILES parsing error:" + e.getMessage$();
} else {
throw e;
}
}
} else {
error="Invalid or unsupported input";
if ($I$(6).isOclIdCode$S(this.chemicalString)) {
try {
convertedmolFile=this.jme.oclCodeToMOL$S(this.chemicalString);
fileTypeRead=$I$(10).OCLCODE;
error=null;
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}}if (convertedmolFile != null  && error == null  ) {
var success=false;
try {
success=this.jme.handleReadMolFileRXN$S$Z(convertedmolFile, false);
} catch (e) {
if (Clazz_exceptionOf(e,"Exception")){
} else {
throw e;
}
}
if (!success) error="Invalid molfile data";
}this.jme.processFileRead$jme_js_AsyncCallback$jme_io_JMEReader_SupportedInputFileFormat$S$Z(callback, fileTypeRead, error, repaint);
});

Clazz_newMeth(C$, 'equals$O',  function (o) {
if (this === o ) return true;
if (o == null  || o.getClass$() !== this.getClass$()  ) return false;
var r=o;
return C$.equals$O$O(this.author, r.author) && C$.equals$O$O(this.majorChemicalFormat, r.majorChemicalFormat) && C$.equals$O$O(this.minorChemicalFormat, r.minorChemicalFormat) && C$.equals$O$O(Boolean.valueOf$Z(this.isReaction), Boolean.valueOf$Z(r.isReaction)) && C$.equals$O$O(this.embeddedChemicalFormat, r.embeddedChemicalFormat)  ;
});

C$.$static$=function(){C$.$static$=0;
C$.InchiKeyPattern=$I$(1).compile$S("^[A-Z]{14}\\-[A-Z]{10}\\-[A-Z]$");
C$.Smiles6Pattern=$I$(1,"compile$S$I",["^[^J][a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:>]{6,}$", 2]);
C$.SmilesOrSmirksPattern=$I$(1,"compile$S$I",["^[a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:>\\\\.]+$", 2]);
C$.NonSmilesPattern=$I$(1).compile$S("j");
C$.SpacePattern=$I$(1).compile$S("\\s+");
C$.Smartspattern=$I$(1,"compile$S$I",["^[a-z0-9@+\\-\\[\\]\\(\\)\\\\\\/%=#$:\\\\.,;!&]+$", 2]);
C$.ExtendedSmartsExtraPattern=$I$(1).compile$S("[\\^]");
C$.SmartsExtraPattern=$I$(1).compile$S$I("[,;!&]", 2);
C$.CSRMlpattern=$I$(1,"compile$S$I",["\\s*^(<\\?xml\\s+[^>]+>)?\\s*<\\s*csrml\\b", 2]);
C$.URLpattern=$I$(1).compile$S("$\\w+:\\/\\/");
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.JMEReader, "OclCheck", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.nAvail=6;
},1);

C$.$fields$=[['I',['nAvail','pt','mData','abits','bbits','nBytes'],'O',['idcode','byte[]']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'isOclIdCode$S',  function (s) {
return Clazz_new_(C$).isIDCode$S(s);
}, 1);

Clazz_newMeth(C$, 'isIDCode$S',  function (s) {
this.nBytes=s.indexOf$I("!");
if (this.nBytes < 0) this.nBytes=s.indexOf$I("#");
if (this.nBytes < 0) this.nBytes=s.length$();
if (this.nBytes < 10 || this.nBytes > 1000 ) return false;
this.idcode=s.substring$I$I(0, this.nBytes).getBytes$();
this.mData=(this.idcode[0] & 63) << 11;
try {
if (this.idcode == null  || this.idcode.length == 0 ) return false;
this.abits=p$1.decodeBits$I.apply(this, [4]);
this.bbits=p$1.decodeBits$I.apply(this, [4]);
var version=8;
if (this.abits > 8) {
version=this.abits;
this.abits=this.bbits;
}if (version != 8 && version != 9 ) return false;
var allAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
var allBonds=p$1.decodeBits$I.apply(this, [this.bbits]);
var closureBonds=1 + allBonds - allAtoms;
if (allAtoms == 0 || closureBonds < 0  || closureBonds > allAtoms - 2 ) return false;
var nitrogens=p$1.decodeBits$I.apply(this, [this.abits]);
var oxygens=p$1.decodeBits$I.apply(this, [this.abits]);
var otherAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
var chargedAtoms=p$1.decodeBits$I.apply(this, [this.abits]);
p$1.checkBits$I.apply(this, [nitrogens]);
p$1.checkBits$I.apply(this, [oxygens]);
p$1.checkBits$I.apply(this, [otherAtoms]);
p$1.checkBits$I.apply(this, [chargedAtoms]);
return true;
} catch (e) {
return false;
}
});

Clazz_newMeth(C$, 'checkBits$I',  function (n) {
if (n != 0) {
for (var i=0; i < n; i++) p$1.decodeBits$I.apply(this, [this.abits]);

}}, p$1);

Clazz_newMeth(C$, 'decodeBits$I',  function (bits) {
var allBits=bits;
var data=0;
while (bits != 0){
if (this.nAvail == 0) {
if (++this.pt >= this.idcode.length) throw Clazz_new_(Clazz_load('NullPointerException'));
this.mData=(this.idcode[this.pt] & 63) << 11;
this.nAvail=6;
}data|=((65536 & this.mData) >> (16 - allBits + bits));
this.mData<<=1;
--bits;
--this.nAvail;
}
return data;
}, p$1);
})()
;
(function(){/*e*/var C$=Clazz_newClass(P$.JMEReader, "MajorChemicalFormat", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$, "MOL", 0, []);
Clazz_newEnumConst($vals, C$.c$, "RXN", 1, []);
Clazz_newEnumConst($vals, C$.c$, "SDF", 2, []);
Clazz_newEnumConst($vals, C$.c$, "RDF", 3, []);
Clazz_newEnumConst($vals, C$.c$, "SMILES", 4, []);
Clazz_newEnumConst($vals, C$.c$, "SMARTS", 5, []);
Clazz_newEnumConst($vals, C$.c$, "SMIRKS", 6, []);
Clazz_newEnumConst($vals, C$.c$, "InChI", 7, []);
Clazz_newEnumConst($vals, C$.c$, "InChIkey", 8, []);
Clazz_newEnumConst($vals, C$.c$, "OCLCODE", 9, []);
Clazz_newEnumConst($vals, C$.c$, "JME", 10, []);
Clazz_newEnumConst($vals, C$.c$, "SVG", 11, []);
Clazz_newEnumConst($vals, C$.c$, "CSRML", 12, []);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz_newClass(P$.JMEReader, "MinorChemicalFormat", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$, "V2000", 0, []);
Clazz_newEnumConst($vals, C$.c$, "V3000", 1, []);
Clazz_newEnumConst($vals, C$.c$, "extended", 2, []);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz_newClass(P$.JMEReader, "Author", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$, "MDL", 0, []);
Clazz_newEnumConst($vals, C$.c$, "DAYLIGHT", 1, []);
Clazz_newEnumConst($vals, C$.c$, "IUPAC", 2, []);
Clazz_newEnumConst($vals, C$.c$, "OPENCHEMLIB", 3, []);
Clazz_newEnumConst($vals, C$.c$, "P_ERTL", 4, []);
Clazz_newEnumConst($vals, C$.c$, "MolecularNetworks", 5, []);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
;
(function(){/*e*/var C$=Clazz_newClass(P$.JMEReader, "SupportedInputFileFormat", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$, "JME", 0, []);
Clazz_newEnumConst($vals, C$.c$, "SMILES", 1, []);
Clazz_newEnumConst($vals, C$.c$, "MOL", 2, []);
Clazz_newEnumConst($vals, C$.c$, "MOL_V3000", 3, []);
Clazz_newEnumConst($vals, C$.c$, "OCLCODE", 4, []);
Clazz_newEnumConst($vals, C$.c$, "RXN", 5, []);
Clazz_newEnumConst($vals, C$.c$, "SMIRKS", 6, []);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-25 03:18:17 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.util"),I$=[[0,['jme.util.Box','.Axis'],['java.awt.geom.Rectangle2D','.Double'],'java.awt.geom.Rectangle2D']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*i*/var C$=Clazz_newInterface(P$, "Box", function(){
});
C$.$classes$=[['Axis',25]];

Clazz_newMeth(C$, 'get$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis',  function (box, xOrY) {
return (xOrY === $I$(1).X  ? box.getX$() : box.getY$());
}, 1);

Clazz_newMeth(C$, 'getDim$java_awt_geom_Rectangle2D_Double$jme_util_Box_Axis',  function (box, xOrY) {
return xOrY === $I$(1).X  ? box.getWidth$() : box.getHeight$();
}, 1);

Clazz_newMeth(C$, 'createUnion$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double$java_awt_geom_Rectangle2D_Double',  function (box, r, union) {
if (union == null ) {
union=Clazz_new_($I$(2,1));
union.setFrame$java_awt_geom_Rectangle2D(box);
} else {
$I$(3).union$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D(union, box, union);
}if (r != null  && r !== union  ) $I$(3).union$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D$java_awt_geom_Rectangle2D(union, r, union);
return union;
}, 1);
;
(function(){/*e*/var C$=Clazz_newClass(P$.Box, "Axis", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$, "X", 0, []);
Clazz_newEnumConst($vals, C$.c$, "Y", 1, []);
};

Clazz_newMeth(C$);
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-17 22:48:14 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("jme.util"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "Isotopes");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['isotopes','java.util.HashMap']]]

Clazz_newMeth(C$, 'getIsotopicMap$',  function () {
return (C$.isotopes == null  ? C$.initIsotopMap$() : C$.isotopes);
}, 1);

Clazz_newMeth(C$, 'initIsotopMap$',  function () {
var dataStr="H.1,2,3.He.3,4.Li.6,7.Be.9.B.10,11.C.12,13,14.N.14,15.O.16,17,18.F.19.Ne.20,21,22.Na.23.Mg.24,25,26.Al.27.Si.28,29,30.P.31.S.32,33,34,36.Cl.35,37.Ar.36,38,40.K.39,40,41.Ca.40,42,43,44,46,48.Sc.45.Ti.46,47,48,49,50.V.50,51.Cr.50,52,53,54.Mn.55.Fe.54,56,57,58.Co.59.Ni.58,60,61,62,64.Cu.63,65.Zn.64,66,67,68,70.Ga.69,71.Ge.70,72,73,74,76.As.75.Se.74,76,77,78,80,82.Br.79,81.Kr.78,80,82,83,84,86.Rb.85,87.Sr.84,86,87,88.Y.90.Zr.90,91,92,94,96.Nb.93.Mo.92,94,95,96,97,98,100.Tc.99.Ru.96,98,99,100,101,102,104.Rh.103.Pd.102,104,105,106,108,110.Ag.107,109.Cd.106,108,110,111,112,113,114,116.In.113,115.Sn.112,114,115,116,117,118,119,120,122,124.Sb.121,123.Te.120,122,123,124,125,126,128,130.I.127.Xe.124,126,128,129,130,131,132,134,136.Cs.133.Ba.130,132,134,135,136,137,138.La.138,139.Ce.136,138,140,142.Pr.141.Nd.142,143,144,145,146,148,150.Pm.145.Sm.144,147,148,149,150,152,154.Eu.151,153.Gd.152,154,155,156,157,158,160.Tb.159.Dy.156,158,160,161,162,163,164.Ho.165.Er.162,164,166,167,168,170.Tm.169.Yb.168,170,171,172,173,174,176.Lu.175,176.Hf.174,176,177,178,179,180.Ta.180,181.W.180,182,183,184,186.Re.185,187.Os.184,186,187,188,189,190,192.Ir.191,193.Pt.190,192,194,195,196,198.Au.197.Hg.197,198,199,200,201,202,204.Tl.203,205.Pb.204,206,207,208.Bi.209.Po.209.At.210.Rn.222.Fr.223.Ra.226.Ac.227.Th.232.Pa.231.U.234,235,238.Np.237.Pu.244.Am.243.Cm.247.Bk.247.Cf.251.Es.254.Fm.257.Md.258.No.255.Lr.256.Ku.261";
var data=dataStr.split$S("\\.");
C$.isotopes=Clazz_new_($I$(1,1));
for (var i=0; i < data.length - 1; i+=2) {
var symbol=data[i];
var parts=data[i + 1].split$S(",");
var a=Clazz_array(Integer.TYPE, [parts.length]);
for (var j=0; j < parts.length; j++) {
a[j]=Integer.parseInt$S(parts[j]);
}
C$.isotopes.put$O$O(symbol, a);
}
return C$.isotopes;
}, 1);

Clazz_newMeth(C$, 'getIsotopicMassOfElementDelta$S$I',  function (elementSymbol, delta) {
var m=C$.getNaturalMass$S(elementSymbol);
return (m > 0 ? m + delta : -1);
}, 1);

Clazz_newMeth(C$, 'getDeltaIsotopicMassOfElement$S$I',  function (elementSymbol, isotopMass) {
var m=C$.getNaturalMass$S(elementSymbol);
return (m > 0 ? isotopMass - m : -1);
}, 1);

Clazz_newMeth(C$, 'getNaturalMass$S',  function (elementSymbol) {
var isotopes=C$.getIsotopicMap$().get$O(elementSymbol);
return (isotopes == null  ? -1 : isotopes[0]);
}, 1);

Clazz_newMeth(C$, 'isKnown$S$I',  function (elementSymbol, isotop) {
var isotopes=C$.getIsotopicMap$().get$O(elementSymbol);
if (isotopes != null ) {
for (var i=0; i < isotopes.length; i++) {
if (isotop == isotopes[i]) return true;
}
}return false;
}, 1);

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v7');//Created 2023-07-17 22:48:14 Java2ScriptVisitor version 3.3.1-v7 net.sf.j2s.core.jar version 3.3.1-v7
(function(){var P$=Clazz_newPackage("sun.text.resources.en"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "FormatData_en", null, 'sun.util.resources.ParallelListResourceBundle');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getContents$',  function () {
return Clazz_array(java.lang.Object, -2, [Clazz_array(java.lang.Object, -1, ["MonthNarrows", Clazz_array(String, -1, ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D", ""])]), Clazz_array(java.lang.Object, -1, ["NumberPatterns", Clazz_array(String, -1, ["#,##0.###;-#,##0.###", "\u00a4#,##0.00;-\u00a4#,##0.00", "#,##0%"])]), Clazz_array(java.lang.Object, -1, ["DateTimePatternChars", "GyMdkHmsSEDFwWahKzZ"])]);
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:28 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.text.resources"),I$=[];
/*c*/var C$=Clazz_newClass(P$, "FormatData", null, 'sun.util.resources.ParallelListResourceBundle');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getContents$',  function () {
var julianEras=Clazz_array(String, -1, ["BC", "AD"]);
var buddhistEras=Clazz_array(String, -1, ["BC", "B.E."]);
var japaneseEraAbbrs=Clazz_array(String, -1, ["", "M", "T", "S", "H"]);
var japaneseEras=Clazz_array(String, -1, ["", "Meiji", "Taisho", "Showa", "Heisei"]);
return Clazz_array(java.lang.Object, -2, [Clazz_array(java.lang.Object, -1, ["MonthNames", Clazz_array(String, -1, ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""])]), Clazz_array(java.lang.Object, -1, ["MonthAbbreviations", Clazz_array(String, -1, ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""])]), Clazz_array(java.lang.Object, -1, ["MonthNarrows", Clazz_array(String, -1, ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", ""])]), Clazz_array(java.lang.Object, -1, ["DayNames", Clazz_array(String, -1, ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"])]), Clazz_array(java.lang.Object, -1, ["DayAbbreviations", Clazz_array(String, -1, ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"])]), Clazz_array(java.lang.Object, -1, ["DayNarrows", Clazz_array(String, -1, ["S", "M", "T", "W", "T", "F", "S"])]), Clazz_array(java.lang.Object, -1, ["AmPmMarkers", Clazz_array(String, -1, ["AM", "PM"])]), Clazz_array(java.lang.Object, -1, ["narrow.AmPmMarkers", Clazz_array(String, -1, ["a", "p"])]), Clazz_array(java.lang.Object, -1, ["Eras", julianEras]), Clazz_array(java.lang.Object, -1, ["short.Eras", julianEras]), Clazz_array(java.lang.Object, -1, ["narrow.Eras", Clazz_array(String, -1, ["B", "A"])]), Clazz_array(java.lang.Object, -1, ["buddhist.Eras", buddhistEras]), Clazz_array(java.lang.Object, -1, ["buddhist.short.Eras", buddhistEras]), Clazz_array(java.lang.Object, -1, ["buddhist.narrow.Eras", buddhistEras]), Clazz_array(java.lang.Object, -1, ["japanese.Eras", japaneseEras]), Clazz_array(java.lang.Object, -1, ["japanese.short.Eras", japaneseEraAbbrs]), Clazz_array(java.lang.Object, -1, ["japanese.narrow.Eras", japaneseEraAbbrs]), Clazz_array(java.lang.Object, -1, ["japanese.FirstYear", Clazz_array(String, -1, [])]), Clazz_array(java.lang.Object, -1, ["NumberPatterns", Clazz_array(String, -1, ["#,##0.###;-#,##0.###", "\u00a4 #,##0.00;-\u00a4 #,##0.00", "#,##0%"])]), Clazz_array(java.lang.Object, -1, ["DefaultNumberingSystem", ""]), Clazz_array(java.lang.Object, -1, ["NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"])]), Clazz_array(java.lang.Object, -1, ["arab.NumberElements", Clazz_array(String, -1, ["\u066b", "\u066c", "\u061b", "\u066a", "\u0660", "#", "-", "\u0627\u0633", "\u0609", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["arabext.NumberElements", Clazz_array(String, -1, ["\u066b", "\u066c", "\u061b", "\u066a", "\u06f0", "#", "-", "\u00d7\u06f1\u06f0^", "\u0609", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["bali.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1b50", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["beng.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u09e6", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["cham.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\uaa50", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["deva.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0966", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["fullwide.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\uff10", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["gujr.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0ae6", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["guru.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0a66", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["java.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\ua9d0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["kali.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\ua900", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["khmr.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u17e0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["knda.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0ce6", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["laoo.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0ed0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["lana.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1a80", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["lanatham.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1a90", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["latn.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "0", "#", "-", "E", "\u2030", "\u221e", "\ufffd"])]), Clazz_array(java.lang.Object, -1, ["lepc.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1c40", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["limb.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1946", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["mlym.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0d66", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["mong.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1810", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["mtei.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\uabf0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["mymr.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1040", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["mymrshan.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1090", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["nkoo.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u07c0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["olck.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1c50", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["orya.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0b66", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["saur.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\ua8d0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["sund.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u1bb0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["talu.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u19d0", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["tamldec.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0be6", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["telu.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0c66", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["thai.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0e50", "#", "-", "E", "\u2030", "\u221e", "\ufffd"])]), Clazz_array(java.lang.Object, -1, ["tibt.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\u0f20", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["vaii.NumberElements", Clazz_array(String, -1, [".", ",", ";", "%", "\ua620", "#", "-", "E", "\u2030", "\u221e", "NaN"])]), Clazz_array(java.lang.Object, -1, ["TimePatterns", Clazz_array(String, -1, ["h:mm:ss a z", "h:mm:ss a z", "h:mm:ss a", "h:mm a"])]), Clazz_array(java.lang.Object, -1, ["DatePatterns", Clazz_array(String, -1, ["EEEE, MMMM d, yyyy", "MMMM d, yyyy", "MMM d, yyyy", "M/d/yy"])]), Clazz_array(java.lang.Object, -1, ["DateTimePatterns", Clazz_array(String, -1, ["{1} {0}"])]), Clazz_array(java.lang.Object, -1, ["buddhist.TimePatterns", Clazz_array(String, -1, ["H:mm:ss z", "H:mm:ss z", "H:mm:ss", "H:mm"])]), Clazz_array(java.lang.Object, -1, ["buddhist.DatePatterns", Clazz_array(String, -1, ["EEEE d MMMM G yyyy", "d MMMM yyyy", "d MMM yyyy", "d/M/yyyy"])]), Clazz_array(java.lang.Object, -1, ["buddhist.DateTimePatterns", Clazz_array(String, -1, ["{1}, {0}"])]), Clazz_array(java.lang.Object, -1, ["japanese.TimePatterns", Clazz_array(String, -1, ["h:mm:ss a z", "h:mm:ss a z", "h:mm:ss a", "h:mm a"])]), Clazz_array(java.lang.Object, -1, ["japanese.DatePatterns", Clazz_array(String, -1, ["GGGG yyyy MMMM d (EEEE)", "GGGG yyyy MMMM d", "GGGG yyyy MMM d", "Gy.MM.dd"])]), Clazz_array(java.lang.Object, -1, ["japanese.DateTimePatterns", Clazz_array(String, -1, ["{1} {0}"])]), Clazz_array(java.lang.Object, -1, ["DateTimePatternChars", "GyMdkHmsSEDFwWahKzZ"]), Clazz_array(java.lang.Object, -1, ["calendarname.islamic-umalqura", "Islamic Umm al-Qura Calendar"])]);
});

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:27 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[[0,'java.util.Locale',['sun.util.locale.provider.AuxLocaleProviderAdapter','.NullProvider'],'java.util.concurrent.ConcurrentHashMap','java.text.spi.BreakIteratorProvider','java.text.spi.CollatorProvider','java.text.spi.DateFormatProvider','java.text.spi.DateFormatSymbolsProvider','java.text.spi.DecimalFormatSymbolsProvider','java.text.spi.NumberFormatProvider','java.util.spi.CurrencyNameProvider','java.util.spi.LocaleNameProvider','java.util.spi.TimeZoneNameProvider','java.util.spi.CalendarDataProvider','java.util.spi.CalendarNameProvider','sun.util.spi.CalendarProvider','java.util.HashSet','sun.util.locale.provider.LocaleServiceProviderPool','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "AuxLocaleProviderAdapter", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'sun.util.locale.provider.LocaleProviderAdapter');
C$.$classes$=[['NullProvider',10]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.providersMap=Clazz_new_($I$(3,1));
},1);

C$.$fields$=[['O',['providersMap','java.util.concurrent.ConcurrentMap']]
,['O',['availableLocales','java.util.Locale[]','NULL_PROVIDER','sun.util.locale.provider.AuxLocaleProviderAdapter.NullProvider']]]

Clazz_newMeth(C$, 'getLocaleServiceProvider$Class',  function (c) {
var lsp=this.providersMap.get$O(c);
if (lsp == null ) {
lsp=this.findInstalledProvider$Class(c);
this.providersMap.putIfAbsent$O$O(c, lsp == null  ? C$.NULL_PROVIDER : lsp);
}return lsp;
});

Clazz_newMeth(C$, 'getBreakIteratorProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(4)));
});

Clazz_newMeth(C$, 'getCollatorProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(5)));
});

Clazz_newMeth(C$, 'getDateFormatProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(6)));
});

Clazz_newMeth(C$, 'getDateFormatSymbolsProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(7)));
});

Clazz_newMeth(C$, 'getDecimalFormatSymbolsProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(8)));
});

Clazz_newMeth(C$, 'getNumberFormatProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(9)));
});

Clazz_newMeth(C$, 'getCurrencyNameProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(10)));
});

Clazz_newMeth(C$, 'getLocaleNameProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(11)));
});

Clazz_newMeth(C$, 'getTimeZoneNameProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(12)));
});

Clazz_newMeth(C$, 'getCalendarDataProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(13)));
});

Clazz_newMeth(C$, 'getCalendarNameProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(14)));
});

Clazz_newMeth(C$, 'getCalendarProvider$',  function () {
return this.getLocaleServiceProvider$Class(Clazz_getClass($I$(15)));
});

Clazz_newMeth(C$, 'getLocaleResources$java_util_Locale',  function (locale) {
return null;
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
if (C$.availableLocales == null ) {
var avail=Clazz_new_($I$(16,1));
for (var c, $c = 0, $$c = $I$(17).spiClasses; $c<$$c.length&&((c=($$c[$c])),1);$c++) {
var lsp=this.getLocaleServiceProvider$Class(c);
if (lsp != null ) {
avail.addAll$java_util_Collection($I$(18,"asList$OA",[lsp.getAvailableLocales$()]));
}}
C$.availableLocales=avail.toArray$OA(Clazz_array($I$(1), [0]));
}return C$.availableLocales;
});

C$.$static$=function(){C$.$static$=0;
C$.availableLocales=null;
C$.NULL_PROVIDER=Clazz_new_($I$(2,1));
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.AuxLocaleProviderAdapter, "NullProvider", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.LocaleServiceProvider');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return Clazz_array($I$(1), [0]);
});

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:33 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[[0,'sun.util.locale.provider.JRELocaleProviderAdapter','java.util.concurrent.ConcurrentHashMap',['sun.util.locale.provider.LocaleProviderAdapter','.Type'],'InternalError','sun.util.locale.provider.BreakIteratorProviderImpl','sun.util.locale.provider.CollatorProviderImpl','sun.util.locale.provider.DateFormatProviderImpl','sun.util.locale.provider.DateFormatSymbolsProviderImpl','sun.util.locale.provider.DecimalFormatSymbolsProviderImpl','sun.util.locale.provider.NumberFormatProviderImpl','sun.util.locale.provider.CurrencyNameProviderImpl','sun.util.locale.provider.LocaleNameProviderImpl','sun.util.locale.provider.TimeZoneNameProviderImpl','sun.util.locale.provider.CalendarDataProviderImpl','sun.util.locale.provider.CalendarNameProviderImpl','sun.util.locale.provider.CalendarProviderImpl','sun.util.locale.provider.LocaleResources','sun.util.resources.LocaleData',['sun.util.locale.provider.JRELocaleProviderAdapter','.AvailableJRELocales'],'sun.util.locale.provider.LocaleDataMetaInfo','java.util.HashSet','java.util.StringTokenizer','java.util.Locale','sun.util.locale.provider.JRELocaleConstants','java.io.File','java.security.AccessController']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "JRELocaleProviderAdapter", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'sun.util.locale.provider.LocaleProviderAdapter', 'sun.util.locale.provider.ResourceBundleBasedAdapter');
C$.$classes$=[['AvailableJRELocales',10]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.langtagSets=Clazz_new_($I$(2,1));
this.localeResourcesMap=Clazz_new_($I$(2,1));
this.breakIteratorProvider=null;
this.collatorProvider=null;
this.dateFormatProvider=null;
this.dateFormatSymbolsProvider=null;
this.decimalFormatSymbolsProvider=null;
this.numberFormatProvider=null;
this.currencyNameProvider=null;
this.localeNameProvider=null;
this.timeZoneNameProvider=null;
this.calendarDataProvider=null;
this.calendarNameProvider=null;
this.calendarProvider=null;
},1);

C$.$fields$=[['O',['langtagSets','java.util.concurrent.ConcurrentMap','+localeResourcesMap','localeData','sun.util.resources.LocaleData','breakIteratorProvider','java.text.spi.BreakIteratorProvider','collatorProvider','java.text.spi.CollatorProvider','dateFormatProvider','java.text.spi.DateFormatProvider','dateFormatSymbolsProvider','java.text.spi.DateFormatSymbolsProvider','decimalFormatSymbolsProvider','java.text.spi.DecimalFormatSymbolsProvider','numberFormatProvider','java.text.spi.NumberFormatProvider','currencyNameProvider','java.util.spi.CurrencyNameProvider','localeNameProvider','java.util.spi.LocaleNameProvider','timeZoneNameProvider','java.util.spi.TimeZoneNameProvider','calendarDataProvider','java.util.spi.CalendarDataProvider','calendarNameProvider','java.util.spi.CalendarNameProvider','calendarProvider','sun.util.spi.CalendarProvider']]
,['O',['isNonENSupported','Boolean']]]

Clazz_newMeth(C$, 'getAdapterType$',  function () {
return $I$(3).JRE;
});

Clazz_newMeth(C$, 'getLocaleServiceProvider$Class',  function (c) {
switch (c.getSimpleName$()) {
case "BreakIteratorProvider":
return this.getBreakIteratorProvider$();
case "CollatorProvider":
return this.getCollatorProvider$();
case "DateFormatProvider":
return this.getDateFormatProvider$();
case "DateFormatSymbolsProvider":
return this.getDateFormatSymbolsProvider$();
case "DecimalFormatSymbolsProvider":
return this.getDecimalFormatSymbolsProvider$();
case "NumberFormatProvider":
return this.getNumberFormatProvider$();
case "CurrencyNameProvider":
return this.getCurrencyNameProvider$();
case "LocaleNameProvider":
return this.getLocaleNameProvider$();
case "TimeZoneNameProvider":
return this.getTimeZoneNameProvider$();
case "CalendarDataProvider":
return this.getCalendarDataProvider$();
case "CalendarNameProvider":
return this.getCalendarNameProvider$();
case "CalendarProvider":
return this.getCalendarProvider$();
default:
throw Clazz_new_($I$(4,1).c$$S,["should not come down here"]);
}
});

Clazz_newMeth(C$, 'getBreakIteratorProvider$',  function () {
if (this.breakIteratorProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(5,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.breakIteratorProvider == null ) {
this.breakIteratorProvider=provider;
}}}return this.breakIteratorProvider;
});

Clazz_newMeth(C$, 'getCollatorProvider$',  function () {
if (this.collatorProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("CollationData")],$I$(6,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.collatorProvider == null ) {
this.collatorProvider=provider;
}}}return this.collatorProvider;
});

Clazz_newMeth(C$, 'getDateFormatProvider$',  function () {
if (this.dateFormatProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(7,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.dateFormatProvider == null ) {
this.dateFormatProvider=provider;
}}}return this.dateFormatProvider;
});

Clazz_newMeth(C$, 'getDateFormatSymbolsProvider$',  function () {
if (this.dateFormatSymbolsProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(8,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.dateFormatSymbolsProvider == null ) {
this.dateFormatSymbolsProvider=provider;
}}}return this.dateFormatSymbolsProvider;
});

Clazz_newMeth(C$, 'getDecimalFormatSymbolsProvider$',  function () {
if (this.decimalFormatSymbolsProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(9,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.decimalFormatSymbolsProvider == null ) {
this.decimalFormatSymbolsProvider=provider;
}}}return this.decimalFormatSymbolsProvider;
});

Clazz_newMeth(C$, 'getNumberFormatProvider$',  function () {
if (this.numberFormatProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(10,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.numberFormatProvider == null ) {
this.numberFormatProvider=provider;
}}}return this.numberFormatProvider;
});

Clazz_newMeth(C$, 'getCurrencyNameProvider$',  function () {
if (this.currencyNameProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("CurrencyNames")],$I$(11,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.currencyNameProvider == null ) {
this.currencyNameProvider=provider;
}}}return this.currencyNameProvider;
});

Clazz_newMeth(C$, 'getLocaleNameProvider$',  function () {
if (this.localeNameProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("LocaleNames")],$I$(12,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.localeNameProvider == null ) {
this.localeNameProvider=provider;
}}}return this.localeNameProvider;
});

Clazz_newMeth(C$, 'getTimeZoneNameProvider$',  function () {
if (this.timeZoneNameProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("TimeZoneNames")],$I$(13,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.timeZoneNameProvider == null ) {
this.timeZoneNameProvider=provider;
}}}return this.timeZoneNameProvider;
});

Clazz_newMeth(C$, 'getCalendarDataProvider$',  function () {
if (this.calendarDataProvider == null ) {
var provider;
provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("CalendarData")],$I$(14,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.calendarDataProvider == null ) {
this.calendarDataProvider=provider;
}}}return this.calendarDataProvider;
});

Clazz_newMeth(C$, 'getCalendarNameProvider$',  function () {
if (this.calendarNameProvider == null ) {
var provider;
provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("FormatData")],$I$(15,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.calendarNameProvider == null ) {
this.calendarNameProvider=provider;
}}}return this.calendarNameProvider;
});

Clazz_newMeth(C$, 'getCalendarProvider$',  function () {
if (this.calendarProvider == null ) {
var provider=Clazz_new_([this.getAdapterType$(), this.getLanguageTagSet$S("CalendarData")],$I$(16,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set);
{
if (this.calendarProvider == null ) {
this.calendarProvider=provider;
}}}return this.calendarProvider;
});

Clazz_newMeth(C$, 'getLocaleResources$java_util_Locale',  function (locale) {
var lr=this.localeResourcesMap.get$O(locale);
if (lr == null ) {
lr=Clazz_new_($I$(17,1).c$$sun_util_locale_provider_ResourceBundleBasedAdapter$java_util_Locale,[this, locale]);
var lrc=this.localeResourcesMap.putIfAbsent$O$O(locale, lr);
if (lrc != null ) {
lr=lrc;
}}return lr;
});

Clazz_newMeth(C$, 'getLocaleData$',  function () {
if (this.localeData == null ) {
{
if (this.localeData == null ) {
this.localeData=Clazz_new_([this.getAdapterType$()],$I$(18,1).c$$sun_util_locale_provider_LocaleProviderAdapter_Type);
}}}return this.localeData;
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return $I$(19).localeList.clone$();
});

Clazz_newMeth(C$, 'getLanguageTagSet$S',  function (category) {
var tagset=this.langtagSets.get$O(category);
if (tagset == null ) {
tagset=this.createLanguageTagSet$S(category);
var ts=this.langtagSets.putIfAbsent$O$O(category, tagset);
if (ts != null ) {
tagset=ts;
}}return tagset;
});

Clazz_newMeth(C$, 'createLanguageTagSet$S',  function (category) {
var supportedLocaleString=$I$(20).getSupportedLocaleString$S(category);
var tagset=Clazz_new_($I$(21,1));
var tokens=Clazz_new_($I$(22,1).c$$S,[supportedLocaleString]);
while (tokens.hasMoreTokens$()){
var token=tokens.nextToken$();
if (token.equals$O("|")) {
if (C$.isNonENLangSupported$()) {
continue;
}break;
}tagset.add$O(token);
}
return tagset;
});

Clazz_newMeth(C$, 'createAvailableLocales$',  function () {
var supportedLocaleString=$I$(20).getSupportedLocaleString$S("AvailableLocales");
if (supportedLocaleString.length$() == 0) {
throw Clazz_new_($I$(4,1).c$$S,["No available locales for JRE"]);
}var barIndex=supportedLocaleString.indexOf$I("|");
var localeStringTokenizer;
if (C$.isNonENLangSupported$()) {
localeStringTokenizer=Clazz_new_([supportedLocaleString.substring$I$I(0, barIndex) + supportedLocaleString.substring$I(barIndex + 1)],$I$(22,1).c$$S);
} else {
localeStringTokenizer=Clazz_new_([supportedLocaleString.substring$I$I(0, barIndex)],$I$(22,1).c$$S);
}var length=localeStringTokenizer.countTokens$();
var locales=Clazz_array($I$(23), [length + 1]);
locales[0]=$I$(23).ROOT;
for (var i=1; i <= length; i++) {
var currentToken=localeStringTokenizer.nextToken$();
switch (currentToken) {
case "ja-JP-JP":
locales[i]=$I$(24).JA_JP_JP;
break;
case "no-NO-NY":
locales[i]=$I$(24).NO_NO_NY;
break;
case "th-TH-TH":
locales[i]=$I$(24).TH_TH_TH;
break;
default:
locales[i]=$I$(23).forLanguageTag$S(currentToken);
}
}
return locales;
}, 1);

Clazz_newMeth(C$, 'isNonENLangSupported$',  function () {
if (C$.isNonENSupported == null ) {
{
if (C$.isNonENSupported == null ) {
var sep=$I$(25).separator;
var localeDataJar=System.getProperty$S("java.home") + sep + "lib" + sep + "ext" + sep + "localedata.jar" ;
var f=Clazz_new_($I$(25,1).c$$S,[localeDataJar]);
C$.isNonENSupported=$I$(26,"doPrivileged$java_security_PrivilegedAction",[((P$.JRELocaleProviderAdapter$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "JRELocaleProviderAdapter$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedAction', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'run$',  function () {
return Boolean.valueOf$Z(this.$finals$.f.exists$());
});
})()
), Clazz_new_(P$.JRELocaleProviderAdapter$1.$init$,[this, {f:f}]))]);
}}}return (C$.isNonENSupported).valueOf();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isNonENSupported=null;
};
;
(function(){/*c*/var C$=Clazz_newClass(P$.JRELocaleProviderAdapter, "AvailableJRELocales", function(){
Clazz_newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['localeList','java.util.Locale[]']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.localeList=$I$(1).createAvailableLocales$();
};
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:34 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "LocaleDataMetaInfo");

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['resourceNameToLocales','java.util.HashMap']]]

Clazz_newMeth(C$, 'getSupportedLocaleString$S',  function (resourceName) {
return C$.resourceNameToLocales.get$O(resourceName);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.resourceNameToLocales=Clazz_new_($I$(1,1).c$$I,[7]);
{
C$.resourceNameToLocales.put$O$O("BreakIteratorInfo", "  |  th ");
C$.resourceNameToLocales.put$O$O("BreakIteratorRules", "  |  th ");
C$.resourceNameToLocales.put$O$O("FormatData", "  en en-AU en-CA en-GB en-IE en-IN en-MT en-NZ en-PH en-SG en-US en-ZA |  ar ar-JO ar-LB ar-SY be be-BY bg bg-BG ca ca-ES cs cs-CZ da da-DK de de-AT de-CH de-DE de-LU el el-CY el-GR es es-AR es-BO es-CL es-CO es-CR es-DO es-EC es-ES es-GT es-HN es-MX es-NI es-PA es-PE es-PR es-PY es-SV es-US es-UY es-VE et et-EE fi fi-FI fr fr-BE fr-CA fr-CH fr-FR ga ga-IE hi-IN hr hr-HR hu hu-HU in in-ID is is-IS it it-CH it-IT iw iw-IL ja ja-JP ko ko-KR lt lt-LT lv lv-LV mk mk-MK ms ms-MY mt mt-MT nl nl-BE nl-NL no no-NO no-NO-NY pl pl-PL pt pt-BR pt-PT ro ro-RO ru ru-RU sk sk-SK sl sl-SI sq sq-AL sr sr-BA sr-CS sr-Latn sr-Latn-ME sr-ME sr-RS sv sv-SE th th-TH tr tr-TR uk uk-UA vi vi-VN zh zh-CN zh-HK zh-SG zh-TW ");
C$.resourceNameToLocales.put$O$O("CollationData", "  |  ar be bg ca cs da el es et fi fr hi hr hu is iw ja ko lt lv mk no pl ro ru sk sl sq sr sr-Latn sv th tr uk vi zh zh-HK zh-TW ");
C$.resourceNameToLocales.put$O$O("TimeZoneNames", "  en en-CA en-GB en-IE |  de es fr hi it ja ko pt-BR sv zh-CN zh-HK zh-TW ");
C$.resourceNameToLocales.put$O$O("LocaleNames", "  en en-MT en-PH en-SG |  ar be bg ca cs da de el el-CY es es-US et fi fr ga hi hr hu in is it iw ja ko lt lv mk ms mt nl no no-NO-NY pl pt pt-PT ro ru sk sl sq sr sr-Latn sv th tr uk vi zh zh-HK zh-SG zh-TW ");
C$.resourceNameToLocales.put$O$O("CurrencyNames", "  en-AU en-CA en-GB en-IE en-IN en-MT en-NZ en-PH en-SG en-US en-ZA |  ar-AE ar-BH ar-DZ ar-EG ar-IQ ar-JO ar-KW ar-LB ar-LY ar-MA ar-OM ar-QA ar-SA ar-SD ar-SY ar-TN ar-YE be-BY bg-BG ca-ES cs-CZ da-DK de de-AT de-CH de-DE de-GR de-LU el-CY el-GR es es-AR es-BO es-CL es-CO es-CR es-CU es-DO es-EC es-ES es-GT es-HN es-MX es-NI es-PA es-PE es-PR es-PY es-SV es-US es-UY es-VE et-EE fi-FI fr fr-BE fr-CA fr-CH fr-FR fr-LU ga-IE hi-IN hr-HR hu-HU in-ID is-IS it it-CH it-IT iw-IL ja ja-JP ko ko-KR lt-LT lv-LV mk-MK ms-MY mt-MT nl-BE nl-NL no-NO pl-PL pt pt-BR pt-PT ro-RO ru-RU sk-SK sl-SI sq-AL sr-BA sr-CS sr-Latn-BA sr-Latn-ME sr-Latn-RS sr-ME sr-RS sv sv-SE th-TH tr-TR uk-UA vi-VN zh-CN zh-HK zh-SG zh-TW ");
C$.resourceNameToLocales.put$O$O("CalendarData", "  en en-GB en-IE en-MT |  ar be bg ca cs da de el el-CY es es-ES es-US et fi fr fr-CA hi hr hu in-ID is it iw ja ko lt lv mk ms-MY mt mt-MT nl no pl pt pt-BR pt-PT ro ru sk sl sq sr sr-Latn-BA sr-Latn-ME sr-Latn-RS sv th tr uk vi zh ");
C$.resourceNameToLocales.put$O$O("AvailableLocales", " en en-AU en-CA en-GB en-IE en-IN en-MT en-NZ en-PH en-SG en-US en-ZA | ar ar-AE ar-BH ar-DZ ar-EG ar-IQ ar-JO ar-KW ar-LB ar-LY ar-MA ar-OM ar-QA ar-SA ar-SD ar-SY ar-TN ar-YE be be-BY bg bg-BG ca ca-ES cs cs-CZ da da-DK de de-AT de-CH de-DE de-GR de-LU el el-CY el-GR es es-AR es-BO es-CL es-CO es-CR es-CU es-DO es-EC es-ES es-GT es-HN es-MX es-NI es-PA es-PE es-PR es-PY es-SV es-US es-UY es-VE et et-EE fi fi-FI fr fr-BE fr-CA fr-CH fr-FR fr-LU ga ga-IE hi hi-IN hr hr-HR hu hu-HU in in-ID is is-IS it it-CH it-IT iw iw-IL ja ja-JP ja-JP-JP ko ko-KR lt lt-LT lv lv-LV mk mk-MK ms ms-MY mt mt-MT nl nl-BE nl-NL no no-NO no-NO-NY pl pl-PL pt pt-BR pt-PT ro ro-RO ru ru-RU sk sk-SK sl sl-SI sq sq-AL sr sr-BA sr-CS sr-Latn sr-Latn-BA sr-Latn-ME sr-Latn-RS sr-ME sr-RS sv sv-SE th th-TH th-TH-TH tr tr-TR uk uk-UA vi vi-VN zh zh-CN zh-HK zh-SG zh-TW ");
};
};

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:34 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[[0,'sun.util.locale.provider.JRELocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter','java.util.concurrent.ConcurrentHashMap','java.util.ArrayList',['sun.util.locale.provider.LocaleProviderAdapter','.Type'],'java.util.Locale','sun.util.cldr.CLDRLocaleProviderAdapter','sun.util.locale.provider.HostLocaleProviderAdapter','sun.util.locale.provider.LocaleServiceProviderPool','sun.util.locale.provider.FallbackLocaleProviderAdapter','java.util.Collections','InternalError',['java.util.ResourceBundle','.Control'],'sun.util.locale.provider.JRELocaleConstants']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "LocaleProviderAdapter", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Type',25]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['adapterPreference','java.util.List','jreLocaleProviderAdapter','sun.util.locale.provider.LocaleProviderAdapter','+spiLocaleProviderAdapter','+cldrLocaleProviderAdapter','+hostLocaleProviderAdapter','+fallbackLocaleProviderAdapter','defaultLocaleProviderAdapter','sun.util.locale.provider.LocaleProviderAdapter.Type','adapterCache','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, 'forType$sun_util_locale_provider_LocaleProviderAdapter_Type',  function (type) {
switch (type) {
case $I$(5).JRE:
return C$.jreLocaleProviderAdapter;
case $I$(5).CLDR:
return C$.cldrLocaleProviderAdapter;
case $I$(5).SPI:
return C$.spiLocaleProviderAdapter;
case $I$(5).HOST:
return C$.hostLocaleProviderAdapter;
case $I$(5).FALLBACK:
return C$.fallbackLocaleProviderAdapter;
default:
throw Clazz_new_($I$(12,1).c$$S,["unknown locale data adapter type"]);
}
}, 1);

Clazz_newMeth(C$, 'forJRE$',  function () {
return C$.jreLocaleProviderAdapter;
}, 1);

Clazz_newMeth(C$, 'getResourceBundleBased$',  function () {
for (var type, $type = C$.getAdapterPreference$().iterator$(); $type.hasNext$()&&((type=($type.next$())),1);) {
if (type === $I$(5).JRE  || type === $I$(5).CLDR   || type === $I$(5).FALLBACK  ) {
return C$.forType$sun_util_locale_provider_LocaleProviderAdapter_Type(type);
}}
throw Clazz_new_($I$(12,1));
}, 1);

Clazz_newMeth(C$, 'getAdapterPreference$',  function () {
return C$.adapterPreference;
}, 1);

Clazz_newMeth(C$, 'getAdapter$Class$java_util_Locale',  function (providerClass, locale) {
var adapter;
var adapterMap=C$.adapterCache.get$O(providerClass);
if (adapterMap != null ) {
if ((adapter=adapterMap.get$O(locale)) != null ) {
return adapter;
}} else {
adapterMap=Clazz_new_($I$(3,1));
C$.adapterCache.putIfAbsent$O$O(providerClass, adapterMap);
}adapter=C$.findAdapter$Class$java_util_Locale(providerClass, locale);
if (adapter != null ) {
adapterMap.putIfAbsent$O$O(locale, adapter);
return adapter;
}var lookupLocales=$I$(13,"getControl$java_util_List",[$I$(13).FORMAT_DEFAULT]).getCandidateLocales$S$java_util_Locale("", locale);
for (var loc, $loc = lookupLocales.iterator$(); $loc.hasNext$()&&((loc=($loc.next$())),1);) {
if (loc.equals$O(locale)) {
continue;
}adapter=C$.findAdapter$Class$java_util_Locale(providerClass, loc);
if (adapter != null ) {
adapterMap.putIfAbsent$O$O(locale, adapter);
return adapter;
}}
adapterMap.putIfAbsent$O$O(locale, C$.fallbackLocaleProviderAdapter);
return C$.fallbackLocaleProviderAdapter;
}, 1);

Clazz_newMeth(C$, 'findAdapter$Class$java_util_Locale',  function (providerClass, locale) {
for (var type, $type = C$.getAdapterPreference$().iterator$(); $type.hasNext$()&&((type=($type.next$())),1);) {
var adapter=C$.forType$sun_util_locale_provider_LocaleProviderAdapter_Type(type);
var provider=adapter.getLocaleServiceProvider$Class(providerClass);
if (provider != null ) {
if (provider.isSupportedLocale$java_util_Locale(locale)) {
return adapter;
}}}
return null;
}, 1);

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale$sun_util_locale_provider_LocaleProviderAdapter_Type$java_util_Set',  function (locale, type, langtags) {
Clazz_assert(C$, this, function(){return type === $I$(5).JRE  || type === $I$(5).CLDR   || type === $I$(5).FALLBACK  });
if ($I$(6).ROOT.equals$O(locale)) {
return true;
}if (type === $I$(5).FALLBACK ) {
return false;
}locale=locale.stripExtensions$();
if (langtags.contains$O(locale.toLanguageTag$())) {
return true;
}if (type === $I$(5).JRE ) {
var oldname=locale.toString().replace$C$C("_", "-");
return langtags.contains$O(oldname) || "ja-JP-JP".equals$O(oldname) || "th-TH-TH".equals$O(oldname) || "no-NO-NY".equals$O(oldname)  ;
}return false;
}, 1);

Clazz_newMeth(C$, 'toLocaleArray$java_util_Set',  function (tags) {
var locs=Clazz_array($I$(6), [tags.size$() + 1]);
var index=0;
locs[index++]=$I$(6).ROOT;
for (var tag, $tag = tags.iterator$(); $tag.hasNext$()&&((tag=($tag.next$())),1);) {
switch (tag) {
case "ja-JP-JP":
locs[index++]=$I$(14).JA_JP_JP;
break;
case "th-TH-TH":
locs[index++]=$I$(14).TH_TH_TH;
break;
default:
locs[index++]=$I$(6).forLanguageTag$S(tag);
break;
}
}
return locs;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.jreLocaleProviderAdapter=Clazz_new_($I$(1,1));
C$.spiLocaleProviderAdapter=Clazz_new_($I$(2,1));
C$.cldrLocaleProviderAdapter=null;
C$.hostLocaleProviderAdapter=null;
C$.fallbackLocaleProviderAdapter=null;
C$.defaultLocaleProviderAdapter=null;
C$.adapterCache=Clazz_new_($I$(3,1));
{
var order=(System.getProperty$S("java.locale.providers"));
var typeList=Clazz_new_($I$(4,1));
if (order != null  && order.length$() != 0 ) {
var types=order.split$S(",");
for (var type, $type = 0, $$type = types; $type<$$type.length&&((type=($$type[$type])),1);$type++) {
try {
var aType=$I$(5,"valueOf$S",[type.trim$().toUpperCase$java_util_Locale($I$(6).ROOT)]);
switch (aType) {
case $I$(5).CLDR:
if (C$.cldrLocaleProviderAdapter == null ) {
C$.cldrLocaleProviderAdapter=Clazz_new_($I$(7,1));
}break;
case $I$(5).HOST:
if (C$.hostLocaleProviderAdapter == null ) {
C$.hostLocaleProviderAdapter=Clazz_new_($I$(8,1));
}break;
}
if (!typeList.contains$O(aType)) {
typeList.add$O(aType);
}} catch (e) {
if (Clazz_exceptionOf(e,"IllegalArgumentException") || Clazz_exceptionOf(e,"UnsupportedOperationException")){
$I$(9,"config$Class$S",[Clazz_getClass(C$), e.toString()]);
} else {
throw e;
}
}
}
}if (!typeList.isEmpty$()) {
if (!typeList.contains$O($I$(5).JRE)) {
C$.fallbackLocaleProviderAdapter=Clazz_new_($I$(10,1));
typeList.add$O($I$(5).FALLBACK);
C$.defaultLocaleProviderAdapter=$I$(5).FALLBACK;
} else {
C$.defaultLocaleProviderAdapter=$I$(5).JRE;
}} else {
typeList.add$O($I$(5).JRE);
typeList.add$O($I$(5).SPI);
C$.defaultLocaleProviderAdapter=$I$(5).JRE;
}C$.adapterPreference=$I$(11).unmodifiableList$java_util_List(typeList);
};
};
;
(function(){/*e*/var C$=Clazz_newClass(P$.LocaleProviderAdapter, "Type", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['UTIL_RESOURCES_PACKAGE','TEXT_RESOURCES_PACKAGE']]]

Clazz_newMeth(C$, 'c$',  function () {
C$.c$$S$S.apply(this, [null, null]);
}, 1);

Clazz_newMeth(C$, 'c$$S$S',  function (util, text) {
;C$.$init$.apply(this);
this.UTIL_RESOURCES_PACKAGE=util;
this.TEXT_RESOURCES_PACKAGE=text;
}, 1);

Clazz_newMeth(C$, 'getUtilResourcesPackage$',  function () {
return this.UTIL_RESOURCES_PACKAGE;
});

Clazz_newMeth(C$, 'getTextResourcesPackage$',  function () {
return this.TEXT_RESOURCES_PACKAGE;
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz_array(C$,[0]);
Clazz_newEnumConst($vals, C$.c$$S$S, "JRE", 0, ["sun.util.resources", "sun.text.resources"]);
Clazz_newEnumConst($vals, C$.c$$S$S, "CLDR", 1, ["sun.util.resources.cldr", "sun.text.resources.cldr"]);
Clazz_newEnumConst($vals, C$.c$, "SPI", 2, []);
Clazz_newEnumConst($vals, C$.c$, "HOST", 3, []);
Clazz_newEnumConst($vals, C$.c$$S$S, "FALLBACK", 4, ["sun.util.resources", "sun.text.resources"]);
};
var $vals=[];
Clazz_newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz_newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:34 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[];
/*i*/var C$=Clazz_newInterface(P$, "ResourceBundleBasedAdapter");
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:34 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.locale.provider"),I$=[[0,'java.util.concurrent.ConcurrentHashMap','sun.util.locale.provider.SPILocaleProviderAdapter','java.util.Locale',['sun.util.locale.provider.LocaleProviderAdapter','.Type'],'java.security.AccessController','java.util.ServiceLoader','sun.util.locale.provider.LocaleServiceProviderPool']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "SPILocaleProviderAdapter", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'sun.util.locale.provider.AuxLocaleProviderAdapter');
C$.$classes$=[['Delegate',8],['BreakIteratorProviderDelegate',8],['CollatorProviderDelegate',8],['DateFormatProviderDelegate',8],['DateFormatSymbolsProviderDelegate',8],['DecimalFormatSymbolsProviderDelegate',8],['NumberFormatProviderDelegate',8],['CalendarDataProviderDelegate',8],['CalendarNameProviderDelegate',8],['CurrencyNameProviderDelegate',8],['LocaleNameProviderDelegate',8],['TimeZoneNameProviderDelegate',8]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'getAdapterType$',  function () {
return $I$(4).SPI;
});

Clazz_newMeth(C$, 'findInstalledProvider$Class',  function (c) {
try {
return $I$(5,"doPrivileged$java_security_PrivilegedExceptionAction",[((P$.SPILocaleProviderAdapter$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "SPILocaleProviderAdapter$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedExceptionAction', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'run$',  function () {
var delegate=null;
for (var provider, $provider = $I$(6).loadInstalled$Class(this.$finals$.c).iterator$(); $provider.hasNext$()&&((provider=($provider.next$())),1);) {
if (delegate == null ) {
try {
delegate=Clazz_forName(Clazz_getClass($I$(2)).getCanonicalName$() + "$" + this.$finals$.c.getSimpleName$() + "Delegate" ).newInstance$();
} catch (e) {
if (Clazz_exceptionOf(e,"ClassNotFoundException") || Clazz_exceptionOf(e,"InstantiationException") || Clazz_exceptionOf(e,"IllegalAccessException")){
$I$(7,"config$Class$S",[Clazz_getClass($I$(2)), e.toString()]);
return null;
} else {
throw e;
}
}
}(delegate).addImpl$java_util_spi_LocaleServiceProvider(provider);
}
return delegate;
});
})()
), Clazz_new_(P$.SPILocaleProviderAdapter$1.$init$,[this, {c:c}]))]);
} catch (e) {
if (Clazz_exceptionOf(e,"java.security.PrivilegedActionException")){
$I$(7,"config$Class$S",[Clazz_getClass(C$), e.toString()]);
} else {
throw e;
}
}
return null;
});

Clazz_newMeth(C$, 'getImpl$java_util_Map$java_util_Locale',  function (map, locale) {
for (var l, $l = $I$(7).getLookupLocales$java_util_Locale(locale).iterator$(); $l.hasNext$()&&((l=($l.next$())),1);) {
var ret=map.get$O(l);
if (ret != null ) {
return ret;
}}
return null;
}, 1);
;
(function(){/*i*/var C$=Clazz_newInterface(P$.SPILocaleProviderAdapter, "Delegate", function(){
});
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "BreakIteratorProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.BreakIteratorProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_BreakIteratorProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getWordInstance$java_util_Locale',  function (locale) {
var bip=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return bip != null });
return bip.getWordInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getLineInstance$java_util_Locale',  function (locale) {
var bip=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return bip != null });
return bip.getLineInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getCharacterInstance$java_util_Locale',  function (locale) {
var bip=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return bip != null });
return bip.getCharacterInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getSentenceInstance$java_util_Locale',  function (locale) {
var bip=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return bip != null });
return bip.getSentenceInstance$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "CollatorProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.CollatorProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_CollatorProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getInstance$java_util_Locale',  function (locale) {
var cp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cp != null });
return cp.getInstance$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "DateFormatProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.DateFormatProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_DateFormatProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getTimeInstance$I$java_util_Locale',  function (style, locale) {
var dfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return dfp != null });
return dfp.getTimeInstance$I$java_util_Locale(style, locale);
});

Clazz_newMeth(C$, 'getDateInstance$I$java_util_Locale',  function (style, locale) {
var dfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return dfp != null });
return dfp.getDateInstance$I$java_util_Locale(style, locale);
});

Clazz_newMeth(C$, 'getDateTimeInstance$I$I$java_util_Locale',  function (dateStyle, timeStyle, locale) {
var dfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return dfp != null });
return dfp.getDateTimeInstance$I$I$java_util_Locale(dateStyle, timeStyle, locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "DateFormatSymbolsProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.DateFormatSymbolsProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_DateFormatSymbolsProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getInstance$java_util_Locale',  function (locale) {
var dfsp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return dfsp != null });
return dfsp.getInstance$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "DecimalFormatSymbolsProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.DecimalFormatSymbolsProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_DecimalFormatSymbolsProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getInstance$java_util_Locale',  function (locale) {
var dfsp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return dfsp != null });
return dfsp.getInstance$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "NumberFormatProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.text.spi.NumberFormatProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_text_spi_NumberFormatProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getCurrencyInstance$java_util_Locale',  function (locale) {
var nfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return nfp != null });
return nfp.getCurrencyInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getIntegerInstance$java_util_Locale',  function (locale) {
var nfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return nfp != null });
return nfp.getIntegerInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getNumberInstance$java_util_Locale',  function (locale) {
var nfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return nfp != null });
return nfp.getNumberInstance$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getPercentInstance$java_util_Locale',  function (locale) {
var nfp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return nfp != null });
return nfp.getPercentInstance$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "CalendarDataProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.CalendarDataProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_util_spi_CalendarDataProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getFirstDayOfWeek$java_util_Locale',  function (locale) {
var cdp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cdp != null });
return cdp.getFirstDayOfWeek$java_util_Locale(locale);
});

Clazz_newMeth(C$, 'getMinimalDaysInFirstWeek$java_util_Locale',  function (locale) {
var cdp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cdp != null });
return cdp.getMinimalDaysInFirstWeek$java_util_Locale(locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "CalendarNameProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.CalendarNameProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_util_spi_CalendarNameProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getDisplayName$S$I$I$I$java_util_Locale',  function (calendarType, field, value, style, locale) {
var cdp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cdp != null });
return cdp.getDisplayName$S$I$I$I$java_util_Locale(calendarType, field, value, style, locale);
});

Clazz_newMeth(C$, 'getDisplayNames$S$I$I$java_util_Locale',  function (calendarType, field, style, locale) {
var cdp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cdp != null });
return cdp.getDisplayNames$S$I$I$java_util_Locale(calendarType, field, style, locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "CurrencyNameProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.CurrencyNameProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_util_spi_CurrencyNameProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getSymbol$S$java_util_Locale',  function (currencyCode, locale) {
var cnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cnp != null });
return cnp.getSymbol$S$java_util_Locale(currencyCode, locale);
});

Clazz_newMeth(C$, 'getDisplayName$S$java_util_Locale',  function (currencyCode, locale) {
var cnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return cnp != null });
return cnp.getDisplayName$S$java_util_Locale(currencyCode, locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "LocaleNameProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.LocaleNameProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_util_spi_LocaleNameProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getDisplayLanguage$S$java_util_Locale',  function (languageCode, locale) {
var lnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return lnp != null });
return lnp.getDisplayLanguage$S$java_util_Locale(languageCode, locale);
});

Clazz_newMeth(C$, 'getDisplayScript$S$java_util_Locale',  function (scriptCode, locale) {
var lnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return lnp != null });
return lnp.getDisplayScript$S$java_util_Locale(scriptCode, locale);
});

Clazz_newMeth(C$, 'getDisplayCountry$S$java_util_Locale',  function (countryCode, locale) {
var lnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return lnp != null });
return lnp.getDisplayCountry$S$java_util_Locale(countryCode, locale);
});

Clazz_newMeth(C$, 'getDisplayVariant$S$java_util_Locale',  function (variant, locale) {
var lnp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return lnp != null });
return lnp.getDisplayVariant$S$java_util_Locale(variant, locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.SPILocaleProviderAdapter, "TimeZoneNameProviderDelegate", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.spi.TimeZoneNameProvider', [['sun.util.locale.provider.SPILocaleProviderAdapter','sun.util.locale.provider.SPILocaleProviderAdapter.Delegate']]);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.map=Clazz_new_($I$(1,1));
},1);

C$.$fields$=[['O',['map','java.util.concurrent.ConcurrentMap']]]

Clazz_newMeth(C$, ['addImpl$java_util_spi_TimeZoneNameProvider','addImpl$java_util_spi_LocaleServiceProvider'],  function (impl) {
for (var l, $l = 0, $$l = impl.getAvailableLocales$(); $l<$$l.length&&((l=($$l[$l])),1);$l++) {
this.map.putIfAbsent$O$O(l, impl);
}
});

Clazz_newMeth(C$, 'getImpl$java_util_Locale',  function (locale) {
return $I$(2).getImpl$java_util_Map$java_util_Locale(this.map, locale);
});

Clazz_newMeth(C$, 'getAvailableLocales$',  function () {
return this.map.keySet$().toArray$OA(Clazz_array($I$(3), [0]));
});

Clazz_newMeth(C$, 'isSupportedLocale$java_util_Locale',  function (locale) {
return this.map.containsKey$O(locale);
});

Clazz_newMeth(C$, 'getDisplayName$S$Z$I$java_util_Locale',  function (ID, daylight, style, locale) {
var tznp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return tznp != null });
return tznp.getDisplayName$S$Z$I$java_util_Locale(ID, daylight, style, locale);
});

Clazz_newMeth(C$, 'getGenericDisplayName$S$I$java_util_Locale',  function (ID, style, locale) {
var tznp=this.getImpl$java_util_Locale(locale);
Clazz_assert(C$, this, function(){return tznp != null });
return tznp.getGenericDisplayName$S$I$java_util_Locale(ID, style, locale);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:35 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.resources"),p$1={},I$=[[0,['java.util.ResourceBundle','.Control'],'java.util.ArrayList','sun.util.locale.provider.LocaleDataMetaInfo','java.util.Locale',['sun.util.locale.provider.LocaleProviderAdapter','.Type'],'java.util.Arrays','java.util.ResourceBundle',['sun.util.resources.LocaleData','.LocaleDataResourceBundleControl'],'java.security.AccessController',['sun.util.resources.LocaleData','.SupplementaryResourceBundleControl']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "LocaleData", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['LocaleDataResourceBundleControl',10],['SupplementaryResourceBundleControl',10]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'c$$sun_util_locale_provider_LocaleProviderAdapter_Type',  function (type) {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'getCalendarData$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.util.resources.CalendarData", locale);
}, 1);

Clazz_newMeth(C$, 'getCurrencyNames$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.util.resources.CurrencyNames", locale);
}, 1);

Clazz_newMeth(C$, 'getLocaleNames$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.util.resources.LocaleNames", locale);
}, 1);

Clazz_newMeth(C$, 'getTimeZoneNames$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.util.resources.TimeZoneNames", locale);
}, 1);

Clazz_newMeth(C$, 'getBreakIteratorInfo$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.text.resources.BreakIteratorInfo", locale);
}, 1);

Clazz_newMeth(C$, 'getCollationData$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.text.resources.CollationData", locale);
}, 1);

Clazz_newMeth(C$, 'getDateFormatData$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.text.resources.FormatData", locale);
}, 1);

Clazz_newMeth(C$, 'setSupplementary$sun_util_resources_ParallelListResourceBundle',  function (formatData) {
if (!formatData.areParallelContentsComplete$()) {
var suppName="sun.text.resources.JavaTimeSupplementary";
p$1.setSupplementary$S$sun_util_resources_ParallelListResourceBundle.apply(this, [suppName, formatData]);
}});

Clazz_newMeth(C$, 'setSupplementary$S$sun_util_resources_ParallelListResourceBundle',  function (suppName, formatData) {
var parent=formatData.getParent$();
var resetKeySet=false;
if (parent != null ) {
resetKeySet=p$1.setSupplementary$S$sun_util_resources_ParallelListResourceBundle.apply(this, [suppName, parent]);
}var supp=C$.getSupplementary$S$java_util_Locale(suppName, formatData.getLocale$());
formatData.setParallelContents$sun_util_resources_OpenListResourceBundle(supp);
resetKeySet=!!(resetKeySet|(supp != null ));
if (resetKeySet) {
formatData.resetKeySet$();
}return resetKeySet;
}, p$1);

Clazz_newMeth(C$, 'getNumberFormatData$java_util_Locale',  function (locale) {
return C$.getBundle$S$java_util_Locale("sun.text.resources.FormatData", locale);
}, 1);

Clazz_newMeth(C$, 'getBundle$S$java_util_Locale',  function (baseName, locale) {
return $I$(7,"getBundle$S$java_util_Locale$java_util_ResourceBundle_Control",[baseName, locale, $I$(8).$INSTANCE]);
}, 1);

Clazz_newMeth(C$, 'getSupplementary$S$java_util_Locale',  function (baseName, locale) {
return $I$(9,"doPrivileged$java_security_PrivilegedAction",[((P$.LocaleData$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "LocaleData$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.security.PrivilegedAction', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'run$',  function () {
var rb=null;
try {
rb=$I$(7,"getBundle$S$java_util_Locale$java_util_ResourceBundle_Control",[this.$finals$.baseName, this.$finals$.locale, $I$(10).$$INSTANCE]);
} catch (e) {
if (Clazz_exceptionOf(e,"java.util.MissingResourceException")){
} else {
throw e;
}
}
return rb;
});
})()
), Clazz_new_(P$.LocaleData$1.$init$,[this, {locale:locale,baseName:baseName}]))]);
}, 1);
;
(function(){/*c*/var C$=Clazz_newClass(P$.LocaleData, "LocaleDataResourceBundleControl", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['java.util.ResourceBundle','.Control']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['$INSTANCE','sun.util.resources.LocaleData.LocaleDataResourceBundleControl']]]

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
}, 1);

Clazz_newMeth(C$, 'getFormats$S',  function (name) {
return name.indexOf$S(".text.") >= 0 || name.indexOf$S("Time") >= 0  ? $I$(1).FORMAT_CLASS : $I$(1).FORMAT_PROPERTIES;
});

Clazz_newMeth(C$, 'getCandidateLocales$S$java_util_Locale',  function (baseName, locale) {
var candidates=C$.superclazz.prototype.getCandidateLocales$S$java_util_Locale.apply(this, [baseName, locale]);
var list=Clazz_new_($I$(2,1));
var localeString=$I$(3).getSupportedLocaleString$S(baseName);
if (localeString != null  && localeString.length$() != 0 ) {
for (var l=candidates.iterator$(); l.hasNext$(); ) {
var loc=l.next$();
var lstr;
if (loc.getScript$().length$() > 0) {
lstr=loc.toLanguageTag$().replaceAll$S$S("-", "_");
} else {
lstr=loc.toString();
var idx=lstr.indexOf$S("_#");
if (idx >= 0) {
lstr=lstr.substring$I$I(0, idx);
}}if (lstr.length$() != 0 && localeString.indexOf$S(" " + lstr + " " ) == -1 ) {
l.remove$();
}}
}if (locale.getLanguage$() !== "en"  && baseName.contains$CharSequence(".cldr")  && baseName.endsWith$S("TimeZoneNames") ) {
candidates.add$I$O(candidates.size$() - 1, $I$(4).ENGLISH);
}return candidates;
});

Clazz_newMeth(C$, 'getFallbackLocale$S$java_util_Locale',  function (baseName, locale) {
if (baseName == null  || locale == null  ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}return null;
});

Clazz_newMeth(C$, 'toBundleName$S$java_util_Locale',  function (baseName, locale) {
var newBaseName=baseName;
var lang=locale.getLanguage$();
if (lang.length$() > 0) {
if (baseName.startsWith$S($I$(5).JRE.getUtilResourcesPackage$()) || baseName.startsWith$S($I$(5).JRE.getTextResourcesPackage$()) ) {
Clazz_assert(C$, this, function(){return $I$(5).JRE.getUtilResourcesPackage$().length$() == $I$(5).JRE.getTextResourcesPackage$().length$()});
var index=$I$(5).JRE.getUtilResourcesPackage$().length$();
if (baseName.indexOf$S$I(".cldr", index) > 0) {
index+=".cldr".length$();
}newBaseName=baseName.substring$I$I(0, index + 1) + lang + baseName.substring$I(index) ;
}}return C$.superclazz.prototype.toBundleName$S$java_util_Locale.apply(this, [newBaseName, locale]);
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.$INSTANCE=Clazz_new_(C$);
};
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.LocaleData, "SupplementaryResourceBundleControl", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['sun.util.resources.LocaleData','.LocaleDataResourceBundleControl']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['$$INSTANCE','sun.util.resources.LocaleData.SupplementaryResourceBundleControl']]]

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
}, 1);

Clazz_newMeth(C$, 'getCandidateLocales$S$java_util_Locale',  function (baseName, locale) {
return $I$(6,"asList$OA",[Clazz_array($I$(4), -1, [locale])]);
});

Clazz_newMeth(C$, 'getTimeToLive$S$java_util_Locale',  function (baseName, locale) {
Clazz_assert(C$, this, function(){return baseName.contains$CharSequence("JavaTimeSupplementary")});
return -1;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.$$INSTANCE=Clazz_new_(C$);
};
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:35 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("sun.util.resources"),p$1={},I$=[[0,'java.util.HashSet','java.util.Collections',['sun.util.resources.ParallelListResourceBundle','.KeySet'],'java.util.HashMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "ParallelListResourceBundle", function(){
Clazz_newInstance(this, arguments,0,C$);
}, 'java.util.ResourceBundle');
C$.$classes$=[['KeySet',10]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.done=false;
},1);

C$.$fields$=[['Z',['done'],'O',['lookup','java.util.Map','keyset','java.util.Set','parallelContents','Object[][]']]]

Clazz_newMeth(C$, 'c$',  function () {
Clazz_super_(C$, this);
}, 1);

Clazz_newMeth(C$, 'getParent$',  function () {
return this.parent;
});

Clazz_newMeth(C$, 'setParallelContents$sun_util_resources_OpenListResourceBundle',  function (rb) {
if (rb == null ) {
p$1.compareAndSet$OAA$OAA$Z$Z.apply(this, [null, null, false, true]);
} else {
p$1.compareAndSet$OAA$OAA$Z$Z.apply(this, [null, rb.getContents$(), false, false]);
}});

Clazz_newMeth(C$, 'compareAndSet$OAA$OAA$Z$Z',  function (orig, val, wasdone, done) {
if (this.parallelContents === orig  && this.done == wasdone  ) {
this.parallelContents=val;
this.done=done;
}}, p$1);

Clazz_newMeth(C$, 'areParallelContentsComplete$',  function () {
return this.parallelContents != null ;
});

Clazz_newMeth(C$, 'handleGetObject$S',  function (key) {
if (key == null ) {
throw Clazz_new_(Clazz_load('NullPointerException'));
}this.loadLookupTablesIfNecessary$();
return this.lookup.get$O(key);
});

Clazz_newMeth(C$, 'getKeys$',  function () {
return $I$(2,"enumeration$java_util_Collection",[this.keySet$()]);
});

Clazz_newMeth(C$, 'containsKey$S',  function (key) {
return this.keySet$().contains$O(key);
});

Clazz_newMeth(C$, 'handleKeySet$',  function () {
this.loadLookupTablesIfNecessary$();
return this.lookup.keySet$();
});

Clazz_newMeth(C$, 'keySet$',  function () {
var ks;
while ((ks=this.keyset) == null ){
ks=Clazz_new_([this.handleKeySet$(), this.parent],$I$(3,1).c$$java_util_Set$java_util_ResourceBundle);
{
if (this.keyset == null ) {
this.keyset=ks;
}}}
return ks;
});

Clazz_newMeth(C$, 'resetKeySet$',  function () {
this.keyset=null;
});

Clazz_newMeth(C$, 'loadLookupTablesIfNecessary$',  function () {
var map=this.lookup;
if (map == null ) {
map=Clazz_new_($I$(4,1));
for (var item, $item = 0, $$item = this.getContents$(); $item<$$item.length&&((item=($$item[$item])),1);$item++) {
map.put$O$O(item[0], item[1]);
}
}var data=this.parallelContents;
if (data != null ) {
for (var item, $item = 0, $$item = data; $item<$$item.length&&((item=($$item[$item])),1);$item++) {
map.putIfAbsent$O$O(item[0], item[1]);
}
this.parallelContents=null;
}if (this.lookup == null ) {
{
if (this.lookup == null ) {
this.lookup=map;
}}}});
;
(function(){/*c*/var C$=Clazz_newClass(P$.ParallelListResourceBundle, "KeySet", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.util.AbstractSet');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['set','java.util.Set','parent','java.util.ResourceBundle']]]

Clazz_newMeth(C$, 'c$$java_util_Set$java_util_ResourceBundle',  function (set, parent) {
Clazz_super_(C$, this);
this.set=set;
this.parent=parent;
}, 1);

Clazz_newMeth(C$, 'contains$O',  function (o) {
if (this.set.contains$O(o)) {
return true;
}return (this.parent != null ) ? this.parent.containsKey$S(o) : false;
});

Clazz_newMeth(C$, 'iterator$',  function () {
if (this.parent == null ) {
return this.set.iterator$();
}return ((P$.ParallelListResourceBundle$KeySet$1||
(function(){/*a*/var C$=Clazz_newClass(P$, "ParallelListResourceBundle$KeySet$1", function(){Clazz_newInstance(this, arguments[0],1,C$);}, null, 'java.util.Iterator', 1);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
this.itr=this.b$['sun.util.resources.ParallelListResourceBundle.KeySet'].set.iterator$();
},1);

C$.$fields$=[['Z',['usingParent'],'O',['itr','java.util.Iterator']]]

Clazz_newMeth(C$, 'hasNext$',  function () {
if (this.itr.hasNext$()) {
return true;
}if (!this.usingParent) {
var nextset=Clazz_new_([this.b$['sun.util.resources.ParallelListResourceBundle.KeySet'].parent.keySet$()],$I$(1,1).c$$java_util_Collection);
nextset.removeAll$java_util_Collection(this.b$['sun.util.resources.ParallelListResourceBundle.KeySet'].set);
this.itr=nextset.iterator$();
this.usingParent=true;
}return this.itr.hasNext$();
});

Clazz_newMeth(C$, 'next$',  function () {
if (this.hasNext$()) {
return this.itr.next$();
}throw Clazz_new_(Clazz_load('java.util.NoSuchElementException'));
});

Clazz_newMeth(C$, 'remove$',  function () {
throw Clazz_new_(Clazz_load('UnsupportedOperationException'));
});
})()
), Clazz_new_(P$.ParallelListResourceBundle$KeySet$1.$init$,[this, null]));
});

Clazz_newMeth(C$, 'size$',  function () {
if (this.parent == null ) {
return this.set.size$();
}var allset=Clazz_new_($I$(1,1).c$$java_util_Collection,[this.set]);
allset.addAll$java_util_Collection(this.parent.keySet$());
return allset.size$();
});

Clazz_newMeth(C$);
})()
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:35 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
(function(){var P$=Clazz_newPackage("swingjs"),p$1={},p$2={},I$=[[0,'swingjs.JSDnD',['swingjs.JSDnD','.FileTransferable'],'java.awt.datatransfer.DataFlavor','java.util.ArrayList','java.io.File','swingjs.JSUtil',['swingjs.JSDnD','.JSTransferable'],['swingjs.JSDnD','.JSDropMouseEvent'],'java.awt.dnd.DropTargetContext',['swingjs.JSDnD','.JSDropTargetContextPeer'],'java.awt.dnd.DropTargetDropEvent','java.awt.Point']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz_load(I$0[i])))),!n&&i.$load$&&Clazz_load(i,2),i)};
/*c*/var C$=Clazz_newClass(P$, "JSDnD", function(){
Clazz_newInstance(this, arguments,0,C$);
});
C$.$classes$=[['JSDropMouseEvent',9],['JSDropTargetContextPeer',8],['JSTransferable',9],['FileTransferable',9]];

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

Clazz_newMeth(C$, 'drop$javax_swing_JComponent$O$S$BA$I$I',  function (jc, html5DataTransfer, name, data, x, y) {
if (html5DataTransfer == null ) return;
var t=Clazz_new_($I$(7,1).c$$O,[html5DataTransfer]);
if (name == null ) {
var url=t.getTransferData$S("text/uri-list");
if (url != null ) {
C$.drop$javax_swing_JComponent$O$S$BA$I$I(jc, t, url, $I$(6).getFileAsBytes$O(url), x, y);
return;
}}var target=jc.getDropTarget$();
System.out.println$S("JSDnD drop for " + jc.getUIClassID$() + " target " + target );
var offset;
if (target != null ) {
offset=jc.getLocationOnScreen$();
target.drop$java_awt_dnd_DropTargetDropEvent(C$.createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA$I$I(target, t, name, data, x, y));
return;
}var top=jc.getTopLevelAncestor$();
offset=top.getLocationOnScreen$();
System.out.println$S("JSDnD drop for " + jc.getUIClassID$() + " offset " + x + " " + y + "  -" + offset );
top.dispatchEvent$java_awt_AWTEvent(Clazz_new_($I$(8,1).c$$java_awt_Component$I$I$I$java_awt_datatransfer_Transferable$S$BA,[jc, 502, x, y, t, name, data]));
}, 1);

Clazz_newMeth(C$, 'drop$javax_swing_JComponent$O$OAA$I$I',  function (jc, html5DataTransfer, data, x, y) {
if (html5DataTransfer == null ) return;
var t=Clazz_new_($I$(2,1).c$$OAA,[data]);
var target=jc.getDropTarget$();
System.out.println$S("JSDnD[] drop for " + jc.getUIClassID$() + " target " + (target == null  ? null : target.getClass$().getName$()) );
if (target != null ) {
target.drop$java_awt_dnd_DropTargetDropEvent(C$.createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$OAA$I$I(target, t, data, x, y));
return;
}var top=jc.getTopLevelAncestor$();
System.out.println$S("JSDnD drop for " + jc.getUIClassID$() + " offset " + x + " " + y );
top.dispatchEvent$java_awt_AWTEvent(Clazz_new_($I$(8,1).c$$java_awt_Component$I$I$I$java_awt_datatransfer_Transferable$S$BA,[jc, 502, x, y, t, null, null]));
t.files=null;
}, 1);

Clazz_newMeth(C$, 'createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$OAA$I$I',  function (target, t, data, x, y) {
var context=Clazz_new_($I$(9,1).c$$java_awt_dnd_DropTarget,[target]);
context.addNotify$java_awt_dnd_peer_DropTargetContextPeer(Clazz_new_($I$(10,1).c$$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA,[target, t, null, null]));
return Clazz_new_([context, Clazz_new_($I$(12,1).c$$I$I,[x, y]), 2, 1073741827],$I$(11,1).c$$java_awt_dnd_DropTargetContext$java_awt_Point$I$I);
}, 1);

Clazz_newMeth(C$, 'createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA$I$I',  function (target, t, name, data, x, y) {
var context=Clazz_new_($I$(9,1).c$$java_awt_dnd_DropTarget,[target]);
context.addNotify$java_awt_dnd_peer_DropTargetContextPeer(Clazz_new_($I$(10,1).c$$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA,[target, t, name, data]));
return Clazz_new_([context, Clazz_new_($I$(12,1).c$$I$I,[x, y]), 2, 1073741827],$I$(11,1).c$$java_awt_dnd_DropTargetContext$java_awt_Point$I$I);
}, 1);
;
(function(){/*c*/var C$=Clazz_newClass(P$.JSDnD, "JSDropMouseEvent", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, 'java.awt.event.MouseEvent', 'java.awt.ActiveEvent');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name'],'O',['transferable','java.awt.datatransfer.Transferable']]]

Clazz_newMeth(C$, 'c$$java_awt_Component$I$I$I$java_awt_datatransfer_Transferable$S$BA',  function (source, id, x, y, t, name, data) {
;C$.superclazz.c$$java_awt_Component$I$J$I$I$I$I$Z$I.apply(this,[source, id, System.currentTimeMillis$(), 0, x, y, 0, false, 0]);C$.$init$.apply(this);
this.transferable=t;
this.name=name;
if (name != null ) this.setBData$BA(data);
}, 1);

Clazz_newMeth(C$, 'c$$java_awt_Component$I$I$I',  function (target, id, x, y) {
C$.c$$java_awt_Component$I$I$I$java_awt_datatransfer_Transferable$S$BA.apply(this, [target, id, x, y, null, null, null]);
}, 1);

Clazz_newMeth(C$, 'copyPrivateDataInto$java_awt_AWTEvent',  function (that) {
var e=that;
e.transferable=this.transferable;
e.name=this.name;
e.bdata=this.bdata;
});

Clazz_newMeth(C$, 'dispatch$',  function () {
try {
var target=(this.getSource$()).getDropTarget$();
if (this.name == null ) target.drop$java_awt_dnd_DropTargetDropEvent($I$(1,"createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA$I$I",[target, this.transferable, null, null, this.getX$(), this.getY$()]));
 else target.drop$java_awt_dnd_DropTargetDropEvent($I$(1,"createDropEvent$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA$I$I",[target, this.transferable, this.name, this.getBData$(), this.getX$(), this.getY$()]));
} catch (e) {
System.out.println$S("JSDnD Error creating Drop event " + e);
}
});

Clazz_newMeth(C$, 'consume$',  function () {
C$.superclazz.prototype.consume$.apply(this, []);
});

Clazz_newMeth(C$, 'paramString$',  function () {
var typeStr=null;
switch (this.id) {
case 502:
typeStr="MOUSE_DROPPED";
break;
default:
return C$.superclazz.prototype.paramString$.apply(this, []);
}
return typeStr + ",(" + this.getX$() + "," + this.getY$() + ")" ;
});

Clazz_newMeth(C$, 'getDispatcher$',  function () {
return null;
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.JSDnD, "JSDropTargetContextPeer", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, null, 'java.awt.dnd.peer.DropTargetContextPeer');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['transferable','java.awt.datatransfer.Transferable','target','java.awt.dnd.DropTarget']]]

Clazz_newMeth(C$, 'c$$java_awt_dnd_DropTarget$java_awt_datatransfer_Transferable$S$BA',  function (target, t, name, data) {
;C$.$init$.apply(this);
this.target=target;
this.transferable=(name == null  ? t : Clazz_new_($I$(2,1).c$$S$BA,[name, data]));
}, 1);

Clazz_newMeth(C$, 'setTargetActions$I',  function (actions) {
});

Clazz_newMeth(C$, 'getTargetActions$',  function () {
return 3;
});

Clazz_newMeth(C$, 'getDropTarget$',  function () {
return this.target;
});

Clazz_newMeth(C$, 'getTransferDataFlavors$',  function () {
return this.transferable.getTransferDataFlavors$();
});

Clazz_newMeth(C$, 'getTransferable$',  function () {
return this.transferable;
});

Clazz_newMeth(C$, 'isTransferableJVMLocal$',  function () {
return true;
});

Clazz_newMeth(C$, 'acceptDrag$I',  function (dragAction) {
});

Clazz_newMeth(C$, 'rejectDrag$',  function () {
});

Clazz_newMeth(C$, 'acceptDrop$I',  function (dropAction) {
});

Clazz_newMeth(C$, 'rejectDrop$',  function () {
});

Clazz_newMeth(C$, 'dropComplete$Z',  function (success) {
});

Clazz_newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.JSDnD, "JSTransferable", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, null, 'java.awt.datatransfer.Transferable');

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['dataTransfer','swingjs.api.js.HTML5DataTransfer','mimeTypes','String[]','flavors','java.awt.datatransfer.DataFlavor[]']]]

Clazz_newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz_newMeth(C$, 'c$$O',  function (html5DataTransfer) {
;C$.$init$.apply(this);
this.set$O(html5DataTransfer);
}, 1);

Clazz_newMeth(C$, 'set$O',  function (html5DataTransfer) {
this.dataTransfer=html5DataTransfer;
this.mimeTypes=html5DataTransfer && html5DataTransfer.types ||null;
if (this.mimeTypes != null ) {
if (this.mimeTypes.length == 0) {
this.mimeTypes=Clazz_array(String, -1, ["application/x-java-file-list;class=java.util.List"]);
} else {
var t=Clazz_array(String, [this.mimeTypes.length]);
for (var i=0; i < this.mimeTypes.length; i++) t[i]=(this.mimeTypes[i].equals$O("Files") ? "application/x-java-file-list;class=java.util.List" : this.mimeTypes[i]);

this.mimeTypes=t;
}}return this;
});

Clazz_newMeth(C$, 'getTransferDataFlavors$',  function () {
return p$1.getFlavors.apply(this, []);
});

Clazz_newMeth(C$, 'getFlavors',  function () {
if (this.flavors == null ) {
this.flavors=Clazz_array($I$(3), [this.mimeTypes.length]);
for (var i=0; i < this.mimeTypes.length; i++) {
try {
this.flavors[i]=Clazz_new_($I$(3,1).c$$S,[this.mimeTypes[i]]);
} catch (e) {
if (Clazz_exceptionOf(e,"ClassNotFoundException")){
e.printStackTrace$();
} else {
throw e;
}
}
}
}return this.flavors;
}, p$1);

Clazz_newMeth(C$, 'isDataFlavorSupported$java_awt_datatransfer_DataFlavor',  function (flavor) {
var type=C$.fixType$S(flavor.getMimeType$());
var data=this.dataTransfer.getData(type);
return (data != null  && !data.equals$O("") );
});

Clazz_newMeth(C$, 'isDataFlavorSupported$S',  function (mimeType) {
var data=this.dataTransfer.getData(C$.fixType$S(mimeType));
return (data != null  && !data.equals$O("") );
});

Clazz_newMeth(C$, 'getTransferData$java_awt_datatransfer_DataFlavor',  function (flavor) {
var data=this.dataTransfer.getData(C$.fixType$S(flavor.getMimeType$()));
return (data == null  || data.equals$O("")  ? null : data);
});

Clazz_newMeth(C$, 'getTransferData$S',  function (mimeType) {
var data=this.dataTransfer.getData(C$.fixType$S(mimeType));
return (data == null  || data.equals$O("")  ? null : data);
});

Clazz_newMeth(C$, 'fixType$S',  function (s) {
var i=s.indexOf$S(";");
return (i < 0 ? s : s.substring$I$I(0, i)).trim$();
}, 1);
})()
;
(function(){/*c*/var C$=Clazz_newClass(P$.JSDnD, "FileTransferable", function(){
Clazz_newInstance(this, arguments[0],false,C$);
}, ['swingjs.JSDnD','.JSTransferable']);

C$.$clinit$=2;

Clazz_newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['files','java.util.List']]
,['S',['temp']]]

Clazz_newMeth(C$, 'c$$S$BA',  function (name, data) {
;C$.superclazz.c$$O.apply(this,[null]);C$.$init$.apply(this);
this.files=Clazz_new_($I$(4,1));
p$2.addFile$S$BA.apply(this, [name, data]);
}, 1);

Clazz_newMeth(C$, 'addFile$S$BA',  function (name, data) {
var file=Clazz_new_($I$(5,1).c$$S,[C$.temp + name]);
$I$(6).setFileBytesStatic$O$O(file, data);
this.files.add$O(file);
}, p$2);

Clazz_newMeth(C$, 'c$$OAA',  function (data) {
;C$.superclazz.c$$O.apply(this,[null]);C$.$init$.apply(this);
this.files=Clazz_new_($I$(4,1));
for (var i=0; i < data.length; i++) {
p$2.addFile$S$BA.apply(this, [data[i][0], data[i][1]]);
}
}, 1);

Clazz_newMeth(C$, 'getTransferDataFlavors$',  function () {
var flavors=Clazz_array($I$(3), [1]);
flavors[0]=$I$(3).javaFileListFlavor;
return flavors;
});

Clazz_newMeth(C$, 'isDataFlavorSupported$java_awt_datatransfer_DataFlavor',  function (flavor) {
return flavor.isFlavorJavaFileListType$();
});

Clazz_newMeth(C$, 'getTransferData$java_awt_datatransfer_DataFlavor',  function (flavor) {
var o=this.files;
return o;
});

C$.$static$=function(){C$.$static$=0;
C$.temp=System.getProperty$S("java.io.tmpdir");
};

Clazz_newMeth(C$);
})()

Clazz_newMeth(C$);
})();
;Clazz_setTVer('3.3.1-v6');//Created 2023-03-20 19:05:36 Java2ScriptVisitor version 3.3.1-v6 net.sf.j2s.core.jar version 3.3.1-v6
})(Clazz,Clazz.setTVer,Clazz.toLong,Clazz.incrAN,Clazz.array,Clazz.assert,Clazz.clone,Clazz.exceptionOf,Clazz.forName,Clazz.getClass,Clazz.instanceOf,Clazz.load,Clazz.new_,Clazz.newClass,Clazz.newEnumConst,Clazz.newInstance,Clazz.newInterface,Clazz.newMeth,Clazz.newPackage,Clazz.super_);
