(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),I$=[[0,'javax.vecmath.Vector3f','javax.media.j3d.Shape3D','com.sun.j3d.utils.geometry.GeomBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Box", null, 'com.sun.j3d.utils.geometry.Primitive');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.numTexUnit=1;
},1);

C$.$fields$=[['F',['xDim','yDim','zDim'],'I',['numTexUnit']]
,['O',['verts','float[]','tcoords','double[]','normals','javax.vecmath.Vector3f[]']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$F$F$F$I$javax_media_j3d_Appearance.apply(this, [1.0, 1.0, 1.0, 1, null]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$javax_media_j3d_Appearance',  function (xdim, ydim, zdim, ap) {
C$.c$$F$F$F$I$javax_media_j3d_Appearance.apply(this, [xdim, ydim, zdim, 1, ap]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$I$javax_media_j3d_Appearance$I',  function (xdim, ydim, zdim, primflags, ap, numTexUnit) {
Clazz.super_(C$, this);
var i;
var sign;
this.xDim=xdim;
this.yDim=ydim;
this.zDim=zdim;
this.flags=primflags;
this.numTexUnit=numTexUnit;
var texCoordYUp=(this.flags & 8) != 0;
if ((this.flags & 4) != 0) sign=-1.0;
 else sign=1.0;
var shape=Clazz.array($I$(2), [6]);
var cache=null;
for (i=0; i <= 5; i++) {
cache=this.getCachedGeometry$I$F$F$F$I$I$I(8, xdim, ydim, zdim, i, i, primflags);
if (cache != null ) {
shape[i]=Clazz.new_([cache.getComputedGeometry$()],$I$(2,1).c$$javax_media_j3d_Geometry);
this.numVerts+=cache.getNumVerts$();
this.numTris+=cache.getNumTris$();
} else {
var gbuf=Clazz.new_($I$(3,1).c$$I$I,[4, numTexUnit]);
gbuf.begin$I(1);
for (var j=0; j < 2; j++) {
gbuf.normal3d$D$D$D(C$.normals[i].x * sign, C$.normals[i].y * sign, C$.normals[i].z * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(C$.tcoords[i * 8 + j * 2], 1.0 - C$.tcoords[i * 8 + j * 2 + 1]);
} else {
gbuf.texCoord2d$D$D(C$.tcoords[i * 8 + j * 2], C$.tcoords[i * 8 + j * 2 + 1]);
}gbuf.vertex3d$D$D$D(C$.verts[i * 12 + j * 3] * xdim, C$.verts[i * 12 + j * 3 + 1] * ydim, C$.verts[i * 12 + j * 3 + 2] * zdim);
}
for (var j=3; j > 1; j--) {
gbuf.normal3d$D$D$D(C$.normals[i].x * sign, C$.normals[i].y * sign, C$.normals[i].z * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(C$.tcoords[i * 8 + j * 2], 1.0 - C$.tcoords[i * 8 + j * 2 + 1]);
} else {
gbuf.texCoord2d$D$D(C$.tcoords[i * 8 + j * 2], C$.tcoords[i * 8 + j * 2 + 1]);
}gbuf.vertex3d$D$D$D(C$.verts[i * 12 + j * 3] * xdim, C$.verts[i * 12 + j * 3 + 1] * ydim, C$.verts[i * 12 + j * 3 + 2] * zdim);
}
gbuf.end$();
shape[i]=Clazz.new_([gbuf.getGeom$I(this.flags)],$I$(2,1).c$$javax_media_j3d_Geometry);
this.numVerts=gbuf.getNumVerts$();
this.numTris=gbuf.getNumTris$();
if ((primflags & 16) == 0) {
this.cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer(8, xdim, ydim, zdim, i, i, primflags, gbuf);
}}if ((this.flags & 64) != 0) {
(shape[i]).setCapability$I(14);
(shape[i]).setCapability$I(15);
}if ((this.flags & 32) != 0) {
(shape[i]).setCapability$I(12);
}this.addChild$javax_media_j3d_Node(shape[i]);
}
if (ap == null ) {
this.setAppearance$();
} else this.setAppearance$javax_media_j3d_Appearance(ap);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$I$javax_media_j3d_Appearance',  function (xdim, ydim, zdim, primflags, ap) {
C$.c$$F$F$F$I$javax_media_j3d_Appearance$I.apply(this, [xdim, ydim, zdim, primflags, ap, 1]);
}, 1);

Clazz.newMeth(C$, 'getShape$I',  function (partId) {
if ((partId >= 0) && (partId <= 5) ) return this.getChild$I(partId);
return null;
});

Clazz.newMeth(C$, 'setAppearance$javax_media_j3d_Appearance',  function (ap) {
(this.getChild$I(4)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(3)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(2)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(0)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(1)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(5)).setAppearance$javax_media_j3d_Appearance(ap);
});

Clazz.newMeth(C$, 'getAppearance$I',  function (partId) {
if (partId > 5 || partId < 0 ) return null;
return this.getShape$I(partId).getAppearance$();
});

Clazz.newMeth(C$, 'cloneNode$Z',  function (forceDuplicate) {
var b=Clazz.new_(C$.c$$F$F$F$I$javax_media_j3d_Appearance,[this.xDim, this.yDim, this.zDim, this.flags, this.getAppearance$()]);
b.duplicateNode$javax_media_j3d_Node$Z(this, forceDuplicate);
return b;
});

Clazz.newMeth(C$, 'duplicateNode$javax_media_j3d_Node$Z',  function (originalNode, forceDuplicate) {
C$.superclazz.prototype.duplicateNode$javax_media_j3d_Node$Z.apply(this, [originalNode, forceDuplicate]);
});

Clazz.newMeth(C$, 'getXdimension$',  function () {
return this.xDim;
});

Clazz.newMeth(C$, 'getYdimension$',  function () {
return this.yDim;
});

Clazz.newMeth(C$, 'getZdimension$',  function () {
return this.zDim;
});

C$.$static$=function(){C$.$static$=0;
C$.verts=Clazz.array(Float.TYPE, -1, [1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0, -1.0, -1.0, -1.0, -1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0, 1.0, -1.0, -1.0, -1.0, 1.0, -1.0, -1.0, 1.0, -1.0, 1.0]);
C$.tcoords=Clazz.array(Double.TYPE, -1, [1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0]);
C$.normals=Clazz.array($I$(1), -1, [Clazz.new_($I$(1,1).c$$F$F$F,[0.0, 0.0, 1.0]), Clazz.new_($I$(1,1).c$$F$F$F,[0.0, 0.0, -1.0]), Clazz.new_($I$(1,1).c$$F$F$F,[1.0, 0.0, 0.0]), Clazz.new_($I$(1,1).c$$F$F$F,[-1.0, 0.0, 0.0]), Clazz.new_($I$(1,1).c$$F$F$F,[0.0, 1.0, 0.0]), Clazz.new_($I$(1,1).c$$F$F$F,[0.0, -1.0, 0.0])]);
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
