(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),I$=[[0,'javax.media.j3d.Shape3D','com.sun.j3d.utils.geometry.GeomBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Sphere", null, 'com.sun.j3d.utils.geometry.Primitive');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['radius'],'I',['divisions']]]

Clazz.newMeth(C$, 'c$$F',  function (radius) {
C$.c$$F$I$I.apply(this, [radius, 1, 16]);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$F$I$I.apply(this, [1.0, 1, 16]);
}, 1);

Clazz.newMeth(C$, 'c$$F$javax_media_j3d_Appearance',  function (radius, ap) {
C$.c$$F$I$I$javax_media_j3d_Appearance.apply(this, [radius, 1, 16, ap]);
}, 1);

Clazz.newMeth(C$, 'c$$F$I$javax_media_j3d_Appearance',  function (radius, primflags, ap) {
C$.c$$F$I$I$javax_media_j3d_Appearance.apply(this, [radius, primflags, 16, ap]);
}, 1);

Clazz.newMeth(C$, 'c$$F$I$I',  function (radius, primflags, divisions) {
C$.c$$F$I$I$javax_media_j3d_Appearance.apply(this, [radius, primflags, divisions, null]);
}, 1);

Clazz.newMeth(C$, 'getShape$I',  function (partId) {
if (partId != 0) return null;
return this.getChild$I(0);
});

Clazz.newMeth(C$, 'getShape$',  function () {
return this.getChild$I(0);
});

Clazz.newMeth(C$, 'setAppearance$javax_media_j3d_Appearance',  function (ap) {
(this.getChild$I(0)).setAppearance$javax_media_j3d_Appearance(ap);
});

Clazz.newMeth(C$, 'getAppearance$I',  function (partId) {
if (partId != 0) return null;
return this.getShape$I(partId).getAppearance$();
});

Clazz.newMeth(C$, 'c$$F$I$I$javax_media_j3d_Appearance',  function (radius, primflags, divisions, ap) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var sign;
var n;
var nstep;
this.radius=radius;
this.divisions=divisions;
this.flags=primflags;
var texCoordYUp=(this.flags & 8) != 0;
if ((this.flags & 4) != 0) {
sign=-1;
} else {
sign=1;
}if (divisions < 4) {
nstep=1;
n=4;
} else {
var mod=divisions % 4;
if (mod == 0) {
n=divisions;
} else {
n=divisions + (4 - mod);
}nstep=(n/4|0);
}var cache=this.getCachedGeometry$I$F$F$F$I$I$I(1, radius, 0.0, 0.0, divisions, 0, primflags);
var shape;
if (cache != null ) {
shape=Clazz.new_([cache.getComputedGeometry$()],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts+=cache.getNumVerts$();
this.numTris+=cache.getNumTris$();
} else {
var gbuf=Clazz.new_([8 * nstep * (nstep + 2) ],$I$(2,1).c$$I);
for (var i=0; i < 4; i++) {
this.buildQuadrant$com_sun_j3d_utils_geometry_GeomBuffer$D$D$I$I$I$Z(gbuf, i * 3.141592653589793 / 2, (i + 1) * 3.141592653589793 / 2, sign, nstep, n, true);
this.buildQuadrant$com_sun_j3d_utils_geometry_GeomBuffer$D$D$I$I$I$Z(gbuf, i * 3.141592653589793 / 2, (i + 1) * 3.141592653589793 / 2, sign, nstep, n, false);
}
if (texCoordYUp) {
var texCoords=gbuf.getTexCoords$();
if (texCoords != null ) {
for (var ii=0; ii < texCoords.length; ii++) {
texCoords[ii].y=1.0 - texCoords[ii].y;
}
}}shape=Clazz.new_([gbuf.getGeom$I(this.flags)],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts=gbuf.getNumVerts$();
this.numTris=gbuf.getNumTris$();
if ((primflags & 16) == 0) {
this.cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer(1, radius, 0.0, 0.0, divisions, 0, primflags, gbuf);
}}if ((this.flags & 64) != 0) {
shape.setCapability$I(14);
shape.setCapability$I(15);
}if ((this.flags & 32) != 0) {
shape.setCapability$I(12);
}this.addChild$javax_media_j3d_Node(shape);
if (ap == null ) {
this.setAppearance$();
} else this.setAppearance$javax_media_j3d_Appearance(ap);
}, 1);

Clazz.newMeth(C$, 'cloneNode$Z',  function (forceDuplicate) {
var s=Clazz.new_(C$.c$$F$I$I$javax_media_j3d_Appearance,[this.radius, this.flags, this.divisions, this.getAppearance$()]);
s.duplicateNode$javax_media_j3d_Node$Z(this, forceDuplicate);
return s;
});

Clazz.newMeth(C$, 'duplicateNode$javax_media_j3d_Node$Z',  function (originalNode, forceDuplicate) {
C$.superclazz.prototype.duplicateNode$javax_media_j3d_Node$Z.apply(this, [originalNode, forceDuplicate]);
});

Clazz.newMeth(C$, 'getRadius$',  function () {
return this.radius;
});

Clazz.newMeth(C$, 'getDivisions$',  function () {
return this.divisions;
});

Clazz.newMeth(C$, 'buildQuadrant$com_sun_j3d_utils_geometry_GeomBuffer$D$D$I$I$I$Z',  function (gbuf, startDelta, endDelta, sign, nstep, n, upperSphere) {
var ds;
var dt;
var theta;
var delta;
var i;
var j;
var index;
var i2;
var h;
var r;
var vx;
var vz;
var pt;
var norm;
var texCoord;
var starth;
var t;
var leftToRight;
if (upperSphere) {
dt=3.141592653589793 / (2 * nstep);
theta=dt;
starth=1;
leftToRight=(sign > 0);
} else {
dt=-3.141592653589793 / (2 * nstep);
theta=3.141592653589793 + dt;
starth=-1;
leftToRight=(sign < 0);
}for (i=1; i <= nstep; i++) {
h=Math.cos(theta);
r=Math.sin(theta);
if (sign > 0) {
t=1 - theta / 3.141592653589793;
} else {
t=theta / 3.141592653589793;
}i2=i << 1;
ds=(endDelta - startDelta) / i;
gbuf.begin$I(32);
if (leftToRight) {
delta=startDelta;
for (j=0; j < i; j++) {
vx=r * Math.cos(delta);
vz=r * Math.sin(delta);
gbuf.normal3d$D$D$D(vx * sign, h * sign, vz * sign);
gbuf.texCoord2d$D$D(0.75 - delta / (6.283185307179586), t);
gbuf.vertex3d$D$D$D(vx * this.radius, h * this.radius, vz * this.radius);
if (i > 1) {
index=gbuf.currVertCnt - i2;
pt=gbuf.pts[index];
norm=gbuf.normals[index];
texCoord=gbuf.tcoords[index];
gbuf.normal3d$D$D$D(norm.x, norm.y, norm.z);
gbuf.texCoord2d$D$D(texCoord.x, texCoord.y);
gbuf.vertex3d$D$D$D(pt.x, pt.y, pt.z);
} else {
gbuf.normal3d$D$D$D(0, sign * starth, 0);
if (sign > 0) {
gbuf.texCoord2d$D$D(0.75 - (startDelta + endDelta) / (12.566370614359172), 1.0 - (theta - dt) / 3.141592653589793);
} else {
gbuf.texCoord2d$D$D(0.75 - (startDelta + endDelta) / (12.566370614359172), (theta - dt) / 3.141592653589793);
}gbuf.vertex3d$D$D$D(0, starth * this.radius, 0);
}delta+=ds;
}
delta=endDelta;
vx=r * Math.cos(delta);
vz=r * Math.sin(delta);
gbuf.normal3d$D$D$D(vx * sign, h * sign, vz * sign);
gbuf.texCoord2d$D$D(0.75 - delta / (6.283185307179586), t);
gbuf.vertex3d$D$D$D(vx * this.radius, h * this.radius, vz * this.radius);
} else {
delta=endDelta;
for (j=i; j > 0; j--) {
vx=r * Math.cos(delta);
vz=r * Math.sin(delta);
gbuf.normal3d$D$D$D(vx * sign, h * sign, vz * sign);
gbuf.texCoord2d$D$D(0.75 - delta / (6.283185307179586), t);
gbuf.vertex3d$D$D$D(vx * this.radius, h * this.radius, vz * this.radius);
if (i > 1) {
index=gbuf.currVertCnt - i2;
pt=gbuf.pts[index];
norm=gbuf.normals[index];
texCoord=gbuf.tcoords[index];
gbuf.normal3d$D$D$D(norm.x, norm.y, norm.z);
gbuf.texCoord2d$D$D(texCoord.x, texCoord.y);
gbuf.vertex3d$D$D$D(pt.x, pt.y, pt.z);
} else {
gbuf.normal3d$D$D$D(0, sign * starth, 0);
if (sign > 0) {
gbuf.texCoord2d$D$D(0.75 - (startDelta + endDelta) / (12.566370614359172), 1.0 - (theta - dt) / 3.141592653589793);
} else {
gbuf.texCoord2d$D$D(0.75 - (startDelta + endDelta) / (12.566370614359172), (theta - dt) / 3.141592653589793);
}gbuf.vertex3d$D$D$D(0, starth * this.radius, 0);
}delta-=ds;
}
delta=startDelta;
vx=r * Math.cos(delta);
vz=r * Math.sin(delta);
gbuf.normal3d$D$D$D(vx * sign, h * sign, vz * sign);
gbuf.texCoord2d$D$D(0.75 - delta / (6.283185307179586), t);
gbuf.vertex3d$D$D$D(vx * this.radius, h * this.radius, vz * this.radius);
}gbuf.end$();
if (i < nstep) {
theta+=dt;
} else {
theta=1.5707963267948966;
}}
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
