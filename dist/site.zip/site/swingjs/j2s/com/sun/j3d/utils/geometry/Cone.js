(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),I$=[[0,'javax.media.j3d.Shape3D','com.sun.j3d.utils.geometry.Quadrics']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Cone", null, 'com.sun.j3d.utils.geometry.Primitive');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['radius','height'],'I',['xdivisions','ydivisions']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$F$F$I$I$I$javax_media_j3d_Appearance.apply(this, [1.0, 2.0, 1, 15, 1, null]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F',  function (radius, height) {
C$.c$$F$F$I$I$I$javax_media_j3d_Appearance.apply(this, [radius, height, 1, 15, 1, null]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$javax_media_j3d_Appearance',  function (radius, height, ap) {
C$.c$$F$F$I$I$I$javax_media_j3d_Appearance.apply(this, [radius, height, 1, 15, 1, ap]);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$I$javax_media_j3d_Appearance',  function (radius, height, primflags, ap) {
C$.c$$F$F$I$I$I$javax_media_j3d_Appearance.apply(this, [radius, height, primflags, 15, 1, ap]);
}, 1);

Clazz.newMeth(C$, 'getShape$I',  function (partId) {
if (partId > 1 || partId < 0 ) return null;
return this.getChild$I(partId);
});

Clazz.newMeth(C$, 'setAppearance$javax_media_j3d_Appearance',  function (ap) {
(this.getChild$I(0)).setAppearance$javax_media_j3d_Appearance(ap);
(this.getChild$I(1)).setAppearance$javax_media_j3d_Appearance(ap);
});

Clazz.newMeth(C$, 'getAppearance$I',  function (partId) {
if (partId > 1 || partId < 0 ) return null;
return this.getShape$I(partId).getAppearance$();
});

Clazz.newMeth(C$, 'c$$F$F$I$I$I$javax_media_j3d_Appearance',  function (radius, height, primflags, xdivision, ydivision, ap) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
var shape=Clazz.array($I$(1), [2]);
this.radius=radius;
this.height=height;
this.xdivisions=xdivision;
this.ydivisions=ydivision;
this.flags=primflags;
var outside=(this.flags & 4) == 0;
var texCoordYUp=(this.flags & 8) != 0;
var q=Clazz.new_($I$(2,1));
var gbuf=null;
var cache=this.getCachedGeometry$I$F$F$F$I$I$I(4, radius, 0.0, height, xdivision, ydivision, primflags);
if (cache != null ) {
shape[0]=Clazz.new_([cache.getComputedGeometry$()],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts+=cache.getNumVerts$();
this.numTris+=cache.getNumTris$();
} else {
gbuf=q.coneTop$D$D$D$I$D$Z$Z((height / 2.0 - height / this.ydivisions), (radius / this.ydivisions), height / this.ydivisions, this.xdivisions, 1.0 - 1.0 / this.ydivisions, outside, texCoordYUp);
shape[0]=Clazz.new_([gbuf.getGeom$I(this.flags)],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts+=gbuf.getNumVerts$();
this.numTris+=gbuf.getNumTris$();
if ((primflags & 16) == 0) {
this.cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer(4, radius, 0.0, height, xdivision, ydivision, primflags, gbuf);
}}if (this.ydivisions > 1) {
cache=this.getCachedGeometry$I$F$F$F$I$I$I(64, radius, 0.0, height, xdivision, ydivision, primflags);
if (cache != null ) {
shape[0].addGeometry$javax_media_j3d_Geometry(cache.getComputedGeometry$());
this.numVerts+=cache.getNumVerts$();
this.numTris+=cache.getNumTris$();
} else {
gbuf=q.coneBody$D$D$D$D$I$I$D$Z$Z(-(height / 2.0), (height / 2.0 - height / this.ydivisions), radius, (radius / this.ydivisions), this.xdivisions, this.ydivisions - 1, 1.0 / this.ydivisions, outside, texCoordYUp);
shape[0].addGeometry$javax_media_j3d_Geometry(gbuf.getGeom$I(this.flags));
this.numVerts+=gbuf.getNumVerts$();
this.numTris+=gbuf.getNumTris$();
if ((primflags & 16) == 0) {
this.cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer(64, radius, 0.0, height, xdivision, ydivision, primflags, gbuf);
}}}if ((this.flags & 64) != 0) {
(shape[0]).setCapability$I(14);
(shape[0]).setCapability$I(15);
}if ((this.flags & 32) != 0) {
(shape[0]).setCapability$I(12);
}this.addChild$javax_media_j3d_Node(shape[0]);
cache=this.getCachedGeometry$I$F$F$F$I$I$I(32, radius, radius, -height / 2.0, xdivision, xdivision, primflags);
if (cache != null ) {
shape[1]=Clazz.new_([cache.getComputedGeometry$()],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts+=cache.getNumVerts$();
this.numTris+=cache.getNumTris$();
} else {
gbuf=q.disk$D$I$D$Z$Z(radius, xdivision, -height / 2.0, !outside, texCoordYUp);
shape[1]=Clazz.new_([gbuf.getGeom$I(this.flags)],$I$(1,1).c$$javax_media_j3d_Geometry);
this.numVerts+=gbuf.getNumVerts$();
this.numTris+=gbuf.getNumTris$();
if ((primflags & 16) == 0) {
this.cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer(32, radius, radius, -height / 2.0, xdivision, xdivision, primflags, gbuf);
}}if ((this.flags & 64) != 0) {
(shape[1]).setCapability$I(14);
(shape[1]).setCapability$I(15);
}if ((this.flags & 32) != 0) {
(shape[1]).setCapability$I(12);
}this.addChild$javax_media_j3d_Node(shape[1]);
if (ap == null ) {
this.setAppearance$();
} else this.setAppearance$javax_media_j3d_Appearance(ap);
}, 1);

Clazz.newMeth(C$, 'cloneNode$Z',  function (forceDuplicate) {
var c=Clazz.new_(C$.c$$F$F$I$I$I$javax_media_j3d_Appearance,[this.radius, this.height, this.flags, this.xdivisions, this.ydivisions, this.getAppearance$()]);
c.duplicateNode$javax_media_j3d_Node$Z(this, forceDuplicate);
return c;
});

Clazz.newMeth(C$, 'duplicateNode$javax_media_j3d_Node$Z',  function (originalNode, forceDuplicate) {
C$.superclazz.prototype.duplicateNode$javax_media_j3d_Node$Z.apply(this, [originalNode, forceDuplicate]);
});

Clazz.newMeth(C$, 'getRadius$',  function () {
return this.radius;
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.height;
});

Clazz.newMeth(C$, 'getXdivisions$',  function () {
return this.xdivisions;
});

Clazz.newMeth(C$, 'getYdivisions$',  function () {
return this.ydivisions;
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
