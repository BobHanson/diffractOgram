(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),p$1={},I$=[[0,'javax.vecmath.Point3f','javax.vecmath.Vector3f','javax.vecmath.TexCoord2f','javax.media.j3d.TriangleStripArray','javax.media.j3d.QuadArray','javax.media.j3d.TriangleArray','javax.media.j3d.TriangleFanArray']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GeomBuffer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.pts=null;
this.normals=null;
this.tcoords=null;
this.currPrimType=null;
this.currPrimStartVertex=null;
this.currPrimEndVertex=null;
this.numVerts=0;
this.numTris=0;
this.numTexUnit=1;
this.texCoordSetMap=(null|0);
},1);

C$.$fields$=[['I',['flags','currVertCnt','currPrimCnt','numVerts','numTris','numTexUnit'],'O',['pts','javax.vecmath.Point3f[]','normals','javax.vecmath.Vector3f[]','tcoords','javax.vecmath.TexCoord2f[]','currPrimType','int[]','+currPrimStartVertex','+currPrimEndVertex','geometry','javax.media.j3d.GeometryArray','texCoordSetMap','int[]']]]

Clazz.newMeth(C$, 'c$$I$I',  function (numVerts, numTexUnit) {
;C$.$init$.apply(this);
this.numTexUnit=numTexUnit;
this.pts=Clazz.array($I$(1), [numVerts]);
this.normals=Clazz.array($I$(2), [numVerts]);
this.tcoords=Clazz.array($I$(3), [numVerts]);
this.currPrimType=Clazz.array(Integer.TYPE, [(numVerts/3|0)]);
this.currPrimStartVertex=Clazz.array(Integer.TYPE, [(numVerts/3|0)]);
this.currPrimEndVertex=Clazz.array(Integer.TYPE, [(numVerts/3|0)]);
this.currVertCnt=0;
this.currPrimCnt=0;
this.texCoordSetMap=Clazz.array(Integer.TYPE, [numTexUnit]);
for (var i=0; i < numTexUnit; i++) this.texCoordSetMap[i]=0;

}, 1);

Clazz.newMeth(C$, 'c$$I',  function (numVerts) {
C$.c$$I$I.apply(this, [numVerts, 1]);
}, 1);

Clazz.newMeth(C$, 'getGeom$I',  function (format) {
var obj=null;
this.flags=format;
this.numTris=0;
switch (this.currPrimType[0]) {
case 2:
obj=p$1.processTriangles.apply(this, []);
break;
case 4:
obj=p$1.processQuads.apply(this, []);
break;
case 1:
case 32:
obj=p$1.processQuadStrips.apply(this, []);
break;
case 16:
obj=p$1.processTriangleFan.apply(this, []);
break;
}
if ((obj != null ) && ((this.flags & 32) != 0) ) {
obj.setCapability$I(18);
obj.setCapability$I(17);
obj.setCapability$I(8);
obj.setCapability$I(0);
}return obj;
});

Clazz.newMeth(C$, 'begin$I',  function (prim) {
if (false) System.out.println$S("quad");
this.currPrimType[this.currPrimCnt]=prim;
this.currPrimStartVertex[this.currPrimCnt]=this.currVertCnt;
});

Clazz.newMeth(C$, 'end$',  function () {
if (false) System.out.println$S("end");
this.currPrimEndVertex[this.currPrimCnt]=this.currVertCnt;
++this.currPrimCnt;
});

Clazz.newMeth(C$, 'vertex3d$D$D$D',  function (x, y, z) {
if (false) System.out.println$S("v " + new Double(x).toString() + " " + new Double(y).toString() + " " + new Double(z).toString() );
this.pts[this.currVertCnt]=Clazz.new_($I$(1,1).c$$F$F$F,[x, y, z]);
++this.currVertCnt;
});

Clazz.newMeth(C$, 'normal3d$D$D$D',  function (x, y, z) {
if (false) System.out.println$S("n " + new Double(x).toString() + " " + new Double(y).toString() + " " + new Double(z).toString() );
var sum=x * x + y * y + z * z;
if (Math.abs(sum - 1.0) > 0.001 ) {
if (false) System.out.println$S("normalizing");
var root=Math.sqrt(sum);
if (root > 1.0E-6 ) {
x/=root;
y/=root;
z/=root;
} else {
y=z=0.0;
x=1.0;
}}this.normals[this.currVertCnt]=Clazz.new_($I$(2,1).c$$F$F$F,[x, y, z]);
});

Clazz.newMeth(C$, 'texCoord2d$D$D',  function (s, t) {
if (false) System.out.println$S("t " + new Double(s).toString() + " " + new Double(t).toString() );
this.tcoords[this.currVertCnt]=Clazz.new_($I$(3,1).c$$F$F,[s, t]);
});

Clazz.newMeth(C$, 'getTexCoords$',  function () {
return this.tcoords;
});

Clazz.newMeth(C$, 'getComputedGeometry$',  function () {
return this.geometry;
});

Clazz.newMeth(C$, 'getNumTris$',  function () {
return this.numTris;
});

Clazz.newMeth(C$, 'getNumVerts$',  function () {
return this.numVerts;
});

Clazz.newMeth(C$, 'processQuadStrips',  function () {
var obj=null;
var i;
var totalVerts=0;
var stripCounts=Clazz.array(Integer.TYPE, [this.currPrimCnt]);
for (i=0; i < this.currPrimCnt; i++) {
stripCounts[i]=this.currPrimEndVertex[i] - this.currPrimStartVertex[i];
totalVerts+=stripCounts[i];
}
if (false) System.out.println$S("totalVerts " + totalVerts);
var tsaFlags=1;
if ((this.flags & 1) != 0) tsaFlags|=2;
if ((this.flags & 2) != 0) tsaFlags|=32;
obj=Clazz.new_($I$(4,1).c$$I$I$I$IA$IA,[totalVerts, tsaFlags, 1, this.texCoordSetMap, stripCounts]);
var newpts=Clazz.array($I$(1), [totalVerts]);
var newnormals=Clazz.array($I$(2), [totalVerts]);
var newtcoords=Clazz.array($I$(3), [totalVerts]);
var currVert=0;
for (i=0; i < this.currPrimCnt; i++) {
for (var j=this.currPrimStartVertex[i]; j < this.currPrimEndVertex[i]; j++) {
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j);
}
}
this.numVerts=currVert;
this.numTris+=totalVerts - this.currPrimCnt * 2;
obj.setCoordinates$I$javax_vecmath_Point3fA(0, newpts);
if ((this.flags & 1) != 0) obj.setNormals$I$javax_vecmath_Vector3fA(0, newnormals);
if ((this.flags & 2) != 0) obj.setTextureCoordinates$I$I$javax_vecmath_TexCoord2fA(0, 0, newtcoords);
this.geometry=obj;
return obj;
}, p$1);

Clazz.newMeth(C$, 'processQuads',  function () {
var obj=null;
var i;
var totalVerts=0;
for (i=0; i < this.currPrimCnt; i++) {
totalVerts+=this.currPrimEndVertex[i] - this.currPrimStartVertex[i];
}
if (false) System.out.println$S("totalVerts " + totalVerts);
if (((this.flags & 1) != 0) && ((this.flags & 2) != 0) ) {
obj=Clazz.new_($I$(5,1).c$$I$I$I$IA,[totalVerts, 35, 1, this.texCoordSetMap]);
} else if (((this.flags & 1) == 0) && ((this.flags & 2) != 0) ) {
obj=Clazz.new_($I$(5,1).c$$I$I$I$IA,[totalVerts, 33, 1, this.texCoordSetMap]);
} else if (((this.flags & 1) != 0) && ((this.flags & 2) == 0) ) {
obj=Clazz.new_($I$(5,1).c$$I$I,[totalVerts, 3]);
} else {
obj=Clazz.new_($I$(5,1).c$$I$I,[totalVerts, 1]);
}var newpts=Clazz.array($I$(1), [totalVerts]);
var newnormals=Clazz.array($I$(2), [totalVerts]);
var newtcoords=Clazz.array($I$(3), [totalVerts]);
var currVert=0;
if (false) System.out.println$S("total prims " + this.currPrimCnt);
for (i=0; i < this.currPrimCnt; i++) {
if (false) System.out.println$S("start " + this.currPrimStartVertex[i] + " end " + this.currPrimEndVertex[i] );
for (var j=this.currPrimStartVertex[i]; j < this.currPrimEndVertex[i] - 3; j+=4) {
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j);
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j + 1);
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j + 2);
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j + 3);
this.numTris+=2;
}
}
this.numVerts=currVert;
obj.setCoordinates$I$javax_vecmath_Point3fA(0, newpts);
if ((this.flags & 1) != 0) obj.setNormals$I$javax_vecmath_Vector3fA(0, newnormals);
if ((this.flags & 2) != 0) obj.setTextureCoordinates$I$I$javax_vecmath_TexCoord2fA(0, 0, newtcoords);
this.geometry=obj;
return obj;
}, p$1);

Clazz.newMeth(C$, 'processTriangles',  function () {
var obj=null;
var i;
var totalVerts=0;
for (i=0; i < this.currPrimCnt; i++) {
totalVerts+=this.currPrimEndVertex[i] - this.currPrimStartVertex[i];
}
if (false) System.out.println$S("totalVerts " + totalVerts);
if (((this.flags & 1) != 0) && ((this.flags & 2) != 0) ) {
obj=Clazz.new_($I$(6,1).c$$I$I$I$IA,[totalVerts, 35, 1, this.texCoordSetMap]);
} else if (((this.flags & 1) == 0) && ((this.flags & 2) != 0) ) {
obj=Clazz.new_($I$(6,1).c$$I$I$I$IA,[totalVerts, 33, 1, this.texCoordSetMap]);
} else if (((this.flags & 1) != 0) && ((this.flags & 2) == 0) ) {
obj=Clazz.new_($I$(6,1).c$$I$I,[totalVerts, 3]);
} else {
obj=Clazz.new_($I$(6,1).c$$I$I,[totalVerts, 1]);
}var newpts=Clazz.array($I$(1), [totalVerts]);
var newnormals=Clazz.array($I$(2), [totalVerts]);
var newtcoords=Clazz.array($I$(3), [totalVerts]);
var currVert=0;
for (i=0; i < this.currPrimCnt; i++) {
for (var j=this.currPrimStartVertex[i]; j < this.currPrimEndVertex[i] - 2; j+=3) {
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j);
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j + 1);
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j + 2);
this.numTris+=1;
}
}
this.numVerts=currVert;
obj.setCoordinates$I$javax_vecmath_Point3fA(0, newpts);
if ((this.flags & 1) != 0) obj.setNormals$I$javax_vecmath_Vector3fA(0, newnormals);
if ((this.flags & 2) != 0) obj.setTextureCoordinates$I$I$javax_vecmath_TexCoord2fA(0, 0, newtcoords);
this.geometry=obj;
return obj;
}, p$1);

Clazz.newMeth(C$, 'processTriangleFan',  function () {
if (false) System.out.println$S("processTriangleFan");
var obj=null;
var i;
var totalVerts=0;
var stripCounts=Clazz.array(Integer.TYPE, [this.currPrimCnt]);
for (i=0; i < this.currPrimCnt; i++) {
stripCounts[i]=this.currPrimEndVertex[i] - this.currPrimStartVertex[i];
totalVerts+=stripCounts[i];
}
var tfFlags=1;
if ((this.flags & 1) != 0) {
tfFlags|=2;
}if ((this.flags & 2) != 0) {
tfFlags|=32;
}obj=Clazz.new_($I$(7,1).c$$I$I$I$IA$IA,[totalVerts, tfFlags, 1, this.texCoordSetMap, stripCounts]);
var newpts=Clazz.array($I$(1), [totalVerts]);
var newnormals=Clazz.array($I$(2), [totalVerts]);
var newtcoords=Clazz.array($I$(3), [totalVerts]);
var currVert=0;
for (i=0; i < this.currPrimCnt; i++) {
for (var j=this.currPrimStartVertex[i]; j < this.currPrimEndVertex[i]; j++) {
this.outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I(newpts, newnormals, newtcoords, currVert++, this.pts, this.normals, this.tcoords, j);
}
}
for (i=0; i < newpts.length; i++) {
if (false) System.out.println$S("i = " + i + " " + newpts[i] );
}
this.numVerts=currVert;
this.numTris=totalVerts - this.currPrimCnt * 2;
obj.setCoordinates$I$javax_vecmath_Point3fA(0, newpts);
if ((this.flags & 1) != 0) {
obj.setNormals$I$javax_vecmath_Vector3fA(0, newnormals);
}if ((this.flags & 2) != 0) {
obj.setTextureCoordinates$I$I$javax_vecmath_TexCoord2fA(0, 0, newtcoords);
}this.geometry=obj;
return obj;
}, p$1);

Clazz.newMeth(C$, 'outVertex$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I$javax_vecmath_Point3fA$javax_vecmath_Vector3fA$javax_vecmath_TexCoord2fA$I',  function (dpts, dnormals, dtcoords, dloc, spts, snormals, stcoords, sloc) {
if (false) System.out.println$S("v " + new Float(spts[sloc].x).toString() + " " + new Float(spts[sloc].y).toString() + " " + new Float(spts[sloc].z).toString() );
dpts[dloc]=Clazz.new_($I$(1,1).c$$javax_vecmath_Point3f,[spts[sloc]]);
if ((this.flags & 1) != 0) {
dnormals[dloc]=Clazz.new_($I$(2,1).c$$javax_vecmath_Vector3f,[snormals[sloc]]);
}if ((this.flags & 2) != 0) {
if (false) System.out.println$S("final out tcoord");
dtcoords[dloc]=Clazz.new_($I$(3,1).c$$javax_vecmath_TexCoord2f,[stcoords[sloc]]);
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
