(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),I$=[[0,'com.sun.j3d.utils.geometry.GeomBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Quadrics");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'disk$D$I$D$Z$Z',  function (r, xdiv, y, outside, texCoordYUp) {
var theta;
var dtheta;
var sign;
var sinTheta;
var cosTheta;
if (outside) sign=1.0;
 else sign=-1.0;
dtheta=6.283185307179586 / xdiv;
var gbuf=Clazz.new_($I$(1,1).c$$I,[xdiv + 2]);
gbuf.begin$I(16);
gbuf.normal3d$D$D$D(0.0, 1.0 * sign, 0.0);
gbuf.texCoord2d$D$D(0.5, 0.5);
gbuf.vertex3d$D$D$D(0.0, y, 0.0);
if (!outside) {
for (var i=0; i <= xdiv; i++) {
theta=i * dtheta;
sinTheta=Math.sin(theta - 1.5707963267948966);
cosTheta=Math.cos(theta - 1.5707963267948966);
gbuf.normal3d$D$D$D(0.0, 1.0 * sign, 0.0);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(0.5 + cosTheta * 0.5, 1.0 - (0.5 + sinTheta * 0.5));
} else {
gbuf.texCoord2d$D$D(0.5 + cosTheta * 0.5, 0.5 + sinTheta * 0.5);
}gbuf.vertex3d$D$D$D(r * cosTheta, y, r * sinTheta);
}
} else {
for (var i=xdiv; i >= 0; i--) {
theta=i * dtheta;
sinTheta=Math.sin(theta - 1.5707963267948966);
cosTheta=Math.cos(theta - 1.5707963267948966);
gbuf.normal3d$D$D$D(0.0, 1.0 * sign, 0.0);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(0.5 + cosTheta * 0.5, 1.0 - (0.5 - sinTheta * 0.5));
} else {
gbuf.texCoord2d$D$D(0.5 + cosTheta * 0.5, 0.5 - sinTheta * 0.5);
}gbuf.vertex3d$D$D$D(cosTheta * r, y, sinTheta * r);
}
}gbuf.end$();
return gbuf;
});

Clazz.newMeth(C$, 'cylinder$D$D$I$I$Z$Z',  function (height, radius, xdiv, ydiv, outside, texCoordYUp) {
var sign;
if (outside) sign=1.0;
 else sign=-1.0;
var dtheta=6.283185307179586 / xdiv;
var dy=height / ydiv;
var du=1.0 / xdiv;
var dv=1.0 / ydiv;
var gbuf=Clazz.new_([ydiv * 2 * (xdiv + 1) ],$I$(1,1).c$$I);
var s=0.0;
var t=0.0;
var px;
var pz;
var qx;
var qz;
var py=-height / 2.0;
var qy;
gbuf.begin$I(1);
for (var i=0; i < ydiv; i++) {
qy=py + dy;
if (outside) {
px=Math.cos(xdiv * dtheta - 1.5707963267948966);
pz=Math.sin(xdiv * dtheta - 1.5707963267948966);
qx=Math.cos((xdiv - 1) * dtheta - 1.5707963267948966);
qz=Math.sin((xdiv - 1) * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * radius, qy, pz * radius);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, py, pz * radius);
gbuf.normal3d$D$D$D(qx * sign, 0.0, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s + du, t + dv);
}gbuf.vertex3d$D$D$D(qx * radius, qy, qz * radius);
gbuf.normal3d$D$D$D(qx * sign, 0.0, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s + du, t);
}gbuf.vertex3d$D$D$D(qx * radius, py, qz * radius);
s+=(du * 2.0);
for (var j=xdiv - 2; j >= 0; j--) {
px=Math.cos(j * dtheta - 1.5707963267948966);
pz=Math.sin(j * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * radius, qy, pz * radius);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, py, pz * radius);
s+=du;
}
} else {
px=Math.cos(-1.5707963267948966);
pz=Math.sin(-1.5707963267948966);
qx=Math.cos(dtheta - 1.5707963267948966);
qz=Math.sin(dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * radius, qy, pz * radius);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, py, pz * radius);
gbuf.normal3d$D$D$D(qx * sign, 0.0, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s + du, t + dv);
}gbuf.vertex3d$D$D$D(qx * radius, qy, qz * radius);
gbuf.normal3d$D$D$D(qx * sign, 0.0, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s + du, t);
}gbuf.vertex3d$D$D$D(qx * radius, py, qz * radius);
s+=(du * 2.0);
for (var j=2; j <= xdiv; j++) {
px=Math.cos(j * dtheta - 1.5707963267948966);
pz=Math.sin(j * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * radius, qy, pz * radius);
gbuf.normal3d$D$D$D(px * sign, 0.0, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, py, pz * radius);
s+=du;
}
}s=0.0;
t+=dv;
py+=dy;
}
gbuf.end$();
return gbuf;
});

Clazz.newMeth(C$, 'coneBody$D$D$D$D$I$I$D$Z$Z',  function (bottom, top, bottomR, topR, xdiv, ydiv, dv, outside, texCoordYUp) {
var r;
var sign;
if (outside) sign=1.0;
 else sign=-1.0;
var dtheta=6.283185307179586 / xdiv;
var dr=(topR - bottomR) / ydiv;
var height=top - bottom;
var dy=height / ydiv;
var ynormal=(bottomR - topR) / height;
var du=1.0 / xdiv;
var gbuf=Clazz.new_([ydiv * 2 * (xdiv + 1) ],$I$(1,1).c$$I);
var s=0.0;
var t=0.0;
var px;
var pz;
var qx;
var qz;
var py=bottom;
var qy;
r=bottomR;
gbuf.begin$I(1);
for (var i=0; i < ydiv; i++) {
qy=py + dy;
if (outside) {
px=Math.cos(xdiv * dtheta - 1.5707963267948966);
pz=Math.sin(xdiv * dtheta - 1.5707963267948966);
qx=Math.cos((xdiv - 1) * dtheta - 1.5707963267948966);
qz=Math.sin((xdiv - 1) * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * (r + dr), qy, pz * (r + dr));
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * r, py, pz * r);
gbuf.normal3d$D$D$D(qx * sign, ynormal * sign, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s + du, t + dv);
}gbuf.vertex3d$D$D$D(qx * (r + dr), qy, qz * (r + dr));
gbuf.normal3d$D$D$D(qx * sign, ynormal * sign, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s + du, t);
}gbuf.vertex3d$D$D$D(qx * r, py, qz * r);
s+=(du * 2.0);
for (var j=xdiv - 2; j >= 0; j--) {
px=Math.cos(j * dtheta - 1.5707963267948966);
pz=Math.sin(j * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * (r + dr), qy, pz * (r + dr));
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * r, py, pz * r);
s+=du;
}
} else {
px=Math.cos(-1.5707963267948966);
pz=Math.sin(-1.5707963267948966);
qx=Math.cos(dtheta - 1.5707963267948966);
qz=Math.sin(dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * (r + dr), qy, pz * (r + dr));
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * r, py, pz * r);
gbuf.normal3d$D$D$D(qx * sign, ynormal * sign, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s + du, t + dv);
}gbuf.vertex3d$D$D$D(qx * (r + dr), qy, qz * (r + dr));
gbuf.normal3d$D$D$D(qx * sign, ynormal * sign, qz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s + du, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s + du, t);
}gbuf.vertex3d$D$D$D(qx * r, py, qz * r);
s+=(du * 2.0);
for (var j=2; j <= xdiv; j++) {
px=Math.cos(j * dtheta - 1.5707963267948966);
pz=Math.sin(j * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - (t + dv));
} else {
gbuf.texCoord2d$D$D(s, t + dv);
}gbuf.vertex3d$D$D$D(px * (r + dr), qy, pz * (r + dr));
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * r, py, pz * r);
s+=du;
}
}s=0.0;
t+=dv;
py+=dy;
r+=dr;
}
gbuf.end$();
return gbuf;
});

Clazz.newMeth(C$, 'coneTop$D$D$D$I$D$Z$Z',  function (bottom, radius, height, xdiv, t, outside, texCoordYUp) {
var sign;
if (outside) sign=1.0;
 else sign=-1.0;
var dtheta=6.283185307179586 / xdiv;
var ynormal=radius / height;
var du=1.0 / xdiv;
var top=bottom + height;
var gbuf=Clazz.new_($I$(1,1).c$$I,[xdiv + 2]);
gbuf.begin$I(16);
gbuf.normal3d$D$D$D(0.0, ynormal * sign, 0.0);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(0.5, 0.0);
} else {
gbuf.texCoord2d$D$D(0.5, 1.0);
}gbuf.vertex3d$D$D$D(0.0, top, 0.0);
var s=0.0;
var px;
var pz;
if (outside) {
for (var i=xdiv; i >= 0; i--) {
px=Math.cos(i * dtheta - 1.5707963267948966);
pz=Math.sin(i * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, bottom, pz * radius);
s+=du;
}
} else {
for (var i=0; i <= xdiv; i++) {
px=Math.cos(i * dtheta - 1.5707963267948966);
pz=Math.sin(i * dtheta - 1.5707963267948966);
gbuf.normal3d$D$D$D(px * sign, ynormal * sign, pz * sign);
if (texCoordYUp) {
gbuf.texCoord2d$D$D(s, 1.0 - t);
} else {
gbuf.texCoord2d$D$D(s, t);
}gbuf.vertex3d$D$D$D(px * radius, bottom, pz * radius);
s+=du;
}
}gbuf.end$();
return gbuf;
});
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
