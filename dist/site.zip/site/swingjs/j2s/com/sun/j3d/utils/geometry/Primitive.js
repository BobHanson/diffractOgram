(function(){var P$=Clazz.newPackage("com.sun.j3d.utils.geometry"),I$=[[0,'java.util.Hashtable','javax.vecmath.Color3f','javax.media.j3d.Material','javax.media.j3d.Appearance']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Primitive", null, 'javax.media.j3d.Group');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.numTris=0;
this.numVerts=0;
},1);

C$.$fields$=[['I',['numTris','numVerts','flags']]
,['O',['geomCache','java.util.Hashtable']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.flags=0;
this.setCapability$I(1);
this.setCapability$I(12);
}, 1);

Clazz.newMeth(C$, 'getNumTriangles$',  function () {
return this.numTris;
});

Clazz.newMeth(C$, 'setNumTriangles$I',  function (num) {
System.err.println$S("Warning: setNumTriangles has no effect");
});

Clazz.newMeth(C$, 'getNumVertices$',  function () {
return this.numVerts;
});

Clazz.newMeth(C$, 'setNumVertices$I',  function (num) {
System.err.println$S("Warning: setNumVertices has no effect");
});

Clazz.newMeth(C$, 'getPrimitiveFlags$',  function () {
return this.flags;
});

Clazz.newMeth(C$, 'setPrimitiveFlags$I',  function (fl) {
System.err.println$S("Warning: setPrimitiveFlags has no effect");
});

Clazz.newMeth(C$, 'getAppearance$',  function () {
return this.getShape$I(0).getAppearance$();
});

Clazz.newMeth(C$, 'setAppearance$I$javax_media_j3d_Appearance',  function (partid, ap) {
this.getShape$I(partid).setAppearance$javax_media_j3d_Appearance(ap);
});

Clazz.newMeth(C$, 'setAppearance$',  function () {
var aColor=Clazz.new_($I$(2,1).c$$F$F$F,[0.1, 0.1, 0.1]);
var eColor=Clazz.new_($I$(2,1).c$$F$F$F,[0.0, 0.0, 0.0]);
var dColor=Clazz.new_($I$(2,1).c$$F$F$F,[0.6, 0.6, 0.6]);
var sColor=Clazz.new_($I$(2,1).c$$F$F$F,[1.0, 1.0, 1.0]);
var m=Clazz.new_($I$(3,1).c$$javax_vecmath_Color3f$javax_vecmath_Color3f$javax_vecmath_Color3f$javax_vecmath_Color3f$F,[aColor, eColor, dColor, sColor, 100.0]);
var a=Clazz.new_($I$(4,1));
m.setLightingEnable$Z(true);
a.setMaterial$javax_media_j3d_Material(m);
this.setAppearance$javax_media_j3d_Appearance(a);
});

Clazz.newMeth(C$, 'strfloat$F',  function (x) {
return ( new Float(x)).toString();
});

Clazz.newMeth(C$, 'cacheGeometry$I$F$F$F$I$I$I$com_sun_j3d_utils_geometry_GeomBuffer',  function (kind, a, b, c, d, e, flags, geo) {
var key= String.instantialize(kind + this.strfloat$F(a) + this.strfloat$F(b) + this.strfloat$F(c) + d + e + flags );
C$.geomCache.put$O$O(key, geo);
});

Clazz.newMeth(C$, 'getCachedGeometry$I$F$F$F$I$I$I',  function (kind, a, b, c, d, e, flags) {
var key= String.instantialize(kind + this.strfloat$F(a) + this.strfloat$F(b) + this.strfloat$F(c) + d + e + flags );
var cache=C$.geomCache.get$O(key);
return (cache);
});

Clazz.newMeth(C$, 'clearGeometryCache$',  function () {
C$.geomCache.clear$();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.geomCache=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-22 13:59:22 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
