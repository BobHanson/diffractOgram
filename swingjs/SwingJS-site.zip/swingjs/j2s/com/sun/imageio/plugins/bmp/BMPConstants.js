(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.bmp"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "BMPConstants");
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-27 18:07:50 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
