(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "CompositeContext");
})();
;Clazz.setTVer('5.0.1-v2');//Created 2024-06-27 18:08:00 Java2ScriptVisitor version 5.0.1-v2 net.sf.j2s.core.jar version 5.0.1-v2
