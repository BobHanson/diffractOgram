(function(){var P$=Clazz.newPackage("jme"),I$=[[0,'org.openscience.jmol.app.jmolpanel.JmolResourceHandler','javajs.api.Interface','javax.swing.SwingUtilities']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEPlugin", null, null, 'org.openscience.jmol.app.JmolPlugin');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['jmeJmol','jme.JMEJmol']]]

Clazz.newMeth(C$, 'destroy$',  function () {
this.jmeJmol=null;
});

Clazz.newMeth(C$, 'getLicense$',  function () {
return null;
});

Clazz.newMeth(C$, 'getMenuIcon$',  function () {
return $I$(1).getIconX$S("2dButton.png");
});

Clazz.newMeth(C$, 'getMenuText$',  function () {
return "JME 2D Editor";
});

Clazz.newMeth(C$, 'getName$',  function () {
return "JME";
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return null;
});

Clazz.newMeth(C$, 'getWebSite$',  function () {
return null;
});

Clazz.newMeth(C$, 'isStarted$',  function () {
return this.jmeJmol != null ;
});

Clazz.newMeth(C$, 'isVisible$',  function () {
return this.jmeJmol != null  && this.jmeJmol.myFrame.isVisible$() ;
});

Clazz.newMeth(C$, 'notifyCallback$org_jmol_c_CBK$OA',  function (type, data) {
});

Clazz.newMeth(C$, 'setVisible$Z',  function (b) {
if (this.jmeJmol != null ) this.jmeJmol.setVisible$Z(true);
});

Clazz.newMeth(C$, 'start$javax_swing_JFrame$org_jmol_viewer_Viewer$java_util_Map',  function (frame, vwr, jmolOptions) {
if (this.jmeJmol == null ) {
this.jmeJmol=$I$(2).getInterface$S("org.openscience.jmol.app.jme.JMEJmol");
this.jmeJmol.setViewer$javax_swing_JFrame$org_jmol_viewer_Viewer$java_awt_Container$S(null, vwr, frame, "jmol");
}this.jmeJmol.setFrameVisible$Z(true);
$I$(3,"invokeLater$Runnable",[((P$.JMEPlugin$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "JMEPlugin$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'Runnable', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
this.b$['jme.JMEPlugin'].jmeJmol.from3D$();
});
})()
), Clazz.new_(P$.JMEPlugin$1.$init$,[this, null]))]);
});

Clazz.newMeth(C$, 'processRequest$S$O',  function (action, value) {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-04 12:12:42 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
