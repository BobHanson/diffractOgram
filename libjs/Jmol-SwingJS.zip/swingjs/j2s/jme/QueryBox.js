(function(){var P$=Clazz.newPackage("jme"),I$=[[0,'java.awt.Color','java.awt.Point','javax.swing.JTextField','jme.JMEmol','java.util.ArrayList','javax.swing.JFrame','javajs.util.Rdr','java.io.FileInputStream','java.awt.Font','java.util.StringTokenizer','java.awt.RenderingHints','jme.MultiBox','jme.QueryBox','jme.JME','java.awt.GridLayout','javax.swing.JLabel','javax.swing.JPanel','javax.swing.JButton','java.awt.BorderLayout','java.awt.FlowLayout','javax.swing.JComboBox']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "QueryBox", null, 'javax.swing.JFrame');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bgc=$I$(14).bgColor;
this.isBondQuery=false;
},1);

C$.$fields$=[['Z',['isBondQuery'],'O',['text','javax.swing.JTextField','bgc','java.awt.Color','jme','jme.JME']]]

Clazz.newMeth(C$, 'c$$jme_JME',  function (jme) {
;C$.superclazz.c$$S.apply(this,["Atom/Bond Query"]);C$.$init$.apply(this);
this.jme=jme;
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(15,1).c$$I$I,[0, 1]));
this.setFont$java_awt_Font(jme.fontSmall);
this.setBackground$java_awt_Color(this.bgc);
var p1=Clazz.new_($I$(17,1));
p1.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
p1.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Atom type :"]));
var first=true;
if (first) {
jme.any=Clazz.new_($I$(18,1).c$$S,["Any"]);
jme.anyec=Clazz.new_($I$(18,1).c$$S,["Any except C"]);
jme.halogen=Clazz.new_($I$(18,1).c$$S,["Halogen"]);
}p1.add$java_awt_Component(jme.any);
p1.add$java_awt_Component(jme.anyec);
p1.add$java_awt_Component(jme.halogen);
this.add$java_awt_Component(p1);
var p2=Clazz.new_($I$(17,1));
p2.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
p2.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S$I,["Or select one or more from the list :", 2]));
this.add$java_awt_Component(p2);
var p3=Clazz.new_($I$(17,1));
p3.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
if (first) {
jme.c=Clazz.new_($I$(18,1).c$$S,["C"]);
jme.n=Clazz.new_($I$(18,1).c$$S,["N"]);
jme.o=Clazz.new_($I$(18,1).c$$S,["O"]);
jme.s=Clazz.new_($I$(18,1).c$$S,["S"]);
jme.p=Clazz.new_($I$(18,1).c$$S,["P"]);
jme.f=Clazz.new_($I$(18,1).c$$S,["F"]);
jme.cl=Clazz.new_($I$(18,1).c$$S,["Cl"]);
jme.br=Clazz.new_($I$(18,1).c$$S,["Br"]);
jme.i=Clazz.new_($I$(18,1).c$$S,["I"]);
}p3.add$java_awt_Component(jme.c);
p3.add$java_awt_Component(jme.n);
p3.add$java_awt_Component(jme.o);
p3.add$java_awt_Component(jme.s);
p3.add$java_awt_Component(jme.p);
p3.add$java_awt_Component(jme.f);
p3.add$java_awt_Component(jme.cl);
p3.add$java_awt_Component(jme.br);
p3.add$java_awt_Component(jme.i);
this.add$java_awt_Component(p3);
var p4=Clazz.new_($I$(17,1));
p4.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
if (first) {
jme.choiceh=Clazz.new_($I$(21,1));
jme.choiceh.addItem$O("Any");
jme.choiceh.addItem$O("0");
jme.choiceh.addItem$O("1");
jme.choiceh.addItem$O("2");
jme.choiceh.addItem$O("3");
}p4.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Number of hydrogens :  "]));
p4.add$java_awt_Component(jme.choiceh);
this.add$java_awt_Component(p4);
var p5=Clazz.new_($I$(17,1));
p5.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
if (first) {
jme.choiced=Clazz.new_($I$(21,1));
jme.choiced.addItem$O("Any");
jme.choiced.addItem$O("0");
jme.choiced.addItem$O("1");
jme.choiced.addItem$O("2");
jme.choiced.addItem$O("3");
jme.choiced.addItem$O("4");
jme.choiced.addItem$O("5");
jme.choiced.addItem$O("6");
}p5.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S$I,["Number of connections :", 2]));
p5.add$java_awt_Component(jme.choiced);
p5.add$java_awt_Component(Clazz.new_([" (H\'s don\'t count.)", 2],$I$(16,1).c$$S$I));
this.add$java_awt_Component(p5);
var p6=Clazz.new_($I$(17,1));
p6.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
p6.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Atom is :"]));
if (first) jme.aromatic=Clazz.new_($I$(18,1).c$$S,["Aromatic"]);
p6.add$java_awt_Component(jme.aromatic);
if (first) jme.nonaromatic=Clazz.new_($I$(18,1).c$$S,["Nonaromatic"]);
p6.add$java_awt_Component(jme.nonaromatic);
if (first) jme.ring=Clazz.new_($I$(18,1).c$$S,["Ring"]);
p6.add$java_awt_Component(jme.ring);
if (first) jme.nonring=Clazz.new_($I$(18,1).c$$S,["Nonring"]);
p6.add$java_awt_Component(jme.nonring);
this.add$java_awt_Component(p6);
var p9=Clazz.new_($I$(17,1));
p9.setBackground$java_awt_Color(this.getBackground$().darker$());
p9.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[0, 3, 1]));
p9.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S,["Bond is :"]));
if (first) jme.anyBond=Clazz.new_($I$(18,1).c$$S,["Any"]);
p9.add$java_awt_Component(jme.anyBond);
if (first) jme.aromaticBond=Clazz.new_($I$(18,1).c$$S,["Aromatic"]);
p9.add$java_awt_Component(jme.aromaticBond);
if (first) jme.ringBond=Clazz.new_($I$(18,1).c$$S,["Ring"]);
p9.add$java_awt_Component(jme.ringBond);
if (first) jme.nonringBond=Clazz.new_($I$(18,1).c$$S,["Nonring"]);
p9.add$java_awt_Component(jme.nonringBond);
this.add$java_awt_Component(p9);
var p8=Clazz.new_($I$(17,1));
p8.setLayout$java_awt_LayoutManager(Clazz.new_($I$(20,1).c$$I$I$I,[1, 3, 1]));
if (first) this.text=Clazz.new_($I$(3,1).c$$S$I,["*", 20]);
p8.add$java_awt_Component(this.text);
p8.add$java_awt_Component(Clazz.new_($I$(18,1).c$$S,["Reset"]));
p8.add$java_awt_Component(Clazz.new_($I$(18,1).c$$S,["Close"]));
this.add$java_awt_Component(p8);
this.setResizable$Z(false);
if (first) {
this.resetAtomList$();
this.resetAtomType$();
this.resetBondType$();
jme.aromatic.setBackground$java_awt_Color(this.bgc);
jme.nonaromatic.setBackground$java_awt_Color(this.bgc);
jme.ring.setBackground$java_awt_Color(this.bgc);
jme.nonring.setBackground$java_awt_Color(this.bgc);
jme.choiceh.setBackground$java_awt_Color(this.bgc);
jme.choiced.setBackground$java_awt_Color(this.bgc);
this.changeColor$javax_swing_JButton(jme.any);
}this.pack$();
this.setLocation$java_awt_Point(jme.point);
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'action$java_awt_Event$O',  function (e, arg) {
if (arg.equals$O("Close")) {
this.jme.point=this.getLocationOnScreen$();
this.setVisible$Z(false);
} else if (arg.equals$O("Reset")) {
this.resetAll$();
this.changeColor$javax_swing_JButton(this.jme.any);
this.doSmarts$();
} else if (Clazz.instanceOf(e.target, "javax.swing.JButton")) {
this.resetBondType$();
if (e.target === this.jme.any ) {
this.resetAtomList$();
this.resetAtomType$();
} else if (e.target === this.jme.anyec ) {
this.resetAtomList$();
this.resetAtomType$();
} else if (e.target === this.jme.halogen ) {
this.resetAtomList$();
this.resetAtomType$();
} else if (e.target === this.jme.ring ) {
this.jme.nonring.setBackground$java_awt_Color(this.bgc);
} else if (e.target === this.jme.nonring ) {
this.jme.ring.setBackground$java_awt_Color(this.bgc);
this.jme.aromatic.setBackground$java_awt_Color(this.bgc);
} else if (e.target === this.jme.aromatic ) {
this.jme.nonaromatic.setBackground$java_awt_Color(this.bgc);
this.jme.nonring.setBackground$java_awt_Color(this.bgc);
} else if (e.target === this.jme.nonaromatic ) {
this.jme.aromatic.setBackground$java_awt_Color(this.bgc);
} else if (e.target === this.jme.anyBond  || e.target === this.jme.aromaticBond   || e.target === this.jme.ringBond   || e.target === this.jme.nonringBond  ) {
this.resetAll$();
this.isBondQuery=true;
} else {
this.resetAtomType$();
}this.changeColor$javax_swing_JButton((e.target));
this.doSmarts$();
} else if (Clazz.instanceOf(e.target, "javax.swing.JComboBox")) {
this.resetBondType$();
var choice=(e.target);
if (choice.getSelectedIndex$() == 0) choice.setBackground$java_awt_Color(this.bgc);
 else choice.setBackground$java_awt_Color($I$(1).orange);
this.doSmarts$();
}if (this.jme.action != 107) {
this.jme.action=107;
this.jme.repaint$();
}return true;
});

Clazz.newMeth(C$, 'resetAll$',  function () {
this.resetAtomList$();
this.resetAtomType$();
this.jme.choiceh.setSelectedIndex$I(0);
this.jme.choiced.setSelectedIndex$I(0);
this.jme.aromatic.setBackground$java_awt_Color(this.bgc);
this.jme.nonaromatic.setBackground$java_awt_Color(this.bgc);
this.jme.ring.setBackground$java_awt_Color(this.bgc);
this.jme.nonring.setBackground$java_awt_Color(this.bgc);
this.jme.choiceh.setBackground$java_awt_Color(this.bgc);
this.jme.choiced.setBackground$java_awt_Color(this.bgc);
this.resetBondType$();
});

Clazz.newMeth(C$, 'resetAtomList$',  function () {
this.jme.c.setBackground$java_awt_Color(this.bgc);
this.jme.n.setBackground$java_awt_Color(this.bgc);
this.jme.o.setBackground$java_awt_Color(this.bgc);
this.jme.s.setBackground$java_awt_Color(this.bgc);
this.jme.p.setBackground$java_awt_Color(this.bgc);
this.jme.f.setBackground$java_awt_Color(this.bgc);
this.jme.cl.setBackground$java_awt_Color(this.bgc);
this.jme.br.setBackground$java_awt_Color(this.bgc);
this.jme.i.setBackground$java_awt_Color(this.bgc);
});

Clazz.newMeth(C$, 'resetAtomType$',  function () {
this.jme.any.setBackground$java_awt_Color(this.bgc);
this.jme.anyec.setBackground$java_awt_Color(this.bgc);
this.jme.halogen.setBackground$java_awt_Color(this.bgc);
});

Clazz.newMeth(C$, 'resetBondType$',  function () {
this.jme.anyBond.setBackground$java_awt_Color(this.bgc);
this.jme.aromaticBond.setBackground$java_awt_Color(this.bgc);
this.jme.ringBond.setBackground$java_awt_Color(this.bgc);
this.jme.nonringBond.setBackground$java_awt_Color(this.bgc);
this.isBondQuery=false;
});

Clazz.newMeth(C$, 'changeColor$javax_swing_JButton',  function (b) {
if (b.getBackground$() === this.bgc ) b.setBackground$java_awt_Color($I$(1).orange);
 else b.setBackground$java_awt_Color(this.bgc);
});

Clazz.newMeth(C$, 'doSmarts$',  function () {
var smarts="";
var showaA=false;
if (this.jme.any.getBackground$() !== this.bgc ) {
smarts="*";
showaA=true;
} else if (this.jme.anyec.getBackground$() !== this.bgc ) {
smarts="!#6";
showaA=true;
} else if (this.jme.halogen.getBackground$() !== this.bgc ) {
this.jme.f.setBackground$java_awt_Color($I$(1).orange);
this.jme.cl.setBackground$java_awt_Color($I$(1).orange);
this.jme.br.setBackground$java_awt_Color($I$(1).orange);
this.jme.i.setBackground$java_awt_Color($I$(1).orange);
smarts="F,Cl,Br,I";
} else {
var ar=this.jme.aromatic.getBackground$() !== this.bgc ;
var nar=this.jme.nonaromatic.getBackground$() !== this.bgc ;
if (this.jme.c.getBackground$() !== this.bgc ) {
if (ar) smarts+="c,";
 else if (nar) smarts+="C,";
 else smarts+="#6,";
}if (this.jme.n.getBackground$() !== this.bgc ) {
if (ar) smarts+="n,";
 else if (nar) smarts+="N,";
 else smarts+="#7,";
}if (this.jme.o.getBackground$() !== this.bgc ) {
if (ar) smarts+="o,";
 else if (nar) smarts+="O,";
 else smarts+="#8,";
}if (this.jme.s.getBackground$() !== this.bgc ) {
if (ar) smarts+="s,";
 else if (nar) smarts+="S,";
 else smarts+="#16,";
}if (this.jme.p.getBackground$() !== this.bgc ) {
if (ar) smarts+="p,";
 else if (nar) smarts+="P,";
 else smarts+="#15,";
}if (this.jme.f.getBackground$() !== this.bgc ) smarts+="F,";
if (this.jme.cl.getBackground$() !== this.bgc ) smarts+="Cl,";
if (this.jme.br.getBackground$() !== this.bgc ) smarts+="Br,";
if (this.jme.i.getBackground$() !== this.bgc ) smarts+="I,";
if (smarts.endsWith$S(",")) smarts=smarts.substring$I$I(0, smarts.length$() - 1);
if (smarts.length$() < 1 && !this.isBondQuery ) {
if (ar) smarts="a";
 else if (nar) smarts="A";
 else {
this.jme.any.setBackground$java_awt_Color($I$(1).orange);
smarts="*";
}}}var ap="";
if (showaA && this.jme.aromatic.getBackground$() !== this.bgc  ) ap+=";a";
if (showaA && this.jme.nonaromatic.getBackground$() !== this.bgc  ) ap+=";A";
if (this.jme.ring.getBackground$() !== this.bgc ) ap+=";R";
if (this.jme.nonring.getBackground$() !== this.bgc ) ap+=";!R";
if (this.jme.any.getBackground$() !== this.bgc  && ap.length$() > 0 ) smarts=ap.substring$I$I(1, ap.length$());
 else smarts+=ap;
var nh=this.jme.choiceh.getSelectedIndex$();
if (nh > 0) {
--nh;
smarts+=";H" + nh;
}var nd=this.jme.choiced.getSelectedIndex$();
if (nd > 0) {
--nd;
smarts+=";D" + nd;
}if (this.jme.anyBond.getBackground$() !== this.bgc ) smarts="~";
if (this.jme.aromaticBond.getBackground$() !== this.bgc ) smarts=":";
if (this.jme.ringBond.getBackground$() !== this.bgc ) smarts="@";
if (this.jme.nonringBond.getBackground$() !== this.bgc ) smarts="!@";
this.text.setText$S(smarts);
});

Clazz.newMeth(C$, 'isBondQuery$',  function () {
return this.isBondQuery;
});

Clazz.newMeth(C$, 'getSmarts$',  function () {
return this.text.getText$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:03:57 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
