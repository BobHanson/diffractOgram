(function(){var P$=Clazz.newPackage("jme.js"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "AsyncCallback");
C$.$defaults$ = function(C$){

Clazz.newMeth(C$, 'onFailure',  function (reason) {
});

Clazz.newMeth(C$, 'onSuccess',  function (o) {
});

Clazz.newMeth(C$, 'onWarn',  function () {
});

Clazz.newMeth(C$, 'loadClassAsync',  function (className, whenDone) {
{
Clazz.
}
});
};})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-03-03 15:25:59 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
