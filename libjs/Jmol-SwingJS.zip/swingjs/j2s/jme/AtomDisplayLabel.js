(function(){var P$=Clazz.newPackage("jme"),I$=[[0,['java.awt.geom.Rectangle2D','.Double']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomDisplayLabel");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.smallAtomWidthLabel=0;
this.boundingBoxpadding=2;
},1);

C$.$fields$=[['Z',['noLabelAtom'],'D',['smallAtomWidthLabel','fullAtomWidthLabel','labelX','labelY','atomMapY','atomMapX'],'I',['alignment','boundingBoxpadding'],'S',['str','mapString'],'O',['atomLabelBoundingBox','java.awt.geom.Rectangle2D.Double','subscripts','int[][]','+superscripts']]]

Clazz.newMeth(C$, 'c$$D$D$S$I$I$I$I$I$I$I$I$java_awt_FontMetrics$D$Z',  function (x, y, z, an, nv, sbo, nh, q, iso, map, alignment, fm, h, showHs) {
;C$.$init$.apply(this);
if (z == null  || z.length$() < 1 ) {
z="*";
System.err.println$S("Z error!");
}this.alignment=alignment;
var padding=2;
this.noLabelAtom=(an == 3 && q == 0  && iso == 0  && nv > 0  && (nv != 2 || sbo != 4 ) );
var hydrogenSymbols="";
if (showHs && !this.noLabelAtom ) {
if (nh > 0) {
hydrogenSymbols+="H";
if (nh > 1) {
hydrogenSymbols+=nh;
}}}var isoSymbol=(iso == 0 ? "" : "[" + iso + "]" );
var chargeSymbols=(q == 0 ? "" : (Math.abs(q) > 1 ? "" + Math.abs(q) : "") + (q > 0 ? "+" : "-"));
var stringForWidth=z;
if (alignment == 2) {
z=chargeSymbols + hydrogenSymbols + isoSymbol + z ;
} else {
z=isoSymbol + z + hydrogenSymbols + chargeSymbols ;
}this.str=z;
if (alignment == 1) {
stringForWidth=z;
}var smallWidth=fm.stringWidth$S(stringForWidth);
var fullWidth=fm.stringWidth$S(z);
this.smallAtomWidthLabel=smallWidth;
this.fullAtomWidthLabel=fullWidth;
var lineThickness=1;
var xstart=x - smallWidth / 2.0;
if (alignment == 2) {
xstart-=(fullWidth - smallWidth);
}var ystart=y - h / 2;
xstart-=lineThickness;
fullWidth+=lineThickness;
var box=this.atomLabelBoundingBox=Clazz.new_($I$(1,1).c$$D$D$D$D,[xstart - padding, ystart - padding, fullWidth + 2 * padding, h + 2 * padding]);
this.mapString=null;
this.labelX=this.atomLabelBoundingBox.x + padding + 1 ;
this.labelY=this.atomLabelBoundingBox.y + h + padding ;
if (hydrogenSymbols.length$() > 1) {
var pos=z.indexOf$S(hydrogenSymbols);
var styleIndices=Clazz.array(Integer.TYPE, -1, [pos + 1, hydrogenSymbols.length$() - 1]);
this.subscripts=Clazz.array(Integer.TYPE, -2, [styleIndices]);
}if (chargeSymbols.length$() > 0) {
var pos=z.indexOf$S(chargeSymbols);
var styleIndices=Clazz.array(Integer.TYPE, -1, [pos, chargeSymbols.length$()]);
this.superscripts=Clazz.array(Integer.TYPE, -2, [styleIndices]);
}if (isoSymbol.length$() > 0) {
var pos=z.indexOf$S(isoSymbol);
var styleIndices=Clazz.array(Integer.TYPE, -1, [pos, isoSymbol.length$()]);
if (this.superscripts == null ) {
this.superscripts=Clazz.array(Integer.TYPE, -2, [styleIndices]);
} else {
this.superscripts=Clazz.array(Integer.TYPE, -2, [this.superscripts[0], styleIndices]);
}}if (map < 0) return;
this.mapString=" " + map;
if (this.noLabelAtom) {
this.atomMapX=x + smallWidth / 4;
this.atomMapY=y - h * 0.1;
} else {
var atomMapStringWidth=fm.stringWidth$S(this.mapString);
if (alignment == 0) {
this.atomMapX=x - smallWidth / 2.0 + fullWidth;
} else {
box.x-=atomMapStringWidth;
this.atomMapX=x + smallWidth / 2 - fullWidth - atomMapStringWidth;
}var superscriptMove=h * 0.3;
this.atomMapY=y - superscriptMove;
box.y-=superscriptMove;
box.height+=superscriptMove;
box.width+=atomMapStringWidth;
}}, 1);

Clazz.newMeth(C$, 'draw$java_awt_Graphics',  function (g) {
g.drawString$S$I$I(this.str, (this.labelX|0), (this.labelY|0));
});

Clazz.newMeth(C$, 'drawRect$java_awt_Graphics',  function (g) {
var box=this.atomLabelBoundingBox;
g.drawRect$I$I$I$I((box.x|0), (box.y|0), (box.width|0), (box.height|0));
});

Clazz.newMeth(C$, 'fillRect$java_awt_Graphics',  function (g) {
var box=this.atomLabelBoundingBox;
g.fillRect$I$I$I$I((box.x|0), (box.y|0), (box.width|0), (box.height|0));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:03:57 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
