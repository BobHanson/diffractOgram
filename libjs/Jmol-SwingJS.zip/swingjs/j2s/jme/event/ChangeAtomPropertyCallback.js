(function(){var P$=Clazz.newPackage("jme.event"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ChangeAtomPropertyCallback");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['atomSymbol']]]

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-03-03 15:25:58 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
