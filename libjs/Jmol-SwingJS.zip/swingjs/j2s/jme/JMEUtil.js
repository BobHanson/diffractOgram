(function(){var P$=Clazz.newPackage("jme"),I$=[[0,'java.lang.reflect.Array','java.util.StringTokenizer','jme.JME']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JMEUtil", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['GWT',9],['RunAsyncCallback',9],['JSME_RunAsyncCallback',1033],['RunWhenDataReadyCallback',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'growArray$IA$I',  function (array, newSize) {
var newArray=C$.createArray$I(newSize);
System.arraycopy$O$I$O$I$I(array, 0, newArray, 0, array.length);
return newArray;
}, 1);

Clazz.newMeth(C$, 'copyArray$IA',  function (array) {
var copy=Clazz.array(Integer.TYPE, [array.length]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, 1);

Clazz.newMeth(C$, 'growArray$OA$I',  function (array, newSize) {
Clazz.assert(C$, this, function(){return (newSize >= array.length)});
var newArray=C$.copyOf$OA$I(array, newSize);
return newArray;
}, 1);

Clazz.newMeth(C$, 'copyOf$OA$I',  function (original, newLength) {
return C$.copyOf$OA$I$Class(original, newLength, original.getClass$());
}, 1);

Clazz.newMeth(C$, 'copyOf$OA$I$Class',  function (original, newLength, newType) {
var copy=(newType === Clazz.array(java.lang.Object, -1) ) ? Clazz.array(java.lang.Object, [newLength]) : Clazz.array(newType.getComponentType$(), newLength);
System.arraycopy$O$I$O$I$I(original, 0, copy, 0, Math.min(original.length, newLength));
return copy;
}, 1);

Clazz.newMeth(C$, 'growArray$SA$I',  function (array, newSize) {
var newArray=C$.createSArray$I(newSize);
System.arraycopy$O$I$O$I$I(array, 0, newArray, 0, array.length);
return newArray;
}, 1);

Clazz.newMeth(C$, 'growArray$DA$I',  function (array, newSize) {
var newArray=C$.createDArray$I(newSize);
System.arraycopy$O$I$O$I$I(array, 0, newArray, 0, array.length);
return newArray;
}, 1);

Clazz.newMeth(C$, 'growArray$IAA$I',  function (array, newSize) {
var secondarySize=array[0].length;
var newArray=C$.createArray$I$I(newSize, secondarySize);
System.arraycopy$O$I$O$I$I(array, 0, newArray, 0, array.length);
return newArray;
}, 1);

Clazz.newMeth(C$, 'equals$IA$IA',  function (a1, a2) {
if (a1.length == a2.length) {
for (var i=0; i < a1.length; i++) {
if (a1[i] != a2[i]) {
return false;
}}
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'intersection$IA$IA',  function (array1, array2) {
var common=Clazz.array(Integer.TYPE, [0]);
for (var v1, $v1 = 0, $$v1 = array1; $v1<$$v1.length&&((v1=($$v1[$v1])),1);$v1++) {
if (C$.contains$IA$I(array2, v1)) {
common=C$.growArray$IA$I(common, common.length + 1);
common[common.length - 1]=v1;
}}
return common;
}, 1);

Clazz.newMeth(C$, 'contains$IA$I',  function (array, v) {
for (var each, $each = 0, $$each = array; $each<$$each.length&&((each=($$each[$each])),1);$each++) {
if (each == v) {
return true;
}}
return false;
}, 1);

Clazz.newMeth(C$, 'swap$OA$I$I',  function (array, i, j) {
var temp=array[j];
array[j]=array[i];
array[i]=temp;
}, 1);

Clazz.newMeth(C$, 'copyArray$IA$I',  function (array, n) {
var copy=Clazz.array(Integer.TYPE, [array.length]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, n);
return copy;
}, 1);

Clazz.newMeth(C$, 'copyArray$SA',  function (array) {
var copy=Clazz.array(String, [array.length]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, 1);

Clazz.newMeth(C$, 'copyArray$DA',  function (array) {
var copy=Clazz.array(Double.TYPE, [array.length]);
System.arraycopy$O$I$O$I$I(array, 0, copy, 0, array.length);
return copy;
}, 1);

Clazz.newMeth(C$, 'createArray$I',  function (size) {
return Clazz.array(Integer.TYPE, [size]);
}, 1);

Clazz.newMeth(C$, 'createSArray$I',  function (size) {
return Clazz.array(String, [size]);
}, 1);

Clazz.newMeth(C$, 'createDArray$I',  function (size) {
return Clazz.array(Double.TYPE, [size]);
}, 1);

Clazz.newMeth(C$, 'createLArray$I',  function (size) {
return Clazz.array(Long.TYPE, [size]);
}, 1);

Clazz.newMeth(C$, 'createBArray$I',  function (size) {
return Clazz.array(Boolean.TYPE, [size]);
}, 1);

Clazz.newMeth(C$, 'createArray$I$I',  function (size1, size2) {
return Clazz.array(Integer.TYPE, [size1, size2]);
}, 1);

Clazz.newMeth(C$, 'isHighDPI$',  function () {
return false;
}, 1);

Clazz.newMeth(C$, 'runAsync$jme_JMEUtil_RunAsyncCallback',  function (runAsyncCallback) {
runAsyncCallback.onSuccess$();
}, 1);

Clazz.newMeth(C$, 'generatePrimes$I',  function (n) {
var npn;
var pn=C$.createLArray$I(n + 2);
var prime=C$.createArray$I(100);
var test=5;
var index=0;
var num=0;
var check=true;
prime[0]=3;
pn[1]=2;
pn[2]=3;
npn=2;
if (n < 3) return pn;
while (test < (prime[num] * prime[num])){
index=0;
check=true;
while (check == true  && index <= num  && test >= (prime[index] * prime[index]) ){
if (test % prime[index] == 0) check=false;
 else ++index;
}
if (check == true ) {
pn[++npn]=test;
if (npn >= n) return pn;
if (num < (prime.length - 1)) {
++num;
prime[num]=test;
}}test+=2;
}
System.err.println$S("ERROR - Prime Number generator failed !");
return pn;
}, 1);

Clazz.newMeth(C$, 'nextData$java_util_StringTokenizer$S',  function (st, separator) {
while (st.hasMoreTokens$()){
var s=st.nextToken$();
if (s.equals$O(separator)) return " ";
if (!st.nextToken$().equals$O(separator)) {
System.err.println$S("mol file line separator problem!");
}while (true){
var c=s.charAt$I(s.length$() - 1);
if (c == "|" || c == "\n"  || c == "\r" ) {
s=s.substring$I$I(0, s.length$() - 1);
if (s.length$() == 0) return " ";
} else {
break;
}}
return s;
}
return null;
}, 1);

Clazz.newMeth(C$, 'findLineSeparator$S',  function (molFile) {
var st=Clazz.new_($I$(2,1).c$$S$S$Z,[molFile, "\n", true]);
if (st.countTokens$() > 4) return "\n";
st=Clazz.new_($I$(2,1).c$$S$S$Z,[molFile, "|", true]);
if (st.countTokens$() > 4) return "|";
System.err.println$S("Cannot process mol file, use | as line separator !");
return null;
}, 1);

Clazz.newMeth(C$, 'squareEuclideanDist$D$D$D$D',  function (x1, y1, x2, y2) {
var dx=x2 - x1;
var dy=y2 - y1;
return dx * dx + dy * dy;
}, 1);

Clazz.newMeth(C$, 'dotProduct$D$D$D$D',  function (x1, y1, x2, y2) {
return x1 * x2 + y1 * y2;
}, 1);

Clazz.newMeth(C$, 'triangleHeight$D$D$D',  function (a, b, c) {
var s=(a + b + c ) / 2;
var area=Math.sqrt(s * (s - a) * (s - b) * (s - c) );
var h=0;
if (b != 0 ) {
h=area / b * 2;
}return h;
}, 1);

Clazz.newMeth(C$, 'compareAngles$D$D$D$D',  function (sina, cosa, sinb, cosb) {
var qa=0;
var qb=0;
if (sina >= 0.0  && cosa >= 0.0  ) qa=1;
 else if (sina >= 0.0  && cosa < 0.0  ) qa=2;
 else if (sina < 0.0  && cosa < 0.0  ) qa=3;
 else if (sina < 0.0  && cosa >= 0.0  ) qa=4;
if (sinb >= 0.0  && cosb >= 0.0  ) qb=1;
 else if (sinb >= 0.0  && cosb < 0.0  ) qb=2;
 else if (sinb < 0.0  && cosb < 0.0  ) qb=3;
 else if (sinb < 0.0  && cosb >= 0.0  ) qb=4;
if (qa < qb) return 1;
 else if (qa > qb) return -1;
switch (qa) {
case 1:
case 4:
return (sina < sinb  ? 1 : -1);
case 2:
case 3:
return (sina > sinb  ? 1 : -1);
}
System.err.println$S("stereowarning #31");
return 0;
}, 1);

Clazz.newMeth(C$, 'stereoTransformation$IA$IA',  function (t, ref) {
var d=0;
if (ref[0] == t[1]) {
d=t[0];
t[0]=t[1];
t[1]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
} else if (ref[0] == t[2]) {
d=t[2];
t[2]=t[0];
t[0]=d;
d=t[1];
t[1]=t[3];
t[3]=d;
} else if (ref[0] == t[3]) {
d=t[3];
t[3]=t[0];
t[0]=d;
d=t[1];
t[1]=t[2];
t[2]=d;
}if (ref[1] == t[2]) {
d=t[1];
t[1]=t[2];
t[2]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
} else if (ref[1] == t[3]) {
d=t[1];
t[1]=t[3];
t[3]=d;
d=t[2];
t[2]=t[3];
t[3]=d;
}}, 1);

Clazz.newMeth(C$, 'checkAtomicSymbol$S',  function (s) {
for (var an=1; an < $I$(3).zlabel.length; an++) {
if (s.equals$O($I$(3).zlabel[an])) return an;
}
return 18;
}, 1);

Clazz.newMeth(C$, 'getSDFDateLine$S',  function (version) {
var mol=(version + "         ").substring$I$I(0, 10);
var cMM;
var cDD;
var cYYYY;
var cHH;
var cmm;
{
var c = new Date(); cMM = c.getMonth(); cDD = c.getDate(); cYYYY = c.getFullYear(); cHH = c.getHours(); cmm = c.getMinutes();
}
mol+=C$.rightJustify$S$S("00", "" + (1 + cMM));
mol+=C$.rightJustify$S$S("00", "" + cDD);
mol+=("" + cYYYY).substring$I$I(2, 4);
mol+=C$.rightJustify$S$S("00", "" + cHH);
mol+=C$.rightJustify$S$S("00", "" + cmm);
mol+="2D 1   1.00000     0.00000     0";
return mol;
}, 1);

Clazz.newMeth(C$, 'iformat$I$I',  function (number, len) {
return C$.rightJustify$S$S("        ".substring$I$I(0, len), "" + number);
}, 1);

Clazz.newMeth(C$, 'rightJustify$S$S',  function (s1, s2) {
var n=s1.length$() - s2.length$();
return (n == 0 ? s2 : n > 0 ? s1.substring$I$I(0, n) + s2 : s1.substring$I$I(0, s1.length$() - 1) + "?");
}, 1);

Clazz.newMeth(C$, 'fformat$D$I$I',  function (number, len, dec) {
if (dec == 0) return C$.iformat$I$I((number|0), len);
if (Math.abs(number) < 9.0E-4 ) number=0.0;
var m=Math.pow(10, dec);
number=Long.$ival(Math.round$D(number * m)) / m;
var s= new Double(number).toString();
var dotpos=s.indexOf$I(".");
if (dotpos < 0) {
s+=".";
dotpos=s.indexOf$I(".");
}var slen=s.length$();
for (var i=1; i <= dec - slen + dotpos + 1; i++) s+="0";

return (len == 0 ? s : C$.rightJustify$S$S("        ".substring$I$I(0, len), s));
}, 1);

Clazz.newMeth(C$, 'stringHeight$java_awt_FontMetrics',  function (fm) {
return fm.getAscent$() - fm.getDescent$();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEUtil, "GWT", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'isScript$',  function () {
return false;
}, 1);

Clazz.newMeth(C$, 'log$S',  function (string) {
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.JMEUtil, "RunAsyncCallback", function(){
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.JMEUtil, "JSME_RunAsyncCallback", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, [['jme.JMEUtil','jme.JMEUtil.RunAsyncCallback']]);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'onFailure$Throwable',  function (reason) {
});

Clazz.newMeth(C$);
})()
;
(function(){/*i*/var C$=Clazz.newInterface(P$.JMEUtil, "RunWhenDataReadyCallback", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:03:57 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
