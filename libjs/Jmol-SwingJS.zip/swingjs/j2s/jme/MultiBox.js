(function(){var P$=Clazz.newPackage("jme"),I$=[[0,'java.awt.Color','java.awt.Point','javax.swing.JTextField','jme.JMEmol','java.util.ArrayList','javax.swing.JFrame','javajs.util.Rdr','java.io.FileInputStream','java.awt.Font','java.util.StringTokenizer','java.awt.RenderingHints','jme.MultiBox','jme.QueryBox','jme.JME','java.awt.GridLayout','javax.swing.JLabel','javax.swing.JPanel','javax.swing.JButton','java.awt.BorderLayout','java.awt.FlowLayout','javax.swing.JComboBox']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MultiBox", null, 'javax.swing.JFrame', 'java.awt.event.KeyListener');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['smilesText','javax.swing.JTextField','jme','jme.JME']]]

Clazz.newMeth(C$, 'c$$I$jme_JME',  function (box, jme) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
this.jme=jme;
this.setFont$java_awt_Font(jme.fontSmall);
this.setBackground$java_awt_Color($I$(14).bgColor);
this.setResizable$Z(false);
this.addKeyListener$java_awt_event_KeyListener(this);
if (box == 1) this.createSmilesBox$S(jme.Smiles$());
 else if (box == 2) this.createAtomxBox$();
 else this.createAboutBox$();
this.pack$();
this.setVisible$Z(true);
}, 1);

Clazz.newMeth(C$, 'createAboutBox$',  function () {
this.setTitle$S("about JSME");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(15,1).c$$I$I$I$I,[0, 1, 0, 0]));
this.setFont$java_awt_Font(this.jme.fontSmall);
this.setBackground$java_awt_Color($I$(14).bgColor);
this.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S$I,["JSME Molecular Editor v2023.01", 0]));
this.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S$I,["Peter Ertl, Bruno BienFait. and Robert Hanson", 0]));
var p=Clazz.new_($I$(17,1));
var b=Clazz.new_($I$(18,1).c$$S,["Close"]);
b.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.MultiBox'].jme.aboutBoxPoint=this.b$['jme.MultiBox'].jme.aboutBox.getLocationOnScreen$();
this.b$['jme.MultiBox'].jme.aboutBox.setVisible$Z(false);
});
})()
), Clazz.new_(P$.MultiBox$1.$init$,[this, null])));
p.add$java_awt_Component(b);
this.add$java_awt_Component(p);
this.setLocation$java_awt_Point(this.jme.aboutBoxPoint);
});

Clazz.newMeth(C$, 'createSmilesBox$S',  function (smiles) {
this.setTitle$S("SMILES");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(19,1).c$$I$I,[2, 0]));
this.smilesText=Clazz.new_($I$(3,1).c$$S,[smiles + "     "]);
if (!this.jme.runsmi) this.smilesText.setEditable$Z(false);
this.add$S$java_awt_Component("Center", this.smilesText);
var p=Clazz.new_($I$(17,1));
var b=Clazz.new_($I$(18,1).c$$S,["Close"]);
b.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.MultiBox'].jme.smilesBoxPoint=this.b$['jme.MultiBox'].jme.smilesBox.getLocationOnScreen$();
this.b$['jme.MultiBox'].jme.smilesBox.setVisible$Z(false);
});
})()
), Clazz.new_(P$.MultiBox$2.$init$,[this, null])));
p.add$java_awt_Component(b);
if (this.jme.runsmi) {
b=Clazz.new_($I$(18,1).c$$S,["Submit"]);
p.add$java_awt_Component(b);
}this.add$S$java_awt_Component("South", p);
this.smilesText.setText$S(this.smilesText.getText$().trim$());
this.setResizable$Z(true);
this.setLocation$java_awt_Point(this.jme.smilesBoxPoint);
});

Clazz.newMeth(C$, 'setSmiles$S',  function (smiles) {
var d=this.getSize$();
var l=this.jme.fontSmallMet.stringWidth$S(smiles) + 30;
if (l < 150) l=150;
this.setSize$I$I(l, d.height);
this.validate$();
this.smilesText.setText$S(smiles);
});

Clazz.newMeth(C$, 'createAtomxBox$',  function () {
this.setTitle$S("nonstandard atom");
this.setLayout$java_awt_LayoutManager(Clazz.new_($I$(19,1).c$$I$I,[2, 0]));
var p=Clazz.new_($I$(17,1));
p.add$java_awt_Component(Clazz.new_($I$(16,1).c$$S$I,["atomic SMILES", 0]));
this.add$S$java_awt_Component("North", p);
var as="H";
if (this.jme.atomicSymbol != null ) as=this.jme.atomicSymbol.getText$();
this.jme.atomicSymbol=Clazz.new_($I$(3,1).c$$S$I,[as, 8]);
this.add$S$java_awt_Component("Center", this.jme.atomicSymbol);
p=Clazz.new_($I$(17,1));
var b=Clazz.new_($I$(18,1).c$$S,["Close "]);
b.addActionListener$java_awt_event_ActionListener(((P$.MultiBox$3||
(function(){/*a*/var C$=Clazz.newClass(P$, "MultiBox$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
this.b$['jme.MultiBox'].jme.atomxBoxPoint=this.b$['jme.MultiBox'].jme.atomxBox.getLocationOnScreen$();
this.b$['jme.MultiBox'].jme.atomxBox.setVisible$Z(false);
});
})()
), Clazz.new_(P$.MultiBox$3.$init$,[this, null])));
p.add$java_awt_Component(b);
this.add$S$java_awt_Component("South", p);
this.setLocation$java_awt_Point(this.jme.atomxBoxPoint);
});

Clazz.newMeth(C$, 'keyDown$java_awt_event_KeyEvent$I',  function (e, key) {
if (this.jme.atomicSymbol == null ) return false;
if (this.jme.action != 1201) {
this.jme.action=1201;
this.jme.active_an=18;
}return false;
});

Clazz.newMeth(C$, 'keyTyped$java_awt_event_KeyEvent',  function (e) {
});

Clazz.newMeth(C$, 'keyPressed$java_awt_event_KeyEvent',  function (e) {
this.keyDown$java_awt_event_KeyEvent$I(e, e.getKeyCode$());
});

Clazz.newMeth(C$, 'keyReleased$java_awt_event_KeyEvent',  function (e) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:03:57 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
