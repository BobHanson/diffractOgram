(function(){var P$=Clazz.newPackage("org.jmol.image"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AviCreator", null, null, 'org.jmol.api.JmolMovieCreatorInterface');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['errorMsg']]]

Clazz.newMeth(C$, 'createMovie$org_jmol_viewer_Viewer$SA$I$I$I$S',  function (vwr, files, width, height, fps, fileName) {
return this.errorMsg;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:49 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
