(function(){var P$=Clazz.newPackage("org.jmol"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "BasicDnD");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:09:10 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
