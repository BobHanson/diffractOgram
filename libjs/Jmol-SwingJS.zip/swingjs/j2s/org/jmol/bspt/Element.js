(function(){var P$=Clazz.newPackage("org.jmol.bspt"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Element");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['count'],'O',['bspt','org.jmol.bspt.Bspt']]]

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:48 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
