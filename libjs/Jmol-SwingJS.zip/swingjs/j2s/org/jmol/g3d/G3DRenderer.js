(function(){var P$=Clazz.newPackage("org.jmol.g3d"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "G3DRenderer");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:49 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
