(function(){var P$=Clazz.newPackage("org.jmol.consolejs"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JSConsole");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:04:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
