(function(){var P$=Clazz.newPackage("org.jmol.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "SymmetryInterface");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-30 14:46:27 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
