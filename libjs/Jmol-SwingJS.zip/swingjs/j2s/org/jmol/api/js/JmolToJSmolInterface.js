(function(){var P$=Clazz.newPackage("org.jmol.api.js"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "JmolToJSmolInterface", null, null, 'javajs.api.js.J2SObjectInterface');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:47 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
