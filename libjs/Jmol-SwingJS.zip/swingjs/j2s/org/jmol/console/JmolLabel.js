(function(){var P$=Clazz.newPackage("org.jmol.console"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JmolLabel", null, 'javax.swing.JLabel', 'org.jmol.api.JmolAbstractButton');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S$I',  function (text, horizontalAlignment) {
;C$.superclazz.c$$S$I.apply(this,[text, horizontalAlignment]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getKey$',  function () {
return null;
});

Clazz.newMeth(C$, 'isSelected$',  function () {
return false;
});

Clazz.newMeth(C$, 'setMnemonic$C',  function (mnemonic) {
});

Clazz.newMeth(C$, 'addConsoleListener$O',  function (console) {
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:48 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
