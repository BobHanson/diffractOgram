(function(){var P$=Clazz.newPackage("org.jmol.awt"),p$1={},I$=[[0,'org.jmol.viewer.Viewer','org.jmol.awt.Display','org.jmol.api.Interface','org.jmol.awt.Mouse','org.jmol.awt.Image','org.jmol.awt.AwtFont','java.awt.GraphicsEnvironment','javajs.api.Interface','org.jmol.awt.AwtFile','javajs.util.Rdr','org.jmol.inchi.InChIJS','org.jmol.inchi.InChIJNA','javax.swing.JOptionPane','org.jmol.i18n.GT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Platform", null, null, 'org.jmol.api.GenericPlatform');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['vwr','org.jmol.api.PlatformViewer']]
,['O',['jsutil','swingjs.api.JSUtilI','inchi','org.jmol.api.JmolInChI']]]

Clazz.newMeth(C$, 'setViewer$org_jmol_api_PlatformViewer$O',  function (vwr, display) {
this.vwr=vwr;
});

Clazz.newMeth(C$, 'isSingleThreaded$',  function () {
return $I$(1).isJS;
});

Clazz.newMeth(C$, 'convertPointFromScreen$O$javajs_util_P3d',  function (display, ptTemp) {
$I$(2).convertPointFromScreen$O$javajs_util_P3d(display, ptTemp);
});

Clazz.newMeth(C$, 'getFullScreenDimensions$O$IA',  function (display, widthHeight) {
$I$(2).getFullScreenDimensions$O$IA(display, widthHeight);
});

Clazz.newMeth(C$, 'getMenuPopup$S$C',  function (menuStructure, type) {
var jmolpopup=$I$(3,"getOption$S$org_jmol_viewer_Viewer$S",[type == "j" ? "awt.AwtJmolPopup" : "awt.AwtModelKitPopup", null, null]);
if (jmolpopup != null ) jmolpopup.jpiInitialize$org_jmol_api_PlatformViewer$S(this.vwr, menuStructure);
return jmolpopup;
});

Clazz.newMeth(C$, 'hasFocus$O',  function (display) {
return $I$(2).hasFocus$O(display);
});

Clazz.newMeth(C$, 'prompt$S$S$SA$Z',  function (label, data, list, asButtons) {
return $I$(2).prompt$org_jmol_api_PlatformViewer$S$S$SA$Z(this.vwr, label, data, list, asButtons);
});

Clazz.newMeth(C$, 'requestFocusInWindow$O',  function (display) {
$I$(2).requestFocusInWindow$O(display);
});

Clazz.newMeth(C$, 'repaint$O',  function (display) {
$I$(2).repaint$O(display);
});

Clazz.newMeth(C$, 'setTransparentCursor$O',  function (display) {
$I$(2).setTransparentCursor$O(display);
});

Clazz.newMeth(C$, 'setCursor$I$O',  function (c, display) {
$I$(2).setCursor$I$O(c, display);
if (c == 12) (display).requestFocus$();
});

Clazz.newMeth(C$, 'getMouseManager$D$O',  function (privateKey, display) {
return Clazz.new_($I$(4,1).c$$D$org_jmol_api_PlatformViewer$O,[privateKey, this.vwr, display]);
});

Clazz.newMeth(C$, 'allocateRgbImage$I$I$IA$I$Z$Z',  function (windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent, isImageWrite) {
return $I$(5).allocateRgbImage$I$I$IA$I$Z(windowWidth, windowHeight, pBuffer, windowSize, backgroundTransparent);
});

Clazz.newMeth(C$, 'createImage$O',  function (data) {
return $I$(5).createImage$O$org_jmol_api_PlatformViewer(data, this.vwr);
});

Clazz.newMeth(C$, 'disposeGraphics$O',  function (gOffscreen) {
$I$(5).disposeGraphics$O(gOffscreen);
});

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I$Z',  function (g, img, x, y, width, height, isDTI) {
if (isDTI) $I$(5).drawImageDTI$O$O$I$I$I$I(g, img, x, y, width, height);
 else $I$(5).drawImage$O$O$I$I$I$I(g, img, x, y, width, height);
});

Clazz.newMeth(C$, 'grabPixels$O$I$I$IA',  function (imageobj, width, height, pixels) {
return $I$(5).grabPixels$O$I$I$IA(imageobj, width, height, pixels);
});

Clazz.newMeth(C$, 'drawImageToBuffer$O$O$O$I$I$I',  function (gOffscreen, imageOffscreen, imageobj, width, height, bgcolor) {
return $I$(5).drawImageToBuffer$O$O$O$I$I$I(gOffscreen, imageOffscreen, imageobj, width, height, bgcolor);
});

Clazz.newMeth(C$, 'getTextPixels$S$org_jmol_util_Font$O$O$I$I$I',  function (text, font3d, gObj, image, width, height, ascent) {
return $I$(5).getTextPixels$S$org_jmol_util_Font$O$O$I$I$I(text, font3d, gObj, image, width, height, ascent);
});

Clazz.newMeth(C$, 'flushImage$O',  function (imagePixelBuffer) {
if (!$I$(1).isJS) $I$(5).flush$O(imagePixelBuffer);
});

Clazz.newMeth(C$, 'getGraphics$O',  function (image) {
return $I$(5).getGraphics$O(image);
});

Clazz.newMeth(C$, 'getImageHeight$O',  function (image) {
return (image == null  ? -1 : $I$(5).getHeight$O(image));
});

Clazz.newMeth(C$, 'getImageWidth$O',  function (image) {
return (image == null  ? -1 : $I$(5).getWidth$O(image));
});

Clazz.newMeth(C$, 'getStaticGraphics$O$Z',  function (image, backgroundTransparent) {
return $I$(5).getStaticGraphics$O$Z(image, backgroundTransparent);
});

Clazz.newMeth(C$, 'newBufferedImage$O$I$I',  function (image, w, h) {
return $I$(5).newBufferedImage$O$I$I(image, w, h);
});

Clazz.newMeth(C$, 'newOffScreenImage$I$I',  function (w, h) {
return $I$(5).newBufferedImage$I$I(w, h);
});

Clazz.newMeth(C$, 'waitForDisplay$O$O',  function (ignored, image) {
$I$(5).waitForDisplay$org_jmol_api_PlatformViewer$O(this.vwr, image);
return true;
});

Clazz.newMeth(C$, 'fontStringWidth$org_jmol_util_Font$S',  function (font, text) {
return $I$(6,"stringWidth$O$S",[font.getFontMetrics$(), text]);
});

Clazz.newMeth(C$, 'getFontAscent$O',  function (fontMetrics) {
return $I$(6).getAscent$O(fontMetrics);
});

Clazz.newMeth(C$, 'getFontDescent$O',  function (fontMetrics) {
return $I$(6).getDescent$O(fontMetrics);
});

Clazz.newMeth(C$, 'getFontMetrics$org_jmol_util_Font$O',  function (font, graphics) {
return $I$(6).getFontMetrics$org_jmol_util_Font$O(font, graphics);
});

Clazz.newMeth(C$, 'newFont$S$Z$Z$F',  function (fontFace, isBold, isItalic, fontSize) {
return $I$(6).newFont$S$Z$Z$F(fontFace, isBold, isItalic, fontSize);
});

Clazz.newMeth(C$, 'getJsObjectInfo$OA$S$OA',  function (jsObject, method, args) {
var obj=Clazz.array(java.lang.Object, -1, [null, method, jsObject, args]);
(this.vwr).sm.cbl.notifyCallback$org_jmol_c_CBK$OA(null, obj);
return obj[0];
});

Clazz.newMeth(C$, 'isHeadless$',  function () {
return $I$(7).isHeadless$();
});

Clazz.newMeth(C$, 'notifyEndOfRendering$',  function () {
});

Clazz.newMeth(C$, 'getWindow$java_awt_Container',  function (p) {
while (p != null ){
if (Clazz.instanceOf(p, "java.awt.Frame")) return p;
 else if (Clazz.instanceOf(p, "javax.swing.JDialog")) return p;
 else if (Clazz.instanceOf(p, "org.jmol.awt.JmolFrame")) return (p).getFrame$();
p=p.getParent$();
}
return null;
}, 1);

Clazz.newMeth(C$, 'getDateFormat$S',  function (isoType) {
if (isoType != null  && isoType.contains$CharSequence("32000") ) {
return "D:" + this.getDateFormat$S("8224") + "'00'" ;
}var d=Clazz.new_(java.util.Date);
if ($I$(1).isSwingJS) {
if (C$.jsutil == null ) C$.jsutil=$I$(8).getInterface$S("swingjs.JSUtil");
return C$.jsutil.getDateFormat$S(isoType);
}if (isoType == null ) {
isoType="EEE, d MMM yyyy HH:mm:ss Z";
} else if (isoType.contains$CharSequence("8601")) {
return p$1.newSimpleDateFormat$S.apply(this, ["yyyy-MM-dd\'T\'HH:mm:ss"]).format$java_util_Date(d);
} else if (isoType.contains$CharSequence("8824")) {
return p$1.newSimpleDateFormat$S.apply(this, ["yyyyMMddHHmmssX"]).format$java_util_Date(d);
}try {
return p$1.newSimpleDateFormat$S.apply(this, [isoType]).format$java_util_Date(d);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return "?";
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'newSimpleDateFormat$S',  function (format) {
return $I$(8,"getInstanceWithParams$S$ClassA$OA",["java.text.SimpleDateFormat", Clazz.array(Class, -1, [Clazz.getClass(String)]), Clazz.array(java.lang.Object, -1, [format])]);
}, p$1);

Clazz.newMeth(C$, 'newFile$S',  function (name) {
return Clazz.new_($I$(9,1).c$$S,[name]);
});

Clazz.newMeth(C$, 'getBufferedFileInputStream$S',  function (name) {
return $I$(9).getBufferedFileInputStream$S(name);
});

Clazz.newMeth(C$, 'getURLContents$java_net_URL$BA$S$Z',  function (url, outputBytes, post, asString) {
var ret=$I$(9).getURLContents$java_net_URL$BA$S(url, outputBytes, post);
try {
return (!asString ? ret : Clazz.instanceOf(ret, "java.lang.String") ? ret :  String.instantialize($I$(10).getStreamAsBytes$java_io_BufferedInputStream$javajs_util_OC(ret, null)));
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return "" + e;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getLocalUrl$S',  function (fileName) {
return $I$(9,"getLocalUrl$org_jmol_api_GenericFileInterface",[this.newFile$S(fileName)]);
});

Clazz.newMeth(C$, 'getImageDialog$S$java_util_Map',  function (title, imageMap) {
return $I$(5).getImageDialog$org_jmol_api_PlatformViewer$S$java_util_Map(this.vwr, title, imageMap);
});

Clazz.newMeth(C$, 'forceAsyncLoad$S',  function (filename) {
return false;
});

Clazz.newMeth(C$, 'isJS$',  function () {
return false;
});

Clazz.newMeth(C$, 'getInChI$',  function () {
return (C$.inchi == null  ? (C$.inchi=(true ||false ? Clazz.new_($I$(11,1)) : Clazz.new_($I$(12,1)))) : C$.inchi);
});

Clazz.newMeth(C$, 'confirm$S$S',  function (msg, msgNo) {
var ret=$I$(13,"showConfirmDialog$java_awt_Component$O",[null, $I$(14).$$S(msg)]);
switch (ret) {
case 0:
return ret;
case 2:
if (false &&true) return ret;
case 1:
default:
return (msgNo != null  && $I$(13,"showConfirmDialog$java_awt_Component$O",[null, $I$(14).$$S(msgNo)]) == 0  ? 1 : 2);
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:47 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
