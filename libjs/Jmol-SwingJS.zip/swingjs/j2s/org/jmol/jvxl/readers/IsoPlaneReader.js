(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers");
/*c*/var C$=Clazz.newClass(P$, "IsoPlaneReader", null, 'org.jmol.jvxl.readers.AtomDataReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init$org_jmol_jvxl_readers_SurfaceGenerator',  function (sg) {
this.initADR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
this.precalculateVoxelData=false;
});

Clazz.newMeth(C$, 'setup$Z',  function (isMapData) {
this.setup2$();
this.setHeader$S$S("PLANE", this.params.thePlane.toString());
this.params.cutoff=0;
this.setVolumeForPlane$();
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
