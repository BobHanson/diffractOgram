(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'javajs.util.P3d','javajs.util.PT']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CifDensityReader", null, 'org.jmol.jvxl.readers.BCifDensityReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getCifData$S$O',  function (fileName, data) {
this.cifData=this.sg.atomDataServer.readCifData$S$O$S(fileName, data, "CIF");
});

Clazz.newMeth(C$, 'readCifP3$S$javajs_util_P3d',  function (key, p3) {
if (p3 == null ) p3=Clazz.new_($I$(1,1));
var x=this.getCifFloat$S(key + "[0]");
if (Double.isNaN$D(x)) {
p3.x=NaN;
} else {
p3.x=x;
p3.y=this.getCifFloat$S(key + "[1]");
p3.z=this.getCifFloat$S(key + "[2]");
}return p3;
});

Clazz.newMeth(C$, 'getCifMap$S',  function (type) {
type="data_" + type;
var list=this.cifData.get$O("models");
for (var i=0; i < list.size$(); i++) {
var map=list.get$I(i);
if (type.equalsIgnoreCase$S(map.get$O("name").toString())) return this.thisData=map;
}
return null;
});

Clazz.newMeth(C$, 'getCifFloat$S',  function (key) {
var o=this.thisData.get$O(key);
var x=NaN;
if (o != null ) {
if (Clazz.instanceOf(o, "java.lang.String")) {
x=$I$(2).parseDouble$S(o);
} else if (Clazz.instanceOf(o, "java.lang.Number")) {
x=(o).doubleValue$();
}}return x;
});

Clazz.newMeth(C$, 'readCifFloats$S$DA',  function (key, values) {
var list=this.thisData.get$O(key);
for (var i=0, n=values.length; i < n; i++) values[i]=$I$(2,"parseDouble$S",[list.get$I(i)]);

return values;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
