(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "IsoMlpReader", null, 'org.jmol.jvxl.readers.IsoMepReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init$org_jmol_jvxl_readers_SurfaceGenerator',  function (sg) {
this.initIMR$org_jmol_jvxl_readers_SurfaceGenerator(sg);
this.type="Mlp";
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
