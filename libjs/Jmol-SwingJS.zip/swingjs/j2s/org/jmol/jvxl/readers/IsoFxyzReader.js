(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers");
/*c*/var C$=Clazz.newClass(P$, "IsoFxyzReader", null, 'org.jmol.jvxl.readers.IsoFxyReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['$data','double[][][]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'setup$Z',  function (isMapData) {
if (this.params.functionInfo.size$() > 5) this.$data=this.params.functionInfo.get$I(5);
this.setupType$S("functionXYZ");
});

Clazz.newMeth(C$, 'getValue$I$I$I$I',  function (x, y, z, xyz) {
return (this.$data == null  ? this.evaluateValue$I$I$I(x, y, z) : this.$data[x][y][z]);
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
