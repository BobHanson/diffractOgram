(function(){var P$=Clazz.newPackage("org.jmol.jvxl.readers"),I$=[[0,'javajs.util.SB','javajs.util.PT','org.jmol.jvxl.readers.VolumeFileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ApbsReader", null, 'org.jmol.jvxl.readers.VolumeFileReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'init2$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader',  function (sg, br) {
this.init2VFR$org_jmol_jvxl_readers_SurfaceGenerator$java_io_BufferedReader(sg, br);
if (this.params.thePlane == null ) this.params.insideOut=!this.params.insideOut;
this.isAngstroms=true;
this.nSurfaces=1;
});

Clazz.newMeth(C$, 'readParameters$',  function () {
this.jvxlFileHeaderBuffer=$I$(1,"newS$S",[this.skipComments$Z(false)]);
while (this.line != null  && this.line.length$() == 0 )this.rd$();

this.jvxlFileHeaderBuffer.append$S("APBS OpenDx DATA ").append$S(this.line).append$S("\n");
this.jvxlFileHeaderBuffer.append$S("see http://apbs.sourceforge.net\n");
var atomLine=this.rd$();
var tokens=$I$(2).getTokens$S(atomLine);
if (tokens.length >= 4) {
this.volumetricOrigin.set$D$D$D(this.parseDoubleStr$S(tokens[1]), this.parseDoubleStr$S(tokens[2]), this.parseDoubleStr$S(tokens[3]));
}$I$(3).checkAtomLine$Z$Z$S$S$javajs_util_SB(this.isXLowToHigh, this.isAngstroms, tokens[0], atomLine, this.jvxlFileHeaderBuffer);
this.readVoxelVector$I(0);
this.readVoxelVector$I(1);
this.readVoxelVector$I(2);
this.rd$();
tokens=this.getTokens$();
for (var i=0; i < 3; i++) this.voxelCounts[i]=this.parseIntStr$S(tokens[i + 5]);

this.rd$();
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
