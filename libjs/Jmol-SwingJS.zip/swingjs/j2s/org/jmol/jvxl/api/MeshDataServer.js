(function(){var P$=Clazz.newPackage("org.jmol.jvxl.api"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MeshDataServer", null, null, 'org.jmol.jvxl.api.VertexDataServer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
