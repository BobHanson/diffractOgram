(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "MSInterface");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-31 18:08:09 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
