(function(){var P$=Clazz.newPackage("org.jmol.adapter.smarter"),I$=[[0,'org.jmol.api.JmolAdapter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomIterator", null, null, 'org.jmol.api.JmolAdapterAtomIterator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['iatom','ac'],'O',['atom','org.jmol.adapter.smarter.Atom','atoms','org.jmol.adapter.smarter.Atom[]','bsAtoms','javajs.util.BS']]]

Clazz.newMeth(C$, 'c$$org_jmol_adapter_smarter_AtomSetCollection',  function (asc) {
;C$.$init$.apply(this);
this.ac=asc.ac;
this.atoms=asc.atoms;
this.bsAtoms=asc.bsAtoms;
this.iatom=0;
}, 1);

Clazz.newMeth(C$, 'hasNext$',  function () {
if (this.iatom == this.ac) return false;
while ((this.atom=this.atoms[this.iatom++]) == null  || (this.bsAtoms != null  && !this.bsAtoms.get$I(this.atom.index) ) )if (this.iatom == this.ac) return false;

this.atoms[this.iatom - 1]=null;
return true;
});

Clazz.newMeth(C$, 'getAtomSetIndex$',  function () {
return this.atom.atomSetIndex;
});

Clazz.newMeth(C$, 'getSymmetry$',  function () {
return this.atom.bsSymmetry;
});

Clazz.newMeth(C$, 'getAtomSite$',  function () {
return this.atom.atomSite + 1;
});

Clazz.newMeth(C$, 'getUniqueID$',  function () {
return Integer.valueOf$I(this.atom.index);
});

Clazz.newMeth(C$, 'getElementNumber$',  function () {
return (this.atom.elementNumber > 0 ? this.atom.elementNumber : $I$(1,"getElementNumber$S",[this.atom.getElementSymbol$()]));
});

Clazz.newMeth(C$, 'getAtomName$',  function () {
return this.atom.atomName;
});

Clazz.newMeth(C$, 'getFormalCharge$',  function () {
return (this.atom.formalCharge == -2147483648 ? 0 : this.atom.formalCharge);
});

Clazz.newMeth(C$, 'getPartialCharge$',  function () {
return this.atom.partialCharge;
});

Clazz.newMeth(C$, 'getTensors$',  function () {
return this.atom.tensors;
});

Clazz.newMeth(C$, 'getRadius$',  function () {
return this.atom.radius;
});

Clazz.newMeth(C$, 'getBondRadius$',  function () {
return this.atom.bondingRadius;
});

Clazz.newMeth(C$, 'getVib$',  function () {
return (this.atom.vib == null  || Double.isNaN$D(this.atom.vib.z)  ? null : this.atom.vib);
});

Clazz.newMeth(C$, 'getSeqID$',  function () {
return ((this.atom.seqIdOrWyckoffCode & (-2147483648)) == (-2147483648) ? this.atom.seqIdOrWyckoffCode & ~(-2147483648) : 0);
});

Clazz.newMeth(C$, 'getBfactor$',  function () {
return this.atom.bfactor;
});

Clazz.newMeth(C$, 'getOccupancy$',  function () {
return (this.atom.foccupancy * 100);
});

Clazz.newMeth(C$, 'getIsHetero$',  function () {
return this.atom.isHetero;
});

Clazz.newMeth(C$, 'getSerial$',  function () {
return this.atom.atomSerial;
});

Clazz.newMeth(C$, 'getChainID$',  function () {
return this.atom.chainID;
});

Clazz.newMeth(C$, 'getAltLoc$',  function () {
return $I$(1).canonizeAlternateLocationID$C(this.atom.altLoc);
});

Clazz.newMeth(C$, 'getGroup3$',  function () {
return this.atom.group3;
});

Clazz.newMeth(C$, 'getSequenceNumber$',  function () {
return this.atom.sequenceNumber;
});

Clazz.newMeth(C$, 'getInsertionCode$',  function () {
return $I$(1).canonizeInsertionCode$C(this.atom.insertionCode);
});

Clazz.newMeth(C$, 'getXYZ$',  function () {
return this.atom;
});

Clazz.newMeth(C$, 'getElement$',  function () {
return this.getElementNumber$() & 127;
});

Clazz.newMeth(C$, 'getIsotope$',  function () {
return this.getElementNumber$() >> 7;
});

Clazz.newMeth(C$, 'getPart$',  function () {
return this.atom.part;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:46 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
