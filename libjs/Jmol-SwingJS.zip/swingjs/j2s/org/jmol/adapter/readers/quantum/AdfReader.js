(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.quantum"),p$1={},I$=[[0,'org.jmol.util.Logger','javajs.util.PT','org.jmol.api.JmolAdapter','javajs.util.Lst','java.util.Hashtable',['org.jmol.adapter.readers.quantum.AdfReader','.SymmetryData'],'org.jmol.quantum.SlaterData','javajs.util.AU']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AdfReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.readers.quantum.SlaterReader');
C$.$classes$=[['SymmetryData',4]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nXX=0;
this.lastModel=-1;
},1);

C$.$fields$=[['Z',['isADF'],'I',['nXX','lastModel'],'S',['energy','symLine'],'O',['htSymmetries','java.util.Map','vSymmetries','javajs.util.Lst']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.isADF=true;
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.indexOf$S("Irreducible Representations, including subspecies") >= 0) {
this.readSymmetries$();
return true;
}if (this.line.indexOf$S("S F O s  ***  (Symmetrized Fragment Orbitals)  ***") >= 0) {
this.readSlaterBasis$();
return true;
}if (this.line.indexOf$S("current energy") >= 0) {
var tokens=$I$(2).getTokens$S(this.line);
this.energy=tokens[2];
return true;
}if (this.isADF ? this.line.indexOf$S(" Coordinates (Cartesian)") >= 0 || this.line.indexOf$S("G E O M E T R Y  ***") >= 0  : this.line.indexOf$S("Formula:") >= 0) {
if (!this.doGetModel$I$S(++this.modelNumber, null)) return this.checkLastModel$();
this.readCoordinates$();
return true;
}if (this.line.startsWith$S("Atomic charges")) {
p$1.readCharges.apply(this, []);
return true;
}if (this.line.indexOf$S(" ======  Eigenvectors (rows) in BAS representation") >= 0) {
if (this.doReadMolecularOrbitals) this.readMolecularOrbitals$S($I$(2).getTokens$S(this.symLine)[1]);
return true;
}if (!this.doProcessLines) {
return true;
}if (this.line.indexOf$S("Total Bonding Energy:") >= 0) {
var tokens=$I$(2,"getTokens$S",[this.line.substring$I(this.line.indexOf$S("Total Bonding Energy:"))]);
var bondingEnergy=tokens[3];
this.asc.setModelInfoForSet$S$O$I("bondingEnergy", Double.valueOf$S(bondingEnergy), this.asc.iSet);
this.asc.setAtomSetModelProperty$S$S("bondingEnergy", bondingEnergy);
return true;
}if (this.line.indexOf$S(this.isADF ? "Vibrations" : "Normal Modes") >= 0) {
this.readFrequencies$();
return true;
}if (this.line.indexOf$S(" === ") >= 0) {
this.symLine=this.line;
return true;
}if (this.line.indexOf$S(" ======  Eigenvectors (rows) in BAS representation") >= 0) {
this.readMolecularOrbitals$S($I$(2).getTokens$S(this.symLine)[1]);
return true;
}if (!this.isADF && this.line.startsWith$S(" Old frequency:") ) {
this.readOldFrequency$();
return true;
}return true;
});

Clazz.newMeth(C$, 'readOldFrequency$',  function () {
var tokens=$I$(2).getTokens$S(this.line);
var frqOld=$I$(2,"parseDouble$S",[tokens[2].replace$CharSequence$CharSequence(",", "")]);
var frqNew=$I$(2).parseDouble$S(tokens[4]);
var finalModel=this.modelNumber + this.vibrationNumber;
for (var i=this.modelNumber; i < finalModel; i++) {
var cname=this.asc.getAtomSetAuxiliaryInfoValue$I$S(i, "name");
var frqPrev=cname.replace$CharSequence$CharSequence(" cm^-1", "");
var frqOldFmt=$I$(2).formatStringD$S$S$D("%.3f", "f", frqOld);
if (frqOldFmt.equals$O(frqPrev)) {
var frqNewFmt=$I$(2).formatStringD$S$S$D("%.3f", "f", frqNew);
cname+=" (now " + frqNewFmt + " cm^-1)" ;
this.asc.setAtomSetModelPropertyForSet$S$S$I("name", cname, i);
break;
}}
});

Clazz.newMeth(C$, 'readCoordinates$',  function () {
var isGeometry=(!this.isADF || this.line.indexOf$S("G E O M E T R Y") >= 0 );
this.asc.newAtomSet$();
this.lastModel=this.asc.iSet;
var modelName="model " + String.valueOf$I(this.modelNumber);
if (this.energy != null ) modelName=modelName + " e=" + this.energy + " a.u." ;
this.asc.setAtomSetName$S(modelName);
var startGeomDelimiter=(this.isADF ? "----" : "Index Symbol");
var pt0=(isGeometry ? 2 : 5);
this.discardLinesUntilContains$S(startGeomDelimiter);
this.nXX=0;
var tokens;
while (this.rd$() != null  && !this.line.startsWith$S(" -----") ){
tokens=this.getTokens$();
if (tokens.length < 5) break;
var symbol=tokens[1];
var name=null;
if (symbol.indexOf$S(".") >= 0) {
name=symbol;
symbol=symbol.substring$I$I(0, symbol.indexOf$S("."));
}if ($I$(3).getElementNumber$S(symbol) < 1) ++this.nXX;
 else this.addAtomXYZSymName$SA$I$S$S(tokens, pt0, symbol, name);
}
});

Clazz.newMeth(C$, 'readFrequencies$',  function () {
this.rd$();
if (!this.isADF) {
this.discardLinesUntilContains$S("Number of removed rigid");
}while (this.rd$() != null ){
this.discardLinesUntilContains2$S$S(this.isADF ? "." : "Mode:", "====");
if (this.line == null  || this.line.indexOf$S(".") < 0 ) return;
var freqdata=this.getTokens$();
this.rd$();
var iAtom0=this.asc.ac;
var ac=this.asc.getLastAtomSetAtomCount$();
var frequencyCount=(this.isADF ? freqdata.length : 1);
var ignore=Clazz.array(Boolean.TYPE, [frequencyCount]);
for (var i=0; i < frequencyCount; ++i) {
ignore[i]=!this.doGetVibration$I(++this.vibrationNumber);
if (ignore[i]) continue;
var frequency=freqdata[this.isADF ? i : 4];
this.asc.cloneLastAtomSet$();
this.asc.setAtomSetFrequency$I$S$S$S$S(this.vibrationNumber, null, null, frequency, null);
}
this.readLines$I(this.nXX);
this.fillFrequencyData$I$I$I$ZA$Z$I$I$IA$I$SAA(iAtom0, ac, ac, ignore, true, 0, 0, null, 0, null);
}
});

Clazz.newMeth(C$, 'readSymmetries$',  function () {
this.vSymmetries=Clazz.new_($I$(4,1));
this.htSymmetries=Clazz.new_($I$(5,1));
this.rd$();
var index=0;
var syms="";
while (this.rd$() != null  && this.line.length$() > 1 )syms+=this.line;

var tokens=$I$(2).getTokens$S(syms);
for (var i=0; i < tokens.length; i++) {
var sd=Clazz.new_($I$(6,1).c$$I$S,[this, null, index++, tokens[i]]);
this.htSymmetries.put$O$O(tokens[i], sd);
this.vSymmetries.addLast$O(sd);
}
});

Clazz.newMeth(C$, 'readSlaterBasis$',  function () {
if (this.vSymmetries == null ) return;
var nBF=0;
for (var i=0; i < this.vSymmetries.size$(); i++) {
var sd=this.vSymmetries.get$I(i);
$I$(1).info$S(sd.sym);
this.discardLinesUntilContains$S("=== " + sd.sym + " ===" );
if (this.line == null ) {
$I$(1).error$S("Symmetry slater basis section not found: " + sd.sym);
return;
}sd.nSFO=this.parseIntAt$S$I(this.rd$(), 15);
sd.nBF=this.parseIntAt$S$I(this.rd$(), 75);
var funcList="";
while (this.rd$() != null  && this.line.length$() > 1 )funcList+=this.line;

var tokens=$I$(2).getTokens$S(funcList);
if (tokens.length != sd.nBF) return;
sd.basisFunctions=Clazz.array(Integer.TYPE, [tokens.length]);
for (var j=tokens.length; --j >= 0; ) {
var n=this.parseIntStr$S(tokens[j]);
if (n > nBF) nBF=n;
sd.basisFunctions[j]=n - 1;
}
}
this.slaterArray=Clazz.array($I$(7), [nBF]);
this.discardLinesUntilContains$S("(power of)");
this.readLines$I(2);
while (this.rd$() != null  && this.line.length$() > 3  && this.line.charAt$I(3) == " " ){
var data=this.line;
while (this.rd$().indexOf$S("---") < 0)data+=this.line;

var tokens=$I$(2).getTokens$S(data);
var nAtoms=tokens.length - 1;
var atomList=Clazz.array(Integer.TYPE, [nAtoms]);
for (var i=1; i <= nAtoms; i++) atomList[i - 1]=this.parseIntStr$S(tokens[i]) - 1;

this.rd$();
while (this.line.length$() >= 10){
data=this.line;
while (this.rd$().length$() > 35 && this.line.substring$I$I(0, 35).trim$().length$() == 0 )data+=this.line;

tokens=$I$(2).getTokens$S(data);
var isCore=tokens[0].equals$O("Core");
var pt=(isCore ? 1 : 0);
var x=this.parseIntStr$S(tokens[pt++]);
var y=this.parseIntStr$S(tokens[pt++]);
var z=this.parseIntStr$S(tokens[pt++]);
var r=this.parseIntStr$S(tokens[pt++]);
var zeta=this.parseDoubleStr$S(tokens[pt++]);
for (var i=0; i < nAtoms; i++) {
var ptBF=this.parseIntStr$S(tokens[pt++]) - 1;
this.slaterArray[ptBF]=Clazz.new_($I$(7,1).c$$I$I$I$I$I$D$D,[atomList[i], x, y, z, r, zeta, 1]);
this.slaterArray[ptBF].index=ptBF;
}
}
}
});

Clazz.newMeth(C$, 'readMolecularOrbitals$S',  function (sym) {
var sd=this.htSymmetries.get$O(sym);
if (sd == null ) return;
var ptSym=sd.index;
var isLast=(ptSym == this.vSymmetries.size$() - 1);
var n=0;
var nBF=this.slaterArray.length;
sd.coefs=Clazz.array(Double.TYPE, [sd.nSFO, nBF]);
while (n < sd.nBF){
this.rd$();
var nLine=$I$(2,"getTokens$S",[this.rd$()]).length;
this.rd$();
sd.mos=$I$(8).createArrayOfHashtable$I(sd.nSFO);
var data=Clazz.array(String, [sd.nSFO, null]);
this.fillDataBlock$SAA$I(data, 0);
for (var j=1; j < nLine; j++) {
var pt=sd.basisFunctions[n++];
for (var i=0; i < sd.nSFO; i++) sd.coefs[i][pt]=this.parseDoubleStr$S(data[i][j]);

}
}
for (var i=0; i < sd.nSFO; i++) {
var mo=Clazz.new_($I$(5,1));
mo.put$O$O("coefficients", sd.coefs[i]);
mo.put$O$O("id", sym + " " + (i + 1) );
sd.mos[i]=mo;
}
if (!isLast) return;
var nSym=this.htSymmetries.size$();
this.discardLinesUntilContains$S(nSym == 1 ? "Orbital Energies, per Irrep" : "Orbital Energies, all Irreps");
this.readLines$I(4);
var pt=(nSym == 1 ? 0 : 1);
if (nSym == 1) sym=this.rd$().trim$();
while (this.rd$() != null  && this.line.length$() > 10 ){
this.line=this.line.replace$C$C("(", " ").replace$C$C(")", " ");
var tokens=this.getTokens$();
var len=tokens.length;
if (nSym > 1) sym=tokens[0];
var moPt=this.parseIntStr$S(tokens[pt]);
var occ=this.parseDoubleStr$S(tokens[len - 4 + pt]);
var energy=this.parseDoubleStr$S(tokens[len - 2 + pt]);
this.addMo$S$I$D$D(sym, moPt, occ, energy);
}
var iAtom0=this.asc.getLastAtomSetAtomIndex$();
for (var i=0; i < nBF; i++) this.slaterArray[i].atomNo+=iAtom0 + 1;

this.setSlaters$Z(true);
this.sortOrbitals$();
this.setMOs$S("eV");
});

Clazz.newMeth(C$, 'addMo$S$I$D$D',  function (sym, moPt, occ, energy) {
var sd=this.htSymmetries.get$O(sym);
if (sd == null ) {
for (var entry, $entry = this.htSymmetries.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) if (entry.getKey$().startsWith$S(sym + ":")) {
sd=entry.getValue$();
break;
}
if (sd == null ) return;
}var mo=sd.mos[moPt - 1];
mo.put$O$O("occupancy", Double.valueOf$D(occ > 2  ? 2 : occ));
mo.put$O$O("energy", Double.valueOf$D(energy));
mo.put$O$O("symmetry", sd.sym + "_" + moPt );
this.setMO$java_util_Map(mo);
});

Clazz.newMeth(C$, 'readCharges',  function () {
if (this.lastModel < 0) return;
this.rd$();
this.rd$();
var n=this.asc.getAtomSetAtomCount$I(this.lastModel);
var charges=Clazz.array(Double.TYPE, [n]);
for (var i=0; i < n; i++) {
this.rd$();
var tokens=this.getTokens$();
var iatom=this.parseIntStr$S(tokens[0]);
charges[iatom - 1]=this.parseDoubleStr$S(tokens[2]);
}
for (var p=0, i=this.asc.getAtomSetAtomIndex$I(this.lastModel); i < this.asc.ac; i++, p=(p + 1) % n) {
this.asc.atoms[i].partialCharge=charges[p];
}
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.AdfReader, "SymmetryData", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index','nSFO','nBF'],'S',['sym'],'O',['coefs','double[][]','mos','java.util.Map[]','basisFunctions','int[]']]]

Clazz.newMeth(C$, 'c$$I$S',  function (index, sym) {
;C$.$init$.apply(this);
$I$(1,"info$S",[(this.b$['org.jmol.adapter.readers.quantum.AdfReader'].isADF ? "ADF" : "AMS") + " reader creating SymmetryData " + sym + " " + index ]);
this.index=index;
this.sym=sym;
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:42 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
