(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.pymol"),p$1={},I$=[[0,'org.jmol.util.BSUtil','java.util.Hashtable','javajs.util.SB','javajs.util.PT','org.jmol.util.Escape','org.jmol.adapter.readers.pymol.PyMOLReader','javajs.util.P3d']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JmolObject");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.size=-1;
this.modelIndex=-2147483648;
this.translucency=0;
this.visible=true;
},1);

C$.$fields$=[['Z',['visible','doCache'],'D',['translucency'],'I',['shape','size','modelIndex','argb'],'S',['jmolName','cacheID'],'O',['bsAtoms','javajs.util.BS','info','java.lang.Object','colors','Object[]','rd','org.jmol.atomdata.RadiusData']]]

Clazz.newMeth(C$, 'c$$I$S$javajs_util_BS$O',  function (shape, branchNameID, bsAtoms, info) {
;C$.$init$.apply(this);
this.shape=shape;
this.bsAtoms=bsAtoms;
this.info=info;
this.jmolName=branchNameID;
}, 1);

Clazz.newMeth(C$, 'offset$I$I',  function (modelOffset, atomOffset) {
if (modelOffset > 0) {
if (this.modelIndex != -2147483648) this.modelIndex+=modelOffset;
switch (this.shape) {
case 1610625028:
case 12294:
return;
case 4115:
var i=(this.info).intValue$();
if (i >= 0) this.info=Integer.valueOf$I(modelOffset + i);
return;
case 1073742031:
var movie=this.info;
var frames=movie.get$O("frames");
for (var j=frames.length; --j >= 0; ) frames[j]+=modelOffset;

return;
}
}if (atomOffset <= 0) return;
if (this.shape == 12290) {
var map=(this.info).values$();
for (var o, $o = map.iterator$(); $o.hasNext$()&&((o=($o.next$())),1);) $I$(1).offset$javajs_util_BS$I$I(o, 0, atomOffset);

return;
}if (this.bsAtoms != null ) $I$(1).offset$javajs_util_BS$I$I(this.bsAtoms, 0, atomOffset);
if (this.colors != null ) {
var colixes=this.colors[0];
var c=Clazz.array(Short.TYPE, [colixes.length + atomOffset]);
System.arraycopy$O$I$O$I$I(colixes, 0, c, atomOffset, colixes.length);
this.colors[0]=c;
}});

Clazz.newMeth(C$, 'finalizeObject$org_jmol_adapter_readers_pymol_PyMOLScene$org_jmol_modelset_ModelSet$S$Z',  function (pymolScene, m, mepList, doCache) {
var sm=m.sm;
var color="color";
var sID;
var sb=null;
if (this.bsAtoms != null ) this.modelIndex=p$1.getModelIndex$org_jmol_modelset_ModelSet.apply(this, [m]);
switch (this.shape) {
case 2097194:
sm.vwr.displayAtoms$javajs_util_BS$Z$Z$I$Z(this.bsAtoms, false, false, 1275069441, true);
return false;
case 12295:
var bs=sm.vwr.getModelUndeletedAtomsBitSet$I(this.argb);
$I$(1).invertInPlace$javajs_util_BS$I(bs, sm.vwr.ms.ac);
sm.vwr.select$javajs_util_BS$Z$I$Z(bs, false, 0, true);
sm.restrictSelected$Z$Z(false, true);
return false;
case 1610625028:
case 12294:
if (this.bsAtoms == null ) {
if (this.info == null ) {
sm.vwr.displayAtoms$javajs_util_BS$Z$Z$I$Z(null, true, false, 0, true);
}sm.vwr.setObjectProp$S$I(this.info, this.shape);
} else {
sm.vwr.displayAtoms$javajs_util_BS$Z$Z$I$Z(this.bsAtoms, this.shape == 1610625028, false, 1275069441, true);
}return false;
case 12290:
sm.vwr.defineAtomSets$java_util_Map(this.info);
return false;
case 1073742031:
sm.vwr.am.setMovie$java_util_Map(this.info);
return false;
case 4115:
var frame=(this.info).intValue$();
if (frame >= 0) {
sm.vwr.setCurrentModelIndex$I(frame);
} else {
sm.vwr.setAnimationRange$I$I(-1, -1);
sm.vwr.setCurrentModelIndex$I(-1);
}return false;
case 1073742139:
sm.vwr.stm.saveScene$S$java_util_Map(this.jmolName, this.info);
sm.vwr.stm.saveOrientation$S$DA(this.jmolName, (this.info).get$O("pymolView"));
return false;
case 5:
sm.loadShape$I(this.shape);
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "pymolLabels", this.info, this.bsAtoms);
return false;
case 1677721602:
break;
case 659488:
case 1:
if (this.size != -1) {
sm.setShapeSizeBs$I$I$org_jmol_atomdata_RadiusData$javajs_util_BS(1, this.size, null, this.bsAtoms);
var bsBonds=sm.vwr.getBondsForSelectedAtoms$javajs_util_BS(this.bsAtoms);
if (this.info != null ) {
var o=this.info;
var bsH=o[0];
var stick_h_scale=(o[1]).floatValue$();
var hsize=((this.size * stick_h_scale)|0);
sm.vwr.setBooleanProperty$S$Z("bondmodeor", true);
sm.setShapeSizeBs$I$I$org_jmol_atomdata_RadiusData$javajs_util_BS(1, hsize, null, bsH);
sm.vwr.setBooleanProperty$S$Z("bondmodeor", false);
}pymolScene.setUniqueBonds$javajs_util_BS$Z(bsBonds, this.shape == 1);
this.size=-1;
}this.shape=1;
break;
case 1153433601:
this.shape=0;
break;
case 0:
break;
case 10:
case 9:
sm.loadShape$I(this.shape);
var bsCarb=m.getAtoms$I$O(2097188, null);
$I$(1).andNot$javajs_util_BS$javajs_util_BS(this.bsAtoms, bsCarb);
break;
case 16:
sm.loadShape$I(this.shape);
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "ignore", $I$(1).copyInvert$javajs_util_BS$I(this.bsAtoms, sm.vwr.ms.ac), null);
break;
default:
if (!this.visible) return false;
break;
}
switch (this.shape) {
case 134222850:
sb=this.info;
break;
case 6:
if (this.modelIndex < 0) return false;
sm.loadShape$I(this.shape);
var md=this.info;
md.setModelSet$org_jmol_modelset_ModelSet(m);
var points=md.points;
for (var i=points.size$(); --i >= 0; ) (points.get$I(i)).mi=($s$[0] = this.modelIndex, $s$[0]);

sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "measure", md, this.bsAtoms);
return false;
case 1112152078:
sm.loadShape$I(this.shape=10);
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "putty", this.info, this.bsAtoms);
break;
case 24:
System.out.println$S("JO ISO");
case 16:
case 0:
case 7:
case 20:
case 11:
case 9:
case 10:
if (Clazz.instanceOf(this.info, Clazz.array(java.lang.Object, -1))) {
sm.loadShape$I(this.shape);
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "pymolparams", this.info, this.bsAtoms);
}break;
case 23:
var map=Clazz.new_($I$(2,1));
map.put$O$O("cgoMeshWidth", Double.valueOf$D(pymolScene.getDoubleOrDefault$I(90)));
map.put$O$O("cgoMeshInfo", this.info);
sm.vwr.setCGO$java_util_Map(map);
break;
case 135180:
sID=(this.bsAtoms == null  ? this.info : this.jmolName);
if (sm.getShapeIdFromObjectName$S(sID) >= 0) {
sm.vwr.setObjectProp$S$I(sID, 1610625028);
return this.doCache;
}sb=Clazz.new_($I$(3,1));
sb.append$S("isosurface ID ").append$S($I$(4).esc$S(sID));
if (this.modelIndex < 0) this.modelIndex=sm.vwr.am.cmi;
if (this.bsAtoms == null ) {
sb.append$S(" model ").append$S(m.getModelNumberDotted$I(this.modelIndex)).append$S(" color density sigma 1.0 ").append$S($I$(4).esc$S(this.cacheID)).append$S(" ").append$S($I$(4).esc$S(sID));
if (doCache) this.doCache=true;
} else {
var lighting=(this.info)[0];
var only=(this.info)[1];
only=" only";
var bsCarve=(this.info)[2];
var carveDistance=((this.info)[3]).doubleValue$();
var resolution="";
if (lighting == null ) {
lighting="mesh nofill";
resolution=" resolution 1.5";
}var haveMep=$I$(4).isOneOf$S$S(sID, mepList);
var model=m.getModelNumberDotted$I(this.modelIndex);
var ignore="";
var type=(this.size < 0 ? " sasurface " : " solvent ");
sb.append$S(" model ").append$S(model).append$S(resolution).append$S(" select ").append$S($I$(5).eBS$javajs_util_BS(this.bsAtoms)).append$S(only).append$S(ignore).append$S(type).appendD$D(Math.abs(this.size / 1000.0));
if (!haveMep) {
if (this.argb == 0) sb.append$S(" map property color");
 else sb.append$S(";color isosurface ").append$S($I$(5).escapeColor$I(this.argb));
}sb.append$S(";isosurface frontOnly ").append$S(lighting);
if (this.translucency > 0 ) sb.append$S(";color isosurface translucent " + new Double(this.translucency).toString());
if (bsCarve != null  && !bsCarve.isEmpty$() ) sb.append$S(";isosurface slab within " + new Double(carveDistance).toString() + " {" + model + " and " + $I$(5).eBS$javajs_util_BS(bsCarve) + "}" );
if (doCache && !haveMep ) this.doCache=true;
}break;
case 1073742016:
var mep=this.info;
sID=mep.get$I(mep.size$() - 2).toString();
var mapID=mep.get$I(mep.size$() - 1).toString();
var min=$I$(6,"floatAt$javajs_util_Lst$I",[$I$(6).listAt$javajs_util_Lst$I(mep, 3), 0]);
var max=$I$(6,"floatAt$javajs_util_Lst$I",[$I$(6).listAt$javajs_util_Lst$I(mep, 3), 2]);
sb=Clazz.new_($I$(3,1));
sb.append$S(";isosurface ID ").append$S($I$(4).esc$S(sID)).append$S(" map ").append$S($I$(4).esc$S(this.cacheID)).append$S(" ").append$S($I$(4).esc$S(mapID)).append$S(";color isosurface range " + new Double(min).toString() + " " + new Double(max).toString() + ";isosurface colorscheme rwb;set isosurfacekey true" );
if (this.translucency > 0 ) sb.append$S(";color isosurface translucent " + new Double(this.translucency).toString());
this.doCache=doCache;
break;
case 1073742018:
this.modelIndex=sm.vwr.am.cmi;
var mesh=this.info;
sID=mesh.get$I(mesh.size$() - 2).toString();
sb=Clazz.new_($I$(3,1));
sb.append$S("isosurface ID ").append$S($I$(4).esc$S(sID)).append$S(" model ").append$S(m.getModelNumberDotted$I(this.modelIndex)).append$S(" color ").append$S($I$(5).escapeColor$I(this.argb)).append$S("  ").append$S($I$(4).esc$S(this.cacheID)).append$S(" ").append$S($I$(4).esc$S(sID)).append$S(" mesh nofill frontonly");
var list=$I$(6,"sublistAt$javajs_util_Lst$IA",[mesh, Clazz.array(Integer.TYPE, -1, [2, 0])]);
var within=$I$(6).floatAt$javajs_util_Lst$I(list, 11);
list=$I$(6).listAt$javajs_util_Lst$I(list, 12);
if (within > 0 ) {
var pt=Clazz.new_($I$(7,1));
sb.append$S(";isosurface slab within ").appendD$D(within).append$S(" [ ");
for (var j=list.size$() - 3; j >= 0; j-=3) {
$I$(6).pointAt$javajs_util_Lst$I$javajs_util_P3d(list, j, pt);
sb.append$S($I$(5).eP$javajs_util_T3d(pt));
}
sb.append$S(" ]");
}sb.append$S(";set meshScale ").appendI$I((this.size/500|0));
this.doCache=(doCache && !$I$(4).isOneOf$S$S(sID, mepList) );
break;
}
if (sb == null ) {
if (this.size != -1 || this.rd != null  ) sm.setShapeSizeBs$I$I$org_jmol_atomdata_RadiusData$javajs_util_BS(this.shape, this.size, this.rd, this.bsAtoms);
if (this.argb != 0) sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, color, Integer.valueOf$I(this.argb), this.bsAtoms);
if (this.translucency > 0 ) {
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "translucentLevel", Double.valueOf$D(this.translucency), this.bsAtoms);
sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "translucency", "translucent", this.bsAtoms);
} else if (this.colors != null ) sm.setShapePropertyBs$I$S$O$javajs_util_BS(this.shape, "colors", this.colors, this.bsAtoms);
} else {
sm.vwr.runScriptCautiously$S(sb.toString());
}return this.doCache;
});

Clazz.newMeth(C$, 'getModelIndex$org_jmol_modelset_ModelSet',  function (m) {
if (this.bsAtoms == null ) return -1;
var iAtom=this.bsAtoms.nextSetBit$I(0);
if (iAtom >= m.at.length) System.err.println$S("JmolObject PyMOL LOADING ERROR IN MERGE. atom index too large");
return (iAtom < 0 ? ($s$[0] = -1, $s$[0]) : m.at[iAtom].mi);
}, p$1);

Clazz.newMeth(C$, 'setColors$HA$D',  function (colixes, translucency) {
this.colors=Clazz.array(java.lang.Object, -1, [colixes, Double.valueOf$D(translucency)]);
});

Clazz.newMeth(C$, 'setSize$D',  function (size) {
this.size=((size * 1000)|0);
});

Clazz.newMeth(C$, 'toString',  function () {
return "[JmolObject " + this.shape + " " + (this.bsAtoms == null  ? "" : this.bsAtoms.cardinality$() + " atoms") + "]" ;
});
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-30 14:46:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
