(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.molxyz"),p$1={},I$=[[0,'org.jmol.util.Logger','org.jmol.api.JmolAdapter','java.util.Hashtable','javajs.util.Lst','javajs.util.PT','javajs.util.BS','org.jmol.adapter.smarter.Atom']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.allow2D=true;
},1);

C$.$fields$=[['Z',['haveAtomSerials','allow2D','haveNonzeroZ','fixN','is3D'],'I',['iatom0','atomCount','nDouble','nH','nC'],'O',['vr','org.jmol.adapter.readers.molxyz.V3000Rdr','atomData','String[]','bsDeleted','javajs.util.BS']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.fixN=this.checkFilterKey$S("FIXN");
});

Clazz.newMeth(C$, 'checkLine$',  function () {
var isMDL=(this.line.startsWith$S("$MDL"));
if (isMDL) {
this.discardLinesUntilStartsWith$S("$HDR");
this.rd$();
if (this.line == null ) {
$I$(1).warn$S("$HDR not found in MDL RG file");
this.continuing=false;
return false;
}} else if (this.line.equals$O("M  END")) {
return true;
}if (this.doGetModel$I$S(++this.modelNumber, null)) {
this.iatom0=this.asc.ac;
p$1.processMolSdHeader.apply(this, []);
p$1.processCtab$Z.apply(this, [isMDL]);
this.vr=null;
if (this.isLastModel$I(this.modelNumber)) {
this.continuing=false;
return false;
}}if (this.line != null  && this.line.indexOf$S("$$$$") < 0 ) this.discardLinesUntilStartsWith$S("$$$$");
return true;
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
this.finalizeReaderMR$();
});

Clazz.newMeth(C$, 'finalizeReaderMR$',  function () {
if (this.fixN) {
this.addJmolScript$S("{search(\'[Nv4+0,nv4+0]\')}.formalCharge=1;{search(\'{[Ov1-0]}[Nv4+1,nv4+1]\')}.formalCharge=-1;");
}p$1.check2D3D.apply(this, []);
if (this.bsDeleted != null ) {
this.asc.getBSAtoms$I(-1).andNot$javajs_util_BS(this.bsDeleted);
}this.isTrajectory=false;
this.finalizeReaderASCR$();
});

Clazz.newMeth(C$, 'check2D3D',  function () {
if (this.haveNonzeroZ) {
if (this.is2D) {
this.is2D=this.optimize2D=false;
}} else if (!this.is2D && !this.is3D ) {
if (this.nC > 0 && this.nH == 0  && this.nDouble != 0 ) {
this.is2D=true;
}}if (this.is2D) {
if (!this.allow2D) {
throw Clazz.new_(Clazz.load('Exception').c$$S,["File is 2D, not 3D"]);
}this.set2D$();
}}, p$1);

Clazz.newMeth(C$, 'processMolSdHeader',  function () {
var thisDataSetName=this.line.trim$();
this.asc.setCollectionName$S(thisDataSetName);
var header=this.line + "\n";
this.rd$();
if (this.line == null ) return;
header+=this.line + "\n";
var dim=(this.line.length$() >= 22 ? this.line.substring$I$I(20, 22) : null);
this.is3D="3D".equals$O(dim);
this.is2D=!this.is3D && ("2D".equals$O(dim) || this.line.startsWith$S("JME ") ) ;
this.rd$();
if (this.line == null ) return;
this.line=this.line.trim$();
header+=this.line + "\n";
$I$(1).info$S(header);
this.checkCurrentLineForScript$();
this.asc.setInfo$S$O("fileHeader", header);
this.newAtomSet$S(thisDataSetName);
}, p$1);

Clazz.newMeth(C$, 'processCtab$Z',  function (isMDL) {
if (isMDL) this.discardLinesUntilStartsWith$S("$CTAB");
if (this.rd$() == null ) return;
if (this.line.indexOf$S("V3000") >= 0) {
this.optimize2D=this.is2D && !this.noHydrogens ;
this.vr=(this.getInterface$S("org.jmol.adapter.readers.molxyz.V3000Rdr")).set$org_jmol_adapter_smarter_AtomSetCollectionReader(this);
this.discardLinesUntilContains$S("COUNTS");
this.vr.readAtomsAndBonds$SA(this.getTokens$());
} else {
p$1.readAtomsAndBonds$I$I.apply(this, [this.parseIntRange$S$I$I(this.line, 0, 3), this.parseIntRange$S$I$I(this.line, 3, 6)]);
}this.applySymmetryAndSetTrajectory$();
}, p$1);

Clazz.newMeth(C$, 'readAtomsAndBonds$I$I',  function (ac, bc) {
this.atomCount=ac;
for (var i=0; i < ac; ++i) {
this.rd$();
var len=this.line.length$();
var elementSymbol;
var x;
var y;
var z;
var charge=0;
var isotope=0;
var iAtom=-2147483648;
x=this.parseDoubleRange$S$I$I(this.line, 0, 10);
y=this.parseDoubleRange$S$I$I(this.line, 10, 20);
z=this.parseDoubleRange$S$I$I(this.line, 20, 30);
if (len < 34) {
elementSymbol=this.line.substring$I(31).trim$();
} else {
elementSymbol=this.line.substring$I$I(31, 34).trim$();
if (elementSymbol.equals$O("H1")) {
elementSymbol="H";
isotope=1;
}if (len >= 39) {
var code=this.parseIntRange$S$I$I(this.line, 36, 39);
if (code >= 1 && code <= 7 ) charge=4 - code;
code=this.parseIntRange$S$I$I(this.line, 34, 36);
if (code != 0 && code >= -3  && code <= 4 ) {
isotope=$I$(2,"getNaturalIsotope$I",[$I$(2).getElementNumber$S(elementSymbol)]) + code;
}if (iAtom == -2147483648 && this.haveAtomSerials ) iAtom=i + 1;
}}this.addMolAtom$I$I$S$I$D$D$D(iAtom, isotope, elementSymbol, charge, x, y, z);
}
this.asc.setModelInfoForSet$S$O$I("dimension", (this.is2D ? "2D" : "3D"), this.asc.iSet);
this.rd$();
if (this.line.startsWith$S("V  ")) {
p$1.readAtomValues.apply(this, []);
}if (bc == 0) this.asc.setNoAutoBond$();
for (var i=0; i < bc; ++i) {
if (i > 0) this.rd$();
var iAtom1;
var iAtom2;
var stereo=0;
iAtom1=this.line.substring$I$I(0, 3).trim$();
iAtom2=this.line.substring$I$I(3, 6).trim$();
var order=this.parseIntRange$S$I$I(this.line, 6, 9);
if (order == 1 && this.line.length$() >= 12 ) stereo=this.parseIntRange$S$I$I(this.line, 9, 12);
if (stereo != 0 && !this.is3D ) this.is2D=true;
order=this.fixOrder$I$I(order, stereo);
if (this.haveAtomSerials) this.asc.addNewBondFromNames$S$S$I(iAtom1, iAtom2, order);
 else this.asc.addNewBondWithOrder$I$I$I(this.iatom0 + this.parseIntStr$S(iAtom1) - 1, this.iatom0 + this.parseIntStr$S(iAtom2) - 1, order);
}
var molData=Clazz.new_($I$(3,1));
var _keyList=Clazz.new_($I$(4,1));
this.rd$();
while (this.line != null  && this.line.indexOf$S("$$$$") != 0 ){
if (this.line.indexOf$S(">") == 0) {
p$1.readMolData$java_util_Map$javajs_util_Lst.apply(this, [molData, _keyList]);
continue;
}if (this.line.startsWith$S("M  ISO")) {
p$1.readIsotopes.apply(this, []);
continue;
}if (this.line.startsWith$S("M  CHG")) {
p$1.readCharges.apply(this, []);
continue;
}this.rd$();
}
if (this.atomData != null ) {
var atomValueName=molData.get$O("atom_value_name");
molData.put$O$O(atomValueName == null  ? "atom_values" : atomValueName.toString(), this.atomData);
}if (!molData.isEmpty$()) {
this.asc.setCurrentModelInfo$S$O("molDataKeys", _keyList);
this.asc.setCurrentModelInfo$S$O("molData", molData);
}}, p$1);

Clazz.newMeth(C$, 'readAtomValues',  function () {
this.atomData=Clazz.array(String, [this.atomCount]);
for (var i=this.atomData.length; --i >= 0; ) this.atomData[i]="";

while (this.line.indexOf$S("V  ") == 0){
var iAtom=this.parseIntAt$S$I(this.line, 3);
if (iAtom < 1 || iAtom > this.atomCount ) {
$I$(1).error$S("V  nnn does not evalute to a valid atom number: " + iAtom);
return;
}var s=this.line.substring$I(6).trim$();
this.atomData[iAtom - 1]=s;
this.rd$();
}
}, p$1);

Clazz.newMeth(C$, 'readIsotopes',  function () {
try {
var n=this.parseIntAt$S$I(this.line, 6);
var i0=this.asc.getLastAtomSetAtomIndex$();
for (var i=0, pt=9; i < n; i++) {
var ipt=this.parseIntAt$S$I(this.line, pt);
var atom=this.asc.atoms[ipt + i0 - 1];
var iso=this.parseIntAt$S$I(this.line, pt + 4);
pt+=8;
var sym=$I$(5).replaceAllCharacters$S$S$S(atom.elementSymbol, "0123456789", "");
if (iso == 17 && sym.equals$O("C") ) {
atom.elementSymbol="N";
} else if (iso == 5 && sym.equals$O("H") ) {
this.deleteAtom$org_jmol_adapter_smarter_Atom(atom);
} else {
atom.elementSymbol="" + iso + sym ;
}}
} catch (e) {
}
this.rd$();
}, p$1);

Clazz.newMeth(C$, 'readCharges',  function () {
try {
var n=this.parseIntAt$S$I(this.line, 6);
var i0=this.asc.getLastAtomSetAtomIndex$();
for (var i=this.asc.ac; --i >= i0; ) {
this.asc.atoms[i].formalCharge=0;
}
for (var i=0, pt=9; i < n; i++, pt+=8) {
this.asc.atoms[this.parseIntAt$S$I(this.line, pt) + i0 - 1].formalCharge=this.parseIntAt$S$I(this.line, pt + 4);
}
} catch (e) {
}
this.rd$();
}, p$1);

Clazz.newMeth(C$, 'deleteAtom$org_jmol_adapter_smarter_Atom',  function (atom) {
if (this.bsDeleted == null ) this.bsDeleted=Clazz.new_($I$(6,1));
this.bsDeleted.set$I(atom.index);
});

Clazz.newMeth(C$, 'readMolData$java_util_Map$javajs_util_Lst',  function (molData, _keyList) {
var atoms=this.asc.atoms;
var dataName=$I$(5).trim$S$S(this.line, "> <").toLowerCase$();
var data="";
var fdata=null;
while (this.rd$() != null  && !this.line.equals$O("$$$$")  && this.line.length$() > 0 )data+=(this.line.length$() == 81 && this.line.charAt$I(80) == "+"  ? this.line.substring$I$I(0, 80) : this.line + "\n");

data=$I$(5).trim$S$S(data, "\n");
$I$(1,"info$S",[dataName + ":" + $I$(5).esc$S(data) ]);
molData.put$O$O(dataName, data);
_keyList.addLast$O(dataName);
var ndata=0;
if (dataName.toUpperCase$().contains$CharSequence("_PARTIAL_CHARGES")) {
try {
fdata=$I$(5).parseDoubleArray$S(data);
for (var i=this.asc.getLastAtomSetAtomIndex$(), n=this.asc.ac; i < n; i++) atoms[i].partialCharge=0;

var pt=0;
for (var i=(fdata[pt++]|0); --i >= 0; ) {
var atomIndex=(fdata[pt++]|0) + this.iatom0 - 1;
var partialCharge=fdata[pt++];
atoms[atomIndex].partialCharge=partialCharge;
++ndata;
}
} catch (e) {
for (var i=this.asc.getLastAtomSetAtomIndex$(), n=this.asc.ac; i < n; i++) atoms[i].partialCharge=0;

$I$(1).error$S("error reading " + dataName + " field -- partial charges cleared" );
}
$I$(1).info$S(ndata + " partial charges read");
} else if (dataName.toUpperCase$().contains$CharSequence("ATOM_NAMES")) {
ndata=0;
try {
var tokens=$I$(5).getTokens$S(data);
var pt=0;
for (var i=this.parseIntStr$S(tokens[pt++]); --i >= 0; ) {
var iatom;
while ((iatom=this.parseIntStr$S(tokens[pt++])) == -2147483648){
}
var atomIndex=iatom + this.iatom0 - 1;
var name=tokens[pt++];
if (!name.equals$O(".")) atoms[atomIndex].atomName=name;
++ndata;
}
} catch (e) {
$I$(1).error$S("error reading " + dataName + " field" );
}
$I$(1).info$S(ndata + " atom names read");
}}, p$1);

Clazz.newMeth(C$, 'addMolAtom$I$I$S$I$D$D$D',  function (iAtom, isotope, elementSymbol, charge, x, y, z) {
if ("H".equals$O(elementSymbol)) ++this.nH;
 else if ("C".equals$O(elementSymbol)) ++this.nC;
this.haveNonzeroZ=!!(this.haveNonzeroZ|((Math.abs(z) > 0.001 )));
switch (isotope) {
case 0:
break;
case 1:
elementSymbol="1H";
break;
case 2:
elementSymbol="2H";
break;
case 3:
elementSymbol="3H";
break;
default:
elementSymbol=isotope + elementSymbol;
}
var atom=Clazz.new_($I$(7,1));
atom.elementSymbol=elementSymbol;
atom.formalCharge=charge;
this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atom, x, y, z);
if (iAtom == -2147483648) {
this.asc.addAtom$org_jmol_adapter_smarter_Atom(atom);
} else {
this.haveAtomSerials=true;
atom.atomSerial=iAtom;
this.asc.addAtomWithMappedSerialNumber$org_jmol_adapter_smarter_Atom(atom);
}return atom;
});

Clazz.newMeth(C$, 'fixOrder$I$I',  function (order, stereo) {
switch (order) {
default:
case 0:
case -10:
return 1;
case 1:
switch (stereo) {
case 1:
this.is2D=true;
return 1025;
case 3:
case 6:
this.is2D=true;
return 1041;
case 2:
case 4:
this.is2D=true;
return 1057;
}
break;
case 2:
case 3:
++this.nDouble;
break;
case 4:
return 515;
case 5:
return 66;
case 6:
return 513;
case 7:
return 514;
case 8:
case 9:
return 33;
case 14:
return 4;
case 15:
return 5;
case 16:
return 6;
}
return order;
});

Clazz.newMeth(C$, 'addMolBond$S$S$I$I',  function (iAtom1, iAtom2, order, stereo) {
order=this.fixOrder$I$I(order, stereo);
if (this.haveAtomSerials) return this.asc.addNewBondFromNames$S$S$I(iAtom1, iAtom2, order);
return this.asc.addNewBondWithOrder$I$I$I(this.iatom0 + this.parseIntStr$S(iAtom1) - 1, this.iatom0 + this.parseIntStr$S(iAtom2) - 1, order);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
