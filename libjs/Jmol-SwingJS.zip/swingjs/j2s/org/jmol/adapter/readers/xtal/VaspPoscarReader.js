(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'org.jmol.util.Logger','org.jmol.util.Vibration','org.jmol.util.Parser','javajs.util.M3d','javajs.util.PT','javajs.util.SB','javajs.util.Lst','org.jmol.api.JmolAdapter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VaspPoscarReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.haveAtomLabels=true;
this.radiusPt=-2147483648;
this.elementPt=-2147483648;
},1);

C$.$fields$=[['Z',['haveAtomLabels','atomsLabeledInline','quiet'],'D',['scaleFac'],'I',['ac','nMagMoments','radiusPt','elementPt'],'S',['title'],'O',['atomLabels','javajs.util.Lst','defaultLabels','String[]','unitCellData','double[]','elementLabel','String[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.isPrimitive=true;
this.readStructure$S(null);
this.continuing=false;
});

Clazz.newMeth(C$, 'readStructure$S',  function (titleMsg) {
this.title=this.rd$().trim$();
var pt=this.title.indexOf$S("--params");
if ((pt=this.title.indexOf$S$I("& ", pt + 1)) >= 0) {
this.latticeType=this.title.substring$I$I(pt + 2, pt + 3);
$I$(1,"info$S",["AFLOW lattice:" + this.latticeType + " title=" + this.title ]);
}this.readUnitCellVectors$();
this.readMolecularFormula$();
this.readCoordinates$();
this.asc.setAtomSetName$S(this.title + (titleMsg == null  ? "" : "[" + titleMsg + "]" ));
p$1.readMagneticMoments.apply(this, []);
});

Clazz.newMeth(C$, 'readMagneticMoments',  function () {
System.out.println$S(this.line);
while (this.rd$() != null  && this.line.indexOf$S("# MAGMOM") < 0 ){
}
if (this.line == null ) return;
var data=this.line.substring$I(9).split$S(" ");
for (var i=0, pt=0; i < this.ac; i++) {
var v;
var a=this.asc.atoms[i];
a.vib=v=Clazz.new_($I$(2,1)).setType$I(-2);
v.set$D$D$D(this.parseDoubleStr$S(data[pt++]), this.parseDoubleStr$S(data[pt++]), this.parseDoubleStr$S(data[pt++]));
v.magMoment=p$1.round$D$D.apply(this, [v.length$(), 1000]);
if (v.magMoment != 0 ) {
++this.nMagMoments;
System.out.println$S("Vasp Moment[" + i + "]=" + a.getElementSymbol$() + " " + new Double(v.magMoment).toString() + " " + v );
}}
}, p$1);

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
if (!this.iHaveFractionalCoordinates) this.fractionalizeCoordinates$Z(true);
if (!this.haveAtomLabels && !this.atomsLabeledInline ) this.appendLoadNote$S("VASP POSCAR reader using pseudo atoms Al B C Db...");
if (this.nMagMoments > 0) {
this.asc.setNoAutoBond$();
this.addJmolScript$S("vectors on;vectors 0.15;");
this.appendLoadNote$S(this.nMagMoments + " magnetic moments - use VECTORS ON/OFF or VECTOR MAX x.x or SELECT VXYZ>0");
}this.finalizeReaderASCR$();
});

Clazz.newMeth(C$, 'round$D$D',  function (x, prec) {
return Math.round$D(x * prec) / prec;
}, p$1);

Clazz.newMeth(C$, 'readUnitCellVectors$',  function () {
this.setSpaceGroupName$S("P1");
this.setFractionalCoordinates$Z(true);
this.scaleFac=this.parseDoubleStr$S(this.rdline$().trim$());
var isVolume=(this.scaleFac < 0 );
if (isVolume) this.scaleFac=Math.pow(-this.scaleFac, 0.3333333333333333);
this.unitCellData=Clazz.array(Double.TYPE, [9]);
var s=this.rdline$() + " " + this.rdline$() + " " + this.rdline$() ;
$I$(3).parseStringInfestedDoubleArray$S$javajs_util_BS$DA(s, null, this.unitCellData);
if (isVolume) {
var m=$I$(4).newA9$DA(this.unitCellData);
this.scaleFac/=m.determinant3$();
}if (this.scaleFac != 1 ) for (var i=0; i < this.unitCellData.length; i++) this.unitCellData[i]*=this.scaleFac;

});

Clazz.newMeth(C$, 'readMolecularFormula$',  function () {
if (this.elementLabel == null ) this.elementLabel=$I$(5,"getTokens$S",[this.discardLinesUntilNonBlank$()]);
var elementCounts;
if ($I$(5).parseInt$S(this.elementLabel[0]) == -2147483648) {
this.atomsLabeledInline=false;
elementCounts=$I$(5,"getTokens$S",[this.rdline$()]);
while (this.line != null  && (elementCounts.length == 0 || this.parseIntStr$S(elementCounts[0]) == -2147483648 ) )elementCounts=$I$(5,"getTokens$S",[this.rdline$()]);

} else {
elementCounts=this.elementLabel;
this.elementLabel=$I$(5).split$S$S(this.title, " ");
if (this.elementLabel.length != elementCounts.length || this.elementLabel[0].length$() > 2 ) {
this.elementLabel=$I$(5).split$S$S("Al B C Db Eu F Ga Hf I K Li Mn N O P Ru S Te U V W Xe Yb Zn", " ");
this.haveAtomLabels=false;
}}var labels=this.elementLabel;
var mf=Clazz.new_($I$(6,1));
this.atomLabels=Clazz.new_($I$(7,1));
this.ac=0;
for (var i=0; i < elementCounts.length; i++) {
var n=Integer.parseInt$S(elementCounts[i]);
this.ac+=n;
var label=labels[i];
mf.append$S(" ").append$S(label).appendI$I(n);
for (var j=n; --j >= 0; ) this.atomLabels.addLast$O(label);

}
var s=mf.toString();
if (!this.quiet) this.appendLoadNote$S(this.ac + " atoms identified for" + s );
this.asc.newAtomSet$();
this.asc.setAtomSetName$S(s);
});

Clazz.newMeth(C$, 'readCoordinates$',  function () {
var isSelective=this.discardLinesUntilNonBlank$().toLowerCase$().contains$CharSequence("selective");
if (isSelective) this.rd$();
var isCartesian=(this.line.toLowerCase$().contains$CharSequence("cartesian"));
if (isCartesian) {
this.setFractionalCoordinates$Z(false);
}this.addExplicitLatticeVector$I$DA$I(0, this.unitCellData, 0);
this.addExplicitLatticeVector$I$DA$I(1, this.unitCellData, 3);
this.addExplicitLatticeVector$I$DA$I(2, this.unitCellData, 6);
for (var i=0; i < this.ac; i++) {
var radius=NaN;
var tokens=$I$(5,"getTokens$S",[this.rdline$()]);
if (this.radiusPt == -2147483648) {
for (var j=tokens.length; --j > 2; ) {
var t=tokens[j];
if (t.equals$O("radius")) {
this.radiusPt=j + 1;
} else if (!t.equals$O("T") && !t.equals$O("F") && this.getElement$S(t) != null   ) {
this.elementPt=j;
this.atomsLabeledInline=true;
}}
}if (this.radiusPt >= 0) radius=this.parseDoubleStr$S(tokens[this.radiusPt]);
var label=(this.atomsLabeledInline ? tokens[this.elementPt] : this.atomLabels.get$I(i));
if (isCartesian) for (var j=0; j < 3; j++) tokens[j]="" + new Double(this.parseDoubleStr$S(tokens[j]) * this.scaleFac).toString();

var atom=this.addAtomXYZSymName$SA$I$S$S(tokens, 0, null, label);
if (!Double.isNaN$D(radius)) atom.radius=radius * this.scaleFac;
if (this.asc.bsAtoms != null ) this.asc.bsAtoms.set$I(atom.index);
}
});

Clazz.newMeth(C$, 'getElement$S',  function (token) {
var s=null;
switch (token.length$()) {
default:
s=(token.length$() > 2 ? token.substring$I$I(0, 2) : null);
if (s != null  && $I$(8).getElementNumber$S(s) >= 0 ) return s;
case 1:
if ($I$(8,"getElementNumber$S",[s=token.substring$I(0)]) >= 0) return s;
case 0:
return null;
}
});

Clazz.newMeth(C$, 'rdline$',  function () {
this.rd$();
if (this.line != null  && this.line.startsWith$S("[") ) this.line=this.line.substring$I(this.line.indexOf$S("]") + 1).trim$();
return this.line;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-07 10:26:50 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
