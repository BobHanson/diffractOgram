(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.simple"),p$1={};
/*c*/var C$=Clazz.newClass(P$, "OrcaReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['xyzBohr'],'I',['atomCount'],'S',['chargeTag']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.chargeTag=(this.checkAndRemoveFilterKey$S("CHARGE=LOW") ? "LOEW" : "MULL");
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.startsWith$S("! Bohrs")) {
this.xyzBohr=true;
return true;
}if (this.line.startsWith$S("* xyz") || this.line.startsWith$S("*xyz") ) {
p$1.processInputFile.apply(this, []);
this.continuing=false;
return false;
}if (this.line.indexOf$S("CARTESIAN COORDINATES (ANG") >= 0) {
this.processCoordinates$();
return true;
}if (this.line.indexOf$S("ATOMIC CHARGES") >= 0 && this.line.indexOf$S(this.chargeTag) >= 0 ) {
this.processAtomicCharges$();
return true;
}if (this.line.startsWith$S("Total Energy")) {
p$1.processEnergyLine.apply(this, []);
return true;
}return true;
});

Clazz.newMeth(C$, 'processEnergyLine',  function () {
var tokens=this.getTokens$();
this.asc.setAtomSetEnergy$S$F(tokens[3], Float.parseFloat$S(tokens[3]));
}, p$1);

Clazz.newMeth(C$, 'processInputFile',  function () {
while (this.rd$() != null ){
while (this.line.trim$().length$() == 0 || this.line.startsWith$S("#") ){
this.rd$();
}
if (this.line.indexOf$S("*") >= 0) break;
var tokens=this.getTokens$();
var a=this.addAtomXYZSymName$SA$I$S$S(tokens, 1, tokens[0], null);
if (this.xyzBohr) a.scale$F(0.5291772);
}
}, p$1);

Clazz.newMeth(C$, 'processCoordinates$',  function () {
this.asc.newAtomSet$();
this.baseAtomIndex=this.asc.ac;
this.rd$();
while (this.rd$() != null ){
var tokens=this.getTokens$();
if (tokens.length != 4) break;
this.addAtomXYZSymName$SA$I$S$S(tokens, 1, tokens[0], null);
}
if (this.baseAtomIndex == 0) this.atomCount=this.asc.ac;
});

Clazz.newMeth(C$, 'processAtomicCharges$',  function () {
this.rd$();
for (var i=0; i < this.atomCount; i++) {
this.rd$();
this.asc.atoms[i + this.baseAtomIndex].partialCharge=Float.parseFloat$S(this.line.substring$I(this.line.indexOf$S(":") + 1));
}
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-05-02 10:04:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
