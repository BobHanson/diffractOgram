(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.PT','org.jmol.adapter.smarter.AtomSetCollectionReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XcrysdenReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.animation=false;
this.unitCellData=Clazz.array(Double.TYPE, [9]);
},1);

C$.$fields$=[['Z',['animation'],'I',['nAtoms','animationStep'],'O',['unitCellData','double[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.setFractionalCoordinates$Z(false);
this.doApplySymmetry=true;
});

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.startsWith$S("ATOMS")) {
this.doApplySymmetry=false;
return p$1.readCoordinates.apply(this, []);
}if (this.line.contains$CharSequence("ANIMSTEP")) {
this.animation=true;
} else if (this.line.contains$CharSequence("PRIMVEC")) {
p$1.readUnitCell.apply(this, []);
} else if (this.line.contains$CharSequence("PRIMCOORD")) {
return p$1.readCoordinates.apply(this, []);
}return true;
});

Clazz.newMeth(C$, 'readUnitCell',  function () {
p$1.setSymmetry.apply(this, []);
this.fillDoubleArray$S$I$DA(null, 0, this.unitCellData);
p$1.setUnitCell.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'setUnitCell',  function () {
this.addExplicitLatticeVector$I$DA$I(0, this.unitCellData, 0);
this.addExplicitLatticeVector$I$DA$I(1, this.unitCellData, 3);
this.addExplicitLatticeVector$I$DA$I(2, this.unitCellData, 6);
}, p$1);

Clazz.newMeth(C$, 'setSymmetry',  function () {
this.applySymmetryAndSetTrajectory$();
this.asc.newAtomSet$();
this.setSpaceGroupName$S("P1");
this.setFractionalCoordinates$Z(false);
}, p$1);

Clazz.newMeth(C$, 'readCoordinates',  function () {
if (this.doApplySymmetry) {
var atomStr=$I$(1,"getTokens$S",[this.rd$()]);
this.nAtoms=Integer.parseInt$S(atomStr[0]);
} else {
this.nAtoms=2147483647;
}this.setFractionalCoordinates$Z(false);
var counter=0;
while (counter < this.nAtoms && this.rd$() != null  ){
var tokens=this.getTokens$();
var an=$I$(1).parseInt$S(tokens[0]);
if (an < 0) {
break;
}this.line=null;
this.addAtomXYZSymName$SA$I$S$S(tokens, 1, null, $I$(2).getElementSymbol$I(an));
++counter;
}
this.asc.setAtomSetName$S(this.animation ? "Structure " + (++this.animationStep) : "Initial coordinates");
if (this.line != null ) p$1.setSymmetry.apply(this, []);
return (this.line == null );
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:46 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
