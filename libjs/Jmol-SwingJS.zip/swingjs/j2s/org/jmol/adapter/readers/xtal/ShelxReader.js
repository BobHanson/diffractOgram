(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.xtal"),p$1={},I$=[[0,'javajs.util.PT','javajs.util.AU','org.jmol.adapter.smarter.AtomSetCollectionReader','org.jmol.util.Logger','org.jmol.adapter.smarter.Atom']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ShelxReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.altloc="\u0000";
},1);

C$.$fields$=[['Z',['isCmdf','isCentroSymmetric','haveXYZ'],'C',['altloc'],'I',['part'],'O',['+sfacElementSymbols','+tokens']]
,['O',['supportedRecordTypes','String[]']]]

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.setFractionalCoordinates$Z(true);
});

Clazz.newMeth(C$, 'checkLine$',  function () {
var lineLength;
if (this.line.length$() == 0 || this.line.startsWith$S(" ") ) return true;
while ((lineLength=this.line.length$()) > 0 && this.line.charAt$I(lineLength - 1) == "=" )this.line=this.line.substring$I$I(0, lineLength - 1) + this.rd$();

this.tokens=this.getTokens$();
var command=this.tokens[0].toUpperCase$();
if (command.equals$O("TITL")) {
if (!this.doGetModel$I$S(++this.modelNumber, null)) return this.checkLastModel$();
this.sfacElementSymbols=null;
this.applySymmetryAndSetTrajectory$();
this.setFractionalCoordinates$Z(true);
this.asc.newAtomSet$();
this.asc.setAtomSetName$S(this.line.substring$I(4).trim$());
return true;
}if (command.equals$O("NOTE")) {
this.isCmdf=true;
return true;
}if (!this.doProcessLines || lineLength < 3 ) return true;
if (";ZERR;DISP;UNIT;LAUE;REM;MORE;TIME;HKLF;OMIT;SHEL;BASF;TWIN;EXTI;SWAT;HOPE;MERG;SPEC;RESI;MOVE;ANIS;AFIX;HFIX;FRAG;FEND;EXYZ;EXTI;EADP;EQIV;CONN;BIND;FREE;DFIX;DANG;BUMP;SAME;SADI;CHIV;FLAT;DELU;SIMU;DEFS;ISOR;NCSY;SUMP;L.S.;CGLS;BLOC;DAMP;STIR;WGHT;FVAR;BOND;CONF;MPLA;RTAB;HTAB;LIST;ACTA;SIZE;TEMP;WPDB;FMAP;GRID;PLAN;MOLE;".indexOf$S(";" + command + ";" ) >= 0) return true;
for (var i=C$.supportedRecordTypes.length; --i >= 0; ) if (command.equals$O(C$.supportedRecordTypes[i])) {
p$1.processSupportedRecord$I.apply(this, [i]);
return true;
}
if (!this.isCmdf) p$1.assumeAtomRecord.apply(this, []);
return true;
});

Clazz.newMeth(C$, 'processSupportedRecord$I',  function (recordIndex) {
switch (recordIndex) {
case 0:
case 9:
break;
case 1:
p$1.cell.apply(this, []);
break;
case 2:
this.setSpaceGroupName$S($I$(1).parseTrimmedAt$S$I(this.line, 4));
break;
case 3:
p$1.parseSfacRecord.apply(this, []);
break;
case 4:
p$1.parseLattRecord.apply(this, []);
break;
case 5:
p$1.parseSymmRecord.apply(this, []);
break;
case 6:
this.isCmdf=true;
break;
case 7:
this.isCmdf=true;
p$1.processCmdfAtoms.apply(this, []);
break;
case 8:
p$1.processPartRecord.apply(this, []);
break;
}
}, p$1);

Clazz.newMeth(C$, 'processPartRecord',  function () {
this.part=this.parseIntStr$S(this.tokens[1]);
this.altloc=String.fromCharCode((this.part == 0 ? 0 : 48 + Math.abs(this.part)));
}, p$1);

Clazz.newMeth(C$, 'parseLattRecord',  function () {
var latt=this.parseIntStr$S(this.tokens[1]);
this.isCentroSymmetric=(latt > 0);
if (latt == 1 || latt == -1 ) return;
this.asc.getXSymmetry$().setLatticeParameter$I(latt);
}, p$1);

Clazz.newMeth(C$, 'parseSymmRecord',  function () {
if (!this.haveXYZ) {
this.setSymmetryOperator$S("x,y,z");
this.haveXYZ=true;
}this.setSymmetryOperator$S(this.line.substring$I(4).trim$());
}, p$1);

Clazz.newMeth(C$, 'cell',  function () {
var ioff=this.tokens.length - 6;
if (ioff == 2) this.asc.setInfo$S$O("wavelength", Double.valueOf$D(this.parseDoubleStr$S(this.tokens[1])));
for (var ipt=0; ipt < 6; ipt++) this.setUnitCellItem$I$D(ipt, this.parseDoubleStr$S(this.tokens[ipt + ioff]));

}, p$1);

Clazz.newMeth(C$, 'parseSfacRecord',  function () {
var allElementSymbols=true;
for (var i=this.tokens.length; allElementSymbols && --i >= 1 ; ) {
var token=this.tokens[i];
allElementSymbols=C$.isValidElementSymbolNoCaseSecondChar$S(token);
}
var sfacTokens=$I$(1,"getTokens$S",[this.line.substring$I(4)]);
if (allElementSymbols) p$1.parseSfacElementSymbols$SA.apply(this, [sfacTokens]);
 else p$1.parseSfacCoefficients$SA.apply(this, [sfacTokens]);
}, p$1);

Clazz.newMeth(C$, 'parseSfacElementSymbols$SA',  function (sfacTokens) {
if (this.sfacElementSymbols == null ) {
this.sfacElementSymbols=sfacTokens;
} else {
var oldCount=this.sfacElementSymbols.length;
var tokenCount=sfacTokens.length;
this.sfacElementSymbols=$I$(2).arrayCopyS$SA$I(this.sfacElementSymbols, oldCount + tokenCount);
for (var i=tokenCount; --i >= 0; ) this.sfacElementSymbols[oldCount + i]=sfacTokens[i];

}}, p$1);

Clazz.newMeth(C$, 'parseSfacCoefficients$SA',  function (sfacTokens) {
var a1=this.parseDoubleStr$S(sfacTokens[1]);
var a2=this.parseDoubleStr$S(sfacTokens[3]);
var a3=this.parseDoubleStr$S(sfacTokens[5]);
var a4=this.parseDoubleStr$S(sfacTokens[7]);
var c=this.parseDoubleStr$S(sfacTokens[9]);
var z=Long.$ival(Math.round$D(a1 + a2 + a3 + a4 + c ));
var elementSymbol=$I$(3).getElementSymbol$I(z);
var oldCount=0;
if (this.sfacElementSymbols == null ) {
this.sfacElementSymbols=Clazz.array(String, [1]);
} else {
oldCount=this.sfacElementSymbols.length;
this.sfacElementSymbols=$I$(2).arrayCopyS$SA$I(this.sfacElementSymbols, oldCount + 1);
this.sfacElementSymbols[oldCount]=elementSymbol;
}this.sfacElementSymbols[oldCount]=elementSymbol;
}, p$1);

Clazz.newMeth(C$, 'assumeAtomRecord',  function () {
var x=NaN;
var y=NaN;
var z=NaN;
var occ=1;
var elementIndex=-1;
var atomName=null;
try {
atomName=this.tokens[0];
elementIndex=this.parseIntStr$S(this.tokens[1]) - 1;
x=this.parsePrecision$S(this.tokens[2]) % 10;
y=this.parsePrecision$S(this.tokens[3]) % 10;
z=this.parsePrecision$S(this.tokens[4]) % 10;
occ=this.parseDoubleStr$S(this.tokens[5]) % 10;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
if (Double.isNaN$D(x) || Double.isNaN$D(y) || Double.isNaN$D(z)  ) {
$I$(4).error$S("skipping line " + this.line);
return;
}var atom=this.asc.addNewAtom$();
atom.atomName=atomName;
atom.foccupancy=occ;
var isQPeak=atomName.startsWith$S("Q");
if (isQPeak) {
atom.elementSymbol="Xx";
} else if (this.sfacElementSymbols != null  && elementIndex >= 0  && elementIndex < this.sfacElementSymbols.length ) {
atom.elementSymbol=this.sfacElementSymbols[elementIndex];
}this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atom, x, y, z);
atom.altLoc=this.altloc;
atom.part=this.part;
if (this.tokens.length == 12) {
var data=Clazz.array(Double.TYPE, [8]);
data[0]=this.parseDoubleStr$S(this.tokens[6]);
data[1]=this.parseDoubleStr$S(this.tokens[7]);
data[2]=this.parseDoubleStr$S(this.tokens[8]);
data[3]=this.parseDoubleStr$S(this.tokens[11]);
data[4]=this.parseDoubleStr$S(this.tokens[10]);
data[5]=this.parseDoubleStr$S(this.tokens[9]);
for (var i=0; i < 6; i++) if (Double.isNaN$D(data[i])) {
$I$(4).error$S("Bad anisotropic Uij data: " + this.line);
return;
}
this.asc.setAnisoBorU$org_jmol_adapter_smarter_Atom$DA$I(atom, data, 8);
}}, p$1);

Clazz.newMeth(C$, 'processCmdfAtoms',  function () {
while (this.rd$() != null  && this.line.length$() > 10 ){
this.tokens=this.getTokens$();
this.addAtomXYZSymName$SA$I$S$S(this.tokens, 2, p$1.getSymbol$S.apply(this, [this.tokens[0]]), this.tokens[1]);
}
}, p$1);

Clazz.newMeth(C$, 'getSymbol$S',  function (sym) {
if (sym == null ) return "Xx";
var len=sym.length$();
if (len < 2) return sym;
var ch1=sym.charAt$I(1);
if (ch1 >= "a" && ch1 <= "z" ) return sym.substring$I$I(0, 2);
return "" + sym.charAt$I(0);
}, p$1);

Clazz.newMeth(C$, 'isValidElementSymbolNoCaseSecondChar$S',  function (str) {
if (str == null ) return false;
var length=str.length$();
if (length == 0) return false;
var chFirst=str.charAt$I(0);
if (length == 1) return $I$(5).isValidSym1$C(chFirst);
if (length > 2) return false;
var chSecond=str.charAt$I(1);
return $I$(5).isValidSymNoCase$C$C(chFirst, chSecond);
}, 1);

Clazz.newMeth(C$, 'applySymmetryAndSetTrajectory$',  function () {
if (this.isCentroSymmetric && !this.ignoreFileSymmetryOperators ) {
if (!this.haveXYZ) {
this.setSymmetryOperator$S("x,y,z");
}this.asc.getXSymmetry$().getFileSymmetry$().addInversion$();
this.isCentroSymmetric=false;
this.haveXYZ=false;
}this.applySymTrajASCR$();
});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
C$.superclazz.prototype.finalizeReaderASCR$.apply(this, []);
this.asc.xtalSymmetry.setPartProperty$();
});

C$.$static$=function(){C$.$static$=0;
C$.supportedRecordTypes=Clazz.array(String, -1, ["TITL", "CELL", "SPGR", "SFAC", "LATT", "SYMM", "NOTE", "ATOM", "PART", "END"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-31 18:08:09 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
