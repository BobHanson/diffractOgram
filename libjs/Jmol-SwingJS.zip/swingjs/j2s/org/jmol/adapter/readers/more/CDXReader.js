(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.more"),I$=[[0,'org.jmol.adapter.writers.CDXMLWriter','javajs.util.Rdr']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXReader", null, 'org.jmol.adapter.readers.xml.XmlCdxReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'processXml2$org_jmol_adapter_readers_xml_XmlReader$O',  function (parent, saxReader) {
this.isCDX=true;
var xml=$I$(1).fromCDX$javajs_api_GenericBinaryDocumentReader(this.binaryDoc);
this.reader=$I$(2).getBR$S(xml);
C$.superclazz.prototype.processXml2$org_jmol_adapter_readers_xml_XmlReader$O.apply(this, [this, saxReader]);
this.binaryDoc=null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
