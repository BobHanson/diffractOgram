(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.quantum"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "AmsReader", null, 'org.jmol.adapter.readers.quantum.AdfReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.isADF=false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:42 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
