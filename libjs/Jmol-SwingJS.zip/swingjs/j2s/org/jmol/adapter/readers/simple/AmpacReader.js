(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.simple"),p$1={},I$=[[0,'org.jmol.adapter.smarter.Atom','org.jmol.api.JmolAdapter','javajs.util.P3d']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AmpacReader", null, 'org.jmol.adapter.readers.simple.InputReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.freqAtom0=-1;
},1);

C$.$fields$=[['I',['$ac','freqAtom0'],'O',['partialCharges','double[]','atomPositions','javajs.util.P3d[]']]]

Clazz.newMeth(C$, 'checkLine$',  function () {
if (this.line.indexOf$S("CARTESIAN COORDINATES") >= 0) {
if (!this.doGetModel$I$S(++this.modelNumber, null)) return this.checkLastModel$();
p$1.readCoordinates.apply(this, []);
return true;
}if (this.line.indexOf$S("FINAL GEOMETRY OBTAINED") >= 0) {
if (!this.doGetModel$I$S(++this.modelNumber, null)) return this.checkLastModel$();
p$1.readZmatrixCoordinates.apply(this, []);
return true;
}if (!this.doProcessLines) return true;
if (this.line.indexOf$S("NET ATOMIC CHARGES") >= 0) {
p$1.readPartialCharges.apply(this, []);
return true;
}if (this.line.indexOf$S("VIBRATIONAL FREQUENCIES") >= 0) {
p$1.readFrequencies.apply(this, []);
return true;
}return true;
});

Clazz.newMeth(C$, 'readZmatrixCoordinates',  function () {
this.rd$();
this.rd$();
this.rd$();
this.setFractionalCoordinates$Z(false);
while (this.rd$() != null  && this.line.length$() >= 50 ){
var atom=Clazz.new_($I$(1,1));
this.vAtoms.addLast$O(atom);
atom.x=this.parseDoubleRange$S$I$I(this.line, 4, 16);
atom.y=this.parseDoubleRange$S$I$I(this.line, 19, 31);
atom.z=this.parseDoubleRange$S$I$I(this.line, 34, 46);
if (this.line.length$() > 48 && this.$ac < 3  || this.line.charAt$I(48) != "0" ) {
switch (this.$ac) {
case 0:
break;
case 1:
atom.sub$javajs_util_T3d(this.vAtoms.get$I(0));
break;
case 2:
this.setAtom$org_jmol_adapter_smarter_Atom$I$I$I$D$D$D(atom, 0, 1, 0, atom.x, atom.y, 1.7976931348623157E308);
break;
default:
this.setAtom$org_jmol_adapter_smarter_Atom$I$I$I$D$D$D(atom, this.parseIntRange$S$I$I(this.line, 50, 54) - 1, this.parseIntRange$S$I$I(this.line, 54, 58) - 1, this.parseIntRange$S$I$I(this.line, 58, 62) - 1, atom.x, atom.y, atom.z);
}
}var sym=this.line.substring$I$I(1, 4).trim$();
atom.elementSymbol=sym;
++this.$ac;
var len=this.line.length$();
if (len > 64) atom.partialCharge=this.parseDoubleRange$S$I$I(this.line, 64, len);
if ($I$(2).getElementNumber$S(sym) != 0) this.asc.addAtom$org_jmol_adapter_smarter_Atom(atom);
this.setAtomCoord$org_jmol_adapter_smarter_Atom(atom);
}
}, p$1);

Clazz.newMeth(C$, 'readCoordinates',  function () {
var haveFreq=(this.freqAtom0 >= 0);
if (haveFreq) {
this.atomPositions=Clazz.array($I$(3), [this.$ac]);
} else {
this.asc.newAtomSet$();
}this.rd$();
this.$ac=0;
while (this.rd$() != null ){
var tokens=this.getTokens$();
if (tokens.length < 5) break;
if (haveFreq) {
this.atomPositions[this.$ac]=$I$(3,"new3$D$D$D",[this.parseDoubleStr$S(tokens[2]), this.parseDoubleStr$S(tokens[3]), this.parseDoubleStr$S(tokens[4])]);
} else {
this.addAtomXYZSymName$SA$I$S$S(tokens, 2, tokens[1], null);
}++this.$ac;
}
if (haveFreq) p$1.setPositions.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'setPositions',  function () {
var maxAtom=this.asc.ac;
var atoms=this.asc.atoms;
for (var i=this.freqAtom0; i < maxAtom; i++) {
atoms[i].setT$javajs_util_T3d(this.atomPositions[i % this.$ac]);
atoms[i].partialCharge=this.partialCharges[i % this.$ac];
}
}, p$1);

Clazz.newMeth(C$, 'readPartialCharges',  function () {
this.rd$();
this.partialCharges=Clazz.array(Double.TYPE, [this.$ac]);
var tokens;
for (var i=0; i < this.$ac; i++) {
if (this.rd$() == null  || (tokens=this.getTokens$()).length < 4 ) break;
this.partialCharges[i]=this.parseDoubleStr$S(tokens[2]);
}
}, p$1);

Clazz.newMeth(C$, 'readFrequencies',  function () {
while (this.rd$() != null  && this.line.indexOf$S("FREQ  :") < 0 ){
}
while (this.line != null  && this.line.indexOf$S("FREQ  :") >= 0 ){
var frequencies=this.getTokens$();
while (this.rd$() != null  && this.line.indexOf$S("IR I") < 0 ){
}
var iAtom0=this.asc.ac;
if (this.vibrationNumber == 0) this.freqAtom0=iAtom0;
var frequencyCount=frequencies.length - 2;
var ignore=Clazz.array(Boolean.TYPE, [frequencyCount]);
for (var i=0; i < frequencyCount; ++i) {
ignore[i]=!this.doGetVibration$I(++this.vibrationNumber);
if (ignore[i]) continue;
this.asc.cloneLastAtomSet$();
this.asc.setAtomSetName$S(frequencies[i + 2] + " cm^-1");
this.asc.setAtomSetModelProperty$S$S("Frequency", frequencies[i + 2] + " cm^-1");
this.asc.setAtomSetModelProperty$S$S(".PATH", "Frequencies");
}
this.fillFrequencyData$I$I$I$ZA$Z$I$I$IA$I$SAA(iAtom0, this.$ac, this.$ac, ignore, false, 8, 9, null, 0, null);
this.rd$();
this.rd$();
}
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
