(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.pymol"),p$1={},I$=[[0,'javajs.util.BS','java.util.Hashtable','javajs.util.Lst','javajs.util.P3d','org.jmol.adapter.readers.pymol.PyMOL','org.jmol.adapter.readers.pymol.PyMOLReader','javajs.util.CU','org.jmol.util.Logger','org.jmol.util.BSUtil','org.jmol.adapter.readers.pymol.JmolObject','org.jmol.adapter.readers.pymol.PyMOLGroup','javajs.util.AU','org.jmol.util.C','org.jmol.modelset.MeasurementData','org.jmol.util.Point3fi','javajs.util.SB','org.jmol.util.Escape','javajs.util.PT','org.jmol.modelset.Text','org.jmol.atomdata.RadiusData',['org.jmol.atomdata.RadiusData','.EnumType'],'org.jmol.c.VDW']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PyMOLScene", null, null, 'org.jmol.api.JmolSceneGenerator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.bsHidden=Clazz.new_($I$(1,1));
this.bsNucleic=Clazz.new_($I$(1,1));
this.bsNonbonded=Clazz.new_($I$(1,1));
this.bsLabeled=Clazz.new_($I$(1,1));
this.bsHydrogen=Clazz.new_($I$(1,1));
this.bsNoSurface=Clazz.new_($I$(1,1));
this.htSpacefill=Clazz.new_($I$(2,1));
this.bsSpacefillSphere=Clazz.new_($I$(1,1));
this.ssMapAtom=Clazz.new_($I$(2,1));
this.atomColorList=Clazz.new_($I$(3,1));
this.occludedObjects=Clazz.new_($I$(2,1));
this.labels=Clazz.new_($I$(2,1));
this.ptTemp=Clazz.new_($I$(4,1));
this.bsCartoon=Clazz.new_($I$(1,1));
this.htCarveSets=Clazz.new_($I$(2,1));
this.htDefinedAtoms=Clazz.new_($I$(2,1));
this.htHiddenObjects=Clazz.new_($I$(2,1));
this.moleculeNames=Clazz.new_($I$(3,1));
this.jmolObjects=Clazz.new_($I$(3,1));
this.htAtomMap=Clazz.new_($I$(2,1));
this.htObjectAtoms=Clazz.new_($I$(2,1));
this.htObjectGroups=Clazz.new_($I$(2,1));
this.htMeasures=Clazz.new_($I$(2,1));
this.htObjectSettings=Clazz.new_($I$(2,1));
this.objectInfo=Clazz.new_($I$(2,1));
this.htStateSettings=Clazz.new_($I$(2,1));
this.labelPosition0=Clazz.new_($I$(4,1));
this.mepList="";
this.bsLineBonds=Clazz.new_($I$(1,1));
this.bsStickBonds=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['haveNucleicLadder','objectHidden','doCache','haveScenes'],'I',['pymolVersion','objectType','baseModelIndex','baseAtomIndex','stateCount','thisState','currentAtomSetIndex','bgRgb'],'S',['objectName','objectStateName','objectJmolName','mepList','surfaceInfoName','modelName'],'O',['vwr','org.jmol.viewer.Viewer','bsHidden','javajs.util.BS','+bsNucleic','+bsNonbonded','+bsLabeled','+bsHydrogen','+bsNoSurface','htSpacefill','java.util.Map','bsSpacefillSphere','javajs.util.BS','ssMapAtom','java.util.Map','atomColorList','javajs.util.Lst','occludedObjects','java.util.Map','+labels','colixes','short[]','frameObj','org.jmol.adapter.readers.pymol.JmolObject','groups','java.util.Map','+objectSettings','jmolToUniqueID','int[]','ptTemp','javajs.util.P3d','bsCartoon','javajs.util.BS','htCarveSets','java.util.Map','+htDefinedAtoms','+htHiddenObjects','moleculeNames','javajs.util.Lst','+jmolObjects','htAtomMap','java.util.Map','+htObjectAtoms','+htObjectGroups','+htMeasures','+htObjectSettings','+objectInfo','globalSettings','javajs.util.Lst','htStateSettings','java.util.Map','+stateSettings','+uniqueSettings','+uniqueList','bsUniqueBonds','javajs.util.BS','labelPosition','javajs.util.P3d','+labelPosition0','bsAtoms','javajs.util.BS','reader','org.jmol.adapter.readers.pymol.PyMOLReader','uniqueIDs','int[]','+cartoonTypes','+sequenceNumbers','newChain','boolean[]','radii','double[]','bsCarve','javajs.util.BS','+bsLineBonds','+bsStickBonds','sceneSettings','double[]']]
,['O',['MEAS_DIGITS','int[]']]]

Clazz.newMeth(C$, 'clearReaderData',  function () {
this.reader=null;
this.colixes=null;
this.atomColorList=null;
this.objectSettings=null;
this.stateSettings=null;
if (this.haveScenes) return;
this.globalSettings=null;
this.groups=null;
this.labels=null;
this.ssMapAtom=null;
this.htSpacefill=null;
this.htAtomMap=null;
this.htMeasures=null;
this.htObjectGroups=null;
this.htObjectAtoms=null;
this.htObjectSettings=null;
this.htStateSettings=null;
this.htHiddenObjects=null;
this.objectInfo=null;
this.occludedObjects=null;
this.bsHidden=this.bsNucleic=this.bsNonbonded=this.bsLabeled=this.bsHydrogen=this.bsNoSurface=this.bsCartoon=null;
}, p$1);

Clazz.newMeth(C$, 'c$$org_jmol_adapter_readers_pymol_PyMOLReader$org_jmol_viewer_Viewer$javajs_util_Lst$java_util_Map$I$Z$I$I$Z$S',  function (reader, vwr, settings, uniqueSettings, pymolVersion, haveScenes, baseAtomIndex, baseModelIndex, doCache, filePath) {
;C$.$init$.apply(this);
this.reader=reader;
this.vwr=vwr;
this.globalSettings=settings;
this.uniqueSettings=uniqueSettings;
this.pymolVersion=pymolVersion;
this.haveScenes=haveScenes;
this.baseAtomIndex=baseAtomIndex;
this.baseModelIndex=baseModelIndex;
this.doCache=doCache;
this.surfaceInfoName=filePath + "##JmolSurfaceInfo##";
this.sceneSettings=Clazz.array(Double.TYPE, [1000]);
for (var i=1000; --i >= 0; ) this.sceneSettings[i]=NaN;

p$1.addVersionSettings.apply(this, []);
settings.trimToSize$();
this.bgRgb=$I$(5,"getRGB$I",[p$1.colorSetting$I.apply(this, [6])]);
this.labelPosition0=p$1.pointSetting$I.apply(this, [471]);
}, 1);

Clazz.newMeth(C$, 'setUniqueBond$I$I',  function (index, uniqueID) {
if (uniqueID < 0) return;
if (this.uniqueList == null ) {
this.uniqueList=Clazz.new_($I$(2,1));
this.bsUniqueBonds=Clazz.new_($I$(1,1));
}this.uniqueList.put$O$O(Integer.valueOf$I(index), Integer.valueOf$I(uniqueID));
this.bsUniqueBonds.set$I(index);
});

Clazz.newMeth(C$, 'setStateCount$I',  function (stateCount) {
this.stateCount=stateCount;
});

Clazz.newMeth(C$, 'colorSetting$I',  function (i) {
var pos=$I$(6).listAt$javajs_util_Lst$I(this.globalSettings, i);
var o=(pos == null  || pos.size$() != 3  ? null : pos.get$I(2));
if (o == null ) return ($I$(5).getDefaultSetting$I$I(i, this.pymolVersion)|0);
return (Clazz.instanceOf(o, "java.lang.Integer") ? (o).intValue$() : $I$(7,"colorPtToFFRGB$javajs_util_T3d",[$I$(6).pointAt$javajs_util_Lst$I$javajs_util_P3d(o, 0, this.ptTemp)]));
}, p$1);

Clazz.newMeth(C$, 'pointSetting$I',  function (i) {
var pt=Clazz.new_($I$(4,1));
var pos=$I$(6).listAt$javajs_util_Lst$I(this.globalSettings, i);
if (pos != null  && pos.size$() == 3 ) return $I$(6,"pointAt$javajs_util_Lst$I$javajs_util_P3d",[pos.get$I(2), 0, pt]);
return $I$(5).getDefaultSettingPt$I$I$javajs_util_P3d(i, this.pymolVersion, pt);
}, p$1);

Clazz.newMeth(C$, 'ensureCapacity$I',  function (n) {
this.atomColorList.ensureCapacity$I(this.atomColorList.size$() + n);
});

Clazz.newMeth(C$, 'setReaderObjectInfo$S$I$S$Z$javajs_util_Lst$javajs_util_Lst$S',  function (name, type, groupName, isHidden, listObjSettings, listStateSettings, ext) {
this.objectName=name;
this.objectHidden=isHidden;
this.objectStateName=(this.objectName == null  ? null : p$1.fixName$S.apply(this, [this.objectName + ext]));
if (this.objectName == null ) {
this.objectSettings=Clazz.new_($I$(2,1));
this.stateSettings=Clazz.new_($I$(2,1));
} else {
this.objectJmolName=p$1.getJmolName$S.apply(this, [name]);
if (groupName != null ) {
this.htObjectGroups.put$O$O(this.objectName, groupName);
this.htObjectGroups.put$O$O(this.objectStateName, groupName);
}this.objectInfo.put$O$O(this.objectName, Clazz.array(java.lang.Object, -1, [this.objectStateName, Integer.valueOf$I(type)]));
this.objectSettings=this.htObjectSettings.get$O(this.objectName);
if (this.objectSettings == null ) {
p$1.listToSettings$javajs_util_Lst$java_util_Map.apply(this, [listObjSettings, this.objectSettings=Clazz.new_($I$(2,1))]);
this.htObjectSettings.put$O$O(this.objectName, this.objectSettings);
}this.stateSettings=this.htStateSettings.get$O(this.objectStateName);
if (this.stateSettings == null ) {
p$1.listToSettings$javajs_util_Lst$java_util_Map.apply(this, [listStateSettings, this.stateSettings=Clazz.new_($I$(2,1))]);
this.htStateSettings.put$O$O(this.objectStateName, this.stateSettings);
}}p$1.getObjectSettings.apply(this, []);
});

Clazz.newMeth(C$, 'listToSettings$javajs_util_Lst$java_util_Map',  function (list, objectSettings) {
if (list != null  && list.size$() != 0 ) {
for (var i=list.size$(); --i >= 0; ) {
var setting=list.get$I(i);
objectSettings.put$O$O(setting.get$I(0), setting);
}
}}, p$1);

Clazz.newMeth(C$, 'getDoubleOrDefault$I',  function (key) {
return this.doubleSetting$I(key);
});

Clazz.newMeth(C$, 'getIntOrDefault$I',  function (key) {
return (this.getDoubleOrDefault$I(key)|0);
});

Clazz.newMeth(C$, 'getBooleanOrDefault$I',  function (key) {
return this.getDoubleOrDefault$I(key) != 0 ;
});

Clazz.newMeth(C$, 'getObjectSettings',  function () {
var carveSet=this.stringSetting$I(342).trim$();
if (carveSet.length$() == 0) {
this.bsCarve=null;
} else {
this.bsCarve=this.htCarveSets.get$O(carveSet);
if (this.bsCarve == null ) this.htCarveSets.put$O$O(carveSet, this.bsCarve=Clazz.new_($I$(1,1)));
}this.labelPosition=Clazz.new_($I$(4,1));
try {
var setting=p$1.getSetting$I.apply(this, [471]);
$I$(6,"pointAt$javajs_util_Lst$I$javajs_util_P3d",[$I$(6).listAt$javajs_util_Lst$I(setting, 2), 0, this.labelPosition]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
this.labelPosition.add$javajs_util_T3d(this.labelPosition0);
}, p$1);

Clazz.newMeth(C$, 'setAtomInfo$IA$IA$IA$ZA$DA',  function (uniqueIDs, cartoonTypes, sequenceNumbers, newChain, radii) {
this.uniqueIDs=uniqueIDs;
this.cartoonTypes=cartoonTypes;
this.sequenceNumbers=sequenceNumbers;
this.newChain=newChain;
this.radii=radii;
});

Clazz.newMeth(C$, 'setSceneObject$S$I',  function (name, istate) {
this.objectName=name;
this.objectType=p$1.getObjectType$S.apply(this, [name]);
this.objectJmolName=p$1.getJmolName$S.apply(this, [name]);
this.objectStateName=(istate == 0 && this.objectType != 0  ? this.getObjectID$S(name) : this.objectJmolName + "_" + istate );
this.bsAtoms=this.htObjectAtoms.get$O(name);
this.objectSettings=this.htObjectSettings.get$O(name);
this.stateSettings=this.htStateSettings.get$O(name + "_" + istate );
var groupName=this.htObjectGroups.get$O(name);
this.objectHidden=(this.htHiddenObjects.containsKey$O(name) || groupName != null  && !this.groups.get$O(groupName).visible  );
p$1.getObjectSettings.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'buildScene$S$javajs_util_Lst$java_util_Map$java_util_Map',  function (name, thisScene, htObjNames, htSecrets) {
var frame=thisScene.get$I(2);
var smap=Clazz.new_($I$(2,1));
smap.put$O$O("pymolFrame", frame);
smap.put$O$O("generator", this);
smap.put$O$O("name", name);
var view=$I$(6).listAt$javajs_util_Lst$I(thisScene, 0);
if (view != null ) smap.put$O$O("pymolView", p$1.getPymolView$javajs_util_Lst$Z.apply(this, [view, false]));
var visibilities=thisScene.get$I(1);
smap.put$O$O("visibilities", visibilities);
var sname="_scene_" + name + "_" ;
var reps=Clazz.array(java.lang.Object, [$I$(5).REP_LIST.length]);
for (var j=$I$(5).REP_LIST.length; --j >= 0; ) {
var list=htObjNames.get$O(sname + $I$(5).REP_LIST[j]);
var data=$I$(6).listAt$javajs_util_Lst$I(list, 5);
if (data != null  && data.size$() > 0 ) reps[j]=$I$(6).listToMap$javajs_util_Lst(data);
}
smap.put$O$O("moleculeReps", reps);
sname="_!c_" + name + "_" ;
var colorection=$I$(6).listAt$javajs_util_Lst$I(thisScene, 3);
var n=colorection.size$();
n-=n % 2;
var colors=Clazz.array(java.lang.Object, [(n/2|0)]);
for (var j=0, i=0; j < n; j+=2) {
var color=$I$(6).intAt$javajs_util_Lst$I(colorection, j);
var c=htSecrets.get$O(sname + color);
if (c != null  && c.size$() > 1 ) colors[i++]=Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(color), c.get$I(1)]);
}
smap.put$O$O("colors", colors);
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [1073742139, null, smap]).jmolName=name;
});

Clazz.newMeth(C$, 'generateScene$java_util_Map',  function (scene) {
$I$(8,"info$S",["PyMOLScene - generateScene " + scene.get$O("name")]);
this.jmolObjects.clear$();
this.bsHidden.clearAll$();
this.occludedObjects.clear$();
this.htHiddenObjects.clear$();
var frame=scene.get$O("pymolFrame");
this.thisState=frame.intValue$();
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [4115, null, Integer.valueOf$I(this.thisState - 1)]);
try {
p$1.generateVisibilities$java_util_Map.apply(this, [scene.get$O("visibilities")]);
p$1.generateColors$OA.apply(this, [scene.get$O("colors")]);
p$1.generateShapes$OA.apply(this, [scene.get$O("moleculeReps")]);
this.finalizeVisibility$();
this.offsetObjects$();
p$1.finalizeObjects.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
$I$(8).info$S("PyMOLScene exception " + e);
e.printStackTrace$();
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'generateColors$OA',  function (colors) {
if (colors == null ) return;
for (var i=colors.length; --i >= 0; ) {
var item=colors[i];
var color=(item[0]).intValue$();
var icolor=$I$(5).getRGB$I(color);
var molecules=item[1];
var bs=p$1.getSelectionAtoms$javajs_util_Lst$I$javajs_util_BS.apply(this, [molecules, this.thisState, Clazz.new_($I$(1,1))]);
p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [1153433601, bs]).argb=icolor;
}
}, p$1);

Clazz.newMeth(C$, 'processSelection$javajs_util_Lst',  function (selection) {
var id=$I$(6).stringAt$javajs_util_Lst$I(selection, 0);
id="_" + (id.equals$O("sele") ? id : "sele_" + id);
var g=this.getGroup$S(id);
p$1.getSelectionAtoms$javajs_util_Lst$I$javajs_util_BS.apply(this, [$I$(6).listAt$javajs_util_Lst$I(selection, 5), 0, g.bsAtoms]);
});

Clazz.newMeth(C$, 'getSelectionAtoms$javajs_util_Lst$I$javajs_util_BS',  function (molecules, istate, bs) {
if (molecules != null ) for (var j=molecules.size$(); --j >= 0; ) p$1.selectAllAtoms$javajs_util_Lst$I$javajs_util_BS.apply(this, [$I$(6).listAt$javajs_util_Lst$I(molecules, j), istate, bs]);

return bs;
}, p$1);

Clazz.newMeth(C$, 'selectAllAtoms$javajs_util_Lst$I$javajs_util_BS',  function (obj, istate, bs) {
var name=$I$(6).stringAt$javajs_util_Lst$I(obj, 0);
p$1.setSceneObject$S$I.apply(this, [name, istate]);
var atomList=$I$(6).listAt$javajs_util_Lst$I(obj, 1);
var k0=(istate == 0 ? 1 : istate);
var k1=(istate == 0 ? this.stateCount : istate);
for (var k=k0; k <= k1; k++) {
var atomMap=this.htAtomMap.get$O(p$1.fixName$S.apply(this, [name + "_" + k ]));
if (atomMap == null ) continue;
p$1.getBsAtoms$javajs_util_Lst$IA$javajs_util_BS.apply(this, [atomList, atomMap, bs]);
}
}, p$1);

Clazz.newMeth(C$, 'generateVisibilities$java_util_Map',  function (vis) {
if (vis == null ) return;
var bs=Clazz.new_($I$(1,1));
p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [12294, null]);
for (var e, $e = this.groups.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) e.getValue$().visible=true;

for (var e, $e = vis.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var name=e.getKey$();
if (name.equals$O("all")) continue;
var list=e.getValue$();
var tok=($I$(6).intAt$javajs_util_Lst$I(list, 0) == 1 ? 1610625028 : 12294);
if (tok == 12294) this.htHiddenObjects.put$O$O(name, Boolean.TRUE);
switch (p$1.getObjectType$S.apply(this, [name])) {
case 12:
var g=this.groups.get$O(name);
if (g != null ) g.visible=(tok == 1610625028);
break;
}
}
p$1.setGroupVisibilities.apply(this, []);
for (var e, $e = vis.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var name=e.getKey$();
if (name.equals$O("all")) continue;
p$1.setSceneObject$S$I.apply(this, [name, this.thisState]);
if (this.objectHidden) continue;
var list=e.getValue$();
var tok=(this.objectHidden ? 12294 : 1610625028);
bs=null;
var info=this.objectJmolName;
switch (this.objectType) {
case 0:
case 12:
continue;
case 1:
bs=this.vwr.getDefinedAtomSet$S(info);
if (bs.nextSetBit$I(0) < 0) continue;
break;
case 4:
if (tok == 1610625028) {
var mdList=this.htMeasures.get$O(name);
if (mdList != null ) this.addMeasurements$org_jmol_modelset_MeasurementDataA$I$javajs_util_Lst$javajs_util_BS$I$javajs_util_Lst$Z(mdList, mdList[0].points.size$(), null, p$1.getBS$javajs_util_Lst.apply(this, [$I$(6).listAt$javajs_util_Lst$I(list, 2)]), $I$(6).intAt$javajs_util_Lst$I(list, 3), null, true);
}info+="_*";
break;
case 6:
case 3:
case 2:
break;
}
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [tok, bs, info]);
}
}, p$1);

Clazz.newMeth(C$, 'generateShapes$OA',  function (reps) {
if (reps == null ) return;
p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [12295, null]).argb=this.thisState - 1;
for (var m=0; m < this.moleculeNames.size$(); m++) {
var name=this.moleculeNames.get$I(m);
p$1.setSceneObject$S$I.apply(this, [name, this.thisState]);
if (this.objectHidden) continue;
var molReps=Clazz.array($I$(1), [23]);
for (var i=0; i < 23; i++) molReps[i]=Clazz.new_($I$(1,1));

for (var i=reps.length; --i >= 0; ) {
var repMap=reps[i];
var list=(repMap == null  ? null : repMap.get$O(this.objectName));
if (list != null ) p$1.selectAllAtoms$javajs_util_Lst$I$javajs_util_BS.apply(this, [list, this.thisState, molReps[i]]);
}
this.createShapeObjects$javajs_util_BSA$Z$I$I(molReps, true, -1, -1);
}
}, p$1);

Clazz.newMeth(C$, 'getBS$javajs_util_Lst',  function (list) {
var bs=Clazz.new_($I$(1,1));
for (var i=list.size$(); --i >= 0; ) bs.set$I($I$(6).intAt$javajs_util_Lst$I(list, i));

return bs;
}, p$1);

Clazz.newMeth(C$, 'getBsAtoms$javajs_util_Lst$IA$javajs_util_BS',  function (list, atomMap, bs) {
for (var i=list.size$(); --i >= 0; ) bs.set$I(atomMap[$I$(6).intAt$javajs_util_Lst$I(list, i)]);

}, p$1);

Clazz.newMeth(C$, 'setReaderObjects$',  function () {
p$1.finalizeObjects.apply(this, []);
p$1.clearReaderData.apply(this, []);
if (!this.haveScenes) {
this.uniqueSettings=null;
this.bsUniqueBonds=this.bsStickBonds=this.bsLineBonds=null;
}});

Clazz.newMeth(C$, 'finalizeObjects',  function () {
this.vwr.setStringProperty$S$S("defaults", "PyMOL");
var needToCache=false;
for (var i=0; i < this.jmolObjects.size$(); i++) {
try {
var obj=this.jmolObjects.get$I(i);
if (obj.finalizeObject$org_jmol_adapter_readers_pymol_PyMOLScene$org_jmol_modelset_ModelSet$S$Z(this, this.vwr.ms, this.mepList, this.doCache)) {
needToCache=true;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
e.printStackTrace$();
} else {
throw e;
}
}
}
p$1.finalizeUniqueBonds.apply(this, []);
if (needToCache) {
this.vwr.runScriptCautiously$S("isosurface cache all");
}this.jmolObjects.clear$();
}, p$1);

Clazz.newMeth(C$, 'offsetObjects$',  function () {
for (var i=0, n=this.jmolObjects.size$(); i < n; i++) this.jmolObjects.get$I(i).offset$I$I(this.baseModelIndex, this.baseAtomIndex);

});

Clazz.newMeth(C$, 'getJmolObject$I$javajs_util_BS$O',  function (shape, bsAtoms, info) {
if (this.baseAtomIndex > 0) bsAtoms=$I$(9).copy$javajs_util_BS(bsAtoms);
return Clazz.new_($I$(10,1).c$$I$S$javajs_util_BS$O,[shape, this.objectStateName, bsAtoms, info]);
}, p$1);

Clazz.newMeth(C$, 'addJmolObjectNoInfo$I$javajs_util_BS',  function (shape, bsAtoms) {
return p$1.addObject$org_jmol_adapter_readers_pymol_JmolObject.apply(this, [p$1.getJmolObject$I$javajs_util_BS$O.apply(this, [shape, bsAtoms, null])]);
}, p$1);

Clazz.newMeth(C$, 'addJmolObject$I$javajs_util_BS$O',  function (shape, bsAtoms, info) {
return p$1.addObject$org_jmol_adapter_readers_pymol_JmolObject.apply(this, [p$1.getJmolObject$I$javajs_util_BS$O.apply(this, [shape, bsAtoms, info])]);
}, p$1);

Clazz.newMeth(C$, 'getPymolView$javajs_util_Lst$Z',  function (view, isViewObj) {
var pymolView=Clazz.array(Double.TYPE, [21]);
var depthCue=this.getBooleanOrDefault$I(84);
var fog=this.getBooleanOrDefault$I(88);
var fog_start=this.getDoubleOrDefault$I(192);
var pt=0;
var i=0;
for (var j=0; j < 3; j++) pymolView[pt++]=$I$(6).floatAt$javajs_util_Lst$I(view, i++);

if (isViewObj) ++i;
for (var j=0; j < 3; j++) pymolView[pt++]=$I$(6).floatAt$javajs_util_Lst$I(view, i++);

if (isViewObj) ++i;
for (var j=0; j < 3; j++) pymolView[pt++]=$I$(6).floatAt$javajs_util_Lst$I(view, i++);

if (isViewObj) i+=5;
for (var j=0; j < 8; j++) pymolView[pt++]=$I$(6).floatAt$javajs_util_Lst$I(view, i++);

var isOrtho=this.getBooleanOrDefault$I(23);
var fov=this.getDoubleOrDefault$I(152);
pymolView[pt++]=(isOrtho ? fov : -fov);
pymolView[pt++]=(depthCue ? 1 : 0);
pymolView[pt++]=(fog ? 1 : 0);
pymolView[pt++]=fog_start;
return pymolView;
}, p$1);

Clazz.newMeth(C$, 'globalSetting$I',  function (i) {
var setting=$I$(6).listAt$javajs_util_Lst$I(this.globalSettings, i);
if (setting != null  && setting.size$() == 3 ) return (setting.get$I(2)).doubleValue$();
return $I$(5).getDefaultSetting$I$I(i, this.pymolVersion);
});

Clazz.newMeth(C$, 'addGroup$javajs_util_Lst$S$I$javajs_util_BS',  function (object, parent, type, bsAtoms) {
if (this.groups == null ) this.groups=Clazz.new_($I$(2,1));
var myGroup=this.getGroup$S(this.objectName);
myGroup.object=object;
myGroup.objectNameID=this.objectStateName;
myGroup.visible=!this.objectHidden;
myGroup.type=type;
if (!myGroup.visible) {
this.occludedObjects.put$O$O(this.objectStateName, Boolean.TRUE);
this.htHiddenObjects.put$O$O(this.objectName, Boolean.TRUE);
}if (parent != null  && parent.length$() != 0 ) this.getGroup$S(parent).addList$org_jmol_adapter_readers_pymol_PyMOLGroup(myGroup);
if (bsAtoms != null ) myGroup.addGroupAtoms$javajs_util_BS(bsAtoms);
return myGroup;
});

Clazz.newMeth(C$, 'getGroup$S',  function (name) {
var g=this.groups.get$O(name);
if (g == null ) {
this.groups.put$O$O(name, (g=Clazz.new_($I$(11,1).c$$S,[name])));
p$1.defineAtoms$S$javajs_util_BS.apply(this, [name, g.bsAtoms]);
}return g;
});

Clazz.newMeth(C$, 'finalizeVisibility$',  function () {
p$1.setGroupVisibilities.apply(this, []);
if (this.groups != null ) for (var i=this.jmolObjects.size$(); --i >= 0; ) {
var obj=this.jmolObjects.get$I(i);
if (obj.jmolName != null  && this.occludedObjects.containsKey$O(obj.jmolName) ) obj.visible=false;
}
if (!this.bsHidden.isEmpty$()) p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [2097194, this.bsHidden]);
});

Clazz.newMeth(C$, 'setCarveSets$java_util_Map',  function (htObjNames) {
if (this.htCarveSets.isEmpty$()) return;
for (var e, $e = this.htCarveSets.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) p$1.getSelectionAtoms$javajs_util_Lst$I$javajs_util_BS.apply(this, [$I$(6,"listAt$javajs_util_Lst$I",[htObjNames.get$O(e.getKey$()), 5]), 0, e.getValue$()]);

});

Clazz.newMeth(C$, 'setGroupVisibilities',  function () {
if (this.groups == null ) return;
var list=this.groups.values$();
var bsAll=Clazz.new_($I$(1,1));
for (var g, $g = list.iterator$(); $g.hasNext$()&&((g=($g.next$())),1);) {
bsAll.or$javajs_util_BS(g.bsAtoms);
if (g.parent == null ) p$1.setGroupVisible$org_jmol_adapter_readers_pymol_PyMOLGroup$Z.apply(this, [g, true]);
 else if (g.list.isEmpty$()) g.addGroupAtoms$javajs_util_BS(Clazz.new_($I$(1,1)));
}
p$1.defineAtoms$S$javajs_util_BS.apply(this, ["all", bsAll]);
}, p$1);

Clazz.newMeth(C$, 'defineAtoms$S$javajs_util_BS',  function (name, bs) {
this.htDefinedAtoms.put$O$O(p$1.getJmolName$S.apply(this, [name]), bs);
}, p$1);

Clazz.newMeth(C$, 'getJmolName$S',  function (name) {
return "__" + p$1.fixName$S.apply(this, [name]);
}, p$1);

Clazz.newMeth(C$, 'createShapeObjects$javajs_util_BSA$Z$I$I',  function (reps, allowSurface, ac0, ac) {
if (ac >= 0) {
this.bsAtoms=$I$(9).newBitSet2$I$I(ac0, ac);
var jo;
jo=p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [1153433601, this.bsAtoms]);
this.colixes=$I$(12).ensureLengthShort$HA$I(this.colixes, ac);
for (var i=ac; --i >= ac0; ) this.colixes[i]=(this.atomColorList.get$I(i).intValue$()|0);

jo.setColors$HA$D(this.colixes, 0);
jo.setSize$D(0);
jo=p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [1, this.bsAtoms]);
jo.setSize$D(0);
}p$1.createShapeObject$I$javajs_util_BS.apply(this, [7, reps[7]]);
p$1.createShapeObject$I$javajs_util_BS.apply(this, [0, reps[0]]);
p$1.fixReps$javajs_util_BSA.apply(this, [reps]);
p$1.createSpacefillObjects.apply(this, []);
for (var i=0; i < 23; i++) switch (i) {
case 7:
case 0:
continue;
case 4:
case 1:
case 11:
p$1.createShapeObject$I$javajs_util_BS.apply(this, [i, reps[i]]);
continue;
case 8:
case 2:
if (!allowSurface || this.reader.isStateScript ) continue;
switch (this.getIntOrDefault$I(143)) {
case 0:
reps[i].andNot$javajs_util_BS(this.bsNoSurface);
break;
case 1:
case 3:
break;
case 2:
case 4:
reps[i].andNot$javajs_util_BS(this.bsHydrogen);
break;
}
default:
if (!this.reader.isStateScript) p$1.createShapeObject$I$javajs_util_BS.apply(this, [i, reps[i]]);
continue;
}

this.bsAtoms=null;
});

Clazz.newMeth(C$, 'addLabel$I$I$I$DA$S',  function (atomIndex, uniqueID, atomColor, labelPos, label) {
var icolor=(this.getUniqueDoubleDef$I$I(uniqueID, 66)|0);
if (icolor == -7 || icolor == -6 ) {
} else if (icolor < 0) {
icolor=atomColor;
}if (labelPos == null ) {
labelPos=C$.setLabelPosition$javajs_util_P3d$DA$Z(this.getUniquePoint$I$I$javajs_util_P3d(uniqueID, 471, this.labelPosition), labelPos, false);
}var offset=this.getUniquePoint$I$I$javajs_util_P3d(uniqueID, 718, null);
if (offset != null ) {
labelPos=C$.setLabelPosition$javajs_util_P3d$DA$Z(offset, labelPos, true);
}this.labels.put$O$O(Integer.valueOf$I(atomIndex), p$1.newTextLabel$S$DA$I.apply(this, [label, labelPos, icolor]));
});

Clazz.newMeth(C$, 'setLabelPosition$javajs_util_P3d$DA$Z',  function (offset, labelPos, isPlacement) {
if (labelPos == null ) labelPos=Clazz.array(Double.TYPE, [7]);
labelPos[0]=1;
if (isPlacement) {
labelPos[4]=offset.x;
labelPos[5]=offset.y;
labelPos[6]=offset.z;
} else {
labelPos[1]=offset.x;
labelPos[2]=offset.y;
labelPos[3]=offset.z;
}return labelPos;
}, 1);

Clazz.newMeth(C$, 'isDefaultSettingID$I$I',  function (id, key) {
return (this.isDefaultSetting$I(key) && p$1.getUniqueSetting$I$I.apply(this, [id, key]) == null  );
});

Clazz.newMeth(C$, 'getUniqueDoubleDef$I$I',  function (id, key) {
return this.getUniqueFloatDefVal$I$I$D(id, key, NaN);
});

Clazz.newMeth(C$, 'getUniqueFloatDefVal$I$I$D',  function (id, key, defValue) {
var setting=p$1.getUniqueSetting$I$I.apply(this, [id, key]);
if (setting == null ) return (Double.isNaN$D(defValue) ? this.getDoubleOrDefault$I(key) : defValue);
var v=(setting.get$I(2)).doubleValue$();
if ($I$(8).debugging) $I$(8,"debug$S",["Pymol unique setting for " + id + ": [" + key + "] = " + new Double(v).toString() ]);
return v;
});

Clazz.newMeth(C$, 'getUniquePoint$I$I$javajs_util_P3d',  function (id, key, pt) {
var setting=p$1.getUniqueSetting$I$I.apply(this, [id, key]);
if (setting == null ) return pt;
pt=Clazz.new_($I$(4,1));
$I$(6,"pointAt$javajs_util_Lst$I$javajs_util_P3d",[setting.get$I(2), 0, pt]);
$I$(8,"info$S",["Pymol unique setting for " + id + ": " + key + " = " + pt ]);
return pt;
});

Clazz.newMeth(C$, 'getUniqueSetting$I$I',  function (id, key) {
return (id < 0 ? null : this.uniqueSettings.get$O(Integer.valueOf$I(id * 1000 + key)));
}, p$1);

Clazz.newMeth(C$, 'isDefaultSetting$I',  function (i) {
var setting=p$1.getSetting$I.apply(this, [i]);
return (setting == null  || setting.size$() != 3 );
});

Clazz.newMeth(C$, 'doubleSetting$I',  function (i) {
var setting=p$1.getSetting$I.apply(this, [i]);
return (setting != null  && setting.size$() == 3  ? (setting.get$I(2)).doubleValue$() : $I$(5).getDefaultSetting$I$I(i, this.pymolVersion));
});

Clazz.newMeth(C$, 'stringSetting$I',  function (i) {
var setting=p$1.getSetting$I.apply(this, [i]);
if (setting != null  && setting.size$() == 3 ) return $I$(6).stringAt$javajs_util_Lst$I(setting, 2);
return $I$(5).getDefaultSettingS$I$I(i, this.pymolVersion);
});

Clazz.newMeth(C$, 'getSetting$I',  function (i) {
var setting=null;
if (this.stateSettings != null ) setting=this.stateSettings.get$O(Integer.valueOf$I(i));
if (setting == null  && this.objectSettings != null  ) setting=this.objectSettings.get$O(Integer.valueOf$I(i));
if (setting == null  && i < this.globalSettings.size$() ) setting=this.globalSettings.get$I(i);
return setting;
}, p$1);

Clazz.newMeth(C$, 'addCGO$javajs_util_Lst$I',  function (data, color) {
data.addLast$O(this.objectName);
var jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [23, null, data]);
jo.argb=color;
jo.translucency=this.getDoubleOrDefault$I(441);
return p$1.fixName$S.apply(this, [this.objectName]);
});

Clazz.newMeth(C$, 'addMeasurements$org_jmol_modelset_MeasurementDataA$I$javajs_util_Lst$javajs_util_BS$I$javajs_util_Lst$Z',  function (mdList, nCoord, list, bsReps, color, offsets, haveLabels) {
var isNew=(mdList == null );
var n=(isNew ? (list.size$()/3 / nCoord |0) : mdList.length);
if (n == 0) return false;
var drawLabel=haveLabels && (bsReps == null  || bsReps.get$I(3) ) ;
var drawDashes=(bsReps == null  || bsReps.get$I(10) );
var rad=this.getDoubleOrDefault$I(107);
rad/=400;
if (rad == 0 ) rad=0.05;
if (!drawDashes) rad=-5.0E-4;
if (color < 0) color=this.getIntOrDefault$I(574);
var c=$I$(5).getRGB$I(color);
var colix=$I$(13).getColix$I(c);
var labelColor=this.getIntOrDefault$I(66);
var clabel=(labelColor < 0 ? color : labelColor);
if (isNew) {
mdList=Clazz.array($I$(14), [n]);
this.htMeasures.put$O$O(this.objectName, mdList);
}var bs=$I$(9).newAndSetBit$I(0);
for (var index=0, p=0; index < n; index++) {
var md;
var offset;
if (isNew) {
var points=Clazz.new_($I$(3,1));
for (var i=0; i < nCoord; i++, p+=3) points.addLast$O($I$(15,"newPF$javajs_util_T3d$I",[$I$(6,"pointAt$javajs_util_Lst$I$javajs_util_P3d",[list, p, Clazz.new_($I$(4,1))]), 0]));

offset=($I$(6,"floatsAt$javajs_util_Lst$I$DA$I",[$I$(6).listAt$javajs_util_Lst$I(offsets, index), 0, Clazz.array(Double.TYPE, [7]), 7]));
if (offset == null ) offset=C$.setLabelPosition$javajs_util_P3d$DA$Z(this.labelPosition, Clazz.array(Double.TYPE, [7]), false);
md=mdList[index]=this.vwr.newMeasurementData$S$javajs_util_Lst(this.objectStateName + "_" + (index + 1) , points);
md.note=this.objectName;
} else {
md=mdList[index];
offset=md.text.getPymolOffset$();
}offset=$I$(5).fixAllZeroLabelPosition$DA(offset);
if (offset == null ) offset=Clazz.array(Double.TYPE, -1, [1, 0, 0, 0, 0, 0, 0]);
var nDigits=this.getIntOrDefault$I(C$.MEAS_DIGITS[nCoord - 2]);
var strFormat=nCoord + ": " + (drawLabel ? "%0." + (nDigits < 0 ? 1 : nDigits) + "VALUE"  : "") ;
var text=p$1.newTextLabel$S$DA$I.apply(this, [strFormat, offset, clabel]);
md.set$I$java_util_Map$org_jmol_atomdata_RadiusData$S$S$S$org_jmol_modelset_TickInfo$Z$Z$Boolean$Z$I$H$org_jmol_modelset_Text$D$javajs_util_BS(12290, null, null, null, strFormat, "angstroms", null, false, false, null, false, ((rad * 2000)|0), colix, text, NaN, null);
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [6, bs, md]);
}
return true;
});

Clazz.newMeth(C$, 'getViewScript$javajs_util_Lst',  function (view) {
var sb=Clazz.new_($I$(16,1));
var pymolView=p$1.getPymolView$javajs_util_Lst$Z.apply(this, [view, true]);
sb.append$S(";set translucent " + (this.globalSetting$I(213) != 2 ) + ";set zshadePower 1;set traceAlpha " + (this.globalSetting$I(111) != 0 ) );
var rockets=this.getBooleanOrDefault$I(180);
sb.append$S(";set cartoonRockets " + rockets);
if (rockets) sb.append$S(";set rocketBarrels " + rockets);
sb.append$S(";set cartoonLadders " + this.haveNucleicLadder);
sb.append$S(";set ribbonBorder " + (this.globalSetting$I(118) != 0 ));
sb.append$S(";set cartoonFancy " + (this.globalSetting$I(118) == 0 ));
var s="000000" + Integer.toHexString$I(this.bgRgb & 16777215);
s="[x" + s.substring$I(s.length$() - 6) + "]" ;
sb.append$S(";background " + s);
sb.append$S(";moveto 0 PyMOL " + $I$(17).eAD$DA(pymolView));
sb.append$S(";save orientation \'default\';");
return sb;
});

Clazz.newMeth(C$, 'getColix$I$D',  function (colorIndex, translucency) {
var colix=(colorIndex == -7 ? ($I$(13).getBgContrast$I(this.bgRgb) == 8 ? 4 : 8) : colorIndex == -6 ? $I$(13).getBgContrast$I(this.bgRgb) : $I$(13,"getColixO$O",[Integer.valueOf$I($I$(5).getRGB$I(colorIndex))]));
return $I$(13).getColixTranslucent3$H$Z$D(colix, translucency > 0 , translucency);
});

Clazz.newMeth(C$, 'setAtomColor$I',  function (atomColor) {
this.atomColorList.addLast$O(Integer.valueOf$I(this.getColix$I$D(atomColor, 0)));
});

Clazz.newMeth(C$, 'setFrameObject$I$O',  function (type, info) {
if (info != null ) {
this.frameObj=p$1.getJmolObject$I$javajs_util_BS$O.apply(this, [type, null, info]);
return;
}if (this.frameObj == null ) return;
this.frameObj.finalizeObject$org_jmol_adapter_readers_pymol_PyMOLScene$org_jmol_modelset_ModelSet$S$Z(this, this.vwr.ms, null, false);
this.frameObj=null;
});

Clazz.newMeth(C$, 'fixName$S',  function (name) {
var chars=name.toLowerCase$().toCharArray$();
for (var i=chars.length; --i >= 0; ) if (!$I$(18).isLetterOrDigit$C(chars[i])) chars[i]="_";

return String.valueOf$CA(chars);
}, p$1);

Clazz.newMeth(C$, 'getObjectID$S',  function (name) {
return this.objectInfo.get$O(name)[0];
});

Clazz.newMeth(C$, 'getObjectType$S',  function (name) {
var o=this.objectInfo.get$O(name);
return (o == null  ? 0 : (o[1]).intValue$());
}, p$1);

Clazz.newMeth(C$, 'setAtomMap$IA$I',  function (atomMap, ac0) {
this.htAtomMap.put$O$O(this.objectStateName, atomMap);
var bsAtoms=this.htDefinedAtoms.get$O(this.objectJmolName);
if (bsAtoms == null ) {
bsAtoms=$I$(1).newN$I(ac0 + atomMap.length);
$I$(8).info$S("PyMOL molecule " + this.objectName + " " + this.objectHidden );
this.htDefinedAtoms.put$O$O(this.objectJmolName, bsAtoms);
this.htObjectAtoms.put$O$O(this.objectName, bsAtoms);
this.moleculeNames.addLast$O(this.objectName);
this.modelName=this.objectName;
}return bsAtoms;
});

Clazz.newMeth(C$, 'newTextLabel$S$DA$I',  function (label, labelOffset, colorIndex) {
var face;
var fontID=this.getIntOrDefault$I(328);
switch (fontID) {
default:
case 11:
case 12:
case 13:
case 14:
face="SansSerif";
break;
case 0:
case 1:
face="Monospaced";
break;
case 9:
case 10:
case 15:
case 16:
case 17:
case 18:
face="Serif";
break;
}
var style;
switch (fontID) {
default:
style="Plain";
break;
case 6:
case 12:
case 16:
case 17:
style="Italic";
break;
case 7:
case 10:
case 13:
style="Bold";
break;
case 8:
case 14:
case 18:
style="BoldItalic";
break;
}
var fontSize=this.getDoubleOrDefault$I(453);
if (fontSize > 0 ) fontSize*=1.25;
var font=this.vwr.getFont3D$S$S$D(face, style, fontSize == 0  ? 12 : fontSize);
var t=$I$(19,"newLabel$org_jmol_viewer_Viewer$org_jmol_util_Font$S$H$H$I$D",[this.vwr, font, label, this.getColix$I$D(colorIndex, 0), 0, 0, 0]);
if (t != null ) t.setPymolOffset$DA(labelOffset);
return t;
}, p$1);

Clazz.newMeth(C$, 'addVersionSettings',  function () {
if (this.pymolVersion < 100) {
p$1.addVersionSetting$I$I$O.apply(this, [550, 2, Integer.valueOf$I(0)]);
p$1.addVersionSetting$I$I$O.apply(this, [529, 2, Integer.valueOf$I(2)]);
if (this.pymolVersion < 99) {
p$1.addVersionSetting$I$I$O.apply(this, [448, 2, Integer.valueOf$I(0)]);
p$1.addVersionSetting$I$I$O.apply(this, [431, 2, Integer.valueOf$I(0)]);
p$1.addVersionSetting$I$I$O.apply(this, [361, 2, Integer.valueOf$I(1)]);
}}}, p$1);

Clazz.newMeth(C$, 'addVersionSetting$I$I$O',  function (key, type, val) {
var settingCount=this.globalSettings.size$();
if (settingCount <= key) for (var i=key + 1; --i >= settingCount; ) this.globalSettings.addLast$O(null);

if (type == 4) {
var d=val;
var list;
val=list=Clazz.new_($I$(3,1));
for (var i=0; i < 3; i++) list.addLast$O(Double.valueOf$D(d[i]));

}var setting=Clazz.new_($I$(3,1));
setting.addLast$O(Integer.valueOf$I(key));
setting.addLast$O(Integer.valueOf$I(type));
setting.addLast$O(val);
this.globalSettings.set$I$O(key, setting);
}, p$1);

Clazz.newMeth(C$, 'fixReps$javajs_util_BSA',  function (reps) {
this.bsCartoon.clearAll$();
for (var iAtom=this.bsAtoms.nextSetBit$I(0); iAtom >= 0; iAtom=this.bsAtoms.nextSetBit$I(iAtom + 1)) {
var atomUID=(this.reader == null  ? this.uniqueIDs[iAtom] : this.reader.getUniqueID$I(iAtom));
var rad=0;
if (reps[1].get$I(iAtom)) {
var scale=this.getUniqueDoubleDef$I$I(atomUID, 155);
rad=(this.reader == null  ? this.radii[iAtom] : this.reader.getVDW$I(iAtom)) * scale;
} else {
var isRepNB=reps[4].get$I(iAtom);
rad=(isRepNB ? this.getStickBallRadius$I(atomUID) : 0);
if (rad > 0  && this.bsHydrogen.get$I(iAtom)  && !this.bsNonbonded.get$I(iAtom) ) {
rad*=this.getUniqueDoubleDef$I$I(atomUID, 605);
}if (rad == 0  && isRepNB ) {
if (this.bsNonbonded.get$I(iAtom)) {
rad=this.getUniqueDoubleDef$I$I(atomUID, 65);
}}}if (rad != 0 ) {
this.addSpacefill$I$D$Z(iAtom, rad, true);
}var cartoonType=(this.reader == null  ? this.cartoonTypes[iAtom] : this.reader.getCartoonType$I(iAtom));
if (reps[5].get$I(iAtom)) {
switch (cartoonType) {
case 1:
case 4:
reps[21].set$I(iAtom);
case -1:
reps[5].clear$I(iAtom);
this.bsCartoon.clear$I(iAtom);
break;
case 7:
reps[22].set$I(iAtom);
reps[5].clear$I(iAtom);
this.bsCartoon.clear$I(iAtom);
break;
default:
this.bsCartoon.set$I(iAtom);
}
}}
reps[5].and$javajs_util_BS(this.bsCartoon);
p$1.cleanSingletons$javajs_util_BS.apply(this, [reps[5]]);
p$1.cleanSingletons$javajs_util_BS.apply(this, [reps[6]]);
p$1.cleanSingletons$javajs_util_BS.apply(this, [reps[21]]);
p$1.cleanSingletons$javajs_util_BS.apply(this, [reps[22]]);
this.bsCartoon.and$javajs_util_BS(reps[5]);
}, p$1);

Clazz.newMeth(C$, 'addSpacefill$I$D$Z',  function (iAtom, rad, doCheck) {
if (doCheck && this.bsSpacefillSphere.get$I(iAtom) ) return;
this.bsSpacefillSphere.set$I(iAtom);
var r=Double.valueOf$D(rad);
var bsr=this.htSpacefill.get$O(r);
if (bsr == null ) this.htSpacefill.put$O$O(r, bsr=Clazz.new_($I$(1,1)));
bsr.set$I(iAtom);
});

Clazz.newMeth(C$, 'cleanSingletons$javajs_util_BS',  function (bs) {
if (bs.isEmpty$()) return;
bs.and$javajs_util_BS(this.bsAtoms);
var bsr=Clazz.new_($I$(1,1));
var n=bs.length$();
var pass=0;
while (true){
for (var i=0, offset=0, iPrev=-2147483648, iSeqLast=-2147483648, iSeq=-2147483648; i < n; i++) {
if (iPrev < 0 || (this.reader == null  ? this.newChain[i] : this.reader.compareAtoms$I$I(iPrev, i)) ) ++offset;
iSeq=(this.reader == null  ? this.sequenceNumbers[i] : this.reader.getSequenceNumber$I(i));
if (iSeq != iSeqLast) {
iSeqLast=iSeq;
++offset;
}if (pass == 0) {
if (bs.get$I(i)) bsr.set$I(offset);
} else if (!bsr.get$I(offset)) bs.clear$I(i);
iPrev=i;
}
if (++pass == 2) break;
var bsnot=Clazz.new_($I$(1,1));
for (var i=bsr.nextSetBit$I(0); i >= 0; i=bsr.nextSetBit$I(i + 1)) if (!bsr.get$I(i - 1) && !bsr.get$I(i + 1) ) bsnot.set$I(i);

bsr.andNot$javajs_util_BS(bsnot);
}
}, p$1);

Clazz.newMeth(C$, 'createShapeObject$I$javajs_util_BS',  function (repType, bs) {
if (bs.isEmpty$()) return;
var jo=null;
switch (repType) {
case 11:
bs.and$javajs_util_BS(this.bsNonbonded);
if (bs.isEmpty$()) return;
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [7, bs, 0, 0, 524, this.getDoubleOrDefault$I(524), 0, this.getDoubleOrDefault$I(65), 0.5]);
break;
case 4:
break;
case 1:
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [0, bs, 173, this.getIntOrDefault$I(173), 172, this.getDoubleOrDefault$I(172), 155, this.getIntOrDefault$I(155), 1]);
break;
case 19:
var ellipsoidTranslucency=this.getDoubleOrDefault$I(571);
var ellipsoidColor=this.getIntOrDefault$I(570);
var ellipsoidScale=this.getDoubleOrDefault$I(569);
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [20, bs, 570, ellipsoidColor, 571, ellipsoidTranslucency, 569, ellipsoidScale, 50]);
break;
case 9:
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [16, bs, 210, this.getIntOrDefault$I(210), 0, 0, 155, this.getDoubleOrDefault$I(155), 1]);
break;
case 2:
{
var withinDistance=this.getDoubleOrDefault$I(344);
var surfaceMode=this.getIntOrDefault$I(421);
jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [135180, bs, Clazz.array(java.lang.Object, -1, [this.getBooleanOrDefault$I(156) ? "FULLYLIT" : "FRONTLIT", (surfaceMode == 3 || surfaceMode == 4 ) ? " only" : "", this.bsCarve, Double.valueOf$D(withinDistance)])]);
jo.setSize$D(this.getDoubleOrDefault$I(4) * (this.getBooleanOrDefault$I(338) ? -1 : 1));
jo.translucency=this.getDoubleOrDefault$I(138);
var surfaceColor=this.getIntOrDefault$I(144);
if (surfaceColor >= 0) jo.argb=$I$(5).getRGB$I(surfaceColor);
jo.modelIndex=this.currentAtomSetIndex;
jo.cacheID=this.surfaceInfoName;
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [24, bs, 144, surfaceColor, 138, jo.translucency, 0, 0, 0]);
break;
}case 8:
{
jo=p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [135180, bs]);
jo.setSize$D(this.getDoubleOrDefault$I(4));
jo.translucency=this.getDoubleOrDefault$I(138);
var surfaceColor=this.getIntOrDefault$I(144);
p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [24, bs, 144, surfaceColor, 138, jo.translucency, 0, 0, 0]);
break;
}case 3:
bs.and$javajs_util_BS(this.bsLabeled);
if (bs.isEmpty$()) return;
jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [5, bs, this.labels]);
break;
case 10:
case 7:
jo=p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [659488, bs]);
jo.setSize$D(this.getDoubleOrDefault$I(44) / 15);
var color=this.getIntOrDefault$I(526);
if (color >= 0) jo.argb=$I$(5).getRGB$I(color);
break;
case 0:
var info=null;
if (!this.bsHydrogen.isEmpty$()) {
var bsH=$I$(9).copy$javajs_util_BS(bs);
bsH.and$javajs_util_BS(this.bsHydrogen);
info=Clazz.array(java.lang.Object, -1, [bsH, Double.valueOf$D(this.getUniqueDoubleDef$I$I(repType, 605))]);
}jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [1, bs, info]);
jo.setSize$D(this.getDoubleOrDefault$I(21) * 2);
jo.translucency=this.getDoubleOrDefault$I(198);
var col=this.getIntOrDefault$I(376);
if (col >= 0) jo.argb=$I$(5).getRGB$I(col);
break;
case 5:
p$1.createCartoonObject$S$I.apply(this, ["H", (this.getBooleanOrDefault$I(180) ? 181 : 100)]);
p$1.createCartoonObject$S$I.apply(this, ["S", 96]);
p$1.createCartoonObject$S$I.apply(this, ["L", 92]);
p$1.createCartoonObject$S$I.apply(this, [" ", 92]);
break;
case 22:
p$1.createPuttyObject$javajs_util_BS.apply(this, [bs]);
break;
case 21:
p$1.createTraceObject$javajs_util_BS.apply(this, [bs]);
break;
case 6:
p$1.createRibbonObject$javajs_util_BS.apply(this, [bs]);
break;
default:
$I$(8).error$S("Unprocessed representation type " + repType);
}
}, p$1);

Clazz.newMeth(C$, 'setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D',  function (shape, bs, setColor, color, setTrans, trans, setSize, size, f) {
var n=bs.cardinality$();
var colixes=Clazz.array(Short.TYPE, [n]);
var atrans=(setTrans == 0 ? null : Clazz.array(Double.TYPE, [n]));
var sizes=Clazz.array(Double.TYPE, [n]);
var checkAtomScale=(shape == 0 && !this.bsHydrogen.isEmpty$() );
for (var pt=0, i=bs.nextSetBit$I(0); i >= 0; i=bs.nextSetBit$I(i + 1), pt++) {
var id=(this.reader == null  ? this.uniqueIDs[i] : this.reader.getUniqueID$I(i));
if (setColor == 0) {
} else {
var c=(this.getUniqueFloatDefVal$I$I$D(id, setColor, color)|0);
if (c > 0) colixes[pt]=this.getColix$I$D(c, 0);
}if (atrans != null ) {
atrans[pt]=this.getUniqueFloatDefVal$I$I$D(id, setTrans, trans);
}var r=this.getUniqueFloatDefVal$I$I$D(id, setSize, size) * f;
if (checkAtomScale && this.bsHydrogen.get$I(i) && this.isDefaultSettingID$I$I(id, setSize)  ) {
sizes[pt]=0;
} else {
sizes[pt]=r;
}}
return p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [shape, bs, Clazz.array(java.lang.Object, -1, [colixes, atrans, sizes])]);
}, p$1);

Clazz.newMeth(C$, 'createSpacefillObjects',  function () {
for (var e, $e = this.htSpacefill.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var r=e.getKey$().doubleValue$();
var bs=e.getValue$();
p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [1153433601, bs]).rd=Clazz.new_([null, r, $I$(21).ABSOLUTE, $I$(22).AUTO],$I$(20,1).c$$DA$D$org_jmol_atomdata_RadiusData_EnumType$org_jmol_c_VDW);
}
this.htSpacefill.clear$();
}, p$1);

Clazz.newMeth(C$, 'createTraceObject$javajs_util_BS',  function (bs) {
p$1.checkNucleicObject$javajs_util_BS$Z.apply(this, [bs, true]);
if (bs.isEmpty$()) return;
var r=this.doubleSetting$I(103);
var jo=p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [10, bs, 236, this.getIntOrDefault$I(236), 0, 0, 0, 0, 0]);
jo.setSize$D(r * 2);
jo.translucency=this.getDoubleOrDefault$I(279);
}, p$1);

Clazz.newMeth(C$, 'checkNucleicObject$javajs_util_BS$Z',  function (bs, isTrace) {
var jo;
var bsNuc=$I$(9).copy$javajs_util_BS(this.bsNucleic);
bsNuc.and$javajs_util_BS(bs);
if (!bsNuc.isEmpty$()) {
if (isTrace && this.getBooleanOrDefault$I(448) ) this.haveNucleicLadder=true;
jo=p$1.addJmolObjectNoInfo$I$javajs_util_BS.apply(this, [11, bsNuc]);
jo.translucency=this.getDoubleOrDefault$I(279);
jo.setSize$D(this.doubleSetting$I(103) * 2);
bs.andNot$javajs_util_BS(bsNuc);
}}, p$1);

Clazz.newMeth(C$, 'createPuttyObject$javajs_util_BS',  function (bs) {
var info=Clazz.array(Double.TYPE, -1, [this.doubleSetting$I(378), this.doubleSetting$I(377), this.doubleSetting$I(382), this.doubleSetting$I(379), this.doubleSetting$I(380), this.doubleSetting$I(381), this.doubleSetting$I(581)]);
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [1112152078, bs, info]).translucency=this.getDoubleOrDefault$I(279);
}, p$1);

Clazz.newMeth(C$, 'createRibbonObject$javajs_util_BS',  function (bs) {
var isTrace=(this.doubleSetting$I(19) > 1 );
var r=this.doubleSetting$I(20) * 2;
var rayScale=this.doubleSetting$I(327);
if (r == 0 ) r=this.doubleSetting$I(106) * (isTrace ? 1 : (rayScale <= 1  ? 0.5 : rayScale)) * 0.1 ;
var jo=p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [(isTrace ? 10 : 9), bs, 235, this.getIntOrDefault$I(235), 0, 0, 0, 0, 0]);
jo.setSize$D(r);
jo.translucency=this.getDoubleOrDefault$I(666);
}, p$1);

Clazz.newMeth(C$, 'createCartoonObject$S$I',  function (key, sizeID) {
var bs=$I$(9,"copy$javajs_util_BS",[this.ssMapAtom.get$O(key)]);
if (bs == null ) return;
bs.and$javajs_util_BS(this.bsCartoon);
if (bs.isEmpty$()) return;
if (key.equals$O(" ")) {
p$1.checkNucleicObject$javajs_util_BS$Z.apply(this, [bs, false]);
if (bs.isEmpty$()) return;
}var jo=p$1.setUniqueObjects$I$javajs_util_BS$I$I$I$D$I$D$D.apply(this, [11, bs, 236, this.getIntOrDefault$I(236), 0, 0, 0, 0, 0]);
jo.setSize$D(this.doubleSetting$I(sizeID) * 2);
jo.translucency=this.getDoubleOrDefault$I(279);
}, p$1);

Clazz.newMeth(C$, 'addObject$org_jmol_adapter_readers_pymol_JmolObject',  function (obj) {
this.jmolObjects.addLast$O(obj);
return obj;
}, p$1);

Clazz.newMeth(C$, 'setGroupVisible$org_jmol_adapter_readers_pymol_PyMOLGroup$Z',  function (g, parentVis) {
var vis=parentVis && g.visible ;
if (vis) return;
g.visible=false;
this.occludedObjects.put$O$O(g.objectNameID, Boolean.TRUE);
this.htHiddenObjects.put$O$O(g.name, Boolean.TRUE);
switch (g.type) {
case 1:
this.bsHidden.or$javajs_util_BS(g.bsAtoms);
break;
default:
g.occluded=true;
break;
}
for (var gg, $gg = g.list.values$().iterator$(); $gg.hasNext$()&&((gg=($gg.next$())),1);) {
p$1.setGroupVisible$org_jmol_adapter_readers_pymol_PyMOLGroup$Z.apply(this, [gg, vis]);
}
}, p$1);

Clazz.newMeth(C$, 'getSSMapAtom$S',  function (ssType) {
var bs=this.ssMapAtom.get$O(ssType);
if (bs == null ) this.ssMapAtom.put$O$O(ssType, bs=Clazz.new_($I$(1,1)));
return bs;
});

Clazz.newMeth(C$, 'setAtomDefs$',  function () {
p$1.setGroupVisibilities.apply(this, []);
var defs=Clazz.new_($I$(2,1));
for (var e, $e = this.htDefinedAtoms.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
var bs=e.getValue$();
if (!bs.isEmpty$()) defs.put$O$O(e.getKey$(), bs);
}
p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [12290, null, defs]);
return defs;
});

Clazz.newMeth(C$, 'needSelections$',  function () {
return this.haveScenes || !this.htCarveSets.isEmpty$() ;
});

Clazz.newMeth(C$, 'setUniqueBonds$javajs_util_BS$Z',  function (bsBonds, isSticks) {
if (isSticks) {
this.bsStickBonds.or$javajs_util_BS(bsBonds);
this.bsStickBonds.andNot$javajs_util_BS(this.bsLineBonds);
} else {
this.bsLineBonds.or$javajs_util_BS(bsBonds);
this.bsLineBonds.andNot$javajs_util_BS(this.bsStickBonds);
}});

Clazz.newMeth(C$, 'finalizeUniqueBonds',  function () {
if (this.uniqueList == null ) return;
var bondCount=this.vwr.ms.bondCount;
var bonds=this.vwr.ms.bo;
for (var i=this.bsUniqueBonds.nextSetBit$I(0); i >= 0 && i < bondCount ; i=this.bsUniqueBonds.nextSetBit$I(i + 1)) {
var b=bonds[i];
var rad=NaN;
var id=this.uniqueList.get$O(Integer.valueOf$I(i)).intValue$();
var isStickBond=this.bsStickBonds.get$I(i);
if (this.bsLineBonds.get$I(i)) {
rad=this.getUniqueDoubleDef$I$I(id, 44) / 30;
} else if (this.bsStickBonds.get$I(i)) {
rad=this.getRadiusForBond$I$I$I(id, b.atom1.i, b.atom2.i);
}var c=(this.getUniqueFloatDefVal$I$I$D(id, 376, 2147483647)|0);
if (c != 2147483647) c=$I$(5).getRGB$I(c);
var v=this.getUniqueDoubleDef$I$I(id, 64);
var t=this.getUniqueDoubleDef$I$I(id, 198);
var scalex50=((v == 1  ? this.getUniqueDoubleDef$I$I(id, 512) * 50 : 0)|0) & 63;
this.setUniqueBondParameters$org_jmol_modelset_Bond$I$D$D$I$D$I$Z(b, this.thisState - 1, rad, v, c, t, scalex50, isStickBond);
}
}, p$1);

Clazz.newMeth(C$, 'setUniqueBondParameters$org_jmol_modelset_Bond$I$D$D$I$D$I$Z',  function (b, modelIndex, rad, pymolValence, argb, trans, scalex50, isStickBond) {
if (modelIndex >= 0 && b.atom1.mi != modelIndex ) return;
if (!Double.isNaN$D(rad)) {
b.mad=($s$[0] = (rad * 2000), $s$[0]);
if (rad > 0  && isStickBond ) {
p$1.addStickBall$I.apply(this, [b.atom1.i]);
p$1.addStickBall$I.apply(this, [b.atom2.i]);
}}var colix=b.colix;
if (argb != 2147483647) colix=$I$(13).getColix$I(argb);
if (!Double.isNaN$D(trans)) b.colix=$I$(13,"getColixTranslucent3$H$Z$D",[colix, trans != 0 , trans]);
 else if (b.colix != colix) b.colix=$I$(13).copyColixTranslucency$H$H(b.colix, colix);
if (pymolValence == 1 ) {
b.order|=(scalex50 << 2) | 98304;
} else if (pymolValence == 0 ) {
b.order|=65536;
}});

Clazz.newMeth(C$, 'addStickBall$I',  function (iatom) {
this.addSpacefill$I$D$Z(iatom, this.getStickBallRadius$I(this.jmolToUniqueID[iatom]), false);
}, p$1);

Clazz.newMeth(C$, 'addMesh$I$javajs_util_Lst$S$Z',  function (tok, obj, objName, isMep) {
var jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [tok, null, obj]);
p$1.setSceneObject$S$I.apply(this, [objName, -1]);
var meshColor=this.getIntOrDefault$I(146);
if (meshColor < 0) meshColor=$I$(6,"intAt$javajs_util_Lst$I",[$I$(6).listAt$javajs_util_Lst$I(obj, 0), 2]);
if (!isMep) {
jo.setSize$D(this.getDoubleOrDefault$I(90));
jo.argb=$I$(5).getRGB$I(meshColor);
}jo.translucency=this.getDoubleOrDefault$I(138);
jo.cacheID=this.surfaceInfoName;
});

Clazz.newMeth(C$, 'addIsosurface$S',  function (objectName) {
var jo=p$1.addJmolObject$I$javajs_util_BS$O.apply(this, [135180, null, objectName]);
jo.translucency=this.getDoubleOrDefault$I(138);
jo.cacheID=this.surfaceInfoName;
return jo;
});

Clazz.newMeth(C$, 'isStickBall$I',  function (id) {
return (this.getUniqueDoubleDef$I$I(id, 276) == 1 );
}, p$1);

Clazz.newMeth(C$, 'getStickBallRadius$I',  function (id) {
return (p$1.isStickBall$I.apply(this, [id]) ? this.getUniqueDoubleDef$I$I(id, 21) * this.getUniqueDoubleDef$I$I(id, 277) : 0);
});

Clazz.newMeth(C$, 'encodeMultipleBond$I$Z',  function (uid, isSpecial) {
var scalex50=((isSpecial ? this.getUniqueDoubleDef$I$I(uid, 512) * 50 : 0)|0) & 63;
return (scalex50 << 2) | 98304;
});

Clazz.newMeth(C$, 'getRadiusForBond$I$I$I',  function (id, a1, a2) {
var rad=this.getUniqueDoubleDef$I$I(id, 21);
if (this.bsHydrogen.get$I(a1) || this.bsHydrogen.get$I(a2) ) {
rad*=this.getUniqueDoubleDef$I$I(id, 605);
}return rad;
});

Clazz.newMeth(C$, 'setNumAtoms$I',  function (nAtomsJmol) {
this.jmolToUniqueID=Clazz.array(Integer.TYPE, [nAtomsJmol]);
});

C$.$static$=function(){C$.$static$=0;
C$.MEAS_DIGITS=Clazz.array(Integer.TYPE, -1, [530, 531, 532]);
};
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-30 14:46:28 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
