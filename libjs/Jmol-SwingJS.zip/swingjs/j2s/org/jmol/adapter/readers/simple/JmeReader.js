(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.simple"),p$1={},I$=[[0,'javajs.util.PT','org.jmol.adapter.smarter.Bond']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "JmeReader", null, 'org.jmol.adapter.smarter.AtomSetCollectionReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.asc.setCollectionName$S("JME");
this.asc.newAtomSet$();
this.line=this.rd$().replace$C$C("\t", " ");
this.checkCurrentLineForScript$();
this.addJmolScript$S("jmeString='" + this.line + "'" );
var ac=this.parseInt$();
var bondCount=this.parseInt$();
p$1.readAtoms$I.apply(this, [ac]);
p$1.readBonds$I.apply(this, [bondCount]);
if (this.asc.ac == 0 && this.line.equals$O("0")  && !this.merging ) {
var atom=this.asc.addNewAtom$();
this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atom, NaN, NaN, 0);
this.addJmolScript$S("delete thisModel");
} else {
this.set2D$();
}this.continuing=false;
});

Clazz.newMeth(C$, 'readAtoms$I',  function (ac) {
for (var i=0; i < ac; ++i) {
var strAtom=this.parseToken$();
var atom=this.asc.addNewAtom$();
this.setAtomCoordXYZ$org_jmol_adapter_smarter_Atom$D$D$D(atom, this.parseDouble$(), this.parseDouble$(), 0);
var indexColon=strAtom.indexOf$I(":");
var elementSymbol=(indexColon > 0 ? strAtom.substring$I$I(0, indexColon) : strAtom);
if (elementSymbol.indexOf$S("+") >= 0) {
elementSymbol=$I$(1).trim$S$S(elementSymbol, "+");
atom.formalCharge=1;
} else if (elementSymbol.indexOf$S("-") >= 0) {
elementSymbol=$I$(1).trim$S$S(elementSymbol, "-");
atom.formalCharge=-1;
}atom.elementSymbol=elementSymbol;
}
if (ac > 0) this.asc.setModelInfoForSet$S$O$I("dimension", "2D", this.asc.iSet);
}, p$1);

Clazz.newMeth(C$, 'readBonds$I',  function (bondCount) {
for (var i=0; i < bondCount; ++i) {
var atomIndex1=this.parseInt$() - 1;
var atomIndex2=this.parseInt$() - 1;
var order=this.parseInt$();
switch (order) {
default:
continue;
case 1:
case 2:
case 3:
break;
case -1:
order=1025;
break;
case -2:
order=1041;
break;
}
this.asc.addBond$org_jmol_adapter_smarter_Bond(Clazz.new_($I$(2,1).c$$I$I$I,[atomIndex1, atomIndex2, order]));
}
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:44 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
