(function(){var P$=Clazz.newPackage("org.jmol.adapter.readers.cif"),p$1={},I$=[[0,'javajs.util.Lst','javajs.util.P3d','javajs.util.Rdr','javajs.util.CifDataParser','org.jmol.util.Logger','javajs.util.PT','java.util.Hashtable','org.jmol.api.JmolAdapter','javajs.api.Interface','org.jmol.adapter.smarter.Atom','org.jmol.util.Vibration','org.jmol.util.SimpleUnitCell','javajs.util.BS']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CifReader", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'org.jmol.adapter.smarter.AtomSetCollectionReader');
C$.$classes$=[['Parser',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.ignoreCollinearSpinBasisIfGiven=false;
this.flagCollinearSpinBasisIfGiven=true;
this.allowRotations=true;
this.readIdeal=true;
this.configurationPtr=-2147483648;
this.useAuthorChainID=true;
this.newAtomSetLabel=-1;
this.thisDataSetName="";
this.chemicalName="";
this.thisStructuralFormula="";
this.thisFormula="";
this.molecularType="GEOM_BOND default";
this.lastAltLoc="\u0000";
this.nMolecular=0;
this.titleAtomSet=1;
this.allowWyckoff=true;
this.maxOps=-1;
this.bondTypes=Clazz.new_($I$(1,1));
this.disorderAssembly=".";
this.ptOffset=Clazz.new_($I$(2,1));
this.col2key=Clazz.array(Integer.TYPE, [100]);
this.key2col=Clazz.array(Integer.TYPE, [100]);
this.firstChar="\u0000";
},1);

C$.$fields$=[['Z',['ignoreCollinearSpinBasisIfGiven','flagCollinearSpinBasisIfGiven','isCollinear','filterAssembly','allowRotations','readIdeal','useAuthorChainID','skipping','isAFLOW','iHaveDesiredModel','isMMCIF','isLigand','haveAromatic','haveHAtoms','isCourseGrained','noLattice','haveCellWaveVector','modulated','addAtomLabelNumbers','ignoreGeomBonds','allowWyckoff','stopOn_SHELX_HKL','spinFrameSetByFILTER','isMagCIF','isSpinCIF','haveSpinReferences','haveMagneticMoments','spinOnly','haveGlobalDummy','isLoop'],'B',['newAtomSetLabel'],'C',['lastAltLoc','firstChar'],'I',['configurationPtr','conformationIndex','nMolecular','nAtoms','ac','nAtoms0','titleAtomSet','maxOps','nops','maxSerial','firstAtom'],'S',['pdbID','thisDataSetName','lastDataSetName','chemicalName','thisStructuralFormula','thisFormula','molecularType','appendedData','auditBlockCode','lastSpaceGroupName','spinFrame','structureId','disorderAssembly','lastDisorderAssembly','key','key0'],'O',['subParser','org.jmol.adapter.readers.cif.CifReader.Parser','modr','org.jmol.adapter.readers.cif.MSCifParser','cifParser','javajs.api.GenericCifDataParser','htAudit','java.util.Hashtable','symops','javajs.util.Lst','+lstSpinLattices','mapSpinIdToUVW','java.util.Map','+htGroup1','+spinFrameExt','+modelMap','+htCellTypes','+htOxStates','bondTypes','javajs.util.Lst','+lattvecs','+magCenterings','htJmolNames','java.util.Map','atomRadius','double[]','bsConnected','javajs.util.BS[]','+bsSets','ptOffset','javajs.util.P3d','bsMolecule','javajs.util.BS','+bsExclude','atoms','org.jmol.adapter.smarter.Atom[]','bsBondDuplicates','javajs.util.BS','field','java.lang.Object','col2key','int[]','+key2col']]
,['O',['TransformFields','String[]','+atomTypeFields','+jmolAtomFields','+atomFields','+citationFields','+symmetryOperationsFields','+geomBondFields']]]

Clazz.newMeth(C$, 'resetGlobalsForNewData$',  function () {
this.isAFLOW=false;
this.pdbID=null;
System.out.println$S("sgName is " + this.sgName);
this.latticeType=null;
this.iHaveUnitCell=this.ignoreFileUnitCell;
this.iHaveSymmetryOperators=false;
this.nops=0;
this.isSpinCIF=this.isMagCIF=false;
this.haveMagneticMoments=false;
this.isMagCIF=this.isSpinCIF=false;
this.haveSpinReferences=this.haveMagneticMoments=false;
this.lstSpinLattices=null;
this.mapSpinIdToUVW=null;
if (!this.spinFrameSetByFILTER) this.spinFrame=null;
this.spinFrameExt=null;
});

Clazz.newMeth(C$, 'initializeReader$',  function () {
this.initSubclass$();
this.stopOn_SHELX_HKL=this.checkFilterKey$S("STOPONSHELXHKL");
this.allowPDBFilter=true;
this.appendedData=this.htParams.get$O("appendedData");
this.spinOnly=this.checkFilterKey$S("SPINONLY");
this.noLattice=this.checkFilterKey$S("NOLATTICE");
var conf=this.getFilter$S("CONF ");
if (conf != null ) this.configurationPtr=this.parseIntStr$S(conf);
if (this.filterCased != null  && this.filterCased.toLowerCase$().startsWith$S("spinframe=") ) {
this.spinFrame=this.filterCased.substring$I(10).trim$();
var pt=this.spinFrame.indexOf$S(";");
if (pt >= 0) this.spinFrame=this.spinFrame.substring$I$I(0, pt);
this.spinFrameSetByFILTER=true;
}this.isMolecular=this.checkFilterKey$S("MOLECUL") && !this.checkFilterKey$S("BIOMOLECULE") ;
this.ignoreGeomBonds=this.checkFilterKey$S("IGNOREGEOMBOND") || this.checkFilterKey$S("IGNOREBOND") ;
this.isPrimitive=this.checkFilterKey$S("PRIMITIVE");
this.readIdeal=!this.checkFilterKey$S("NOIDEAL");
this.allowWyckoff=!this.checkFilterKey$S("NOWYCKOFF");
this.filterAssembly=this.checkFilterKey$S("$");
this.useAuthorChainID=!this.checkFilterKey$S("NOAUTHORCHAINS");
if (this.isMolecular) {
this.forceSymmetry$Z(false);
this.molecularType="filter \"MOLECULAR\"";
}this.checkNearAtoms=!this.checkFilterKey$S("NOSPECIAL");
this.allowRotations=!this.checkFilterKey$S("NOSYM");
if (this.binaryDoc != null ) return;
p$1.readCifData.apply(this, []);
this.continuing=false;
});

Clazz.newMeth(C$, 'initSubclass$',  function () {
});

Clazz.newMeth(C$, 'readCifData',  function () {
this.cifParser=this.getCifDataParser$();
this.line="";
this.cifParser.peekToken$();
this.addAtomLabelNumbers=(this.cifParser.getFileHeader$().startsWith$S("# primitive CIF file created by Jmol"));
while (p$1.continueWith$S.apply(this, [this.key=this.cifParser.peekToken$()]) && p$1.readEntryOrLoopData.apply(this, []) ){
}
if (this.appendedData != null ) {
this.cifParser=(this.getInterface$S("javajs.util.CifDataParser")).set$javajs_api_GenericLineReader$java_io_BufferedReader$Z(null, $I$(3).getBR$S(this.appendedData), this.debugging);
while ((this.key=this.cifParser.peekToken$()) != null )if (!p$1.readEntryOrLoopData.apply(this, [])) break;

}}, p$1);

Clazz.newMeth(C$, 'continueWith$S',  function (key) {
var isHKL=false;
var ret=key != null  && (!this.stopOn_SHELX_HKL || (this.ac == 0 || !key.equals$O("_shelx_hkl_file") ) ) ;
if (ret && isHKL ) System.err.println$S("CIFReader reading _shelx_hkl_file; use FILTER \'StopOnShelxHKL\' to stop reading when this is found");
return ret;
}, p$1);

Clazz.newMeth(C$, 'getCifDataParser$',  function () {
return Clazz.new_($I$(4,1)).set$javajs_api_GenericLineReader$java_io_BufferedReader$Z(this, null, this.debugging);
});

Clazz.newMeth(C$, 'readEntryOrLoopData',  function () {
if (this.key.startsWith$S("data_")) {
return p$1.newData.apply(this, []);
}if (this.skipping && this.key.equals$O("_audit_block_code") ) {
this.iHaveDesiredModel=false;
this.skipping=false;
}this.isLoop=this.isLoopKey$();
if (this.isLoop) {
if (this.skipping && !this.isMMCIF ) {
this.cifParser.getTokenPeeked$();
this.skipLoop$Z(false);
} else {
this.processLoopBlock$();
}return true;
}if (this.key.indexOf$S("_") != 0) {
$I$(5,"warn$S",[this.key.startsWith$S("save_") ? "CIF reader ignoring save_" : "CIF ERROR ? should be an underscore: " + this.key]);
this.cifParser.getTokenPeeked$();
} else if (!p$1.getData.apply(this, [])) {
return true;
}if (!this.skipping) {
this.key=this.cifParser.fixKey$S(this.key0=this.key);
if (this.key.startsWith$S("_chemical_name") || this.key.equals$O("_chem_comp_name") ) {
p$1.processChemicalInfo$S.apply(this, ["name"]);
} else if (this.key.startsWith$S("_chemical_formula_structural")) {
p$1.processChemicalInfo$S.apply(this, ["structuralFormula"]);
} else if (this.key.startsWith$S("_chemical_formula_sum") || this.key.equals$O("_chem_comp_formula") ) {
p$1.processChemicalInfo$S.apply(this, ["formula"]);
} else if (this.key.equals$O("_cell_modulation_dimension")) {
this.modDim=this.parseIntField$();
if (this.modr != null ) this.modr.setModDim$I(this.modDim);
} else if (p$1.skipKey$S.apply(this, [this.key])) {
} else if (this.key.startsWith$S("_cell") && this.key.indexOf$S("_commen_") < 0 ) {
this.processCellParameter$();
} else if (this.key.startsWith$S("_atom_sites_fract_tran")) {
this.processUnitCellTransformMatrix$();
} else if (this.key.startsWith$S("_audit")) {
if (this.key.equals$O("_audit_block_code")) {
p$1.processsAuditBlock.apply(this, []);
} else if (this.key.equals$O("_audit_creation_date")) {
this.symmetry=null;
}} else if (this.key.startsWith$S("_chem_comp_atom") || this.key.startsWith$S("_atom") ) {
this.processLoopBlock$();
} else if (this.key.startsWith$S("_symmetry_space_group_name_h-m") || this.key.equals$O("_space_group_it_number") || this.key.startsWith$S("_symmetry_space_group_name_hall") || this.key.startsWith$S("_space_group_name") || this.key.contains$CharSequence("_ssg_name") || this.key.contains$CharSequence("_name_chen") || this.key.contains$CharSequence("_magn_name") || this.key.contains$CharSequence("_magn_number") || this.key.contains$CharSequence("_bns_name")  ) {
p$1.processSymmetrySpaceGroupName.apply(this, []);
} else if (this.key.startsWith$S("_space_group_transform") || this.key.startsWith$S("_parent_space_group") || this.key.startsWith$S("_space_group_magn_transform") || this.key.contains$CharSequence("_space_group_spin")  ) {
p$1.processUnitCellTransform.apply(this, []);
} else if (this.key.contains$CharSequence("_database_code")) {
p$1.addModelTitle$S.apply(this, ["ID"]);
} else if ("__citation_title__publ_section_title__active_magnetic_irreps_details__".contains$CharSequence("_" + this.key + "__" )) {
p$1.addModelTitle$S.apply(this, ["TITLE"]);
} else if (this.key.startsWith$S("_aflow_")) {
this.isAFLOW=true;
} else if (this.key.equals$O("_symmetry_int_tables_number")) {
var intTableNo=this.parseIntStr$S(this.field);
this.rotateHexCell=(this.isAFLOW && (intTableNo >= 143 && intTableNo <= 194 ) );
} else if (this.key.equals$O("_entry_id")) {
this.pdbID=this.field;
} else if (this.key.startsWith$S("_topol_")) {
p$1.getTopologyParser.apply(this, []).ProcessRecord$S$S(this.key, this.field);
} else if (this.key.equals$O("_structure_id")) {
this.structureId=this.field;
} else {
this.processSubclassEntry$();
}}return true;
}, p$1);

Clazz.newMeth(C$, 'processsAuditBlock',  function () {
this.auditBlockCode=C$.fullTrim$O(this.field).toUpperCase$();
this.appendLoadNote$S(this.auditBlockCode);
if (this.htAudit != null ) {
if (this.auditBlockCode.contains$CharSequence("_MOD_")) {
var key=$I$(6).rep$S$S$S(this.auditBlockCode, "_MOD_", "_REFRNCE_");
if (this.asc.setSymmetryFromAuditBlock$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(this.htAudit.get$O(key)) != null ) {
this.unitCellParams=this.asc.getSymmetry$().getUnitCellParams$();
this.iHaveUnitCell=true;
}}if (this.symops != null ) for (var i=0; i < this.symops.size$(); i++) this.setSymmetryOperator$S(this.symops.get$I(i));

}if (this.lastSpaceGroupName != null ) this.setSpaceGroupName$S(this.lastSpaceGroupName);
}, p$1);

Clazz.newMeth(C$, 'setSymmetryOperator$S',  function (xyz) {
if (this.maxOps >= 0 && this.nops++ > this.maxOps ) return 0;
return C$.superclazz.prototype.setSymmetryOperator$S.apply(this, [xyz]);
});

Clazz.newMeth(C$, 'newData',  function () {
System.out.println$S("newData " + this.key);
this.isLigand=false;
if (this.asc.atomSetCount == 0) this.iHaveDesiredModel=false;
if (this.iHaveDesiredModel) return false;
if (this.desiredModelNumber != -2147483648) this.appendLoadNote$S(null);
this.newModel$I(-1);
this.haveCellWaveVector=false;
if (this.auditBlockCode == null ) this.modulated=false;
if (!this.skipping) {
this.nAtoms0=this.asc.ac;
p$1.processDataParameter.apply(this, []);
this.nAtoms=this.asc.ac;
}return true;
}, p$1);

Clazz.newMeth(C$, 'skipKey$S',  function (key) {
return key.startsWith$S("_shelx_") || key.startsWith$S("_reflns_") || key.startsWith$S("_diffrn_")  ;
}, p$1);

Clazz.newMeth(C$, 'addModelTitle$S',  function (key) {
if (this.asc.atomSetCount > this.titleAtomSet) this.appendLoadNote$S("\nMODEL: " + (this.titleAtomSet=this.asc.atomSetCount));
this.appendLoadNote$S(key + ": " + C$.fullTrim$O(this.field) );
}, p$1);

Clazz.newMeth(C$, 'processSubclassEntry$',  function () {
if (this.modDim > 0) p$1.getModulationReader.apply(this, []).processEntry$();
});

Clazz.newMeth(C$, 'processUnitCellTransform',  function () {
this.field=$I$(6).replaceAllCharacters$S$S$S(this.field, " ", "");
if (this.key.startsWith$S("_space_group_spin_")) {
p$1.processSpinSpaceGroup.apply(this, []);
} else if (this.key.contains$CharSequence("_from_parent") || this.key.contains$CharSequence("child_transform") ) {
p$1.addCellType$S$S$Z.apply(this, ["parent", this.field, true]);
} else if (this.key.contains$CharSequence("_to_standard") || this.key.contains$CharSequence("transform_bns_pp_abc") ) {
p$1.addCellType$S$S$Z.apply(this, ["standard", this.field, false]);
}this.appendLoadNote$S(this.key + ": " + this.field );
}, p$1);

Clazz.newMeth(C$, 'processSpinSpaceGroup',  function () {
var tag=this.key.substring$I(18);
if (tag.indexOf$S("fsg_") >= 0) tag=$I$(6).rep$S$S$S(tag, "fsg_", "");
switch (tag) {
case "collinear_direction":
case "collinear_direction_xyz":
this.isCollinear=true;
break;
case "transform_spinframe_p_abc":
if (this.spinFrameSetByFILTER) {
System.out.println$S("CifReader spinFrame set by user to " + this.spinFrame + " file setting ignored: " + this.field );
this.field=this.spinFrame;
}case "transform_spinframe_p_matrix":
case "spinframe_orientation_cartn":
case "spinframe_orientation_hex":
p$1.addSpinFrameExt$S$Z.apply(this, [tag, false]);
return;
case "rotation_axis_cartn":
this.field=p$1.addSpinFrameExt$S$Z.apply(this, ["axis", false]);
return;
case "rotation_axis_xyz":
this.field=p$1.addSpinFrameExt$S$Z.apply(this, ["axis", true]);
return;
case "rotation_angle":
this.field=p$1.addSpinFrameExt$S$Z.apply(this, ["angle", false]);
return;
case "coplanar_perp_uvw":
break;
case "number_chen":
case "number_chen_liu":
tag="spsg_number";
break;
case "oriented_spin_space_group_name_linear":
case "name_chen":
case "name_chen_liu":
p$1.processSymmetrySpaceGroupName.apply(this, []);
return;
case "g0_number":
tag="spsg_G0";
break;
case "l0_number":
tag="spsg_L0";
break;
case "it":
tag="spsg_it";
break;
case "ik":
tag="spsg_ik";
break;
case "spin_part_point_group":
case "spin_space_point_group_name":
tag="spsg_SPG";
break;
case "transform_to_input_pp":
p$1.addCellType$S$S$Z.apply(this, ["input", "!" + this.field, true]);
tag=null;
break;
case "transform_to_magnetic_primitive_pp":
p$1.addCellType$S$S$Z.apply(this, ["magneticprimitive", "!" + this.field, true]);
tag=null;
break;
case "transform_to_l0std_pp":
p$1.addCellType$S$S$Z.apply(this, ["l0", "!" + this.field, true]);
tag=null;
break;
case "transform_to_g0std_pp":
p$1.addCellType$S$S$Z.apply(this, ["g0", "!" + this.field, true]);
tag=null;
break;
default:
System.err.println$S("CIFReader unrecognized spin key " + this.key + " " + this.field );
return;
}
if (tag != null ) this.addMoreUnitCellInfo$S(tag + "=" + this.field );
}, p$1);

Clazz.newMeth(C$, 'addSpinFrameExt$S$Z',  function (name, doClean) {
var val=this.field.toString();
if (doClean) val=$I$(6).replaceAllCharacters$S$S$S(val, "[]\"", "");
if (this.spinFrameExt == null ) {
this.spinFrameExt=Clazz.new_($I$(7,1));
}this.spinFrameExt.put$O$O(name, val);
return val;
}, p$1);

Clazz.newMeth(C$, 'addCellType$S$S$Z',  function (type, data, isFrom) {
if (this.htCellTypes == null ) this.htCellTypes=Clazz.new_($I$(7,1));
if (data.startsWith$S("!")) {
data=data.substring$I(1);
isFrom=!isFrom;
}var cell=(isFrom ? "!" : "") + data;
this.htCellTypes.put$O$O(type, cell);
if (type.equalsIgnoreCase$S(this.strSupercell)) {
this.strSupercell=cell;
this.htCellTypes.put$O$O("super", (isFrom ? "!" : "") + data);
this.htCellTypes.put$O$O("conventional", (isFrom ? "" : "!") + data);
}}, p$1);

Clazz.newMeth(C$, 'getModulationReader',  function () {
return (this.modr == null  ? p$1.initializeMSCIF.apply(this, []) : this.modr);
}, p$1);

Clazz.newMeth(C$, 'initializeMSCIF',  function () {
if (this.modr == null ) this.ms=this.modr=this.getInterface$S("org.jmol.adapter.readers.cif.MSCifParser");
this.modulated=(this.modr.initialize$org_jmol_adapter_smarter_AtomSetCollectionReader$I(this, this.modDim) > 0);
return this.modr;
}, p$1);

Clazz.newMeth(C$, 'newModel$I',  function (modelNo) {
if (modelNo < 0) {
if (this.modelNumber == 1 && this.asc.ac == 0  && this.nAtoms == 0  && !this.haveGlobalDummy  && !this.skipping ) {
this.modelNumber=0;
this.haveModel=false;
this.haveGlobalDummy=true;
this.asc.removeCurrentAtomSet$();
}modelNo=++this.modelNumber;
}this.skipping=!this.doGetModel$I$S(this.modelNumber=modelNo, null);
if (this.skipping) {
if (!this.isMMCIF) this.cifParser.getTokenPeeked$();
return;
}this.chemicalName="";
this.thisStructuralFormula="";
this.thisFormula="";
this.iHaveDesiredModel=this.isLastModel$I(this.modelNumber);
if (this.isCourseGrained) this.asc.setCurrentModelInfo$S$O("courseGrained", Boolean.TRUE);
if (this.nAtoms0 > 0 && this.nAtoms0 == this.asc.ac ) {
--this.modelNumber;
this.haveModel=false;
this.asc.removeCurrentAtomSet$();
} else if (this.asc.iSet >= 0) {
this.applySymmetryAndSetTrajectory$();
}this.structureId=null;
this.isMolecular=false;
if (this.auditBlockCode == null ) {
this.modDim=0;
}});

Clazz.newMeth(C$, 'finalizeSubclassReader$',  function () {
if (this.htOxStates != null ) p$1.setOxidationStates.apply(this, []);
if (this.htJmolNames != null ) p$1.setJmolNames.apply(this, []);
if (this.asc.iSet > 0 && this.asc.getAtomSetAtomCount$I(this.asc.iSet) == 0 ) --this.asc.atomSetCount;
 else if (!this.finalizeSubclass$()) this.applySymmetryAndSetTrajectory$();
var n=this.asc.atomSetCount;
if (n > 1) this.asc.setCollectionName$S("<collection of " + n + " models>" );
if (this.pdbID != null ) this.asc.setCurrentModelInfo$S$O("pdbID", this.pdbID);
this.finalizeReaderASCR$();
this.addHeader$();
if (this.haveAromatic) this.addJmolScript$S("calculate aromatic");
if (!this.isMMCIF && this.asc.xtalSymmetry != null  ) {
this.asc.xtalSymmetry.setPartProperty$();
}});

Clazz.newMeth(C$, 'setOxidationStates',  function () {
for (var i=this.asc.ac; --i >= 0; ) {
var a=this.asc.atoms[i];
var sym=a.typeSymbol;
var data;
if (sym != null  && (data=this.htOxStates.get$O(sym)) != null  ) {
var charge=data[0];
var radius=data[1];
if (!Double.isNaN$D(charge)) {
a.formalCharge=Long.$ival(Math.round$D(charge));
}if (!Double.isNaN$D(radius)) {
a.bondingRadius=radius;
}}}
}, p$1);

Clazz.newMeth(C$, 'addHeader$',  function () {
var header=this.cifParser.getFileHeader$();
if (header.length$() > 0) {
var s=this.setLoadNote$();
this.appendLoadNote$S(null);
this.appendLoadNote$S(header);
this.appendLoadNote$S(s);
this.setLoadNote$();
this.asc.setInfo$S$O("fileHeader", header);
}});

Clazz.newMeth(C$, 'finalizeSubclass$',  function () {
return (this.subParser == null  ? false : this.subParser.finalizeReader$());
});

Clazz.newMeth(C$, 'doPreSymmetry$Z',  function (doApplySymmetry) {
if (this.mapSpinIdToUVW != null ) {
this.asc.getSymmetry$().mapSpins$java_util_Map(this.mapSpinIdToUVW);
} else if (this.haveSpinReferences) {
this.lstSpinLattices=null;
this.appendLoadNote$S("Warning: CIF FILE contains _space_group_symop_spin_lattice_R.uvw_id but not _space_group_symop_spin_operation_U.uvw!");
}if (this.magCenterings != null  || this.lstSpinLattices != null  ) p$1.addLatticeVectors.apply(this, []);
if (this.modDim > 0) p$1.getModulationReader.apply(this, []).setModulation$Z$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(false, null);
if (this.isMagCIF || this.isSpinCIF ) {
if (!this.haveMagneticMoments) {
this.isMagCIF=this.isSpinCIF=false;
} else {
if (this.isSpinCIF) {
var header=this.cifParser.getFileHeader$();
var pt=header.indexOf$S("version -");
if (pt >= 0) {
this.field=header.substring$I(pt + 9).trim$();
p$1.addSpinFrameExt$S$Z.apply(this, ["version", false]);
}if (this.ignoreCollinearSpinBasisIfGiven && this.isCollinear ) {
this.field="true";
p$1.addSpinFrameExt$S$Z.apply(this, ["ignoreForCollinear", false]);
} else if (this.flagCollinearSpinBasisIfGiven && this.isCollinear ) {
this.field="true";
p$1.addSpinFrameExt$S$Z.apply(this, ["flagForCollinear", false]);
}}if (this.htCellTypes == null ) this.htCellTypes=Clazz.new_($I$(7,1));
this.asc.getXSymmetry$().finalizeMoments$java_util_Map$java_util_Map(this.spinFrameExt, this.htCellTypes);
this.vibsFractional=true;
}}if (this.isSpinCIF) {
var lst=this.asc.getSymmetry$().setSpinList$S(null);
if (lst != null ) {
this.asc.setCurrentModelInfo$S$O("spinList", lst);
this.appendLoadNote$S(lst.size$() + " spin operations -- see _M.spinList" + (doApplySymmetry ? " and atom.spin" : "") );
}}});

Clazz.newMeth(C$, 'applySymmetryAndSetTrajectory$',  function () {
var doCheckBonding=this.doCheckUnitCell && !this.isMMCIF ;
if (this.isMMCIF) {
this.checkNearAtoms=false;
if (this.asc.iSet >= 0) {
var modelIndex=this.asc.iSet;
this.asc.setCurrentModelInfo$S$O("PDB_CONECT_firstAtom_count_max", Clazz.array(Integer.TYPE, -1, [this.asc.getAtomSetAtomIndex$I(modelIndex), this.asc.getAtomSetAtomCount$I(modelIndex), this.maxSerial]));
}}if (!this.haveCellWaveVector) this.modDim=0;
if (this.doApplySymmetry && !this.iHaveFractionalCoordinates ) this.fractionalizeCoordinates$Z(true);
if (!this.haveCellWaveVector) {
this.modDim=0;
}if (this.spinOnly) {
var bs=this.asc.getBSAtoms$I(-1);
for (var i=0; i < this.asc.ac; i++) {
var isVib=(this.asc.atoms[i].vib != null  && this.asc.atoms[i].vib.lengthSquared$() > 0  );
if (!isVib) bs.clear$I(i);
}
}this.applySymTrajASCR$();
if (this.htCellTypes != null ) {
for (var e, $e = this.htCellTypes.entrySet$().iterator$(); $e.hasNext$()&&((e=($e.next$())),1);) {
this.asc.setCurrentModelInfo$S$O("unitcell_" + e.getKey$(), e.getValue$());
this.appendLoadNote$S("unitcell_" + e.getKey$() + " = " + e.getValue$() );
}
this.htCellTypes=null;
}if (!this.haveCellWaveVector) {
if (!this.isMolecular) {
this.asc.setBSAtomsForSet$I(-1);
}}if (doCheckBonding && (this.bondTypes.size$() > 0 || this.isMolecular ) ) p$1.setBondingAndMolecules.apply(this, []);
this.asc.setCurrentModelInfo$S$O("fileHasUnitCell", Boolean.TRUE);
this.asc.xtalSymmetry=null;
});

Clazz.newMeth(C$, 'finalizeSubclassSymmetry$Z',  function (haveSymmetry) {
var sym=(haveSymmetry ? this.asc.getXSymmetry$().getBaseSymmetry$() : null);
if (sym != null  && sym.getSpaceGroup$() == null  ) {
if (!this.isBinary && !this.isMMCIF ) this.appendLoadNote$S("Invalid or missing space group operations!");
sym=null;
}if (this.modDim > 0 && sym != null  ) {
p$1.addLatticeVectors.apply(this, []);
this.asc.setTensors$();
p$1.getModulationReader.apply(this, []).setModulation$Z$org_jmol_adapter_smarter_XtalSymmetry_FileSymmetry(true, sym);
this.modr.finalizeModulation$();
}if (sym != null  && this.auditBlockCode != null   && this.auditBlockCode.contains$CharSequence("REFRNCE") ) {
if (this.htAudit == null ) this.htAudit=Clazz.new_($I$(7,1));
this.htAudit.put$O$O(this.auditBlockCode, sym);
}if (this.subParser != null ) this.subParser.finalizeSymmetry$Z(haveSymmetry);
if (sym != null  && (this.isMagCIF || this.isSpinCIF ) ) p$1.finalizeMagneticMoments.apply(this, []);
});

Clazz.newMeth(C$, 'finalizeMagneticMoments',  function () {
if (this.asc.xtalSymmetry == null ) return;
this.asc.setNoAutoBond$();
this.addJmolScript$S("vectors on;vectors 0.15;");
var n=this.asc.xtalSymmetry.setMagneticMoments$Z(false);
this.appendLoadNote$S(n + " magnetic moments - use VECTORS ON/OFF or VECTOR MAX x.x or SELECT VXYZ>0");
}, p$1);

Clazz.newMeth(C$, 'processDataParameter',  function () {
this.bondTypes.clear$();
this.cifParser.getTokenPeeked$();
this.thisDataSetName=(this.key.length$() < 6 ? "" : this.key.substring$I(5));
if (this.thisDataSetName.length$() > 0) this.nextAtomSet$();
if (this.debugging) $I$(5).debug$S(this.key);
this.resetGlobalsForNewData$();
}, p$1);

Clazz.newMeth(C$, 'nextAtomSet$',  function () {
this.newAtomSetLabel=-1;
this.asc.setCurrentModelInfo$S$O("isCIF", Boolean.TRUE);
if (this.asc.iSet >= 0) {
if (this.isMMCIF) {
this.setModelPDB$Z(true);
if (this.pdbID != null ) this.asc.setCurrentModelInfo$S$O("pdbID", this.pdbID);
}this.newAtomSet$();
if (this.isMMCIF) {
this.setModelPDB$Z(true);
if (this.pdbID != null ) this.asc.setCurrentModelInfo$S$O("pdbID", this.pdbID);
}} else {
this.asc.setCollectionName$S(this.thisDataSetName);
}});

Clazz.newMeth(C$, 'newAtomSet$',  function () {
this.asc.newAtomSet$();
});

Clazz.newMeth(C$, 'processChemicalInfo$S',  function (type) {
var field=this.field;
if (type.equals$O("name")) {
this.chemicalName=field=C$.fullTrim$O(field);
this.appendLoadNote$S(this.chemicalName);
if (!field.equals$O("?")) this.asc.setInfo$S$O("modelLoadNote", field);
} else if (type.equals$O("structuralFormula")) {
this.thisStructuralFormula=field=C$.fullTrim$O(field);
} else if (type.equals$O("formula")) {
this.thisFormula=field=C$.fullTrim$O(field);
if (this.thisFormula.length$() > 1) this.appendLoadNote$S(this.thisFormula);
}if (this.debugging) {
$I$(5,"debug$S",[type + " = " + field ]);
}return field;
}, p$1);

Clazz.newMeth(C$, 'processSymmetrySpaceGroupName',  function () {
if (this.key.indexOf$S("_ssg_name") >= 0) {
this.modulated=true;
this.latticeType=(this.field).substring$I$I(0, 1);
} else if (this.modulated) {
return;
}var s=this.cifParser.toUnicode$S(this.field);
if (this.key.indexOf$S("number_bns") >= 0) {
s=(this.lastSpaceGroupName == null  ? "BNS #" + s : this.lastSpaceGroupName + " #" + s );
} else {
s=(this.key.indexOf$S("h-m") > 0 ? "HM:" : this.modulated ? "SSG:" : this.key.indexOf$S("spin") > 0 || this.key.indexOf$S("spsg") > 0  ? "spinSG:" : this.key.indexOf$S("bns") >= 0 ? "BNS:" : this.key.indexOf$S("hall") >= 0 ? "Hall:" : "") + s;
}this.setSpaceGroupName$S(this.lastSpaceGroupName=s);
}, p$1);

Clazz.newMeth(C$, 'addLatticeVectors',  function () {
if (this.lstSpinLattices != null  && !this.noLattice ) {
this.asc.getSymmetry$().addSpinLattice$javajs_util_Lst$java_util_Map(this.lstSpinLattices, this.mapSpinIdToUVW);
}if (this.noLattice) return;
this.lattvecs=null;
if (this.magCenterings != null ) {
this.latticeType="Magnetic";
this.lattvecs=Clazz.new_($I$(1,1));
for (var i=0; i < this.magCenterings.size$(); i++) {
var s=this.magCenterings.get$I(i);
var f=Clazz.array(Double.TYPE, [this.modDim + 4]);
if (s.indexOf$S("x1") >= 0) for (var j=1; j <= this.modDim + 3; j++) s=$I$(6).rep$S$S$S(s, "x" + j, "");

var tokens=$I$(6,"split$S$S",[$I$(6).replaceAllCharacters$S$S$S(s, "xyz+", ""), ","]);
var n=0;
for (var j=0; j < tokens.length; j++) {
s=tokens[j].trim$();
if (s.length$() == 0) continue;
if ((f[j]=$I$(6).parseDoubleFraction$S(s)) != 0 ) ++n;
}
if (n >= 2) this.lattvecs.addLast$O(f);
}
this.magCenterings=null;
} else if (this.latticeType != null  && "ABCFI".indexOf$S(this.latticeType) >= 0 ) {
this.lattvecs=Clazz.new_($I$(1,1));
try {
this.ms.addLatticeVector$javajs_util_Lst$S(this.lattvecs, this.latticeType);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}if (this.lattvecs != null  && this.lattvecs.size$() > 0  && this.asc.getSymmetry$().addMagLatticeVectors$javajs_util_Lst(this.lattvecs) ) {
this.appendLoadNote$S("Note! " + this.lattvecs.size$() + " symmetry operators added for lattice centering " + this.latticeType );
for (var i=0; i < this.lattvecs.size$(); i++) this.appendLoadNote$S($I$(6,"toJSON$S$O",[null, this.lattvecs.get$I(i)]));

}this.latticeType=null;
}, p$1);

Clazz.newMeth(C$, 'processCellParameter$',  function () {
for (var i=6; --i >= 0; ) {
if (this.key.equals$O($I$(8).cellParamNames[i])) {
var p=this.parseDoubleField$();
if (this.rotateHexCell && i == 5  && p == 120  ) p=-1;
this.setUnitCellItem$I$D(i, p);
return;
}}
});

Clazz.newMeth(C$, 'processUnitCellTransformMatrix$',  function () {
var v=this.parseDoubleField$();
if (Double.isNaN$D(v)) return;
for (var i=0; i < C$.TransformFields.length; i++) {
if (this.key.indexOf$S(C$.TransformFields[i]) >= 0) {
this.setUnitCellItem$I$D(6 + i, v);
return;
}}
});

Clazz.newMeth(C$, 'processLoopBlock$',  function () {
if (this.isLoop) {
this.skipLoopKeyword$();
this.key=this.cifParser.peekToken$();
if (this.key == null ) return;
this.key=this.cifParser.fixKey$S(this.key0=this.key);
}if (this.modDim > 0) {
switch (p$1.getModulationReader.apply(this, []).processLoopBlock$()) {
case 0:
break;
case -1:
this.skipLoop$Z(false);
case 1:
return;
}
}var isLigand=false;
if (this.key.startsWith$S("_atom_site") || (isLigand=this.key.startsWith$S("_chem_comp_atom_")) ) {
if (this.processAtomSiteLoopBlock$Z(isLigand)) p$1.setModelInfoForAtoms.apply(this, []);
return;
}if (this.key.startsWith$S("_space_group_symop") || this.key.startsWith$S("_symmetry_equiv_pos") || this.key.startsWith$S("_symmetry_ssg_equiv")  ) {
if (this.ignoreFileSymmetryOperators || this.modDim > 0 && this.key.indexOf$S("ssg") < 0  ) {
$I$(5).warn$S("ignoring file-based symmetry operators");
this.skipLoop$Z(false);
} else {
p$1.processSymmetryOperationsLoopBlock.apply(this, []);
}return;
}if (this.key.startsWith$S("_citation")) {
this.processCitationListBlock$();
return;
}if (this.key.startsWith$S("_atom_type")) {
this.processAtomTypeLoopBlock$();
return;
}if (this.key.startsWith$S("_geom_bond")) {
p$1.processGeomBondLoopBlock.apply(this, []);
return;
}if (this.key.startsWith$S("_jmol")) {
p$1.processJmolBlock.apply(this, []);
return;
}if (this.processSubclassLoopBlock$()) return;
if (this.key.equals$O("_propagation_vector_seq_id")) {
p$1.addMore.apply(this, []);
return;
}this.skipLoop$Z(false);
});

Clazz.newMeth(C$, 'setModelInfoForAtoms',  function () {
if (this.structureId != null ) {
this.asc.setAtomSetName$S(this.structureId);
this.thisDataSetName=this.structureId;
this.asc.setCurrentModelInfo$S$O("structureID", this.structureId);
}if (this.thisDataSetName.equals$O("global")) this.asc.setCollectionName$S(this.thisDataSetName=this.chemicalName);
if (!this.thisDataSetName.equals$O(this.lastDataSetName)) {
this.asc.setAtomSetName$S(this.thisDataSetName);
this.lastDataSetName=this.thisDataSetName;
}this.asc.setCurrentModelInfo$S$O("chemicalName", this.chemicalName);
this.asc.setCurrentModelInfo$S$O("structuralFormula", this.thisStructuralFormula);
this.asc.setCurrentModelInfo$S$O("formula", this.thisFormula);
}, p$1);

Clazz.newMeth(C$, 'processSubclassLoopBlock$',  function () {
if (this.key.startsWith$S("_topol_")) {
return p$1.getTopologyParser.apply(this, []).processBlock$S(this.key);
}return false;
});

Clazz.newMeth(C$, 'getTopologyParser',  function () {
if (this.subParser == null ) {
this.subParser=($I$(9).getInterface$S("org.jmol.adapter.readers.cif.TopoCifParser"));
this.subParser=this.subParser.setReader$org_jmol_adapter_readers_cif_CifReader(this);
}return this.subParser;
}, p$1);

Clazz.newMeth(C$, 'addMore',  function () {
var str;
var n=0;
try {
while ((str=this.cifParser.peekToken$()) != null  && str.charAt$I(0) == "_" ){
this.cifParser.getTokenPeeked$();
++n;
}
var m=0;
var s="";
while ((str=this.cifParser.getNextDataToken$()) != null ){
s+=str + (m % n == 0 ? "=" : " ");
if (++m % n == 0) {
this.addMoreUnitCellInfo$S(s.trim$());
s="";
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'disableField$I',  function (fieldIndex) {
var i=this.key2col[fieldIndex];
if (i != -1) this.col2key[i]=-1;
}, p$1);

Clazz.newMeth(C$, 'processAtomTypeLoopBlock$',  function () {
this.parseLoopParameters$SA(C$.atomTypeFields);
while (this.cifParser.getData$()){
var sym=this.getFieldString$B(0);
if (sym == null ) continue;
var oxno=this.parseDoubleStr$S(this.getFieldString$B(1));
var radius=this.parseDoubleStr$S(this.getFieldString$B(2));
if (Double.isNaN$D(oxno) && Double.isNaN$D(radius) ) continue;
if (this.htOxStates == null ) this.htOxStates=Clazz.new_($I$(7,1));
this.htOxStates.put$O$O(sym, Clazz.array(Double.TYPE, -1, [oxno, radius]));
}
return true;
});

Clazz.newMeth(C$, 'processJmolBlock',  function () {
this.htJmolNames=Clazz.new_($I$(7,1));
this.parseLoopParameters$SA(C$.jmolAtomFields);
while (this.cifParser.getData$()){
var jmolName=this.getFieldString$B(1);
var cifName=this.getFieldString$B(2);
if (jmolName == null  || cifName == null  ) continue;
this.htJmolNames.put$O$O(cifName, jmolName);
}
}, p$1);

Clazz.newMeth(C$, 'setJmolNames',  function () {
for (var i=0, n=this.asc.ac; i < n; i++) {
var a=this.asc.atoms[i];
var name=this.htJmolNames.get$O(a.atomName);
if (name != null ) a.atomName=name;
}
}, p$1);

Clazz.newMeth(C$, 'parseLoopParametersFor$S$SA',  function (key, fieldNames) {
if (fieldNames[0].charAt$I(0) == "*") for (var i=fieldNames.length; --i >= 0; ) if (fieldNames[i].charAt$I(0) == "*") fieldNames[i]=key + fieldNames[i].substring$I(1);

this.parseLoopParameters$SA(fieldNames);
});

Clazz.newMeth(C$, 'fieldProperty$I',  function (col) {
var k=(col < 0 ? -1 : this.col2key[col]);
if (k == -1) return -1;
this.field=this.cifParser.getColumnData$I(col);
return (col >= 0 && this.isFieldValid$()  ? this.col2key[col] : -1);
});

Clazz.newMeth(C$, 'processAtomSiteLoopBlock$Z',  function (isLigand) {
this.isLigand=isLigand;
var pdbModelNo=-1;
var haveCoord=true;
var noPreviousReferences=this.asc.atomSymbolicMap.isEmpty$();
this.parseLoopParametersFor$S$SA("_atom_site", C$.atomFields);
if (this.key2col[55] != -1) {
this.setFractionalCoordinates$Z(false);
} else if (this.key2col[6] != -1 || this.key2col[52] != -1 ) {
this.setFractionalCoordinates$Z(false);
p$1.disableField$I.apply(this, [3]);
p$1.disableField$I.apply(this, [4]);
p$1.disableField$I.apply(this, [5]);
if (this.key2col[16] != -1 && !this.isMMCIF ) {
this.setIsPDB$();
this.isMMCIF=true;
}} else if (this.key2col[3] != -1) {
this.setFractionalCoordinates$Z(true);
p$1.disableField$I.apply(this, [6]);
p$1.disableField$I.apply(this, [7]);
p$1.disableField$I.apply(this, [8]);
} else if (this.key2col[20] != -1 || this.key2col[21] != -1  || this.key2col[63] != -1  || this.key2col[79] != -1 ) {
haveCoord=false;
} else {
this.skipLoop$Z(false);
return false;
}if (this.key2col[76] != -1 || this.key2col[80] != -1 ) {
p$1.disableField$I.apply(this, [67]);
p$1.disableField$I.apply(this, [68]);
p$1.disableField$I.apply(this, [69]);
}var modelField=this.key2col[17];
var siteMult=0;
var atomLabels=(this.isMMCIF ? null : "");
while (this.cifParser.getData$()){
if (modelField >= 0) {
pdbModelNo=this.checkPDBModelField$I$I(modelField, pdbModelNo);
if (pdbModelNo < 0) break;
if (this.skipping) continue;
}var atom=null;
var atomName=null;
if (this.isMMCIF) {
if (haveCoord) {
atom=Clazz.new_($I$(10,1));
} else {
if (this.fieldProperty$I(this.key2col[20]) != -1 || this.fieldProperty$I(this.key2col[21]) != -1  || this.fieldProperty$I(this.key2col[63]) != -1 ) {
if ((atom=this.asc.getAtomFromName$S(this.field)) == null ) continue;
} else {
continue;
}}} else {
var fNewAtomSet=-1;
var f0=-1;
var label=-1;
if ((f0=fNewAtomSet=this.fieldProperty$I(this.key2col[1])) != -1 && (label=1) != -1  || (fNewAtomSet=this.fieldProperty$I(this.key2col[49])) != -1 && (label=49) != -1   || (fNewAtomSet=this.fieldProperty$I(this.key2col[73])) != -1 && (label=73) != -1   || (f0=fNewAtomSet=this.fieldProperty$I(this.key2col[20])) != -1 && (label=20) != -1   || (fNewAtomSet=this.fieldProperty$I(this.key2col[21])) != -1 && (label=21) != -1   || (f0=fNewAtomSet=this.fieldProperty$I(this.key2col[63])) != -1 && (label=63) != -1   || (f0=fNewAtomSet=this.fieldProperty$I(this.key2col[79])) != -1 && (label=79) != -1  ) {
if (f0 != -1 && atomLabels != null  ) {
atom=this.asc.getAtomFromName$S(this.field);
if (this.addAtomLabelNumbers || atom != null  ) {
var key=";" + this.field + ";" ;
if (noPreviousReferences) {
atomLabels+=key;
}if (atomLabels.indexOf$S(key) < 0) {
atomLabels+=key;
} else {
this.field=atomName=(this.field) + (this.asc.ac + 1);
System.err.println$S("CifReader found duplicate atom_site_label! New label is " + this.field);
atom=null;
}}}}var field=this.field;
if (atom == null ) {
atom=Clazz.new_($I$(10,1));
if (fNewAtomSet != -1) {
if (this.asc.iSet < 0 && this.newAtomSetLabel == -1 ) {
this.nextAtomSet$();
this.newAtomSet$();
this.newAtomSetLabel=label;
}this.asc.atomSymbolicMap.put$O$O(field, atom);
}}}var componentId=null;
var id=null;
var authAtom=null;
var authComp=null;
var authSeq=-2147483648;
var authAsym=null;
var wyckoff=null;
var haveAuth=false;
var seqIdOrWyckoffCode=0;
var n=this.cifParser.getColumnCount$();
for (var i=0; i < n; ++i) {
var tok=this.fieldProperty$I(i);
var field=this.field;
switch (tok) {
case -1:
break;
case 70:
id=field;
break;
case 50:
case 0:
var elementSymbol;
if (field.length$() < 2) {
elementSymbol=field;
} else {
var ch1=Character.toLowerCase$C(field.charAt$I(1));
if ($I$(10).isValidSym2$C$C(this.firstChar, ch1)) {
elementSymbol="" + this.firstChar + ch1 ;
} else {
elementSymbol="" + this.firstChar;
if (!this.haveHAtoms && this.firstChar == "H" ) this.haveHAtoms=true;
}}atom.elementSymbol=elementSymbol;
atom.typeSymbol=field;
break;
case 49:
case 1:
case 73:
atom.atomName=(atomName == null  ? field : atomName);
break;
case 2:
haveAuth=true;
authAtom=field;
break;
case 48:
case 72:
atom.group3=field;
break;
case 11:
authComp=field;
haveAuth=true;
break;
case 59:
componentId=field;
break;
case 12:
authAsym=field;
haveAuth=true;
break;
case 71:
atom.sequenceNumber=seqIdOrWyckoffCode=this.parseIntField$();
break;
case 74:
if (this.allowWyckoff) {
wyckoff=field;
}break;
case 13:
haveAuth=true;
authSeq=this.parseIntField$();
break;
case 55:
var x=this.parseDoubleField$();
if (this.readIdeal && !Double.isNaN$D(x) ) atom.x=x;
break;
case 56:
var y=this.parseDoubleField$();
if (this.readIdeal && !Double.isNaN$D(y) ) atom.y=y;
break;
case 57:
var z=this.parseDoubleField$();
if (this.readIdeal && !Double.isNaN$D(z) ) atom.z=z;
break;
case 3:
atom.x=this.parsePrecision$S(field);
break;
case 52:
case 6:
atom.x=this.parseCartesianField$();
break;
case 4:
atom.y=this.parsePrecision$S(field);
break;
case 53:
case 7:
atom.y=this.parseCartesianField$();
break;
case 5:
atom.z=this.parsePrecision$S(field);
break;
case 54:
case 8:
atom.z=this.parseCartesianField$();
break;
case 51:
atom.formalCharge=this.parseIntField$();
break;
case 9:
var doubleOccupancy=this.parseDoubleField$();
if (!Double.isNaN$D(doubleOccupancy)) atom.foccupancy=doubleOccupancy;
break;
case 10:
atom.bfactor=this.parseDoubleField$() * (this.isMMCIF ? 1 : 100.0);
break;
case 14:
atom.insertionCode=this.firstChar;
break;
case 15:
case 60:
atom.altLoc=this.firstChar;
break;
case 58:
this.disorderAssembly=field;
break;
case 19:
if (!this.isMMCIF) {
atom.part=$I$(6).parseInt$S(field);
}atom.altLoc=(atom.part < 0 ? field.charAt$I(1) : this.firstChar);
break;
case 16:
if ("HETATM".equals$O(field)) atom.isHetero=true;
break;
case 18:
if ("dum".equals$O(field)) {
atom.x=NaN;
continue;
}break;
case 75:
case 61:
siteMult=this.parseIntField$();
break;
case 62:
case 47:
if (field.equalsIgnoreCase$S("Uiso")) {
var j=this.key2col[34];
if (j != -1) this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, 7, this.getDoubleColumnData$I(j));
}break;
case 22:
case 23:
case 24:
case 25:
case 26:
case 27:
case 28:
case 29:
case 30:
case 31:
case 32:
case 33:
this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, (this.col2key[i] - 22) % 6, this.parseDoubleField$());
break;
case 35:
case 36:
case 37:
case 38:
case 39:
case 40:
this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, 6, 4);
this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, (this.col2key[i] - 35) % 6, this.parseDoubleField$());
break;
case 41:
case 42:
case 43:
case 44:
case 45:
case 46:
this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, 6, 0);
this.asc.setU$org_jmol_adapter_smarter_Atom$I$D(atom, (this.col2key[i] - 41) % 6, this.parseDoubleField$());
break;
case 64:
case 65:
case 66:
case 67:
case 68:
case 69:
case 76:
case 77:
case 78:
case 80:
case 81:
case 82:
case 84:
case 83:
this.haveMagneticMoments=true;
var pt=atom.vib;
if (pt == null ) atom.vib=pt=Clazz.new_($I$(11,1)).setType$I(-2);
var v=this.parseDoubleField$();
switch (tok) {
case 84:
pt.magMoment=v;
continue;
case 83:
pt.symmform=field;
continue;
case 64:
case 67:
case 76:
case 80:
pt.x=v;
this.appendLoadNote$S("magnetic moment: " + this.line);
break;
case 65:
case 68:
case 77:
case 81:
pt.y=v;
break;
case 66:
case 69:
case 78:
case 82:
pt.z=v;
if (pt.length$() == 0  && this.modDim == 0 ) {
atom.vib=null;
} else {
pt.isFractional=true;
}break;
}
break;
}
}
if (!haveCoord) continue;
if (Double.isNaN$D(atom.x) || Double.isNaN$D(atom.y) || Double.isNaN$D(atom.z)  ) {
$I$(5).warn$S("atom " + atom.atomName + " has invalid/unknown coordinates" );
continue;
}if (siteMult > 0 && wyckoff != null   && wyckoff.length$() > 0 ) seqIdOrWyckoffCode=((siteMult << 16)) | (wyckoff.charCodeAt$I(0));
var strChain=componentId;
if (haveAuth) {
if (authAtom != null ) atom.atomName=authAtom;
if (authComp != null ) atom.group3=authComp;
if (authSeq != -2147483648) atom.sequenceNumber=authSeq;
if (authAsym != null  && this.useAuthorChainID ) strChain=authAsym;
}if (strChain != null ) {
this.setChainID$org_jmol_adapter_smarter_Atom$S(atom, strChain);
}if (this.maxSerial != -2147483648) this.maxSerial=Math.max(this.maxSerial, atom.sequenceNumber);
if (!this.addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S(atom, id, componentId, strChain)) continue;
if ((id != null  || wyckoff != null  ) && seqIdOrWyckoffCode > 0 ) {
atom.seqIdOrWyckoffCode=seqIdOrWyckoffCode | (-2147483648);
}if (this.modDim > 0 && siteMult != 0 ) {
atom.seqIdOrWyckoffCode|=(siteMult << 16);
}}
this.asc.setCurrentModelInfo$S$O("isCIF", Boolean.TRUE);
if (this.isMMCIF) this.setModelPDB$Z(true);
if (this.isMMCIF && this.skipping ) this.skipping=false;
return true;
});

Clazz.newMeth(C$, 'parseCartesianField$',  function () {
return this.parseDoubleField$();
});

Clazz.newMeth(C$, 'addCifAtom$org_jmol_adapter_smarter_Atom$S$S$S',  function (atom, id, componentId, strChain) {
if (atom.elementSymbol == null  && atom.atomName != null  ) atom.getElementSymbol$();
if (!this.filterCIFAtom$org_jmol_adapter_smarter_Atom$S(atom, componentId)) return false;
this.setAtomCoord$org_jmol_adapter_smarter_Atom(atom);
if (this.isMMCIF && !this.processSubclassAtom$org_jmol_adapter_smarter_Atom$S$S(atom, componentId, strChain) ) return false;
if (this.asc.iSet < 0) this.nextAtomSet$();
this.asc.addAtomWithMappedName$org_jmol_adapter_smarter_Atom(atom);
if (id != null ) {
this.asc.atomSymbolicMap.put$O$O(id, atom);
}++this.ac;
return true;
});

Clazz.newMeth(C$, 'checkPDBModelField$I$I',  function (modelField, currentModelNo) {
return 0;
});

Clazz.newMeth(C$, 'processSubclassAtom$org_jmol_adapter_smarter_Atom$S$S',  function (atom, assemblyId, strChain) {
return true;
});

Clazz.newMeth(C$, 'filterCIFAtom$org_jmol_adapter_smarter_Atom$S',  function (atom, componentId) {
if (!this.filterAtom$org_jmol_adapter_smarter_Atom$I(atom, -1)) return false;
if (this.filterAssembly && this.filterReject$S$S$S(this.filter, "$", componentId) ) return false;
if (this.configurationPtr > 0) {
if (!this.disorderAssembly.equals$O(this.lastDisorderAssembly)) {
this.lastDisorderAssembly=this.disorderAssembly;
this.lastAltLoc="\u0000";
this.conformationIndex=this.configurationPtr;
}if (atom.altLoc != "\u0000") {
if (this.conformationIndex >= 0 && atom.altLoc != this.lastAltLoc ) {
this.lastAltLoc=atom.altLoc;
--this.conformationIndex;
}if (this.conformationIndex != 0) {
$I$(5).info$S("ignoring " + atom.atomName);
return false;
}}}return true;
});

Clazz.newMeth(C$, 'processCitationListBlock$',  function () {
this.parseLoopParameters$SA(C$.citationFields);
while (this.cifParser.getData$()){
var title=this.getFieldString$B(0);
if (!this.isNull$S(title)) this.appendLoadNote$S("TITLE: " + this.cifParser.toUnicode$S(title));
}
});

Clazz.newMeth(C$, 'processSymmetryOperationsLoopBlock',  function () {
this.parseLoopParametersFor$S$SA("_space_group_symop", C$.symmetryOperationsFields);
var n;
this.symops=Clazz.new_($I$(1,1));
for (n=C$.symmetryOperationsFields.length; --n >= 0; ) if (this.key2col[n] != -1) break;

if (n < 0) {
$I$(5).warn$S("required _space_group_symop key not found");
this.skipLoop$Z(false);
return;
}n=0;
var isMag=false;
var sxyz=null;
var suvw=null;
var suvwMapped=null;
var suvwId=null;
while (this.cifParser.getData$()){
var ssgop=false;
var oxyz=null;
var ouvw=null;
var nn=this.cifParser.getColumnCount$();
var timeRev=(this.fieldProperty$I(this.key2col[7]) == -1 && this.fieldProperty$I(this.key2col[8]) == -1  && this.fieldProperty$I(this.key2col[6]) == -1  ? 0 : (this.field).equals$O("-1") ? -1 : 1);
if (timeRev != 0) this.isMagCIF=true;
for (var i=0; i < nn; ++i) {
var tok=this.fieldProperty$I(i);
var field=this.field;
switch (tok) {
case 5:
if (field.indexOf$I("~") >= 0) field=$I$(6).rep$S$S$S(field, "~", "");
case 2:
case 3:
this.modulated=true;
ssgop=true;
case 0:
case 4:
case 1:
case 15:
case 16:
case 17:
if (this.allowRotations || timeRev != 0  || ++n == 1 ) if (!this.modulated || ssgop ) {
switch (tok) {
case 1:
case 3:
isMag=this.isMagCIF=true;
timeRev=p$1.getTimeReversal$S.apply(this, [field]);
if (timeRev != 0) field=this.field;
break;
case 15:
this.isSpinCIF=true;
timeRev=p$1.getTimeReversal$S.apply(this, [field]);
if (timeRev != 0) field=this.field;
oxyz=field;
if (ouvw == null ) {
continue;
}case 17:
if (ouvw == null ) {
this.haveSpinReferences=true;
ouvw="u" + field;
}case 16:
if (ouvw == null ) ouvw=field;
if (oxyz == null ) {
continue;
}ouvw=p$1.parseUvwMath$S.apply(this, [ouvw]);
field=oxyz + "(" + ouvw + ")" ;
timeRev=0;
}
if (timeRev != 0) field+="," + (timeRev == 1 ? "m" : "-m");
field=field.replace$C$C(";", " ");
this.symops.addLast$O(field);
this.setSymmetryOperator$S(field);
if (this.modulated && this.modDim == 0  && this.modr != null  ) this.modDim=this.modr.modDim;
}break;
case 18:
suvwId="u" + field;
if (suvwMapped == null ) continue;
field=suvwMapped;
case 19:
suvwMapped=field;
if (suvwId == null ) continue;
if (this.mapSpinIdToUVW == null ) this.mapSpinIdToUVW=Clazz.new_($I$(7,1));
this.mapSpinIdToUVW.put$O$O(suvwId, suvwMapped);
break;
case 9:
case 10:
case 11:
isMag=this.isMagCIF=true;
if (this.magCenterings == null ) this.magCenterings=Clazz.new_($I$(1,1));
this.magCenterings.addLast$O(field);
break;
case 12:
timeRev=p$1.getTimeReversal$S.apply(this, [field]);
sxyz=this.field;
break;
case 14:
field="u" + field;
this.haveSpinReferences=true;
case 13:
suvw=field;
break;
}
}
if (sxyz != null ) {
if (suvw != null ) {
isMag=this.isSpinCIF=true;
if (this.lstSpinLattices == null ) {
this.lstSpinLattices=Clazz.new_($I$(1,1));
}suvw=p$1.parseUvwMath$S.apply(this, [suvw]);
this.lstSpinLattices.addLast$O(sxyz + "(" + suvw + ")" );
suvw=suvwMapped=suvwId=null;
}sxyz=null;
}}
if (this.ms != null  && !isMag ) {
p$1.addLatticeVectors.apply(this, []);
}}, p$1);

Clazz.newMeth(C$, 'parseUvwMath$S',  function (suvw) {
return $I$(12).parseSimpleMath$org_jmol_viewer_Viewer$S(this.vwr, suvw);
}, p$1);

Clazz.newMeth(C$, 'getTimeReversal$S',  function (field) {
var tr=(field.endsWith$S(",+1") || field.endsWith$S(",1")  ? 1 : field.endsWith$S(",-1") ? -1 : 0);
if (tr != 0) this.field=field.substring$I$I(0, field.lastIndexOf$I(","));
return tr;
}, p$1);

Clazz.newMeth(C$, 'getBondOrder$S',  function (field) {
switch ((field.toUpperCase$().charCodeAt$I(0))) {
default:
$I$(5).warn$S("unknown CIF bond order: " + field);
case 0:
case 83:
return 1;
case 68:
return 2;
case 84:
return 3;
case 81:
return 4;
case 65:
this.haveAromatic=true;
return 515;
}
});

Clazz.newMeth(C$, 'processGeomBondLoopBlock',  function () {
var ok=!this.modulated && (this.isMolecular || !this.doApplySymmetry && !this.ignoreGeomBonds && !(this.stateScriptVersionInt >= 130304 && this.stateScriptVersionInt < 140403 )   ) ;
if (ok) {
this.parseLoopParameters$SA(C$.geomBondFields);
ok=this.checkAllFieldsPresent$SA$I$Z(C$.geomBondFields, 2, true);
}if (!ok) {
this.skipLoop$Z(false);
return;
}var bondCount=0;
while (this.cifParser.getData$()){
var name1=this.getFieldString$B(0);
var name2=this.getFieldString$B(1);
var order=this.getBondOrder$S(this.getFieldString$B(3));
var sdist=this.getFieldString$B(2);
var distance=this.parseDoubleStr$S(sdist);
if (distance == 0  || Double.isNaN$D(distance) ) {
if (!this.iHaveFractionalCoordinates) {
var a=p$1.getAtomFromNameCheckCase$S.apply(this, [name1]);
var b=p$1.getAtomFromNameCheckCase$S.apply(this, [name2]);
if (a == null  || b == null  ) {
System.err.println$S("ATOM_SITE atom for name " + (a != null  ? name2 : b != null  ? name1 : name1 + " and " + name2 ) + " not found" );
continue;
}this.asc.addNewBondWithOrder$I$I$I(a.index, b.index, order);
}continue;
}var dx=p$1.getStandardDeviation$S.apply(this, [sdist]);
++bondCount;
this.bondTypes.addLast$O(Clazz.array(java.lang.Object, -1, [name1, name2, Double.valueOf$D(distance), Double.valueOf$D(dx), Integer.valueOf$I(order)]));
}
if (bondCount > 0) {
$I$(5).info$S(bondCount + " bonds read");
if (!this.doApplySymmetry) {
this.isMolecular=true;
this.forceSymmetry$Z(false);
}}}, p$1);

Clazz.newMeth(C$, 'getStandardDeviation$S',  function (sdist) {
var pt=sdist.indexOf$I("(");
if (pt >= 0) {
var data=sdist.toCharArray$();
var sdx=sdist.substring$I$I(pt + 1, data.length - 1);
var n=sdx.length$();
for (var j=pt; --j >= 0; ) {
if (data[j] == "." && --j < 0 ) break;
data[j]=(--n < 0 ? "0" : data[pt + 1 + n ]);
}
var dx=this.parseDoubleStr$S(String.valueOf$CA(data));
if (!Double.isNaN$D(dx)) {
return dx;
}}$I$(5,"info$S",["CifReader error reading uncertainty for " + sdist + " (set to 0.015) on line " + this.line ]);
return 0.015;
}, p$1);

Clazz.newMeth(C$, 'getAtomFromNameCheckCase$S',  function (name) {
var a=this.asc.getAtomFromName$S(name);
if (a == null ) {
if (!this.asc.atomMapAnyCase) {
this.asc.setAtomMapAnyCase$();
}a=this.asc.getAtomFromName$S(name.toUpperCase$());
}return a;
}, p$1);

Clazz.newMeth(C$, 'setBondingAndMolecules',  function () {
this.atoms=this.asc.atoms;
this.firstAtom=this.asc.getLastAtomSetAtomIndex$();
var nat=this.asc.getLastAtomSetAtomCount$();
this.ac=this.firstAtom + nat;
$I$(5,"info$S",["CIF creating molecule for " + nat + " atoms " + (this.bondTypes.size$() > 0 ? " using GEOM_BOND records" : "") ]);
this.bsSets=Clazz.array($I$(13), [nat]);
this.symmetry=this.asc.getSymmetry$();
for (var i=this.firstAtom; i < this.ac; i++) {
var ipt=this.asc.getAtomFromName$S(this.atoms[i].atomName).index - this.firstAtom;
if (ipt < 0) continue;
if (this.bsSets[ipt] == null ) this.bsSets[ipt]=Clazz.new_($I$(13,1));
this.bsSets[ipt].set$I(i - this.firstAtom);
}
if (this.isMolecular) {
this.atomRadius=Clazz.array(Double.TYPE, [this.ac]);
for (var i=this.firstAtom; i < this.ac; i++) {
var elemnoWithIsotope=$I$(8,"getElementNumber$S",[this.atoms[i].getElementSymbol$()]);
this.atoms[i].elementNumber=($s$[0] = elemnoWithIsotope, $s$[0]);
var charge=(this.atoms[i].formalCharge == -2147483648 ? 0 : this.atoms[i].formalCharge);
if (elemnoWithIsotope > 0) this.atomRadius[i]=$I$(8).getBondingRadius$I$I(elemnoWithIsotope, charge);
}
this.bsConnected=Clazz.array($I$(13), [this.ac]);
for (var i=this.firstAtom; i < this.ac; i++) this.bsConnected[i]=Clazz.new_($I$(13,1));

this.bsMolecule=Clazz.new_($I$(13,1));
this.bsExclude=Clazz.new_($I$(13,1));
}var isFirst=true;
this.bsBondDuplicates=Clazz.new_($I$(13,1));
while (p$1.createBonds$Z.apply(this, [isFirst])){
isFirst=false;
}
if (this.isMolecular && this.iHaveFractionalCoordinates && !this.bsMolecule.isEmpty$()  ) {
var bs=this.asc.getBSAtoms$I(this.asc.bsAtoms == null  ? this.firstAtom : 0);
bs.clearBits$I$I(this.firstAtom, this.ac);
bs.or$javajs_util_BS(this.bsMolecule);
bs.andNot$javajs_util_BS(this.bsExclude);
for (var i=this.firstAtom; i < this.ac; i++) {
if (bs.get$I(i)) this.symmetry.toCartesian$javajs_util_T3d$Z(this.atoms[i], true);
 else if (this.debugging) $I$(5).debug$S(this.molecularType + " removing " + i + " " + this.atoms[i].atomName + " " + this.atoms[i] );
}
this.asc.setCurrentModelInfo$S$O("unitCellParams", null);
if (this.nMolecular++ == this.asc.iSet) {
this.asc.clearGlobalBoolean$I(0);
this.asc.clearGlobalBoolean$I(1);
this.asc.clearGlobalBoolean$I(2);
}}if (this.bondTypes.size$() > 0) this.asc.setCurrentModelInfo$S$O("hasBonds", Boolean.TRUE);
this.bondTypes.clear$();
this.atomRadius=null;
this.bsSets=null;
this.bsConnected=null;
this.bsMolecule=null;
this.bsExclude=null;
}, p$1);

Clazz.newMeth(C$, 'fixAtomForBonding$javajs_util_P3d$I',  function (pt, i) {
pt.setT$javajs_util_T3d(this.atoms[i]);
if (this.iHaveFractionalCoordinates) this.symmetry.toCartesian$javajs_util_T3d$Z(pt, true);
}, p$1);

Clazz.newMeth(C$, 'createBonds$Z',  function (doInit) {
var list="";
var haveH=false;
for (var i=this.bondTypes.size$(); --i >= 0; ) {
if (this.bsBondDuplicates.get$I(i)) continue;
var o=this.bondTypes.get$I(i);
var distance=(o[2]).doubleValue$();
var dx=(o[3]).doubleValue$();
var order=(o[4]).intValue$();
var a1=p$1.getAtomFromNameCheckCase$S.apply(this, [o[0]]);
var a2=p$1.getAtomFromNameCheckCase$S.apply(this, [o[1]]);
if (a1 == null  || a2 == null  ) {
System.err.println$S("CifReader checking GEOM_BOND " + o[0] + "-" + o[1] + " found " + a1 + " " + a2 );
continue;
}if (Double.isNaN$D(a1.x) || Double.isNaN$D(a2.x) ) {
System.err.println$S("CifReader checking GEOM_BOND " + o[0] + "-" + o[1] + " found x coord NaN" );
continue;
}var iatom1=a1.index;
var iatom2=a2.index;
if (doInit) {
var key=";" + iatom1 + ";" + iatom2 + ";" + new Double(distance).toString() ;
if (list.indexOf$S(key) >= 0) {
this.bsBondDuplicates.set$I(i);
continue;
}list+=key;
}var bs1=this.bsSets[iatom1 - this.firstAtom];
var bs2=this.bsSets[iatom2 - this.firstAtom];
if (bs1 == null  || bs2 == null  ) continue;
if (this.atoms[iatom1].elementNumber == 1 || this.atoms[iatom2].elementNumber == 1 ) haveH=true;
for (var j=bs1.nextSetBit$I(0); j >= 0; j=bs1.nextSetBit$I(j + 1)) {
for (var k=bs2.nextSetBit$I(0); k >= 0; k=bs2.nextSetBit$I(k + 1)) {
if ((!this.isMolecular || !this.bsConnected[j + this.firstAtom].get$I(k) ) && p$1.checkBond$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom$D$D.apply(this, [this.atoms[j + this.firstAtom], this.atoms[k + this.firstAtom], distance, dx]) ) {
p$1.addNewBond$I$I$I.apply(this, [j + this.firstAtom, k + this.firstAtom, order]);
}}
}
}
if (!this.iHaveFractionalCoordinates) return false;
if (this.bondTypes.size$() > 0 && !haveH ) for (var i=this.firstAtom; i < this.ac; i++) if (this.atoms[i].elementNumber == 1) {
var checkAltLoc=(this.atoms[i].altLoc != "\u0000");
for (var k=this.firstAtom; k < this.ac; k++) if (k != i && this.atoms[k].elementNumber != 1  && (!checkAltLoc || this.atoms[k].altLoc == "\u0000"  || this.atoms[k].altLoc == this.atoms[i].altLoc ) ) {
if (!this.bsConnected[i].get$I(k) && p$1.checkBond$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom$D$D.apply(this, [this.atoms[i], this.atoms[k], 1.1, 0]) ) p$1.addNewBond$I$I$I.apply(this, [i, k, 1]);
}
}
if (!this.isMolecular) return false;
if (doInit) for (var i=this.firstAtom; i < this.ac; i++) if (this.atoms[i].atomSite + this.firstAtom == i && !this.bsMolecule.get$I(i) ) p$1.setBs$org_jmol_adapter_smarter_AtomA$I$javajs_util_BSA$javajs_util_BS.apply(this, [this.atoms, i, this.bsConnected, this.bsMolecule]);

var bondTolerance=this.vwr.getDouble$I(570425348);
var bsBranch=Clazz.new_($I$(13,1));
var cart1=Clazz.new_($I$(2,1));
var cart2=Clazz.new_($I$(2,1));
var nFactor=2;
for (var i=this.firstAtom; i < this.ac; i++) if (!this.bsMolecule.get$I(i) && !this.bsExclude.get$I(i) ) for (var j=this.bsMolecule.nextSetBit$I(0); j >= 0; j=this.bsMolecule.nextSetBit$I(j + 1)) if (p$1.checkBondDistance$javajs_util_P3d$javajs_util_P3d$D$D$I$I$I$javajs_util_P3d.apply(this, [this.atoms[j], this.atoms[i], this.atomRadius[i] + this.atomRadius[j] + bondTolerance , 0, nFactor, nFactor, nFactor, this.ptOffset])) {
p$1.setBs$org_jmol_adapter_smarter_AtomA$I$javajs_util_BSA$javajs_util_BS.apply(this, [this.atoms, i, this.bsConnected, bsBranch]);
for (var k=bsBranch.nextSetBit$I(0); k >= 0; k=bsBranch.nextSetBit$I(k + 1)) {
this.atoms[k].add$javajs_util_T3d(this.ptOffset);
p$1.fixAtomForBonding$javajs_util_P3d$I.apply(this, [cart1, k]);
var bs=this.bsSets[this.asc.getAtomIndex$S(this.atoms[k].atomName) - this.firstAtom];
if (bs != null ) for (var ii=bs.nextSetBit$I(0); ii >= 0; ii=bs.nextSetBit$I(ii + 1)) {
if (ii + this.firstAtom == k) continue;
p$1.fixAtomForBonding$javajs_util_P3d$I.apply(this, [cart2, ii + this.firstAtom]);
if (cart2.distance$javajs_util_T3d(cart1) < 0.1 ) {
this.bsExclude.set$I(k);
break;
}}
this.bsMolecule.set$I(k);
}
return true;
}

return false;
}, p$1);

Clazz.newMeth(C$, 'checkBond$org_jmol_adapter_smarter_Atom$org_jmol_adapter_smarter_Atom$D$D',  function (a, b, distance, dx) {
var ret;
if (this.iHaveFractionalCoordinates) {
ret=p$1.checkBondDistance$javajs_util_P3d$javajs_util_P3d$D$D$I$I$I$javajs_util_P3d.apply(this, [a, b, distance, dx, 0, 0, 0, this.ptOffset]);
} else {
var d=a.distance$javajs_util_T3d(b);
ret=(dx > 0  ? Math.abs(d - distance) <= dx  : d <= distance  && d > 0.1  );
}return ret;
}, p$1);

Clazz.newMeth(C$, 'checkBondDistance$javajs_util_P3d$javajs_util_P3d$D$D$I$I$I$javajs_util_P3d',  function (f1, f2, distance, slop, iRange, jRange, kRange, ptOffset) {
var p1=$I$(2).newP$javajs_util_T3d(f1);
this.symmetry.toCartesian$javajs_util_T3d$Z(p1, true);
for (var i=-iRange; i <= iRange; i++) for (var j=-jRange; j <= jRange; j++) for (var k=-kRange; k <= kRange; k++) {
ptOffset.set$D$D$D(f2.x + i, f2.y + j, f2.z + k);
this.symmetry.toCartesian$javajs_util_T3d$Z(ptOffset, true);
var d=p1.distance$javajs_util_T3d(ptOffset);
if (slop > 0  ? Math.abs(d - distance) <= slop  : d <= distance  && d > 0.1  ) {
ptOffset.set$D$D$D(i, j, k);
return true;
}}


return false;
}, p$1);

Clazz.newMeth(C$, 'addNewBond$I$I$I',  function (i, j, order) {
this.asc.addNewBondWithOrder$I$I$I(i, j, order);
if (!this.isMolecular) return;
this.bsConnected[i].set$I(j);
this.bsConnected[j].set$I(i);
}, p$1);

Clazz.newMeth(C$, 'setBs$org_jmol_adapter_smarter_AtomA$I$javajs_util_BSA$javajs_util_BS',  function (atoms, iatom, bsBonds, bs) {
var bsBond=bsBonds[iatom];
bs.set$I(iatom);
for (var i=bsBond.nextSetBit$I(0); i >= 0; i=bsBond.nextSetBit$I(i + 1)) {
if (!bs.get$I(i)) p$1.setBs$org_jmol_adapter_smarter_AtomA$I$javajs_util_BSA$javajs_util_BS.apply(this, [atoms, i, bsBonds, bs]);
}
}, p$1);

Clazz.newMeth(C$, 'checkSubclassSymmetry$',  function () {
return this.doCheckUnitCell;
});

Clazz.newMeth(C$, 'checkAllFieldsPresent$SA$I$Z',  function (keys, lastKey, critical) {
for (var i=(lastKey < 0 ? keys.length : lastKey); --i >= 0; ) if (this.key2col[i] == -1) {
if (critical) $I$(5).warn$S("CIF reader missing property: " + keys[i]);
return false;
}
return true;
});

Clazz.newMeth(C$, 'isNull$S',  function (key) {
return key.equals$O("\u0000");
});

Clazz.newMeth(C$, 'skipLoop$Z',  function (doReport) {
if (this.isLoop) this.cifParser.skipLoop$Z(doReport);
});

Clazz.newMeth(C$, 'fullTrim$O',  function (s) {
var str=s;
var pt0=-1;
var pt1=str.length$();
while (++pt0 < pt1 && $I$(6,"isWhitespace$C",[str.charAt$I(pt0)]) ){
}
while (--pt1 > pt0 && $I$(6,"isWhitespace$C",[str.charAt$I(pt1)]) ){
}
return str.substring$I$I(pt0, pt1 + 1);
}, 1);

Clazz.newMeth(C$, 'isFieldValid$',  function () {
return ((this.field).length$() > 0 && (this.firstChar=(this.field).charAt$I(0)) != "\u0000" );
});

Clazz.newMeth(C$, 'parseIntField$',  function () {
return this.parseIntStr$S(this.field);
});

Clazz.newMeth(C$, 'parseDoubleField$',  function () {
return this.parseDoubleStr$S(this.field);
});

Clazz.newMeth(C$, 'getData',  function () {
this.key=this.cifParser.getTokenPeeked$();
if (!p$1.continueWith$S.apply(this, [this.key])) return false;
if (p$1.skipKey$S.apply(this, [this.key])) {
this.field=this.cifParser.skipNextToken$();
} else {
this.field=this.cifParser.getNextToken$();
}if (this.field == null ) {
$I$(5).warn$S("CIF ERROR ? end of file; data missing: " + this.key);
return false;
}var field=this.field;
return (field.length$() == 0 || field.charAt$I(0) != "\u0000" );
}, p$1);

Clazz.newMeth(C$, 'parseLoopParameters$SA',  function (fieldNames) {
this.cifParser.parseDataBlockParameters$SA$S$S$IA$IA(fieldNames, this.isLoop ? null : this.key0, this.field, this.key2col, this.col2key);
});

Clazz.newMeth(C$, 'getFieldString$B',  function (type) {
var i=this.key2col[type];
return (i <= -1 ? "\u0000" : this.cifParser.getColumnData$I(i));
});

Clazz.newMeth(C$, 'skipLoopKeyword$',  function () {
this.cifParser.getTokenPeeked$();
});

Clazz.newMeth(C$, 'isLoopKey$',  function () {
return this.key.startsWith$S("loop_");
});

Clazz.newMeth(C$, 'getDoubleColumnData$I',  function (i) {
return this.parseDoubleStr$S(this.cifParser.getColumnData$I(i));
});

C$.$static$=function(){C$.$static$=0;
C$.TransformFields=Clazz.array(String, -1, ["x[1][1]", "x[1][2]", "x[1][3]", "r[1]", "x[2][1]", "x[2][2]", "x[2][3]", "r[2]", "x[3][1]", "x[3][2]", "x[3][3]", "r[3]"]);
C$.atomTypeFields=Clazz.array(String, -1, ["_atom_type_symbol", "_atom_type_oxidation_number", "_atom_type_radius_bond"]);
C$.jmolAtomFields=Clazz.array(String, -1, ["_jmol_atom_index", "_jmol_atom_name", "_jmol_atom_site_label"]);
C$.atomFields=Clazz.array(String, -1, ["*_type_symbol", "*_label", "*_auth_atom_id", "*_fract_x", "*_fract_y", "*_fract_z", "*_cartn_x", "*_cartn_y", "*_cartn_z", "*_occupancy", "*_b_iso_or_equiv", "*_auth_comp_id", "*_auth_asym_id", "*_auth_seq_id", "*_pdbx_pdb_ins_code", "*_label_alt_id", "*_group_pdb", "*_pdbx_pdb_model_num", "*_calc_flag", "*_disorder_group", "*_aniso_label", "*_anisotrop_id", "*_aniso_u_11", "*_aniso_u_22", "*_aniso_u_33", "*_aniso_u_12", "*_aniso_u_13", "*_aniso_u_23", "*_anisotrop_u[1][1]", "*_anisotrop_u[2][2]", "*_anisotrop_u[3][3]", "*_anisotrop_u[1][2]", "*_anisotrop_u[1][3]", "*_anisotrop_u[2][3]", "*_u_iso_or_equiv", "*_aniso_b_11", "*_aniso_b_22", "*_aniso_b_33", "*_aniso_b_12", "*_aniso_b_13", "*_aniso_b_23", "*_aniso_beta_11", "*_aniso_beta_22", "*_aniso_beta_33", "*_aniso_beta_12", "*_aniso_beta_13", "*_aniso_beta_23", "*_adp_type", "_chem_comp_atom_comp_id", "_chem_comp_atom_atom_id", "_chem_comp_atom_type_symbol", "_chem_comp_atom_charge", "_chem_comp_atom_model_cartn_x", "_chem_comp_atom_model_cartn_y", "_chem_comp_atom_model_cartn_z", "_chem_comp_atom_pdbx_model_cartn_x_ideal", "_chem_comp_atom_pdbx_model_cartn_y_ideal", "_chem_comp_atom_pdbx_model_cartn_z_ideal", "*_disorder_assembly", "*_label_asym_id", "*_subsystem_code", "*_symmetry_multiplicity", "*_thermal_displace_type", "*_moment_label", "*_moment_crystalaxis_mx", "*_moment_crystalaxis_my", "*_moment_crystalaxis_mz", "*_moment_crystalaxis_x", "*_moment_crystalaxis_y", "*_moment_crystalaxis_z", "*_id", "*_label_seq_id", "*_label_comp_id", "*_label_atom_id", "*_wyckoff_label", "*_site_symmetry_multiplicity", "*_moment_spinaxis_u", "*_moment_spinaxis_v", "*_moment_spinaxis_w", "*_spin_moment_label", "*_spin_moment_axis_u", "*_spin_moment_axis_v", "*_spin_moment_axis_w", "*_spin_moment_symmform_uvw", "*_spin_moment_magnitude", "*_spin_moment_spherical_azimuthal", "*_spin_moment_spherical_polar"]);
C$.citationFields=Clazz.array(String, -1, ["_citation_title"]);
C$.symmetryOperationsFields=Clazz.array(String, -1, ["*_operation_xyz", "*_magn_operation_xyz", "*_ssg_operation_algebraic", "*_magn_ssg_operation_algebraic", "_symmetry_equiv_pos_as_xyz", "_symmetry_ssg_equiv_pos_as_xyz", "*_magn_operation_timereversal", "*_magn_ssg_operation_timereversal", "*_operation_timereversal", "*_magn_centering_xyz", "*_magn_ssg_centering_algebraic", "*_magn_ssg_centering_xyz", "*_spin_lattice_xyzt", "*_spin_lattice_uvw", "*_spin_lattice_uvw_id", "*_spin_operation_xyzt", "*_spin_operation_uvw", "*_spin_operation_uvw_id", "*_spin_upart_id", "*_spin_upart_uvw"]);
C$.geomBondFields=Clazz.array(String, -1, ["_geom_bond_atom_site_label_1", "_geom_bond_atom_site_label_2", "_geom_bond_distance", "_ccdc_geom_bond_type"]);
};
var $s$ = new Int16Array(1);
;
(function(){/*i*/var C$=Clazz.newInterface(P$.CifReader, "Parser", function(){
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-08-07 10:28:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
