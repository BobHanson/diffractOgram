(function(){var P$=Clazz.newPackage("org.jmol.awtjs2d"),I$=[[0,'javajs.util.PT']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Display");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFullScreenDimensions$O$IA',  function (canvas, widthHeight) {
{
widthHeight[0] = canvas.width;
widthHeight[1] = canvas.height;
}
}, 1);

Clazz.newMeth(C$, 'hasFocus$O',  function (canvas) {
{

}
return true;
}, 1);

Clazz.newMeth(C$, 'requestFocusInWindow$O',  function (canvas) {
{

}
}, 1);

Clazz.newMeth(C$, 'renderScreenImage$org_jmol_api_PlatformViewer$O$O',  function (vwr, g, size) {
{

}
}, 1);

Clazz.newMeth(C$, 'prompt$org_jmol_api_PlatformViewer$S$S$SA$Z',  function (vwr, label, data, list, asButtons) {
if (!asButtons) {
{
var s = (data == null ? alert(label) : prompt(label, data));
return "" + s;
}
}if (data != null ) list=$I$(1).split$S$S(data, "|");
var option=(vwr).eval.promptAsync$S$SA(label, list);
if (option != null ) {
if (data == null ) {
for (var i=0; i < list.length; i++) if (list[i].equals$O(data)) return "" + i;

}return option;
}return "null";
}, 1);

Clazz.newMeth(C$, 'convertPointFromScreen$O$javajs_util_P3d',  function (canvas, ptTemp) {
{

}
}, 1);

Clazz.newMeth(C$, 'drawImage$O$O$I$I$I$I$Z',  function (context, canvas, x, y, width, height, isDTI) {
{
var buf8 = canvas.buf8;
var buf32 = canvas.buf32;
var n = canvas.width * canvas.height;
var di = 1;
if (isDTI) { var diw = width % 2;
width = Math.floor(width/2);
di = Math.floor(canvas.width/width);
} var dw = (canvas.width - width || x) * 4;
for (var i = 0, p = 0, j = x * 4; i < n;) { buf8[j++] = (buf32[i] >> 16) & 0xFF;
buf8[j++] = (buf32[i] >> 8) & 0xFF;
buf8[j++] = buf32[i] & 0xFF;
buf8[j++] = 0xFF;
i += di;
if (++p%width==0) { if (diw) { i += 1;
buf8[j] = 0;
buf8[j+1] = 0;
buf8[j+2] = 0;
buf8[j+3] = 0;
} j += dw;
} } context.putImageData(canvas.imgdata,0,0);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:48 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
