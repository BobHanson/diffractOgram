(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ListSelectionModel");
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:48 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
