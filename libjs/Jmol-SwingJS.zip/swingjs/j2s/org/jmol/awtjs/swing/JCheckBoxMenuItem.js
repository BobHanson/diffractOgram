(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JCheckBoxMenuItem", null, 'org.jmol.awtjs.swing.JMenuItem');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$S$I.apply(this,["chk", 2]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:47 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
