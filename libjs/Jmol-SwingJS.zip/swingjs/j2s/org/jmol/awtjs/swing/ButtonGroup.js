(function(){var P$=Clazz.newPackage("org.jmol.awtjs.swing"),I$=[[0,'org.jmol.awtjs.swing.Component']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ButtonGroup");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['count'],'S',['id']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.id=$I$(1).newID$S("bg");
}, 1);

Clazz.newMeth(C$, 'add$org_jmol_api_SC',  function (item) {
++this.count;
(item).htmlName=this.id;
});

Clazz.newMeth(C$, 'getButtonCount$',  function () {
return this.count;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2026-07-29 15:08:47 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
