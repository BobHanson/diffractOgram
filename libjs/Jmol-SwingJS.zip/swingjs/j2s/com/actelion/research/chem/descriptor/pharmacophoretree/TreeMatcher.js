(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode',['com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher','.TreeMatching'],'com.actelion.research.chem.descriptor.pharmacophoretree.TreeUtils','java.util.HashSet','com.actelion.research.chem.descriptor.pharmacophoretree.HungarianAlgorithm',['com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher','.FeatureMatch']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TreeMatcher", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['TreeMatching',9],['FeatureMatch',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['dpMatchMatrix','com.actelion.research.chem.descriptor.pharmacophoretree.TreeMatcher.TreeMatching[][]','queryTree','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','+baseTree','queryNodes','java.util.List','+baseNodes']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (queryTree, baseTree) {
;C$.$init$.apply(this);
this.queryTree=queryTree;
this.baseTree=baseTree;
this.queryNodes=queryTree.getNodes$();
this.baseNodes=baseTree.getNodes$();
this.dpMatchMatrix=Clazz.array($I$(3), [2 * queryTree.getEdges$().size$(), 2 * baseTree.getEdges$().size$()]);
}, 1);

Clazz.newMeth(C$, 'matchSearch$',  function () {
var bestScore=0.0;
var bestMatch=Clazz.new_($I$(3,1));
var splits=this.findInitialSplits$();
for (var split, $split = 0, $$split = splits; $split<$$split.length&&((split=($$split[$split])),1);$split++) {
var index1=split[0];
var cut1=-1;
var index2=(split[1]/2|0);
var cut2=split[1] % 2 == 0 ? -1 : 1;
var sourceTreeEdges1=Clazz.new_($I$(1,1));
var targetTreeEdges1=Clazz.new_($I$(1,1));
var sourceTreeEdgeParents1=Clazz.new_($I$(1,1));
var targetTreeEdgeParents1=Clazz.new_($I$(1,1));
var headNodes1=this.queryTree.initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List(cut1, index1, sourceTreeEdges1, sourceTreeEdgeParents1, targetTreeEdges1, targetTreeEdgeParents1);
var sourceTreeEdges2=Clazz.new_($I$(1,1));
var targetTreeEdges2=Clazz.new_($I$(1,1));
var sourceTreeEdgeParents2=Clazz.new_($I$(1,1));
var targetTreeEdgeParents2=Clazz.new_($I$(1,1));
var headNodes2=this.baseTree.initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List(cut2, index2, sourceTreeEdges2, sourceTreeEdgeParents2, targetTreeEdges2, targetTreeEdgeParents2);
var match1=p$1.extensionMatch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List.apply(this, [headNodes1[0], headNodes2[0], index1, index2, cut1, cut2, sourceTreeEdges1, sourceTreeEdges2, sourceTreeEdgeParents1, sourceTreeEdgeParents2]);
var match2=p$1.extensionMatch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List.apply(this, [headNodes1[1], headNodes2[1], index1, index2, cut1 * -1, cut2 * -1, targetTreeEdges1, targetTreeEdges2, targetTreeEdgeParents1, targetTreeEdgeParents2]);
match1.addMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(match2);
match1.calculate$();
if (match1.sim > bestScore ) {
bestScore=match1.sim;
bestMatch=match1;
}}
bestMatch.calculate$();
return bestMatch;
});

Clazz.newMeth(C$, 'findInitialSplits$',  function () {
var cuts=Clazz.array(Integer.TYPE, -1, [-1, 1]);
var initialSplitScores=Clazz.array(Double.TYPE, [2 * this.queryTree.getEdges$().size$(), 2 * this.baseTree.getEdges$().size$()]);
for (var i=0; i < this.queryTree.getEdges$().size$(); i++) {
var sourceTreeEdges1=Clazz.new_($I$(1,1));
var targetTreeEdges1=Clazz.new_($I$(1,1));
var sourceTreeEdgeParents1=Clazz.new_($I$(1,1));
var targetTreeEdgeParents1=Clazz.new_($I$(1,1));
var headNodes1=this.queryTree.initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List(cuts[0], i, sourceTreeEdges1, sourceTreeEdgeParents1, targetTreeEdges1, targetTreeEdgeParents1);
for (var j=0; j < this.baseTree.getEdges$().size$(); j++) {
for (var cut2, $cut2 = 0, $$cut2 = cuts; $cut2<$$cut2.length&&((cut2=($$cut2[$cut2])),1);$cut2++) {
var sourceTreeEdges2=Clazz.new_($I$(1,1));
var targetTreeEdges2=Clazz.new_($I$(1,1));
var sourceTreeEdgeParents2=Clazz.new_($I$(1,1));
var targetTreeEdgeParents2=Clazz.new_($I$(1,1));
var headNodes2=this.baseTree.initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List(cut2, j, sourceTreeEdges2, sourceTreeEdgeParents2, targetTreeEdges2, targetTreeEdgeParents2);
var nodesQuerySource=this.queryTree.getNodesFromEdges$java_util_List(sourceTreeEdges1);
nodesQuerySource.add$O(Integer.valueOf$I(headNodes1[0]));
var nodesQueryTarget=this.queryTree.getNodesFromEdges$java_util_List(targetTreeEdges1);
nodesQueryTarget.add$O(Integer.valueOf$I(headNodes1[1]));
var nodesBaseSource=this.baseTree.getNodesFromEdges$java_util_List(sourceTreeEdges2);
nodesBaseSource.add$O(Integer.valueOf$I(headNodes2[0]));
var nodesBaseTarget=this.baseTree.getNodesFromEdges$java_util_List(targetTreeEdges2);
nodesBaseTarget.add$O(Integer.valueOf$I(headNodes2[1]));
var index1=i;
var index2=cut2 == -1 ? j * 2 : j * 2 + 1;
initialSplitScores[index1][index2]=p$1.getSplitScore$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection.apply(this, [this.queryTree, this.baseTree, nodesQuerySource, nodesBaseSource, nodesQueryTarget, nodesBaseTarget]);
}
}
}
var bestSplits=Clazz.array(Integer.TYPE, [5, 2]);
var bestScores=Clazz.array(Double.TYPE, [5]);
$I$(4).retrieveHighestValuesFrom2DArray$DAA$DA$IAA(initialSplitScores, bestScores, bestSplits);
return bestSplits;
});

Clazz.newMeth(C$, 'extensionMatch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List',  function (headNode1, headNode2, cutEdge1, cutEdge2, cutDir1, cutDir2, subTreeEdgeIndeces1, subTreeEdgeIndeces2, subTreeEdgeParentIndeces1, subTreeEdgeParentIndeces2) {
var matching;
var index1=cutDir1 == -1 ? cutEdge1 * 2 : cutEdge1 * 2 + 1;
var index2=cutDir2 == -1 ? cutEdge2 * 2 : cutEdge2 * 2 + 1;
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
var nodes2=this.baseTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
if (this.dpMatchMatrix[index1][index2] != null ) matching=this.dpMatchMatrix[index1][index2];
 else {
var matches=p$1.assessMatch$java_util_Collection$java_util_Collection.apply(this, [nodes1, nodes2]);
if (matches != null ) {
matching=Clazz.new_($I$(3,1));
for (var fmatch, $fmatch = matches.iterator$(); $fmatch.hasNext$()&&((fmatch=($fmatch.next$())),1);) matching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(fmatch);

matching.calculate$();
this.dpMatchMatrix[index1][index2]=matching;
} else {
var cuts1=this.queryTree.getExtensionCuts$java_util_List$java_util_List(subTreeEdgeIndeces1, subTreeEdgeParentIndeces1);
var cuts2=this.baseTree.getExtensionCuts$java_util_List$java_util_List(subTreeEdgeIndeces2, subTreeEdgeParentIndeces2);
var scores=Clazz.array(Double.TYPE, [cuts1.size$(), cuts2.size$()]);
for (var i=0; i < cuts1.size$(); i++) {
var cut1=cuts1.get$I(i);
var extensionNodes1=Clazz.new_($I$(5,1));
var sourceNodes1=Clazz.new_($I$(5,1));
this.queryTree.enumerateExtensionCutFast$I$IA$java_util_List$java_util_Set$java_util_Set(headNode1, cut1, subTreeEdgeIndeces1, extensionNodes1, sourceNodes1);
for (var j=0; j < cuts2.size$(); j++) {
var cut2=cuts2.get$I(j);
var extensionNodes2=Clazz.new_($I$(5,1));
var sourceNodes2=Clazz.new_($I$(5,1));
this.baseTree.enumerateExtensionCutFast$I$IA$java_util_List$java_util_Set$java_util_Set(headNode2, cut2, subTreeEdgeIndeces2, extensionNodes2, sourceNodes2);
scores[i][j]=p$1.scoreExtensionMatch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Set$java_util_Set$java_util_Set$java_util_Set.apply(this, [this.queryTree, this.baseTree, extensionNodes1, extensionNodes2, sourceNodes1, sourceNodes2]);
}
}
var bestCuts=Clazz.array(Integer.TYPE, [cuts1.size$() * cuts2.size$(), 2]);
var bestScores=Clazz.array(Double.TYPE, [cuts1.size$() * cuts2.size$()]);
$I$(4).retrieveHighestValuesFrom2DArray$DAA$DA$IAA(scores, bestScores, bestCuts);
var bestScore=-1.7976931348623157E308;
var bestMatching=null;
var counter=0;
for (var cut, $cut = 0, $$cut = bestCuts; $cut<$$cut.length&&((cut=($$cut[$cut])),1);$cut++) {
if (counter > 3) break;
if (cut[0] == -1 || cut[1] == -1 ) continue;
var cut1=cuts1.get$I(cut[0]);
var cut2=cuts2.get$I(cut[1]);
var sourceTreeEdgeIndeces1=Clazz.new_($I$(1,1));
var sourceTreeEdgeParentIndeces1=Clazz.new_($I$(1,1));
var sourceTreeHeadNodes1=Clazz.new_($I$(1,1));
var extensionNodes1=Clazz.new_($I$(5,1));
var cutEdges1=Clazz.new_($I$(1,1));
var cutDirs1=Clazz.new_($I$(1,1));
this.queryTree.enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List(headNode1, cut1, subTreeEdgeIndeces1, subTreeEdgeParentIndeces1, sourceTreeEdgeIndeces1, sourceTreeEdgeParentIndeces1, sourceTreeHeadNodes1, extensionNodes1, cutEdges1, cutDirs1);
var sourceTreeEdgeIndeces2=Clazz.new_($I$(1,1));
var sourceTreeEdgeParentIndeces2=Clazz.new_($I$(1,1));
var sourceTreeHeadNodes2=Clazz.new_($I$(1,1));
var extensionNodes2=Clazz.new_($I$(5,1));
var cutEdges2=Clazz.new_($I$(1,1));
var cutDirs2=Clazz.new_($I$(1,1));
this.baseTree.enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List(headNode2, cut2, subTreeEdgeIndeces2, subTreeEdgeParentIndeces2, sourceTreeEdgeIndeces2, sourceTreeEdgeParentIndeces2, sourceTreeHeadNodes2, extensionNodes2, cutEdges2, cutDirs2);
var extensionMatch=p$1.assessExtensionMatch$java_util_Collection$java_util_Collection.apply(this, [extensionNodes1, extensionNodes2]);
if (extensionMatch == null ) continue;
++counter;
var sourceTreeMatches=Clazz.array($I$(3), [sourceTreeHeadNodes1.size$(), sourceTreeHeadNodes2.size$()]);
var sourceTreeScores=Clazz.array(Double.TYPE, [sourceTreeHeadNodes1.size$(), sourceTreeHeadNodes2.size$()]);
for (var i=0; i < sourceTreeHeadNodes1.size$(); i++) {
for (var j=0; j < sourceTreeHeadNodes2.size$(); j++) {
var m=p$1.extensionMatch$I$I$I$I$I$I$java_util_List$java_util_List$java_util_List$java_util_List.apply(this, [(sourceTreeHeadNodes1.get$I(i)).$c(), (sourceTreeHeadNodes2.get$I(j)).$c(), (cutEdges1.get$I(i)).$c(), (cutEdges2.get$I(j)).$c(), (cutDirs1.get$I(i)).$c(), (cutDirs2.get$I(j)).$c(), sourceTreeEdgeIndeces1.get$I(i), sourceTreeEdgeIndeces2.get$I(j), sourceTreeEdgeParentIndeces1.get$I(i), sourceTreeEdgeParentIndeces2.get$I(j)]);
sourceTreeMatches[i][j]=m;
sourceTreeScores[i][j]=m.sim;
}
}
var assignment=Clazz.array(Integer.TYPE, [0, 0]);
var transpose=false;
if (sourceTreeScores.length > 0 && sourceTreeScores[0].length > 0 ) {
if (sourceTreeScores.length > sourceTreeScores[0].length) {
sourceTreeScores=$I$(6).transpose$DAA(sourceTreeScores);
transpose=true;
}if (sourceTreeScores.length > 0 && sourceTreeScores[0].length > 0 ) ;assignment=$I$(6).hgAlgorithm$DAA$S(sourceTreeScores, "max");
if (transpose) {
sourceTreeScores=$I$(6).transpose$DAA(sourceTreeScores);
for (var a=0; a < assignment.length; a++) {
var pair=assignment[a];
var ele=pair[0];
pair[0]=pair[1];
pair[1]=ele;
}
}}var matchedSourceTrees1=Clazz.new_($I$(5,1));
var matchedSourceTrees2=Clazz.new_($I$(5,1));
var extensionMatching=Clazz.new_($I$(3,1));
extensionMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(extensionMatch);
for (var i=0; i < assignment.length; i++) {
matchedSourceTrees1.add$O(Integer.valueOf$I(assignment[i][0]));
matchedSourceTrees2.add$O(Integer.valueOf$I(assignment[i][1]));
extensionMatching.addMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching(sourceTreeMatches[assignment[i][0]][assignment[i][1]]);
}
for (var i=0; i < sourceTreeHeadNodes1.size$(); i++) {
if (!matchedSourceTrees1.contains$O(Integer.valueOf$I(i))) {
var nullMatch=p$1.getMatch$I$java_util_List$I$java_util_List.apply(this, [(sourceTreeHeadNodes1.get$I(i)).$c(), sourceTreeEdgeIndeces1.get$I(i), -1, Clazz.new_($I$(1,1))]);
extensionMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(nullMatch);
}}
for (var j=0; j < sourceTreeHeadNodes2.size$(); j++) {
if (!matchedSourceTrees2.contains$O(Integer.valueOf$I(j))) {
var nullMatch=p$1.getMatch$I$java_util_List$I$java_util_List.apply(this, [-1, Clazz.new_($I$(1,1)), (sourceTreeHeadNodes2.get$I(j)).$c(), sourceTreeEdgeIndeces2.get$I(j)]);
extensionMatching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(nullMatch);
}}
extensionMatching.calculate$();
var extensionScore=extensionMatching.sim;
if (extensionScore >= bestScore ) {
bestScore=extensionScore;
bestMatching=extensionMatching;
}}
matching=bestMatching;
}}return matching;
}, p$1);

Clazz.newMeth(C$, 'assessMatch$java_util_Collection$java_util_Collection',  function (nodes1, nodes2) {
var matches=null;
var size1=p$1.getSizeOfNodeCollection$java_util_Collection$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree.apply(this, [nodes1, this.queryTree]);
var size2=p$1.getSizeOfNodeCollection$java_util_Collection$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree.apply(this, [nodes2, this.baseTree]);
var balanced=p$1.isMatchBalanced$D$D.apply(this, [size1, size2]);
if ((size1 < 3.0  || size2 < 3.0  ) || (nodes1.size$() < 2 || nodes2.size$() < 2 ) ) {
if (balanced) {
matches=Clazz.new_($I$(1,1));
matches.add$O(p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [nodes1, nodes2]));
} else {
matches=Clazz.new_($I$(1,1));
matches.add$O(p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [nodes1, Clazz.new_($I$(1,1))]));
matches.add$O(p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [Clazz.new_($I$(1,1)), nodes2]));
}}return matches;
}, p$1);

Clazz.newMeth(C$, 'assessExtensionMatch$java_util_Collection$java_util_Collection',  function (nodes1, nodes2) {
var match=null;
var size1=p$1.getSizeOfNodeCollection$java_util_Collection$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree.apply(this, [nodes1, this.queryTree]);
var size2=p$1.getSizeOfNodeCollection$java_util_Collection$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree.apply(this, [nodes2, this.baseTree]);
if (nodes1.size$() != 0 && nodes2.size$() != 0 ) {
if ((size1 < 3.0  || size2 < 3.0  ) || (nodes1.size$() < 2 || nodes2.size$() < 2 ) ) {
match=p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [nodes1, nodes2]);
}}return match;
}, p$1);

Clazz.newMeth(C$, 'getMatch$I$java_util_List$I$java_util_List',  function (headNode1, subTreeEdgeIndeces1, headNode2, subTreeEdgeIndeces2) {
var m=null;
var match=Clazz.array(Integer.TYPE, [2, null]);
if (headNode1 == -1) {
var nodes2=this.baseTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
match[0]=Clazz.array(Integer.TYPE, [0]);
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda1$||(P$.TreeMatcher$lambda1$=(((P$.TreeMatcher$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda1.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.baseNodes);
} else if (headNode2 == -1) {
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
match[1]=Clazz.array(Integer.TYPE, [0]);
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda2$||(P$.TreeMatcher$lambda2$=(((P$.TreeMatcher$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda2.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.baseNodes);
} else {
var nodes1=this.queryTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces1);
nodes1.add$O(Integer.valueOf$I(headNode1));
var nodes2=this.baseTree.getNodesFromEdges$java_util_List(subTreeEdgeIndeces2);
nodes2.add$O(Integer.valueOf$I(headNode2));
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda3$||(P$.TreeMatcher$lambda3$=(((P$.TreeMatcher$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda3.$init$,[this, null])))))).toArray$();
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda4$||(P$.TreeMatcher$lambda4$=(((P$.TreeMatcher$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda4.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.baseNodes);
}return m;
}, p$1);

Clazz.newMeth(C$, 'getMatch$java_util_Collection$java_util_Collection',  function (nodes1, nodes2) {
var m=null;
var match=Clazz.array(Integer.TYPE, [2, null]);
match[0]=nodes1.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda5$||(P$.TreeMatcher$lambda5$=(((P$.TreeMatcher$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda5.$init$,[this, null])))))).toArray$();
match[1]=nodes2.stream$().mapToInt$java_util_function_ToIntFunction((P$.TreeMatcher$lambda6$||(P$.TreeMatcher$lambda6$=(((P$.TreeMatcher$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "TreeMatcher$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$Integer','applyAsInt$O'],  function (x) { return (x);});
})()
), Clazz.new_(P$.TreeMatcher$lambda6.$init$,[this, null])))))).toArray$();
m=Clazz.new_($I$(7,1).c$$IAA,[match]);
m.calculate$java_util_List$java_util_List(this.queryNodes, this.baseNodes);
return m;
}, p$1);

Clazz.newMeth(C$, 'scoreExtensionMatch$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Set$java_util_Set$java_util_Set$java_util_Set',  function (pTree1, pTree2, extensionNodes1, extensionNodes2, sourceNodes1, sourceNodes2) {
var extensionScore=$I$(2).getSimilarity$java_util_Collection$java_util_Collection$java_util_List$java_util_List(extensionNodes1, extensionNodes2, this.queryNodes, this.baseNodes);
var sourceScore=$I$(2).getSimilarity$java_util_Collection$java_util_Collection$java_util_List$java_util_List(sourceNodes1, sourceNodes2, this.queryNodes, this.baseNodes);
return 0.8 * extensionScore + (0.19999999999999996) * sourceScore;
}, p$1);

Clazz.newMeth(C$, 'isMatchBalanced$D$D',  function (size1, size2) {
var isBalanced=true;
var ratio=size1 / size2;
if (ratio > 2.0  || ratio < 0.5  ) isBalanced=false;
return isBalanced;
}, p$1);

Clazz.newMeth(C$, 'getSizeOfNodeCollection$java_util_Collection$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (nodes, pTree) {
var size=0;
var n=pTree.getNodes$java_util_Collection(nodes);
for (var node, $node = n.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) size+=node.getSize$();

return size;
}, p$1);

Clazz.newMeth(C$, 'getCutBalance$java_util_Collection$java_util_Collection',  function (nodes1, nodes2) {
var bal=1.0;
var abs=Math.abs(nodes1.size$() - nodes2.size$());
if (abs > 2) bal=1.0 - ((abs - 2.0) / (nodes1.size$() + nodes2.size$() - 2.0));
return bal;
}, p$1);

Clazz.newMeth(C$, 'getSplitScore$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree$java_util_Collection$java_util_Collection$java_util_Collection$java_util_Collection',  function (pTree1, pTree2, a1, b1, a2, b2) {
var score=0.0;
var na1=a1.size$();
var na2=a2.size$();
var nb1=b1.size$();
var nb2=b2.size$();
var balance=0.0;
if (na1 + na2 < nb1 + nb2) balance=p$1.getCutBalance$java_util_Collection$java_util_Collection.apply(this, [a1, a2]);
 else if (na1 + na2 == nb1 + nb2) balance=0.5 * p$1.getCutBalance$java_util_Collection$java_util_Collection.apply(this, [a1, a2]) + 0.5 * p$1.getCutBalance$java_util_Collection$java_util_Collection.apply(this, [b1, b2]);
 else balance=p$1.getCutBalance$java_util_Collection$java_util_Collection.apply(this, [b1, b2]);
var match1=p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [a1, b1]);
var match2=p$1.getMatch$java_util_Collection$java_util_Collection.apply(this, [a2, b2]);
var matching=Clazz.new_($I$(3,1));
matching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(match1);
matching.addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch(match2);
matching.calculate$();
score=(0.4) * (matching.sim) + 0.6 * balance;
return score;
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.TreeMatcher, "TreeMatching", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['sim','size1','size2'],'O',['matches','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.matches=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'addFeatureMatch$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_FeatureMatch',  function (match) {
this.matches.add$O(match);
});

Clazz.newMeth(C$, 'addMatching$com_actelion_research_chem_descriptor_pharmacophoretree_TreeMatcher_TreeMatching',  function (matching) {
this.matches.addAll$java_util_Collection(matching.matches);
});

Clazz.newMeth(C$, 'calculate$',  function () {
this.sim=0.0;
this.size1=0.0;
this.size2=0.0;
for (var match, $match = this.matches.iterator$(); $match.hasNext$()&&((match=($match.next$())),1);) {
this.sim+=match.size * match.sim;
this.size1+=match.sizes[0];
this.size2+=match.sizes[1];
}
var nom=0.5 * this.sim;
var denom=((0.5 * Math.max(this.size1, this.size2) + (0.5) * Math.min(this.size1, this.size2)));
this.sim=nom / denom;
});

Clazz.newMeth(C$, 'getMatches$',  function () {
return this.matches;
});

Clazz.newMeth(C$, 'getSim$',  function () {
return this.sim;
});

Clazz.newMeth(C$, 'getSize1$',  function () {
return this.size1;
});

Clazz.newMeth(C$, 'getSize2$',  function () {
return this.size2;
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.TreeMatcher, "FeatureMatch", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.sizes=Clazz.array(Double.TYPE, [2]);
},1);

C$.$fields$=[['D',['sim','size'],'O',['sizes','double[]','match','int[][]']]]

Clazz.newMeth(C$, 'c$$IAA',  function (match) {
;C$.$init$.apply(this);
this.match=match;
}, 1);

Clazz.newMeth(C$, 'calculate$java_util_List$java_util_List',  function (treeNodes1, treeNodes2) {
this.sim=0.0;
this.sizes[0]=0.0;
this.sizes[1]=0.0;
this.size=0.0;
var nodes1=Clazz.new_($I$(1,1));
var nodes2=Clazz.new_($I$(1,1));
if (this.match[0].length != 0) {
for (var node, $node = 0, $$node = this.match[0]; $node<$$node.length&&((node=new Integer($$node[$node])),1);$node++) {
nodes1.add$O(treeNodes1.get$I((node).$c()));
}
}if (this.match[1].length != 0) {
for (var node, $node = 0, $$node = this.match[1]; $node<$$node.length&&((node=new Integer($$node[$node])),1);$node++) {
nodes2.add$O(treeNodes2.get$I((node).$c()));
}
}if (nodes1.size$() == 0 || nodes2.size$() == 0 ) this.sim=0.0;
 else this.sim=$I$(2).getSimilarity$java_util_Collection$java_util_Collection(nodes1, nodes2);
if (nodes1.size$() > 0) {
for (var pn, $pn = nodes1.iterator$(); $pn.hasNext$()&&((pn=($pn.next$())),1);) {
this.sizes[0]+=pn.getSize$();
}
}if (nodes2.size$() > 0) {
for (var pn, $pn = nodes2.iterator$(); $pn.hasNext$()&&((pn=($pn.next$())),1);) {
this.sizes[1]+=pn.getSize$();
}
}this.size=this.sizes[0] + this.sizes[1];
});

Clazz.newMeth(C$, 'getSizes$',  function () {
return this.sizes;
});

Clazz.newMeth(C$, 'getSim$',  function () {
return this.sim;
});

Clazz.newMeth(C$, 'getMatch$',  function () {
return this.match;
});

Clazz.newMeth(C$, 'setSizes$DA',  function (sizes) {
this.sizes=sizes;
this.size=sizes[0] + sizes[1];
});

Clazz.newMeth(C$, 'setSim$D',  function (sim) {
this.sim=sim;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:23 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
