(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DockingFailedException", null, 'Exception');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$S',  function (errorMessage) {
;C$.superclazz.c$$S.apply(this,[errorMessage]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:23 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
