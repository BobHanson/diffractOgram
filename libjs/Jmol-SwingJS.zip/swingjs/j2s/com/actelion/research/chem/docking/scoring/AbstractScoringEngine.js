(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring"),I$=[[0,'com.actelion.research.chem.conf.Conformer','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractScoringEngine");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.BUMP_PENALTY=500;
this.BUMP_RADIUS=3;
},1);

C$.$fields$=[['D',['BUMP_PENALTY'],'I',['BUMP_RADIUS'],'O',['receptorConf','com.actelion.research.chem.conf.Conformer','bindingSiteAtoms','java.util.Set','candidatePose','com.actelion.research.chem.docking.LigandPose','grid','com.actelion.research.chem.io.pdb.converter.MoleculeGrid','constraints','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid',  function (receptor, bindingSiteAtoms, grid) {
;C$.$init$.apply(this);
this.receptorConf=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[receptor]);
this.bindingSiteAtoms=bindingSiteAtoms;
this.grid=grid;
this.constraints=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getCandidatePose$',  function () {
return this.candidatePose;
});

Clazz.newMeth(C$, 'getBumpTerm$',  function () {
var bumpTerm=0.0;
var gridSize=this.grid.getGridSize$();
for (var a=0; a < this.candidatePose.getLigConf$().getMolecule$().getAllAtoms$(); a++) {
var c=this.candidatePose.getLigConf$().getCoordinates$I(a);
var gridC=this.grid.getGridCoordinates$com_actelion_research_chem_Coordinates(c);
var x=gridC[0];
var y=gridC[1];
var z=gridC[2];
if (x < this.BUMP_RADIUS || x > (gridSize[0] - this.BUMP_RADIUS) ) {
bumpTerm=this.BUMP_PENALTY;
break;
} else if (y < this.BUMP_RADIUS || y > (gridSize[1] - this.BUMP_RADIUS) ) {
bumpTerm=this.BUMP_PENALTY;
break;
} else if (z < this.BUMP_RADIUS || z > (gridSize[2] - this.BUMP_RADIUS) ) {
bumpTerm=this.BUMP_PENALTY;
break;
}}
return bumpTerm;
});

Clazz.newMeth(C$, 'addConstraint$com_actelion_research_chem_potentialenergy_PotentialEnergyTerm',  function (constraint) {
this.constraints.add$O(constraint);
});

Clazz.newMeth(C$, 'removeConstraints$',  function () {
this.constraints=Clazz.new_($I$(2,1));
});

Clazz.newMeth(C$, 'getReceptorConf$',  function () {
return this.receptorConf;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:23 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
