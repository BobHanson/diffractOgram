(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StretchBend", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['theta0','kba_ijk','kba_kji','r0i','r0k'],'I',['a1','a2','a3'],'O',['mol','com.actelion.research.chem.forcefield.mmff.MMFFMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (table, mol, a1, a2, a3) {
;C$.$init$.apply(this);
this.mol=mol;
this.a1=a1;
this.a2=a2;
this.a3=a3;
this.theta0=table.angle.theta$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
this.r0i=table.bond.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a1, a2);
this.r0k=table.bond.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a3, a2);
this.kba_ijk=table.stbn.kba$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
this.kba_kji=table.stbn.kba$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a3, a2, a1);
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var dist1=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).length$();
var dist2=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]).length$();
var theta=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).angle$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]));
var factor=143.9325 * 0.017453292519943295 * (Math.toDegrees(theta) - this.theta0) ;
return factor * (dist1 - this.r0i) * this.kba_ijk  + factor * (dist2 - this.r0k) * this.kba_kji ;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var dist1=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).length$();
var dist2=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]).length$();
var p12=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a1]).normalise$();
var p32=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a2, this.a3]).normalise$();
var c5=2.5120960256267386;
var cosTheta=p12.dot$com_actelion_research_chem_forcefield_mmff_Vector3(p32);
var sinThetaSq=1.0 - cosTheta * cosTheta;
var sinTheta=Math.max(sinThetaSq > 0.0  ? Math.sqrt(sinThetaSq) : 0.0, 1.0E-8);
var angleTerm=57.29577951308232 * Math.acos(cosTheta) - this.theta0;
var distTerm=57.29577951308232 * (this.kba_ijk * (dist1 - this.r0i) + this.kba_kji * (dist2 - this.r0k));
var dCos_dS1=1.0 / dist1 * (p32.x - cosTheta * p12.x);
var dCos_dS2=1.0 / dist1 * (p32.y - cosTheta * p12.y);
var dCos_dS3=1.0 / dist1 * (p32.z - cosTheta * p12.z);
var dCos_dS4=1.0 / dist2 * (p12.x - cosTheta * p32.x);
var dCos_dS5=1.0 / dist2 * (p12.y - cosTheta * p32.y);
var dCos_dS6=1.0 / dist2 * (p12.z - cosTheta * p32.z);
grad[3 * this.a1 + 0]+=2.5120960256267386 * (p12.x * this.kba_ijk * angleTerm  + dCos_dS1 / (-sinTheta) * distTerm);
grad[3 * this.a1 + 1]+=2.5120960256267386 * (p12.y * this.kba_ijk * angleTerm  + dCos_dS2 / (-sinTheta) * distTerm);
grad[3 * this.a1 + 2]+=2.5120960256267386 * (p12.z * this.kba_ijk * angleTerm  + dCos_dS3 / (-sinTheta) * distTerm);
grad[3 * this.a2 + 0]+=2.5120960256267386 * ((-p12.x * this.kba_ijk - p32.x * this.kba_kji) * angleTerm + (-dCos_dS1 - dCos_dS4) / (-sinTheta) * distTerm);
grad[3 * this.a2 + 1]+=2.5120960256267386 * ((-p12.y * this.kba_ijk - p32.y * this.kba_kji) * angleTerm + (-dCos_dS2 - dCos_dS5) / (-sinTheta) * distTerm);
grad[3 * this.a2 + 2]+=2.5120960256267386 * ((-p12.z * this.kba_ijk - p32.z * this.kba_kji) * angleTerm + (-dCos_dS3 - dCos_dS6) / (-sinTheta) * distTerm);
grad[3 * this.a3 + 0]+=2.5120960256267386 * (p32.x * this.kba_kji * angleTerm  + dCos_dS4 / (-sinTheta) * distTerm);
grad[3 * this.a3 + 1]+=2.5120960256267386 * (p32.y * this.kba_kji * angleTerm  + dCos_dS5 / (-sinTheta) * distTerm);
grad[3 * this.a3 + 2]+=2.5120960256267386 * (p32.z * this.kba_kji * angleTerm  + dCos_dS6 / (-sinTheta) * distTerm);
});

Clazz.newMeth(C$, 'valid$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (table, mol, a1, a2, a3) {
var a2t=mol.getAtomType$I(a2);
if (table.atom.linear$I(a2t) || a1 == a3 ) return false;
if (mol.getBond$I$I(a1, a2) == -1 || mol.getBond$I$I(a2, a3) == -1 ) return false;
return true;
}, 1);

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (t, mol) {
var stbn=Clazz.new_($I$(2,1));
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var atomt=mol.getAtomType$I(atom);
if (mol.getAllConnAtoms$I(atom) <= 1 && t.atom.linear$I(atomt) ) continue;
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr_i=mol.getConnAtom$I$I(atom, i);
for (var k=0; k < mol.getAllConnAtoms$I(atom); k++) {
var nbr_k=mol.getConnAtom$I$I(atom, k);
if (nbr_i > nbr_k) continue;
if (C$.valid$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(t, mol, nbr_i, atom, nbr_k)) {
var bend=Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I,[t, mol, nbr_i, atom, nbr_k]);
if (Math.abs(bend.kba_ijk) > 1.0E-4  || Math.abs(bend.kba_kji) > 1.0E-4  ) {
stbn.add$O(bend);
}}}
}
}
return stbn;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:24 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
