(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.MolDistHist','java.util.Arrays','StringBuilder','com.actelion.research.util.ArrayUtils','com.actelion.research.chem.descriptor.flexophore.DistHistHelper','com.actelion.research.chem.descriptor.flexophore.generator.SubFlexophoreGenerator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'assemble$com_actelion_research_chem_descriptor_flexophore_MolDistHistA',  function (arr) {
var nNodesSum=0;
var maxNumNodes=0;
for (var mdhFrag, $mdhFrag = 0, $$mdhFrag = arr; $mdhFrag<$$mdhFrag.length&&((mdhFrag=($$mdhFrag[$mdhFrag])),1);$mdhFrag++) {
var nNodes=mdhFrag.getNumPPNodes$();
nNodesSum+=nNodes;
if (nNodes > maxNumNodes) maxNumNodes=nNodes;
}
var mdh=Clazz.new_($I$(1,1).c$$I,[nNodesSum]);
var arrMapIndexNew=Clazz.array(Integer.TYPE, [arr.length, maxNumNodes]);
var indexNew=0;
for (var i=0; i < arr.length; i++) {
var n=arr[i].getNumPPNodes$();
for (var j=0; j < n; j++) {
arrMapIndexNew[i][j]=indexNew;
++indexNew;
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(arr[i].getNode$I(j));
}
}
for (var i=0; i < arr.length; i++) {
var n=arr[i].getNumPPNodes$();
var mdhFrag=arr[i];
for (var j=0; j < n; j++) {
for (var k=j + 1; k < n; k++) {
var arrDistHist=mdhFrag.getDistHist$I$I(j, k);
var index1=arrMapIndexNew[i][j];
var index2=arrMapIndexNew[i][k];
mdh.setDistHist$I$I$BA(index1, index2, arrDistHist);
}
}
}
for (var i=0; i < nNodesSum; i++) {
for (var j=i + 1; j < nNodesSum; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
if (C$.isZero$BA(arrDistHist)) {
$I$(2).fill$BA$B(arrDistHist, 1);
mdh.setDistHist$I$I$BA(i, j, arrDistHist);
}}
}
return mdh;
}, 1);

Clazz.newMeth(C$, 'isZero$BA',  function (b) {
var z=true;
for (var v, $v = 0, $$v = b; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
if (v != 0) {
z=false;
break;
}}
return z;
}, 1);

Clazz.newMeth(C$, 'toStringDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var sb=Clazz.new_($I$(3,1));
var nNodes=mdh.getNumPPNodes$();
for (var i=0; i < nNodes; i++) {
for (var j=i + 1; j < nNodes; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
sb.append$S($I$(4).toString$BA(arrDistHist));
sb.append$S("\n");
}
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'setDistHistToOne$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var nNodes=mdh.getNumPPNodes$();
for (var i=0; i < nNodes; i++) {
for (var j=i + 1; j < nNodes; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
$I$(2).fill$BA$B(arrDistHist, 1);
mdh.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
}, 1);

Clazz.newMeth(C$, 'getMostDistantPairOfNodes$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var n=mdh.getNumPPNodes$();
var maxMedBinIndex=0;
var indexNode1=-1;
var indexNode2=-1;
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
var arr=mdh.getDistHist$I$I(i, j);
var medBinInd=$I$(5).getMedianBin$BA(arr);
if (medBinInd > maxMedBinIndex) {
maxMedBinIndex=medBinInd;
indexNode1=i;
indexNode2=j;
}}
}
var arrIndexNodes=Clazz.array(Integer.TYPE, [2]);
arrIndexNodes[0]=indexNode1;
arrIndexNodes[1]=indexNode2;
var mdhSub=$I$(6).getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndexNodes);
return mdhSub;
}, 1);

Clazz.newMeth(C$, 'getMostDistantPairOfNodesOneHeteroAtom$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var n=mdh.getNumPPNodes$();
var maxMedBinIndex=0;
var indexNode1=-1;
var indexNode2=-1;
var arrHetero=Clazz.array(Boolean.TYPE, [n]);
for (var i=0; i < n; i++) {
arrHetero[i]=mdh.getNode$I(i).containsHetero$();
}
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
if (arrHetero[i] || arrHetero[j] ) {
var arr=mdh.getDistHist$I$I(i, j);
var medBinInd=$I$(5).getMedianBin$BA(arr);
if (medBinInd > maxMedBinIndex) {
maxMedBinIndex=medBinInd;
indexNode1=i;
indexNode2=j;
}}}
}
var arrIndexNodes=Clazz.array(Integer.TYPE, [2]);
arrIndexNodes[0]=indexNode1;
arrIndexNodes[1]=indexNode2;
var mdhSub=$I$(6).getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndexNodes);
return mdhSub;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:21 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
