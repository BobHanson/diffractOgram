(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.SSSearcherWithIndex','com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.AbstractDescriptorHandlerFP']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerFFP512", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerFP');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['I',['sIntCount'],'O',['sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerFFP512']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) C$.sDefaultInstance=Clazz.new_(C$);
}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(2).DESCRIPTOR_FFP512;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return "1.2.1";
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
var descriptor=(s != null  && s.length$() == 128 ) ? $I$(1).getIndexFromHexString$S(s) : C$.superclazz.prototype.decode$S.apply(this, [s]);
return (descriptor != null  && descriptor.length == C$.sIntCount ) ? descriptor : null;
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
var descriptor=(bytes != null  && bytes.length == 128 ) ? $I$(1).getIndexFromHexString$BA(bytes) : C$.superclazz.prototype.decode$BA.apply(this, [bytes]);
return (descriptor != null  && descriptor.length == C$.sIntCount ) ? descriptor : null;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
var descriptor=Clazz.new_($I$(1,1)).createIndex$com_actelion_research_chem_StereoMolecule(mol);
return (descriptor == null ) ? $I$(3).FAILED_OBJECT : descriptor;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});

C$.$static$=function(){C$.$static$=0;
C$.sIntCount=(($I$(1).getNoOfKeys$() + 31)/32|0);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v5');//Created 2023-02-09 07:26:20 Java2ScriptVisitor version 3.3.1-v5 net.sf.j2s.core.jar version 3.3.1-v5
